# ENEMY-ALL-02 actual capture

Initial arena fixtures; normal-speed AI/InputRouter/projectiles. Human visual approval pending.

| Case | Species / chain | Movie process-frame seconds | Accepted enemy hits | Coverage gaps |
| --- | --- | --- | --- | --- |
| 1 | patrol_drone / underworld | 0.02–10.57 | 3 | none recorded |
| 2 | patrol_drone / scene | 10.62–21.18 | 3 | none recorded |
| 3 | plains_charger / underworld | 21.23–32.30 | 3 | none recorded |
| 4 | plains_charger / scene | 32.35–43.42 | 3 | none recorded |
| 5 | plains_diver / underworld | 43.47–54.57 | 3 | none recorded |
| 6 | plains_diver / scene | 54.62–65.68 | 3 | none recorded |
| 7 | plains_hopper / underworld | 65.73–76.25 | 3 | none recorded |
| 8 | plains_hopper / scene | 76.30–86.82 | 3 | none recorded |
| 9 | plains_sentry / underworld | 86.87–97.50 | 3 | none recorded |
| 10 | plains_sentry / scene | 97.55–108.18 | 3 | none recorded |
| 11 | plains_fan_sentry / underworld | 108.23–118.88 | 3 | none recorded |
| 12 | plains_fan_sentry / scene | 118.93–129.58 | 3 | none recorded |
| 13 | plains_root_bell / underworld | 129.63–140.23 | 3 | none recorded |
| 14 | plains_root_bell / scene | 140.28–150.88 | 3 | none recorded |
| 15 | plains_root_bell / root_bell | 150.93–161.53 | 3 | none recorded |
| 16 | forest_bark_beetle / scene | 161.58–181.08 | 3 | none recorded |
| 17 | forest_swing_pod / scene | 181.13–190.13 | 2 | none recorded |
| 18 | forest_lantern / scene | 190.18–199.18 | 2 | none recorded |
| 19 | forest_seed_sentry / scene | 199.23–209.87 | 3 | none recorded |
| 20 | forest_thread_spider / scene | 209.92–218.92 | 2 | none recorded |
| 21 | forest_crossbranch / scene | 218.97–232.90 | 3 | none recorded |
| 22 | forest_bible_weaver / scene | 232.95–245.33 | 2 | none recorded |
| 23 | candidate_lure_guard / scene | 245.38–259.03 | 3 | none recorded |
| 24 | candidate_crosswind_moth / scene | 259.08–269.70 | 3 | none recorded |
