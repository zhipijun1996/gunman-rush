# ENEMY-ALL-02 actual capture

Initial arena fixtures; normal-speed AI/InputRouter/projectiles. Human visual approval pending.

| Case | Species / chain | Movie process-frame seconds | Accepted enemy hits | Coverage gaps |
| --- | --- | --- | --- | --- |
| 1 | clockwork_guardian / actual_boss_scene | 0.02–12.30 | 8 | none recorded |
| 2 | bellstrider / actual_boss_scene | 12.35–29.05 | 16 | none recorded |
| 3 | windkeeper / actual_boss_scene | 29.10–62.77 | 12 | none recorded |
| 4 | windkeeper_storm / actual_boss_scene | 62.82–86.25 | 13 | lethal_HP_commit, terminal_observed_210_frames, player_survived |
| 5 | thorn_guardian / actual_boss_scene | 86.30–104.80 | 10 | none recorded |
| 6 | thorn_queen / actual_boss_scene | 104.85–164.85 | 18 | none recorded |
| 7 | rootbell_guardian_v2 / actual_boss_scene | 164.90–200.10 | 32 | none recorded |
| 8 | thorn_queen_v2 / actual_boss_scene | 200.15–228.73 | 24 | none recorded |
| 9 | thorn_queen_canopy / actual_boss_scene | 228.78–264.35 | 24 | none recorded |
