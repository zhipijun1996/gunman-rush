# 失序之钟 · 怪物工坊

用于审核现有25个怪物条目的真实动作，记录具体动作、录制版本和时间点意见，并保存新怪物创意。每次认可仅针对所选动作与录制，不自动通过整怪品质或改动主游戏。

- `ui/`：中文响应式审片界面，慢放、循环、步进、放大与意见草稿。
- `worker/index.js`：Sites Worker API，使用平台提供的登录身份，D1按所有者保存不可覆盖的意见与提案。
- `data/catalog.json`：当前与历史录片目录；`data/posters`为真实录片帧，缺片与不适用动作明确分列。
- `db/schema.ts`和`drizzle/`： schema-only数据库迁移。已应用迁移不修改；新结构追加迁移。
- `scripts/build.mjs`：校验来源、动作区间与唯一映射，构建自含Worker产物，视频直接流式读取固定GitHub提交中的原MP4。

当前游戏录制源为52d0a0ada2103b64b53ecc09d342dc85387111c3；当前媒体固定在游戏仓库805d849d68a92bd4d116fbee80b70b1aa4ccf885。历史素材保各自原来源与用户拒绝结论。记录基本状态链不代表穷尽每个招式。

## 开发与验证

Node24；`npm ci`后执行`npm test`及`node --test ui/tests/*.test.mjs`。`npm run build`输出`dist/server/index.js`、`dist/.openai/hosting.json`和迁移。平台负责生产身份验证与D1配置；本地测试数据库与生产分开。不要在本地记录或源码中存放发布凭据。

本环境缺少Sites的本地workflow辅助脚本，因此使用提供的WorkerESM结构、自含构建、短期凭据的隐藏stdin Git推送及Sites原生保存/发布工具。保持同一project_id、owner-private与DB逻辑绑定；不自行创建账号认证栈、改变访问范围或通过请求临时创建表。

网页数据仅用于该游戏的内部审核。游戏原素材、音乐与音效保各自原许可，工坊不是第三方素材授权库。未提交草稿仅在本机；收到数据库保存确认后才显示云端保存。意见与新创意不会自动成为正式游戏内容。
