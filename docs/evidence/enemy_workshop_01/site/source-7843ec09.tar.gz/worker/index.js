const DECISIONS = new Set(['needs_work', 'approve_action', 'question']);
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const MAX_BODY = 24576;
class InputError extends Error { constructor(message, status = 400, code = null) { super(message); this.status = status; this.code = code; } }
const json = (body, status = 200, extra = {}) => new Response(JSON.stringify(body), {status, headers: {'content-type':'application/json; charset=utf-8','cache-control':'no-store','x-content-type-options':'nosniff',...extra}});
function text(value, name, max, required = true) {
  if (typeof value !== 'string') throw new InputError(`${name}格式不正确`);
  const result = value.trim();
  if ((required && !result) || result.length > max) throw new InputError(`${name}${required?'不能为空且':''}最多${max}字`);
  return result;
}
async function readBody(request, allowed) {
  if (!request.headers.get('content-type')?.toLowerCase().startsWith('application/json')) throw new InputError('请使用JSON提交',415);
  const origin = request.headers.get('origin');
  if (!origin || origin !== new URL(request.url).origin) throw new InputError('请在工坊页面内提交',403);
  const reader = request.body?.getReader(); let size=0; const chunks=[];
  if (!reader) throw new InputError('提交内容为空');
  try {
    while (true) { const {value,done}=await reader.read(); if(done) break; size+=value.byteLength; if(size>MAX_BODY) {await reader.cancel();throw new InputError('提交内容过长',413);} chunks.push(value); }
  } finally { reader.releaseLock(); }
  const bytes=new Uint8Array(size); let offset=0; for(const chunk of chunks){bytes.set(chunk,offset);offset+=chunk.length;}
  let body; try {body=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(bytes));} catch {throw new InputError('提交内容不是有效JSON');}
  if (!body || Array.isArray(body) || typeof body!=='object' || Object.keys(body).some(k=>!allowed.includes(k))) throw new InputError('提交字段不正确');
  if (typeof body.id!=='string' || !UUID.test(body.id)) throw new InputError('提交标识不正确，请刷新后重试');
  return body;
}
const publicRow = row => {if(!row)return null; const {owner_id,payload_hash,...safe}=row;return safe;};
async function fingerprint(value){const bytes=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(JSON.stringify(value)));return [...new Uint8Array(bytes)].map(n=>n.toString(16).padStart(2,'0')).join('');}
function cursorEncode(row){return btoa(JSON.stringify([row.created_at,row.id])).replaceAll('+','-').replaceAll('/','_').replaceAll('=','');}
function cursorDecode(raw){if(!raw)return null;try{if(raw.length>200||!/^[a-zA-Z0-9_-]+$/.test(raw))throw 0;const v=JSON.parse(atob(raw.replaceAll('-','+').replaceAll('_','/')));if(!Array.isArray(v)||v.length!==2||!/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d{3}Z$/.test(v[0])||!UUID.test(v[1]))throw 0;return v;}catch{throw new InputError('翻页标识已失效，请重新加载');}}
async function listRows(db,table,owner,url){
  const cursor=cursorDecode(url.searchParams.get('cursor'));
  const where=cursor?'owner_id=? AND (created_at<? OR (created_at=? AND id<?))':'owner_id=?';
  const args=cursor?[owner,cursor[0],cursor[0],cursor[1]]:[owner];
  const result=await db.prepare(`SELECT * FROM ${table} WHERE ${where} ORDER BY created_at DESC,id DESC LIMIT 31`).bind(...args).all();
  const rows=result.results??[]; const items=rows.slice(0,30).map(publicRow);
  return json({items,next_cursor:rows.length>30?cursorEncode(rows[29]):null});
}
async function insertImmutable(db,table,row){
  const before=await db.prepare(`SELECT * FROM ${table} WHERE id=? AND owner_id=?`).bind(row.id,row.owner_id).first();
  if(before){if(before.payload_hash!==row.payload_hash)throw new InputError('同一提交标识的内容已变化，请将修改稿作为新意见提交',409,'submission_conflict');return json({item:publicRow(before),replayed:true});}
  const fields=Object.keys(row);
  await db.prepare(`INSERT OR IGNORE INTO ${table} (${fields.join(',')}) VALUES (${fields.map(()=>'?').join(',')})`).bind(...Object.values(row)).run();
  const saved=await db.prepare(`SELECT * FROM ${table} WHERE id=? AND owner_id=?`).bind(row.id,row.owner_id).first();
  if(!saved || saved.payload_hash!==row.payload_hash)throw new InputError('提交标识冲突，请将修改稿作为新意见提交',409,'submission_conflict');
  return json({item:publicRow(saved)},201);
}
export function isRecordedAction(action,variant){
  return !!action && action.status==='recorded' && Number.isFinite(action.start) && Number.isFinite(action.end) && Number.isFinite(variant.in) && Number.isFinite(variant.out) && action.end>action.start && action.start>=variant.in-1/60 && action.end<=variant.out+1/60;
}
export function validateCatalog(catalog){
  if(catalog.schema_version!==1 || !Array.isArray(catalog.monsters) || catalog.monsters.length!==25)throw new Error('Expected exact25 creature catalog');
  const ids=new Set(),variants=new Set(),media=new Map();
  for(const monster of catalog.monsters){
    if(!monster.id||ids.has(monster.id)||!monster.name||!['plains','forest','boss','candidate'].includes(monster.category))throw new Error('Invalid creature identity/category');ids.add(monster.id);
    if(!Array.isArray(monster.variants)||!monster.variants.length||!monster.variants.some(v=>v.is_current))throw new Error('Missing current creature revision: '+monster.id);
    for(const v of monster.variants){
      if(!v.id||variants.has(v.id)||!v.revision||!Array.isArray(v.actions)||!['pending','recorded'].includes(v.capture_status))throw new Error('Invalid/duplicate variant: '+monster.id);variants.add(v.id);
      const actions=new Set();for(const action of v.actions){if(!action.id||actions.has(action.id)||!['recorded','missing','not_applicable'].includes(action.status))throw new Error('Invalid/duplicate action: '+v.id);actions.add(action.id);if(action.status==='recorded'&&!isRecordedAction(action,v))throw new Error('Recorded action outside original chapter: '+v.id+'/'+action.id);}
      if(v.video_url){
        if(v.capture_status!=='recorded'||!Number.isFinite(v.in)||!Number.isFinite(v.out)||!Number.isFinite(v.duration)||v.in<0||v.out<=v.in||v.out>v.duration+1/60)throw new Error('Invalid original movie range: '+v.id);
        if(!/^[0-9a-f]{40}$/.test(v.game_commit)||!/^[0-9a-f]{64}$/.test(v.media_sha256)||!v.media_id||v.video_url!=='/media/'+v.media_id)throw new Error('Missing immutable capture identity: '+v.id);
        const source=new URL(v.source_video_url);if(source.origin!=='https://raw.githubusercontent.com'||!source.pathname.startsWith('/zhipijun1996/gunman-rush/')||!/^[0-9a-f]{40}$/.test(source.pathname.split('/')[3]))throw new Error('Movie source is not immutable: '+v.id);
        const fingerprint=JSON.stringify([v.source_video_url,v.media_sha256,v.duration]);if(media.has(v.media_id)&&media.get(v.media_id)!==fingerprint)throw new Error('Ambiguous media mapping: '+v.media_id);media.set(v.media_id,fingerprint);
      }else if(v.capture_status!=='pending'&&v.actions.some(a=>a.status==='recorded'))throw new Error('Recorded actions require a playable original movie: '+v.id);
    }
  }
  return {monsters:ids.size,variants:variants.size,media:media.size};
}
function reviewInput(body,catalog){
  const monster=catalog.monsters.find(m=>m.id===body.monster_id);
  if(!monster)throw new InputError('这只怪物不在当前工坊目录中');
  const variant=monster.variants.find(v=>v.id===body.clip_id&&v.revision===body.revision);
  if(!variant)throw new InputError('动作版本已更新，请刷新后提交',409,'revision_changed');
  const action=body.action_id==='overall'?null:variant.actions.find(a=>a.id===body.action_id);
  if(body.action_id!=='overall'&&!action)throw new InputError('该版本没有这个动作条目');
  if(!DECISIONS.has(body.decision))throw new InputError('请选择意见类型');
  if(body.decision==='approve_action'&&(!isRecordedAction(action,variant)||!variant.video_url||variant.capture_status==='pending'))throw new InputError('只能认可已录制的具体动作；缺失动作可以提出建议');
  const comment=text(body.comment??'','意见',3000,body.decision!=='approve_action');
  const ms=body.playback_ms??null;
  if(ms!==null && (!Number.isSafeInteger(ms)||!variant.video_url||ms<Math.floor(variant.in*1000)-1||ms>Math.ceil(variant.out*1000)+1))throw new InputError('记录的画面时间超出当前片段');
  return {id:body.id,monster_id:monster.id,monster_name:monster.name,action_id:body.action_id,action_label:action?.label??'整体反馈',revision:variant.revision,clip_id:variant.id,clip_label:variant.label,capture_source_commit:variant.game_commit??'',media_sha256:variant.media_sha256??'',media_url:variant.source_video_url??variant.video_url??'',playback_ms:ms,decision:body.decision,comment};
}
function displayName(request){const raw=request.headers.get('oai-authenticated-user-full-name');if(raw){try{return request.headers.get('oai-authenticated-user-full-name-encoding')==='percent-encoded-utf-8'?decodeURIComponent(raw):raw;}catch{}}
 return request.headers.get('oai-authenticated-user-email')?.split('@')[0]??'导演';}
export function createWorkshop({catalog,assets,fetchMedia=globalThis.fetch}){
  const media=new Map();for(const m of catalog.monsters){for(const v of m.variants){if(v.media_id&&v.source_video_url)media.set(v.media_id,v.source_video_url);}}
  return {async fetch(request,env={}){
    const url=new URL(request.url);const path=url.pathname;
    try {
      if(path.startsWith('/api/')){
        const owner=request.headers.get('oai-authenticated-user-id');
        if(!owner)return json({error:'请先登录后保存审核意见'},401);
        if(request.method==='GET'&&path==='/api/session')return json({user:{id:owner,name:displayName(request)},storage:'cloud'});
        if(request.method==='GET'&&path==='/api/catalog')return json(catalog);
        if(!env.DB)throw new InputError('意见存储暂不可用，请保留草稿后重试',503);
        if(request.method==='GET'&&path==='/api/reviews')return await listRows(env.DB,'monster_reviews',owner,url);
        if(request.method==='GET'&&path==='/api/ideas')return await listRows(env.DB,'monster_ideas',owner,url);
        if(request.method==='POST'&&path==='/api/reviews'){
          const body=await readBody(request,['id','monster_id','action_id','revision','clip_id','playback_ms','decision','comment']);
          const row=reviewInput(body,catalog);const payload_hash=await fingerprint({owner,id:row.id,monster_id:row.monster_id,action_id:row.action_id,revision:row.revision,clip_id:row.clip_id,playback_ms:row.playback_ms,decision:row.decision,comment:row.comment});
          return await insertImmutable(env.DB,'monster_reviews',{...row,owner_id:owner,created_at:new Date().toISOString(),payload_hash});
        }
        if(request.method==='POST'&&path==='/api/ideas'){
          const body=await readBody(request,['id','title','region','details']);
          const row={id:body.id,title:text(body.title,'创意名称',100),region:text(body.region??'','地区',80,false),details:text(body.details,'创意说明',5000),status:'proposed'};
          return await insertImmutable(env.DB,'monster_ideas',{...row,owner_id:owner,created_at:new Date().toISOString(),payload_hash:await fingerprint({owner,...row})});
        }
        if(request.method==='GET'&&path==='/api/export'){
          const reviews=await env.DB.prepare('SELECT * FROM monster_reviews WHERE owner_id=? ORDER BY created_at,id').bind(owner).all();
          const ideas=await env.DB.prepare('SELECT * FROM monster_ideas WHERE owner_id=? ORDER BY created_at,id').bind(owner).all();
          return json({schema_version:1,workshop:'ENEMY-WORKSHOP-01',exported_at:new Date().toISOString(),review_scope:'Specific action, capture revision and time; no automatic whole-monster or game admission approval',reviews:(reviews.results??[]).map(publicRow),ideas:(ideas.results??[]).map(publicRow)},200,{'content-disposition':'attachment; filename="monster-workshop-review.json"'});
        }
        return json({error:'没有这个接口'},404);
      }
      if(path.startsWith('/media/')&&['GET','HEAD'].includes(request.method)){
        const source=media.get(path.slice(7));if(!source)return new Response('没有这段录屏',{status:404});
        const headers=new Headers();const range=request.headers.get('range');if(range){if(!/^bytes=\d*-\d*$/.test(range))return new Response('只支持单段Range',{status:416});headers.set('Range',range);}
        const remote=await fetchMedia(source,{method:request.method,headers,redirect:'follow'});
        if(!remote.ok)return new Response('原始录屏暂时无法载入，请重试',{status:502,headers:{'cache-control':'no-store'}});
        const responseHeaders=new Headers({'content-type':'video/mp4','accept-ranges':'bytes','cache-control':'private, max-age=86400','x-content-type-options':'nosniff'});
        for(const key of ['content-range','content-length','etag','last-modified'])if(remote.headers.has(key))responseHeaders.set(key,remote.headers.get(key));
        return new Response(remote.body,{status:remote.status,headers:responseHeaders});
      }
      if(!['GET','HEAD'].includes(request.method))return new Response('Method not allowed',{status:405});
      const key=path==='/'?'/index.html':path;const asset=assets[key];if(!asset)return new Response('Not found',{status:404});
      const body=asset.base64?Uint8Array.from(atob(asset.body),c=>c.charCodeAt(0)):asset.body;
      return new Response(request.method==='HEAD'?null:body,{headers:{'content-type':asset.type,'cache-control':key==='/index.html'?'no-cache':'private, max-age=300','x-content-type-options':'nosniff','referrer-policy':'same-origin'}});
    }catch(error){
      if(error instanceof InputError)return json({error:error.message,...(error.code?{code:error.code}:{})},error.status);
      console.error('MONSTER_WORKSHOP_REQUEST_FAILED',path,error?.name??'Error');
      return json({error:'暂时无法完成，请保留草稿并重试'},503);
    }
  }};
}
