const $ = id => document.getElementById(id);
const CATEGORY = { plains: '风铃平原', forest: '荆棘森林', boss: '首领', candidate: '候选怪物' };
const DECISION = { needs_work: '需要调整', question: '有个问题', approve_action: '认可此动作' };
const STORAGE = 'enemy-workshop-01:';
const state = { catalog: null, monster: null, variant: null, action: 'overall', region: 'all', search: '', view: 'review', session: null, sessionChecked: false, reviews: [], ideas: [], reviewCursor: null, ideaCursor: null, mineKind: 'reviews', mineLoaded: false, mineLoading: false, mineError: '', draft: null, saving: new Set(), videoReady: false, videoError: false, loop: false, drawerTrigger: null };
let toastTimer;
let zoom = 1, panX = 0, panY = 0, drag = null, suppressVideoClick = false;

export function clampPan(x, y, scale, width, height) {
  const maxX = Math.max(0, width * (scale - 1) / 2), maxY = Math.max(0, height * (scale - 1) / 2);
  return { x: Math.max(-maxX, Math.min(maxX, x)), y: Math.max(-maxY, Math.min(maxY, y)) };
}

function renderZoom() {
  const stage = $('video-stage'); const bounded = clampPan(panX, panY, zoom, stage.clientWidth, stage.clientHeight);
  panX = bounded.x; panY = bounded.y;
  $('video').style.transform = `translate(${panX}px, ${panY}px) scale(${zoom})`;
  stage.classList.toggle('zoomed', zoom > 1);
  for (const button of document.querySelectorAll('[data-zoom]')) button.setAttribute('aria-pressed', String(Number(button.dataset.zoom) === zoom));
  $('zoom-hint').textContent = zoom > 1 ? `${zoom}×查看 · 拖动平移（仅放大原片）` : '原景 · 仅调整查看比例';
}

function resetZoom() { zoom = 1; panX = 0; panY = 0; drag = null; suppressVideoClick = false; renderZoom(); }

export function formatTime(value, decimals = false) {
  if (!Number.isFinite(value)) return '—';
  const seconds = decimals ? Math.round(Math.max(0, value) * 100) / 100 : Math.max(0, value);
  const minutes = Math.floor(seconds / 60);
  return `${String(minutes).padStart(2, '0')}:${decimals ? (seconds % 60).toFixed(2).padStart(5, '0') : String(Math.floor(seconds % 60)).padStart(2, '0')}`;
}

export function preferredVariant(monster) {
  const variants = Array.isArray(monster?.variants) ? monster.variants : [];
  return variants.find(item => item.is_current === true) || variants[0] || null;
}

export function clipRange(variant, duration = Infinity) {
  if (!variant) return null;
  const start = variant.in;
  const end = variant.out;
  if (!Number.isFinite(start) || !Number.isFinite(end) || start < 0 || end <= start) return null;
  const capped = Math.min(end, duration);
  return capped > start ? { start, end: capped } : null;
}

export function actionRange(variant, action, duration = Infinity) {
  const clip = clipRange(variant, duration);
  if (!clip || !action || action.status !== 'recorded' || !Number.isFinite(action.start) || !Number.isFinite(action.end)) return null;
  const start = Math.max(clip.start, action.start);
  const end = Math.min(clip.end, action.end);
  return end > start ? { start, end } : null;
}

export function hasRecording(variant) {
  return Boolean(variant && typeof variant.video_url === 'string' && variant.video_url.trim() && variant.capture_status !== 'pending' && clipRange(variant));
}

export function canApprove(variant, action, duration = Infinity) {
  const clip = clipRange(variant, duration);
  return Boolean(hasRecording(variant) && clip && action?.id !== 'overall' && action?.status === 'recorded' && Number.isFinite(action.start) && Number.isFinite(action.end) && action.end > action.start && action.start >= clip.start - 1 / 60 && action.end <= clip.end + 1 / 60);
}

// Keep the first uncertain request intact for exact replay, including after reload.
export async function sendDraftSubmission(draft, payload, send, persist = () => {}) {
  if (!draft.last_submission) draft.last_submission = { ...payload };
  persist(draft);
  try {
    const data = await send(payload);
    if (!data?.item?.id) throw new Error('服务未返回保存确认，草稿仍然保留。请重试。');
    draft.submission_error = null; persist(draft); return data;
  } catch (error) { draft.submission_error = error.code || 'unconfirmed'; persist(draft); throw error; }
}

export function forkSubmissionDraft(draft, id) {
  if (draft.submission_error !== 'submission_conflict') throw new Error('只有已确认的内容冲突才能明确另存新记录；版本变化请刷新审核版本。');
  return { ...draft, id, last_submission: null, submission_error: null };
}

export function sameSubmissionGeneration(latest, attempted) {
  return Boolean(latest && latest.id === attempted.id && (!latest.last_submission || JSON.stringify(latest.last_submission) === JSON.stringify(attempted.last_submission)));
}

export function mergeSubmissionMetadata(latest, attempted) {
  if (!sameSubmissionGeneration(latest, attempted)) return latest;
  return { ...latest, last_submission: latest.last_submission || attempted.last_submission, submission_error: attempted.submission_error || null };
}

export function draftMatchesPayload(draft, payload) {
  if (!draft || draft.id !== payload.id) return false;
  const fields = 'monster_id' in payload ? ['comment', 'decision', 'playback_ms'] : ['title', 'region', 'details'];
  return fields.every(key => ['comment', 'title', 'details'].includes(key) ? String(draft[key] ?? '').trim() === payload[key] : draft[key] === payload[key]);
}

function latestSubmissionDraft(key, kind) {
  const saved = stored(key, null);
  if (saved) return saved;
  if (kind === 'review') return sameContext(key) ? state.draft : null;
  return state.ideaDraft || null;
}

function persistSubmissionMetadata(key, attempted, kind) {
  const latest = latestSubmissionDraft(key, kind);
  const merged = mergeSubmissionMetadata(latest, attempted);
  if (!merged || merged === latest) return latest;
  remember(key, merged);
  const visible = kind === 'review' ? (sameContext(key) ? state.draft : null) : state.ideaDraft;
  if (visible?.id === merged.id) {
    visible.last_submission = merged.last_submission;
    visible.submission_error = merged.submission_error;
  }
  return merged;
}

function node(tag, text, className) {
  const result = document.createElement(tag);
  if (text != null) result.textContent = String(text);
  if (className) result.className = className;
  return result;
}

function stored(key, fallback) {
  try { return JSON.parse(localStorage.getItem(STORAGE + key)) ?? fallback; } catch { return fallback; }
}

function remember(key, value) {
  try { value == null ? localStorage.removeItem(STORAGE + key) : localStorage.setItem(STORAGE + key, JSON.stringify(value)); return true; }
  catch { return false; }
}

function uuid() {
  if (globalThis.crypto?.randomUUID) return crypto.randomUUID();
  const bytes = crypto.getRandomValues(new Uint8Array(16));
  bytes[6] = (bytes[6] & 15) | 64; bytes[8] = (bytes[8] & 63) | 128;
  const hex = [...bytes].map(value => value.toString(16).padStart(2, '0')).join('');
  return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
}

async function api(path, options = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 7000);
  try {
    const response = await fetch(path, { credentials: 'same-origin', ...options, signal: controller.signal, headers: { ...(options.body ? { 'Content-Type': 'application/json' } : {}), ...options.headers } });
    let body;
    try { body = await response.json(); } catch { throw new Error('服务暂未就绪，请稍后重试。草稿仍然保留。'); }
    if (!response.ok) {
      const error = new Error(body.error || (response.status === 401 ? '请先登录，再保存到云端。草稿仍然保留。' : '请求没有成功，请重试。'));
      error.status = response.status;
      error.code = body.code;
      if (response.status === 401) { state.session = null; state.sessionChecked = true; renderAccount(); }
      throw error;
    }
    return body;
  } catch (error) {
    if (error.name === 'AbortError') throw new Error('连接超时，尚未确认保存。请重试；不会清空草稿。');
    if (error instanceof TypeError) throw new Error('网络连接失败，请检查网络后重试。草稿仍然保留。');
    throw error;
  } finally { clearTimeout(timer); }
}

function toast(message) {
  clearTimeout(toastTimer); $('toast').textContent = message; $('toast').hidden = false;
  toastTimer = setTimeout(() => { $('toast').hidden = true; }, 5000);
}

function currentAction() { return state.variant?.actions?.find(item => item.id === state.action) || null; }
function recordingLabel(variant) {
  return String(variant?.label || '动作片段').replace(/^(?:当前|历史)(?:\s+[a-f0-9]{6,64})?\s*[·／/-]?\s*/i, '').replace(/正式Underworld身体/g, '主游戏身体').replace(/正式App原场景/g, '正式关卡片段') || '动作片段';
}
function shortRevision(value) { const parts = String(value || '待定').split(':'); return (/^[a-f0-9]{8,}$/i.test(parts[1] || '') ? parts[1] : parts[0]).slice(0, 8); }
function recordingContext(variant) {
  if (!variant) return '场景类型尚未说明';
  if (!hasRecording(variant)) return '录制待补（尚无可看片段）';
  return `${variant.id || ''} ${variant.context || ''}`.includes('formal_App') ? '正式关卡实录（固定审核站位）' : '实验场实录（固定场地与初始站位，真实游戏机制）';
}
function gapLabel(gap) {
  return String(gap).includes('Historical basic0gaps is not all-action approval') ? '受伤打断、反向与边界组合尚待补录；已有基础片段不代表全部动作已获认可。' : gap;
}
function draftKey() { return state.monster && state.variant ? ['draft', state.monster.id, state.variant.id, state.variant.revision, state.action].map(encodeURIComponent).join(':') : null; }
function sameContext(key) { return key === draftKey(); }
function safeMediaURL(value) {
  if (typeof value !== 'string' || !value.trim()) return '';
  try { const url = new URL(value, location.origin); return ['http:', 'https:'].includes(url.protocol) ? url.href : ''; } catch { return ''; }
}

function renderAccount() {
  $('account-name').textContent = state.session?.user?.name || (state.sessionChecked ? '访客审片' : '连接中…');
  $('sign-in').hidden = Boolean(state.session?.user);
}

async function loadCatalog() {
  $('library-state').hidden = false; $('library-state').textContent = '正在整理名册…'; $('catalog-retry').hidden = true;
  try {
    const data = await api('/api/catalog');
    if (data.schema_version !== 1 || !Array.isArray(data.monsters)) throw new Error('名册尚未准备好，请稍后重新载入。');
    state.catalog = data;
    $('monster-count').textContent = String(data.monsters.length);
    renderLibrary();
    if (data.monsters.length) {
      const preference = stored('preferences', {});
      selectMonster(data.monsters.find(item => item.id === preference.monster) || data.monsters[0]);
    } else { $('library-state').hidden = false; $('library-state').textContent = '名册正在准备中，暂未发布任何怪物。'; $('catalog-retry').hidden = false; }
  } catch (error) {
    $('library-state').textContent = error.message; $('catalog-retry').hidden = false;
    if (!state.catalog) $('selection-empty').querySelector('p').textContent = '名册暂未载入。请稍后重试；你仍可记录新怪物创意。';
  }
}

function renderLibrary() {
  const list = $('monster-list'); list.replaceChildren();
  const query = state.search.trim().toLocaleLowerCase();
  const monsters = (state.catalog?.monsters || []).filter(item => (state.region === 'all' || item.category === state.region) && `${item.name} ${item.summary || ''} ${CATEGORY[item.category] || ''}`.toLocaleLowerCase().includes(query));
  for (const monster of monsters) {
    const variant = preferredVariant(monster);
    const button = node('button', null, `monster-card${state.monster?.id === monster.id ? ' selected' : ''}`);
    button.setAttribute('aria-pressed', String(state.monster?.id === monster.id));
    const thumb = node('span', null, 'monster-thumb'); thumb.setAttribute('aria-hidden', 'true'); thumb.append(node('span', monster.name?.slice(0, 1) || '◷'));
    const poster = safeMediaURL(variant?.poster_url);
    if (poster) { const image = node('img'); image.src = poster; image.alt = ''; image.loading = 'lazy'; image.addEventListener('error', () => image.remove()); thumb.append(image); }
    const info = node('span', null, 'monster-card-info'); info.append(node('strong', monster.name || monster.id));
    const detail = node('small'); detail.append(node('span', null, `card-dot${hasRecording(variant) ? ' available' : ''}`), document.createTextNode(`${CATEGORY[monster.category] || '地区未定'} · ${hasRecording(variant) ? (variant.is_current ? '有当前片段' : '仅历史片段') : '待录制'}`)); info.append(detail);
    button.append(thumb, info, node('span', '›', 'card-arrow'));
    button.addEventListener('click', () => { selectMonster(monster); closeMobileLibrary(); }); list.append(button);
  }
  $('library-state').hidden = Boolean(monsters.length);
  if (!monsters.length) $('library-state').textContent = state.catalog?.monsters?.length ? '没有找到匹配的怪物，试试其他名称或地区。' : '名册正在准备中，暂未发布任何怪物。';
}

function selectMonster(monster) {
  saveDraft(false); state.monster = monster; state.variant = preferredVariant(monster); state.action = 'overall';
  remember('preferences', { ...stored('preferences', {}), monster: monster.id });
  $('selection-empty').hidden = true; $('selected-monster').hidden = false;
  $('monster-name').textContent = monster.name; $('monster-category').textContent = `${CATEGORY[monster.category] || '地区未定'} / CREATURE STUDY`;
  $('monster-summary').textContent = monster.summary || '设计资料待补充，可先记录希望明确的方向。';
  $('terminal-policy').textContent = monster.terminal_policy || '终态与留尸规则尚未说明，可在整体意见中提出问题。';
  $('known-gaps').replaceChildren(...(monster.known_gaps || []).map(gap => node('li', gapLabel(gap))));
  const select = $('variant-select'); select.replaceChildren();
  for (const variant of monster.variants || []) { const option = node('option', `${variant.is_current ? '当前录制 · ' : '历史录制 · '}${recordingLabel(variant)}`); option.value = variant.id; option.title = variant.revision || ''; select.append(option); }
  if (!state.variant) select.append(node('option', '暂无录制版本'));
  select.disabled = !state.variant; if (state.variant) select.value = state.variant.id;
  renderLibrary(); renderVariant();
}

function renderVariant() {
  const variant = state.variant;
  $('version-badge').textContent = variant ? `${variant.is_current ? '当前录制' : '历史录制'} · ${recordingLabel(variant)}` : '等待首个录制';
  $('version-badge').title = variant?.revision || '';
  $('capture-context').textContent = recordingContext(variant);
  $('capture-context').title = variant?.context || '';
  const commit = variant?.game_commit || state.catalog?.game_commit;
  $('revision-info').textContent = variant ? `${variant.is_current ? '当前审看版本' : '历史录像，仅代表此版本'} · ${recordingLabel(variant)} · ${shortRevision(variant.revision)}` : '尚未发布可对应的动作版本。';
  $('recording-source').textContent = variant ? `完整版本：${variant.revision}\n片段：${variant.id}\n游戏来源：${commit || '尚未说明'}\n场景原始说明：${variant.context || '尚未说明'}` : '暂无录制来源。';
  $('stage-label-text').textContent = variant?.is_current ? '当前实机片段' : variant ? '历史实机片段 · 非当前版本' : '等待实机录制';
  const fps = Number(variant?.fps) > 0 ? Number(variant.fps) : 60;
  $('frame-note').textContent = `步进 1/${fps} 秒`;
  $('frame-back').setAttribute('aria-label', `向前步进1/${fps}秒`); $('frame-forward').setAttribute('aria-label', `向后步进1/${fps}秒`);
  state.videoReady = false; state.videoError = false; state.loop = false; $('loop').setAttribute('aria-pressed', 'false'); resetZoom();
  const video = $('video'); video.pause(); video.removeAttribute('src'); video.removeAttribute('poster');
  const poster = safeMediaURL(variant?.poster_url); if (poster) video.poster = poster;
  const source = safeMediaURL(variant?.video_url);
  if (hasRecording(variant) && source) { video.src = source; video.load(); } else video.load();
  renderActions(); renderVideoState(); loadDraft(); renderDrawerContext();
}

function renderVideoState() {
  const available = hasRecording(state.variant) && Boolean(safeMediaURL(state.variant?.video_url)) && !state.videoError;
  $('video').hidden = !available;
  $('video-empty').hidden = available;
  $('video-empty-title').textContent = state.videoError ? '视频暂时无法播放' : state.variant?.is_current === false ? '这个历史版本暂无录制' : '暂无当前录制';
  $('video-empty-note').textContent = state.videoError ? '请检查网络或重试加载。你仍可保存对缺片或动作的意见。' : '缺失的动作也可以记录意见，等待补片后再审核。';
  $('video-retry').hidden = !state.videoError;
  $('stage-label-text').textContent = available && !state.videoReady ? '正在载入真实片段…' : state.variant?.is_current ? '当前实机片段' : state.variant ? '历史实机片段 · 非当前版本' : '等待实机录制';
  for (const id of ['play', 'frame-back', 'frame-forward', 'seek', 'loop', 'mute', 'fullscreen']) $(id).disabled = !available || !state.videoReady;
  for (const button of document.querySelectorAll('[data-zoom], #zoom-reset')) button.disabled = !available || !state.videoReady;
  $('pin-time').disabled = !available || !state.videoReady;
  $('play').textContent = $('video').paused ? '▶' : 'Ⅱ'; $('play').setAttribute('aria-label', $('video').paused ? '播放片段' : '暂停片段');
  updateClock(); updateApproval();
}

function activeRange() { return actionRange(state.variant, currentAction(), $('video').duration || Infinity) || clipRange(state.variant, $('video').duration || Infinity); }

function renderActions() {
  const list = $('action-list'); list.replaceChildren();
  const actions = state.variant?.actions || [];
  const choices = [{ id: 'overall', label: '整体连续性', status: 'overall' }, ...actions];
  $('action-count').textContent = `${actions.filter(action => action.status === 'recorded').length}/${actions.length} 已录动作`;
  const select = $('review-action'); select.replaceChildren();
  for (const action of choices) {
    const option = node('option', action.label + (action.status === 'missing' ? ' · 缺失' : action.status === 'not_applicable' ? ' · 不适用' : '')); option.value = action.id; select.append(option);
    const unavailable = action.status === 'missing' || action.status === 'not_applicable';
    const button = node('button', null, `action-card${state.action === action.id ? ' selected' : ''}${action.status === 'missing' ? ' missing' : ''}${action.status === 'not_applicable' ? ' not-applicable' : ''}`);
    button.setAttribute('aria-pressed', String(state.action === action.id));
    const range = action.id === 'overall' ? clipRange(state.variant) : actionRange(state.variant, action);
    const status = action.id === 'overall' ? '移动到退场 · 整段' : unavailable ? (action.status === 'missing' ? '待补录 · 可提意见' : 'N/A · 可提问题') : range && hasRecording(state.variant) ? `${formatTime(range.start, true)}—${formatTime(range.end, true)}` : '暂无可看片段';
    button.append(node('strong', action.label), node('small', status));
    button.addEventListener('click', () => selectAction(action.id)); list.append(button);
  }
  select.value = state.action;
  const action = currentAction();
  $('action-note').textContent = action ? (action.note || (action.status === 'missing' ? '这个动作尚未收录。可以记录补录要求，不能据此认可。' : action.status === 'not_applicable' ? '制作资料标注为不适用；如有疑问，可以提出意见。' : '动作时间点对应原片，可慢放或循环查看。')) : '先看完整移动、受伤、恢复与退场，再逐个动作留下判断。';
  $('stage-action').textContent = action ? `${action.label}${action.status === 'recorded' ? '' : ' · 无对应画面'}` : '整体连续性';
}

function selectAction(id, seek = true) {
  saveDraft(false); state.action = id; renderActions(); loadDraft(); renderDrawerContext();
  const range = id === 'overall' ? clipRange(state.variant, $('video').duration || Infinity) : actionRange(state.variant, currentAction(), $('video').duration || Infinity);
  if (seek && range && state.videoReady) seekTo(range.start);
  if (!range) { state.loop = false; $('loop').setAttribute('aria-pressed', 'false'); }
  updateClock(); updateApproval();
}

function seekTo(time) {
  const range = clipRange(state.variant, $('video').duration || Infinity);
  if (range && state.videoReady) $('video').currentTime = Math.max(range.start, Math.min(range.end, time));
}

function updateClock() {
  const video = $('video'); const range = clipRange(state.variant, video.duration || Infinity);
  const current = Number.isFinite(video.currentTime) ? video.currentTime : 0;
  $('time-label').textContent = range ? `${formatTime(Math.max(0, current - range.start))} / ${formatTime(range.end - range.start)}` : '00:00 / —';
  if (range) { $('seek').min = range.start; $('seek').max = range.end; $('seek').value = Math.max(range.start, Math.min(range.end, current)); }
}

async function togglePlayback() {
  if (!state.videoReady || state.videoError) return;
  const video = $('video');
  if (!video.paused) { video.pause(); return; }
  const range = activeRange();
  if (range && (video.currentTime >= range.end - .02 || video.currentTime < range.start)) seekTo(range.start);
  try { await video.play(); } catch { toast('播放未能开始，请再次点击播放或重试加载视频。'); }
}

function approvalReady() { return state.videoReady && !state.videoError && canApprove(state.variant, currentAction(), $('video').duration) && Boolean(actionRange(state.variant, currentAction(), $('video').duration)); }

function updateApproval() {
  if (!$('decision')) return;
  const allowed = approvalReady();
  const option = $('decision').querySelector('[value="approve_action"]'); option.disabled = !allowed;
  if (!allowed && $('decision').value === 'approve_action') { $('decision').value = 'needs_work'; if (state.draft) state.draft.decision = 'needs_work'; }
  $('approval-scope').textContent = allowed ? `认可范围：${currentAction().label} · ${recordingLabel(state.variant)}（${shortRevision(state.variant.revision)}）。不代表整只怪物通过。` : '整体、缺失、不适用、待录制或未能播放的动作可以提意见与问题，暂不能认可。';
  $('approval-scope').title = state.variant?.revision || '';
  $('review-submit').disabled = !state.monster || !state.variant || state.saving.has(draftKey());
  $('review-submit').textContent = state.saving.has(draftKey()) ? '正在提交…' : '提交这条意见 ↗';
  $('loop').textContent = state.action === 'overall' ? '↻ 循环整段' : actionRange(state.variant, currentAction()) ? '↻ 循环动作' : '↻ 循环整段';
}

function loadDraft() {
  const key = draftKey(); const saved = key ? stored(key, null) : null;
  state.draft = saved || { id: uuid(), comment: '', decision: 'needs_work', playback_ms: null };
  $('comment').value = state.draft.comment || ''; $('decision').value = state.draft.decision || 'needs_work'; $('review-error').textContent = ''; $('review-error').classList.remove('success');
  $('draft-status').textContent = saved ? '未提交 · 已恢复本机草稿' : '未提交 · 本机草稿';
  renderPinnedTime(); updateApproval(); renderRecovery('review', state.draft);
}

function saveDraft(announce = true) {
  const key = draftKey(); if (!key || !state.draft) return;
  state.draft.comment = $('comment').value; state.draft.decision = $('decision').value;
  if (!state.draft.comment && state.draft.playback_ms == null && state.draft.decision === 'needs_work' && !state.draft.last_submission) { remember(key, null); return; }
  const kept = remember(key, state.draft);
  if (announce) $('draft-status').textContent = kept ? '未提交 · 仅保留在本机草稿' : '未提交 · 浏览器无法保存草稿，请保持此页开启';
}

function renderPinnedTime() {
  const time = state.draft?.playback_ms;
  $('pinned-time').textContent = Number.isInteger(time) ? `原片 ${formatTime(time / 1000, true)}` : '未关联时间点';
  $('clear-time').hidden = !Number.isInteger(time);
}

function renderDrawerContext() {
  const box = $('feedback-context'); box.replaceChildren();
  box.append(node('strong', state.monster?.name || '请先选择一只怪物'), node('small', state.variant ? `${recordingLabel(state.variant)} · ${shortRevision(state.variant.revision)}${state.variant.is_current ? ' · 当前录制' : ' · 历史录制'}` : '暂无录制版本，等待名册补充'));
  box.title = state.variant?.revision || '';
  renderDrawerReviews(); updateApproval();
}

function setView(view) {
  saveDraft(false); state.view = view;
  for (const item of ['review', 'ideas', 'mine']) { $(`view-${item}`).hidden = item !== view; }
  for (const button of document.querySelectorAll('[data-view]')) { const active = button.dataset.view === view; button.classList.toggle('active', active); active ? button.setAttribute('aria-current', 'page') : button.removeAttribute('aria-current'); }
  $('video').pause(); closeMobileLibrary();
  if (view === 'mine') { if (!state.mineLoaded) loadMine(); else renderMine(); }
  window.scrollTo({ top: 0, behavior: 'auto' });
}

function openDrawer(trigger) {
  if (!state.monster) { toast('名册载入后，选择一只怪物再记录动作意见。'); return; }
  state.drawerTrigger = trigger || document.activeElement;
  $('feedback-drawer').hidden = false;
  syncDrawerMode();
  renderDrawerContext(); $('close-feedback').focus();
  if (!state.mineLoaded && !state.mineLoading) loadMine();
}

function closeDrawer() {
  saveDraft(false); $('feedback-drawer').hidden = true; $('drawer-backdrop').hidden = true; document.body.classList.remove('body-drawer-open');
  $('main').inert = false; document.querySelector('.site-header').inert = false; state.drawerTrigger?.focus?.();
}

function syncDrawerMode() {
  if ($('feedback-drawer').hidden) return;
  const modal = window.matchMedia('(max-width: 820px)').matches;
  $('feedback-drawer').setAttribute('aria-modal', String(modal));
  $('drawer-backdrop').hidden = !modal; document.body.classList.toggle('body-drawer-open', modal);
  $('main').inert = modal; document.querySelector('.site-header').inert = modal;
}

function closeMobileLibrary() { document.querySelector('.library').classList.remove('mobile-open'); $('mobile-library-open').setAttribute('aria-expanded', 'false'); }

function renderRecovery(kind, draft) {
  const code = draft?.submission_error;
  const revisionChanged = kind === 'review' && code === 'revision_changed';
  const active = Boolean(draft?.last_submission && code);
  $(`${kind}-recovery`).hidden = !active;
  $(`${kind}-replay`).hidden = !active || revisionChanged;
  $(`${kind}-fork`).hidden = !active || code !== 'submission_conflict';
  if (kind === 'review') $('review-refresh-version').hidden = !revisionChanged;
  if (active) {
    const message = revisionChanged ? '录制版本已更新，请刷新名册并重新选择审核版本。草稿保留，不能通过新提交绕过版本检查。' : code === 'submission_conflict' ? '这个提交的原稿已存在，修改稿尚未保存。可重新确认原提交，或明确将修改稿另存为一条新记录。' : '上一次提交结果尚未确认。原请求已保留，可原样重新确认；编辑后的内容仍在草稿中。';
    $(`${kind}-error`).textContent = message; $(`${kind}-error`).classList.remove('success');
  }
}

async function submitReview(event, replayOriginal = false) {
  event.preventDefault(); saveDraft();
  if (!state.variant || !state.monster) return;
  const key = draftKey(); if (state.saving.has(key)) return;
  const draft = state.draft; const comment = $('comment').value.trim(); const decision = $('decision').value;
  if (!replayOriginal && !comment && decision !== 'approve_action') { $('review-error').textContent = '写一句具体意见或问题，再提交。'; $('comment').focus(); return; }
  if (!replayOriginal && comment.length > 3000) { $('review-error').textContent = '意见最多3000字，请缩短后重试；草稿仍保留。'; return; }
  if (!replayOriginal && decision === 'approve_action' && !approvalReady()) { $('review-error').textContent = '请先选择可播放的具体动作。整体、缺失或未能播放的动作不能认可。'; return; }
  const payload = replayOriginal ? draft.last_submission : { id: draft.id, monster_id: state.monster.id, action_id: state.action, revision: state.variant.revision, clip_id: state.variant.id, playback_ms: Number.isInteger(draft.playback_ms) ? draft.playback_ms : null, decision, comment };
  if (!payload) return;
  state.saving.add(key); updateApproval(); $('review-error').textContent = '';
  try {
    const data = await sendDraftSubmission(draft, payload, value => api('/api/reviews', { method: 'POST', body: JSON.stringify(value) }), value => persistSubmissionMetadata(key, value, 'review'));
    state.reviews = [data.item, ...state.reviews.filter(item => item.id !== data.item.id)];
    const latest = latestSubmissionDraft(key, 'review');
    const visible = sameContext(key) ? state.draft : null;
    const belongs = sameSubmissionGeneration(latest, draft);
    const canClear = belongs && draftMatchesPayload(latest, payload) && (!visible || draftMatchesPayload(visible, payload));
    if (canClear) {
      remember(key, null);
      if (sameContext(key)) { loadDraft(); $('draft-status').textContent = '这条意见已保存到云端'; $('review-error').textContent = '已保存到云端。可以继续记录下一条。'; $('review-error').classList.add('success'); }
    } else if (belongs) {
      // The latest text may belong to a different object after A → B → A.
      // Merge receipt metadata only; never re-persist the captured old body.
      const kept = persistSubmissionMetadata(key, { ...draft, submission_error: 'submission_conflict' }, 'review');
      if (sameContext(key) && visible?.id === draft.id) { renderRecovery('review', kept); $('draft-status').textContent = '原提交已保存 · 最新修改稿尚未提交'; }
    }
    renderDrawerReviews(); if (state.view === 'mine') renderMine(); updateReviewCount(); toast('原提交已确认保存到云端');
  } catch (error) { if (sameContext(key) && state.draft?.id === draft.id) { renderRecovery('review', latestSubmissionDraft(key, 'review')); if (!['submission_conflict', 'revision_changed'].includes(error.code)) $('review-error').textContent = `${error.message}\n${$('review-error').textContent}`; } toast('本次尚未确认保存，草稿与原请求均保留'); }
  finally { state.saving.delete(key); updateApproval(); }
}

function ideaDraft() {
  state.ideaDraft ||= { id: $('idea-form').dataset.draftId };
  Object.assign(state.ideaDraft, { id: $('idea-form').dataset.draftId, title: $('idea-title').value, region: $('idea-region').value, details: $('idea-details').value });
  return state.ideaDraft;
}
function saveIdeaDraft() { const draft = ideaDraft(); if (!draft.title && !draft.details && !draft.last_submission) { remember('idea-draft', null); return; } $('idea-draft-status').textContent = remember('idea-draft', draft) ? '未提交 · 仅保留在本机草稿' : '浏览器无法保存草稿，请保持此页开启'; }

async function submitIdea(event, replayOriginal = false) {
  event.preventDefault(); saveIdeaDraft();
  const draft = ideaDraft();
  const payload = replayOriginal ? draft.last_submission : { id: draft.id, title: draft.title.trim(), region: draft.region, details: draft.details.trim() };
  if (!payload) return;
  if (!payload.title || !payload.details) { $('idea-error').textContent = '请填写暂定名字与创意描述。'; return; }
  if (payload.title.length > 100 || payload.details.length > 5000) { $('idea-error').textContent = '名字最多100字，创意描述最多5000字。请缩短后重试；草稿仍保留。'; return; }
  if ($('idea-submit').disabled) return;
  $('idea-submit').disabled = true; $('idea-submit').textContent = '正在提交…'; $('idea-error').textContent = '';
  try {
    const data = await sendDraftSubmission(draft, payload, value => api('/api/ideas', { method: 'POST', body: JSON.stringify(value) }), value => persistSubmissionMetadata('idea-draft', value, 'idea'));
    state.ideas = [data.item, ...state.ideas.filter(item => item.id !== data.item.id)];
    const latest = latestSubmissionDraft('idea-draft', 'idea');
    const visible = ideaDraft();
    if (sameSubmissionGeneration(latest, draft) && draftMatchesPayload(latest, payload) && draftMatchesPayload(visible, payload)) {
      remember('idea-draft', null); $('idea-form').reset(); $('idea-form').dataset.draftId = uuid(); state.ideaDraft = null;
      $('idea-draft-status').textContent = '这条创意已保存到云端'; $('idea-error').textContent = '创意已保存到云端，作为待讨论提案。'; $('idea-error').classList.add('success'); renderRecovery('idea', null);
    } else if (sameSubmissionGeneration(latest, draft)) {
      const kept = persistSubmissionMetadata('idea-draft', { ...draft, submission_error: 'submission_conflict' }, 'idea');
      if (visible.id === draft.id) { renderRecovery('idea', kept); $('idea-draft-status').textContent = '原提案已保存 · 最新修改稿尚未提交'; }
    }
    toast('原提案已确认保存到云端');
  } catch (error) { if (state.ideaDraft?.id === draft.id) renderRecovery('idea', latestSubmissionDraft('idea-draft', 'idea')); if (state.ideaDraft?.id === draft.id && error.code !== 'submission_conflict') $('idea-error').textContent = `${error.message}\n${$('idea-error').textContent}`; }
  finally { $('idea-submit').disabled = false; $('idea-submit').textContent = '提交创意 ↗'; }
}

function deduplicate(items) { return [...new Map(items.map(item => [item.id, item])).values()]; }
async function loadMine(append = false) {
  if (state.mineLoading) return;
  state.mineLoading = true; state.mineError = ''; renderMine();
  try {
    if (append) {
      const kind = state.mineKind; const cursor = kind === 'reviews' ? state.reviewCursor : state.ideaCursor;
      const data = await api(`/api/${kind}?cursor=${encodeURIComponent(cursor || '')}`);
      if (!Array.isArray(data.items)) throw new Error('云端记录格式暂不可用，请重新载入。');
      state[kind] = deduplicate([...state[kind], ...data.items]);
      if (kind === 'reviews') state.reviewCursor = data.next_cursor || null; else state.ideaCursor = data.next_cursor || null;
    } else {
      const results = await Promise.allSettled([api('/api/reviews'), api('/api/ideas')]);
      for (const [index, result] of results.entries()) {
        if (result.status === 'rejected') { state.mineError = result.reason.message; continue; }
        if (!Array.isArray(result.value.items)) { state.mineError = '部分云端记录暂时无法读取，请刷新重试。'; continue; }
        if (index === 0) { state.reviews = deduplicate([...result.value.items, ...state.reviews]); state.reviewCursor = result.value.next_cursor || null; }
        else { state.ideas = deduplicate([...result.value.items, ...state.ideas]); state.ideaCursor = result.value.next_cursor || null; }
      }
      state.mineLoaded = results.every(result => result.status === 'fulfilled' && Array.isArray(result.value.items));
    }
  } catch (error) { state.mineError = error.message; }
  finally { state.mineLoading = false; renderMine(); renderDrawerReviews(); updateReviewCount(); }
}

function reviewCard(item, compact = false) {
  const monster = state.catalog?.monsters?.find(value => value.id === item.monster_id);
  const variant = monster?.variants?.find(value => value.id === item.clip_id && value.revision === item.revision);
  const action = variant?.actions?.find(value => value.id === item.action_id);
  const card = node('article', null, 'saved-card'); const top = node('div', null, 'saved-card-top');
  top.append(node('h3', `${compact ? '' : `${monster?.name || item.monster_id} · `}${item.action_id === 'overall' ? '整体连续性' : action?.label || item.action_id}`), node('span', DECISION[item.decision] || item.decision, `decision-tag${item.decision === 'approve_action' ? ' approved' : ''}`)); card.append(top);
  const date = new Date(item.created_at); const dateText = Number.isNaN(date.valueOf()) ? '' : date.toLocaleString('zh-CN', { month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' });
  const metadata = node('p', [variant ? recordingLabel(variant) : '原审核版本', shortRevision(item.revision), Number.isInteger(item.playback_ms) ? `原片 ${formatTime(item.playback_ms / 1000, true)}` : '未关联时间点', dateText, '云端已保存'].filter(Boolean).join(' · '), 'record-meta');
  metadata.title = item.revision || ''; card.append(metadata);
  card.append(node('p', item.comment || '认可此动作的当前审看版本。', 'record-comment'));
  if (!compact && monster && variant) { const jump = node('button', '回到这条意见的片段 ↗', 'text-button'); jump.addEventListener('click', () => { setView('review'); selectMonster(monster); if (state.variant?.id !== variant.id) { state.variant = variant; state.action = 'overall'; $('variant-select').value = variant.id; renderVariant(); } selectAction(item.action_id === 'overall' || variant.actions?.some(value => value.id === item.action_id) ? item.action_id : 'overall', false); if (Number.isInteger(item.playback_ms)) { const go = () => seekTo(item.playback_ms / 1000); if (state.videoReady) go(); else $('video').addEventListener('loadedmetadata', go, { once: true }); } }); card.append(jump); }
  return card;
}

function ideaCard(item) {
  const card = node('article', null, 'saved-card'); const top = node('div', null, 'saved-card-top'); top.append(node('h3', item.title), node('span', '待讨论提案', 'decision-tag')); card.append(top);
  const date = new Date(item.created_at); card.append(node('p', `${CATEGORY[item.region] || item.region || '地区未定'} · ${Number.isNaN(date.valueOf()) ? '' : date.toLocaleDateString('zh-CN')} · 云端已保存`, 'record-meta'), node('p', item.details, 'record-comment')); return card;
}

function renderMine() {
  const kind = state.mineKind; const items = state[kind];
  $('mine-reviews-tab').classList.toggle('active', kind === 'reviews'); $('mine-ideas-tab').classList.toggle('active', kind === 'ideas');
  $('mine-reviews-tab').setAttribute('aria-pressed', String(kind === 'reviews')); $('mine-ideas-tab').setAttribute('aria-pressed', String(kind === 'ideas'));
  $('mine-status').textContent = state.mineLoading ? '正在读取云端记录…' : state.mineError || `${items.length} 条云端已保存${kind === 'reviews' ? '意见' : '创意'}${(kind === 'reviews' ? state.reviewCursor : state.ideaCursor) ? '，还有更多' : ''}`;
  $('mine-list').replaceChildren(...items.map(item => kind === 'reviews' ? reviewCard(item) : ideaCard(item)));
  if (!items.length && !state.mineLoading) { const empty = node('div', null, 'empty-records'); empty.append(node('p', state.mineError ? '尚未取得云端记录。未提交草稿不会出现在这里。' : kind === 'reviews' ? '还没有已保存意见。看完一个动作，留下第一条判断吧。' : '还没有已保存创意。留住那个有趣的念头。')); if (!state.session?.user) { const login = node('a', '登录后查看与保存', 'button small-button'); login.href = '/signin-with-chatgpt?return_to=/'; login.target = '_top'; empty.append(login); } $('mine-list').append(empty); }
  $('load-more').hidden = !(kind === 'reviews' ? state.reviewCursor : state.ideaCursor); $('load-more').disabled = state.mineLoading; $('refresh-mine').disabled = state.mineLoading;
}

function renderDrawerReviews() {
  const reviews = state.reviews.filter(item => item.monster_id === state.monster?.id).slice(0, 6);
  $('drawer-reviews').replaceChildren(...reviews.map(item => reviewCard(item, true)));
  if (!reviews.length) $('drawer-reviews').append(node('p', state.mineLoading ? '正在读取云端意见…' : state.mineError || '当前已载入的记录中，还没有这只怪物的意见。', 'muted'));
}

function updateReviewCount() { $('review-count').hidden = !state.reviews.length; $('review-count').textContent = state.reviews.length; }

async function exportRecords() {
  $('export').disabled = true;
  try {
    const data = await api('/api/export'); const url = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' }));
    const link = node('a'); link.href = url; link.download = `monster-workshop-${new Date().toISOString().slice(0, 10)}.json`; document.body.append(link); link.click(); link.remove(); setTimeout(() => URL.revokeObjectURL(url), 1000); toast('已导出云端记录');
  } catch (error) { toast(error.message); } finally { $('export').disabled = false; }
}

function init() {
  for (const button of document.querySelectorAll('[data-view]')) button.addEventListener('click', () => setView(button.dataset.view));
  for (const button of document.querySelectorAll('[data-go]')) button.addEventListener('click', () => setView(button.dataset.go));
  $('search').addEventListener('input', event => { state.search = event.target.value; renderLibrary(); });
  for (const button of document.querySelectorAll('[data-region]')) button.addEventListener('click', () => { state.region = button.dataset.region; for (const item of document.querySelectorAll('[data-region]')) { const active = item === button; item.classList.toggle('active', active); item.setAttribute('aria-pressed', String(active)); } renderLibrary(); });
  $('variant-select').addEventListener('change', event => { saveDraft(false); state.variant = state.monster.variants.find(item => item.id === event.target.value); state.action = 'overall'; renderVariant(); });
  $('catalog-retry').addEventListener('click', loadCatalog);
  const video = $('video');
  video.addEventListener('loadedmetadata', () => { const range = clipRange(state.variant, video.duration); if (!range) { state.videoError = true; renderVideoState(); return; } state.videoReady = true; const action = actionRange(state.variant, currentAction(), video.duration); video.currentTime = action?.start ?? range.start; video.playbackRate = Number($('speed').value); renderVideoState(); });
  video.addEventListener('error', () => { if (!video.getAttribute('src')) return; state.videoError = true; state.videoReady = false; renderVideoState(); });
  video.addEventListener('play', renderVideoState); video.addEventListener('pause', renderVideoState);
  video.addEventListener('timeupdate', () => { if (state.videoReady) { const clip = clipRange(state.variant, video.duration); const range = state.loop ? activeRange() : clip; if (range && video.currentTime >= range.end) { if (state.loop && !video.paused) video.currentTime = range.start; else { video.pause(); if (clip && video.currentTime > clip.end) video.currentTime = clip.end; } } } updateClock(); });
  video.addEventListener('seeking', () => { const range = clipRange(state.variant, video.duration || Infinity); if (state.videoReady && range && (video.currentTime < range.start || video.currentTime > range.end)) seekTo(video.currentTime); });
  video.addEventListener('ended', () => { if (state.loop && activeRange()) { seekTo(activeRange().start); video.play().catch(() => toast('循环播放暂停，请点击播放继续。')); } });
  $('video-retry').addEventListener('click', () => { state.videoError = false; state.videoReady = false; video.load(); renderVideoState(); });
  $('play').addEventListener('click', togglePlayback); video.addEventListener('click', () => { if (suppressVideoClick) { suppressVideoClick = false; return; } togglePlayback(); });
  for (const button of document.querySelectorAll('[data-zoom]')) button.addEventListener('click', () => { zoom = Number(button.dataset.zoom); panX = 0; panY = 0; renderZoom(); });
  $('zoom-reset').addEventListener('click', resetZoom);
  video.addEventListener('pointerdown', event => { if (zoom <= 1 || !state.videoReady || (event.pointerType === 'mouse' && event.button !== 0)) return; drag = { id: event.pointerId, startX: event.clientX, startY: event.clientY, x: panX, y: panY, moved: false }; video.setPointerCapture(event.pointerId); });
  video.addEventListener('pointermove', event => { if (!drag || drag.id !== event.pointerId) return; const dx = event.clientX - drag.startX, dy = event.clientY - drag.startY; if (Math.abs(dx) + Math.abs(dy) > 4) drag.moved = true; panX = drag.x + dx; panY = drag.y + dy; renderZoom(); });
  const finishPan = event => { if (!drag || drag.id !== event.pointerId) return; suppressVideoClick = drag.moved; drag = null; if (video.hasPointerCapture(event.pointerId)) video.releasePointerCapture(event.pointerId); };
  video.addEventListener('pointerup', finishPan); video.addEventListener('pointercancel', finishPan);
  $('seek').addEventListener('input', event => seekTo(Number(event.target.value)));
  for (const [id, direction] of [['frame-back', -1], ['frame-forward', 1]]) $(id).addEventListener('click', () => { video.pause(); seekTo(video.currentTime + direction / (Number(state.variant?.fps) > 0 ? Number(state.variant.fps) : 60)); });
  $('loop').addEventListener('click', () => { state.loop = !state.loop; $('loop').setAttribute('aria-pressed', String(state.loop)); const range = activeRange(); if (state.loop && range && (video.currentTime < range.start || video.currentTime >= range.end)) seekTo(range.start); });
  $('speed').addEventListener('change', event => { video.playbackRate = Number(event.target.value); remember('preferences', { ...stored('preferences', {}), speed: video.playbackRate }); });
  $('mute').addEventListener('click', () => { video.muted = !video.muted; $('mute').setAttribute('aria-pressed', String(video.muted)); $('mute').setAttribute('aria-label', video.muted ? '开启原片声音' : '静音'); $('mute').textContent = video.muted ? '♪̸' : '♪'; });
  $('fullscreen').addEventListener('click', async () => { try { if (document.fullscreenElement) await document.exitFullscreen(); else if ($('video-stage').requestFullscreen) await $('video-stage').requestFullscreen(); else if (video.webkitEnterFullscreen) video.webkitEnterFullscreen(); else toast('此浏览器暂不支持全屏。'); } catch { toast('未能进入全屏，请在浏览器中查看。'); } });
  for (const id of ['open-feedback', 'bottom-feedback']) $(id).addEventListener('click', event => openDrawer(event.currentTarget));
  $('close-feedback').addEventListener('click', closeDrawer);
  $('drawer-backdrop').addEventListener('click', closeDrawer);
  $('review-action').addEventListener('change', event => selectAction(event.target.value));
  $('comment').addEventListener('input', () => { $('review-error').textContent = ''; saveDraft(); });
  $('decision').addEventListener('change', () => { updateApproval(); saveDraft(); });
  $('pin-time').addEventListener('click', () => { if (state.videoReady && !state.videoError) { state.draft.playback_ms = Math.round(video.currentTime * 1000); renderPinnedTime(); saveDraft(); } });
  $('clear-time').addEventListener('click', () => { state.draft.playback_ms = null; renderPinnedTime(); saveDraft(); });
  $('review-form').addEventListener('submit', submitReview);
  $('review-replay').addEventListener('click', event => submitReview(event, true));
  $('review-fork').addEventListener('click', () => { if (state.draft?.submission_error !== 'submission_conflict' || state.saving.has(draftKey())) return; state.draft = forkSubmissionDraft(state.draft, uuid()); saveDraft(); renderRecovery('review', state.draft); $('review-form').requestSubmit(); });
  $('review-refresh-version').addEventListener('click', () => { saveDraft(); loadCatalog(); });
  $('drawer-refresh').addEventListener('click', () => loadMine());
  $('mobile-library-open').setAttribute('aria-expanded', 'false');
  $('mobile-library-open').addEventListener('click', () => { document.querySelector('.library').classList.add('mobile-open'); $('mobile-library-open').setAttribute('aria-expanded', 'true'); $('mobile-library-close').focus(); });
  $('mobile-library-close').addEventListener('click', () => { closeMobileLibrary(); $('mobile-library-open').focus(); });
  for (const [id, kind] of [['mine-reviews-tab', 'reviews'], ['mine-ideas-tab', 'ideas']]) $(id).addEventListener('click', () => { state.mineKind = kind; renderMine(); });
  $('refresh-mine').addEventListener('click', () => loadMine()); $('load-more').addEventListener('click', () => loadMine(true)); $('export').addEventListener('click', exportRecords);
  const idea = stored('idea-draft', null); state.ideaDraft = idea; $('idea-form').dataset.draftId = idea?.id || uuid(); if (idea) { $('idea-title').value = idea.title || ''; $('idea-region').value = idea.region || 'candidate'; $('idea-details').value = idea.details || ''; $('idea-draft-status').textContent = '未提交 · 已恢复本机创意草稿'; }
  for (const id of ['idea-title', 'idea-region', 'idea-details']) $(id).addEventListener('input', () => { $('idea-error').textContent = ''; saveIdeaDraft(); });
  $('idea-form').addEventListener('submit', submitIdea);
  renderRecovery('idea', state.ideaDraft);
  $('idea-replay').addEventListener('click', event => submitIdea(event, true));
  $('idea-fork').addEventListener('click', () => { if (state.ideaDraft?.submission_error !== 'submission_conflict' || $('idea-submit').disabled) return; state.ideaDraft = forkSubmissionDraft(ideaDraft(), uuid()); $('idea-form').dataset.draftId = state.ideaDraft.id; saveIdeaDraft(); renderRecovery('idea', state.ideaDraft); $('idea-form').requestSubmit(); });
  const preferences = stored('preferences', {}); if ([1, .5, .25].includes(preferences.speed)) $('speed').value = String(preferences.speed);
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape') { if (!$('feedback-drawer').hidden) closeDrawer(); else closeMobileLibrary(); }
    if (!$('feedback-drawer').hidden && $('feedback-drawer').getAttribute('aria-modal') === 'true' && event.key === 'Tab') { const focusable = [...$('feedback-drawer').querySelectorAll('button:not(:disabled), a[href], input:not(:disabled), textarea:not(:disabled), select:not(:disabled)')].filter(item => !item.hidden && item.getClientRects().length); const first = focusable[0]; const last = focusable.at(-1); if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus(); } else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); } }
    const editing = ['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement?.tagName);
    if (event.key === '/' && !editing && state.view === 'review' && $('feedback-drawer').hidden) { event.preventDefault(); $('search').focus(); }
    if ((event.key === ' ' || event.key === 'ArrowLeft' || event.key === 'ArrowRight') && document.activeElement === video) { event.preventDefault(); if (event.key === ' ') togglePlayback(); else { video.pause(); seekTo(video.currentTime + (event.key === 'ArrowLeft' ? -1 : 1) / (Number(state.variant?.fps) || 60)); } }
  });
  window.addEventListener('pagehide', () => { saveDraft(false); saveIdeaDraft(); video.pause(); });
  window.addEventListener('resize', () => { syncDrawerMode(); renderZoom(); });
  document.addEventListener('fullscreenchange', renderZoom);
  document.addEventListener('visibilitychange', () => { if (document.hidden) { video.pause(); saveDraft(false); saveIdeaDraft(); } });
  loadCatalog();
  api('/api/session').then(session => { state.session = session; }).catch(() => { state.session = null; }).finally(() => { state.sessionChecked = true; renderAccount(); });
}

if (typeof document !== 'undefined') init();
