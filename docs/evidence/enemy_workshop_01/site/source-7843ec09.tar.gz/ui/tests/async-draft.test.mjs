import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

const source = await readFile(new URL('../app.js', import.meta.url), 'utf8');
let serial = 0;
async function fixture() {
  delete globalThis.document;
  const module = await import(`data:text/javascript;base64,${Buffer.from(source + `\nexport {state,submitReview,submitIdea,loadDraft,saveDraft,ideaDraft,saveIdeaDraft,toastTimer};\n// fixture ${serial++}`).toString('base64')}`);
  const elements = new Map();
  function element() { return { value: '', textContent: '', hidden: false, disabled: false, dataset: {}, classList: { add() {}, remove() {}, toggle() {} }, querySelector: element, append() {}, replaceChildren() {}, setAttribute() {}, focus() {}, reset() {}, duration: 12, paused: true }; }
  globalThis.document = { getElementById(id) { if (!elements.has(id)) elements.set(id, element()); return elements.get(id); }, createElement: element, createTextNode: text => ({ textContent: text }), querySelector: element, querySelectorAll: () => [] };
  const values = new Map();
  globalThis.localStorage = { getItem: key => values.get(key) ?? null, setItem: (key, value) => values.set(key, value), removeItem: key => values.delete(key) };
  let resolve, reject, sent;
  globalThis.fetch = (_path, options) => { sent = JSON.parse(options.body); return new Promise((yes, no) => { resolve = yes; reject = no; }); };
  return { module, values, get sent() { return sent; }, get: id => document.getElementById(id), finish(fail) { if (fail) reject(new TypeError('network disconnected')); else resolve(new Response(JSON.stringify({ item: { ...sent, created_at: '2026-10-29T00:00:00Z' } }), { status: 201, headers: { 'content-type': 'application/json' } })); } };
}

for (const fail of [false, true]) test(`review A pending → B → A(new object) → edit → old ${fail ? 'failure' : 'success'} preserves the newest persisted draft`, async () => {
  const f = await fixture(); const { state, submitReview, loadDraft, saveDraft } = f.module;
  const monster = { id: 'a', name: 'A' }; const variant = { id: 'clip-a', revision: 'r1', in: 1, out: 12, actions: [{ id: 'hurt', label: '受伤', status: 'recorded', start: 3, end: 4 }] };
  Object.assign(state, { monster, variant, action: 'hurt', draft: { id: 'original-request', comment: 'original', decision: 'needs_work', playback_ms: null } });
  f.get('comment').value = 'original'; f.get('decision').value = 'needs_work';
  const pending = submitReview({ preventDefault() {} });
  const key = [...f.values.keys()][0]; const captured = state.draft;
  state.monster = { id: 'b' }; state.variant = { id: 'clip-b', revision: 'r1' }; state.draft = { id: 'b-draft', comment: 'B' };
  state.monster = monster; state.variant = variant; loadDraft();
  assert.notEqual(state.draft, captured);
  f.get('comment').value = 'NEW USER EDIT AFTER RETURN'; saveDraft();
  f.finish(fail); await pending;
  const persisted = JSON.parse(f.values.get(key));
  assert.equal(persisted.comment, 'NEW USER EDIT AFTER RETURN'); assert.equal(state.draft.comment, persisted.comment);
  assert.equal(persisted.id, 'original-request'); assert.equal(persisted.last_submission.comment, 'original');
  assert.equal(persisted.submission_error, fail ? 'unconfirmed' : 'submission_conflict');
  loadDraft(); assert.equal(f.get('comment').value, 'NEW USER EDIT AFTER RETURN');
  clearTimeout(f.module.toastTimer);
});

for (const fail of [false, true]) test(`idea restored into a new object while pending survives old ${fail ? 'failure' : 'success'}`, async () => {
  const f = await fixture(); const { state, submitIdea, saveIdeaDraft } = f.module;
  f.get('idea-form').dataset.draftId = 'original-idea'; f.get('idea-title').value = 'Title'; f.get('idea-region').value = 'forest'; f.get('idea-details').value = 'original details';
  const pending = submitIdea({ preventDefault() {} }); const key = 'enemy-workshop-01:idea-draft'; const captured = state.ideaDraft;
  state.ideaDraft = JSON.parse(f.values.get(key)); assert.notEqual(state.ideaDraft, captured);
  f.get('idea-title').value = 'Changed title'; f.get('idea-details').value = 'NEW IDEA DETAILS'; saveIdeaDraft();
  f.finish(fail); await pending;
  const persisted = JSON.parse(f.values.get(key));
  assert.equal(persisted.title, 'Changed title'); assert.equal(persisted.details, 'NEW IDEA DETAILS');
  assert.equal(state.ideaDraft.details, persisted.details); assert.equal(persisted.last_submission.details, 'original details');
  assert.equal(persisted.submission_error, fail ? 'unconfirmed' : 'submission_conflict');
  clearTimeout(f.module.toastTimer);
});

test('an old response cannot alter a replacement draft with a new UUID', async () => {
  const f = await fixture(); const { state, submitReview } = f.module;
  Object.assign(state, { monster: { id: 'a', name: 'A' }, variant: { id: 'clip', revision: 'r1', in: 1, out: 12, actions: [] }, action: 'overall', draft: { id: 'old-id', comment: 'old', decision: 'needs_work', playback_ms: null } });
  f.get('comment').value = 'old'; f.get('decision').value = 'needs_work'; const pending = submitReview({ preventDefault() {} });
  const key = [...f.values.keys()][0]; const replacement = { id: 'new-explicit-id', comment: 'new independent draft', decision: 'needs_work', playback_ms: null, last_submission: null, submission_error: null };
  state.draft = { ...replacement }; f.get('comment').value = replacement.comment; f.values.set(key, JSON.stringify(replacement));
  f.finish(false); await pending;
  assert.deepEqual(JSON.parse(f.values.get(key)), replacement); assert.deepEqual(state.draft, replacement);
  clearTimeout(f.module.toastTimer);
});
