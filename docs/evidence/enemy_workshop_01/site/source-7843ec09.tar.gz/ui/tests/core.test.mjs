import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

const source = await readFile(new URL('../app.js', import.meta.url), 'utf8');
const { formatTime, preferredVariant, clipRange, actionRange, hasRecording, canApprove, sendDraftSubmission, forkSubmissionDraft, clampPan } = await import(`data:text/javascript;base64,${Buffer.from(source).toString('base64')}`);
const variant = { id: 'current', revision: 'r2', is_current: true, capture_status: 'recorded', video_url: '/media/original.mp4', in: 10, out: 20, duration: 10, actions: [] };
const recorded = { id: 'hurt', label: '受伤', status: 'recorded', start: 12, end: 14 };

test('current capture remains default even when an older ready film comes first', () => {
  const old = { ...variant, id: 'legacy', is_current: false };
  const pending = { ...variant, id: 'current', capture_status: 'pending', video_url: null };
  assert.equal(preferredVariant({ variants: [old, pending] }), pending);
  assert.equal(preferredVariant({ variants: [old] }), old);
  assert.equal(preferredVariant({ variants: [] }), null);
});

test('shared original video uses absolute in/out bounds and never manufactures a missing end', () => {
  assert.deepEqual(clipRange(variant), { start: 10, end: 20 });
  assert.deepEqual(clipRange(variant, 17), { start: 10, end: 17 });
  assert.equal(clipRange(variant, 8), null);
  for (const update of [{ in: null }, { in: '10' }, { out: undefined }, { out: 9 }, { out: Infinity }, { in: -1 }]) assert.equal(clipRange({ ...variant, ...update }), null);
});

test('actions cannot seek outside this monster or outside the loaded media', () => {
  assert.deepEqual(actionRange(variant, recorded), { start: 12, end: 14 });
  assert.deepEqual(actionRange(variant, { ...recorded, start: 8, end: 13 }), { start: 10, end: 13 });
  assert.equal(actionRange(variant, { ...recorded, start: 21, end: 22 }), null);
  assert.equal(actionRange(variant, recorded, 11), null);
  assert.equal(actionRange(variant, { ...recorded, start: 12, end: 12 }), null);
});

test('pending, missing and N/A retain comment scope but cannot approve an action', () => {
  assert.equal(canApprove(variant, recorded), true);
  for (const status of ['missing', 'not_applicable']) {
    assert.equal(canApprove(variant, { ...recorded, status }), false);
    assert.equal(actionRange(variant, { ...recorded, status }), null);
  }
  assert.equal(canApprove(variant, { ...recorded, id: 'overall' }), false);
  assert.equal(canApprove(variant, null), false);
  assert.equal(canApprove({ ...variant, capture_status: 'pending' }, recorded), false);
  assert.equal(canApprove({ ...variant, video_url: null }, recorded), false);
  assert.equal(hasRecording({ ...variant, video_url: ' ' }), false);
  assert.equal(canApprove(variant, { ...recorded, start: 8, end: 13 }), false);
  assert.equal(canApprove(variant, { ...recorded, start: 19, end: 21 }), false);
  assert.equal(canApprove(variant, { ...recorded, start: 10 - 1 / 60, end: 20 + 1 / 60 }), true);
  assert.equal(canApprove(variant, { ...recorded, start: 10 - 1 / 59 }), false);
  assert.equal(canApprove(variant, { ...recorded, end: 20 + 1 / 59 }), false);
  assert.equal(canApprove(variant, { ...recorded, start: NaN }), false);
  assert.equal(canApprove(variant, { ...recorded, end: Infinity }), false);
  assert.equal(canApprove(variant, { ...recorded, end: 12 }), false);
  assert.equal(canApprove(variant, recorded, 13), false);
});

test('unreleased catalog and empty captures are safe', () => {
  assert.equal(preferredVariant(null), null);
  assert.equal(clipRange(null), null);
  assert.equal(actionRange(null, recorded), null);
  assert.equal(hasRecording(null), false);
  assert.equal(canApprove(null, recorded), false);
});

test('time labels carry centisecond rounding across minute boundaries', () => {
  assert.equal(formatTime(63.25, true), '01:03.25');
  assert.equal(formatTime(59.999, true), '01:00.00');
  assert.equal(formatTime(-4), '00:00');
  assert.equal(formatTime(NaN), '—');
});

test('user-facing app never injects HTML or treats local storage as a cloud record', () => {
  assert.doesNotMatch(source, /\.innerHTML|\.outerHTML|insertAdjacentHTML|document\.write/);
  assert.doesNotMatch(source, /remember\(['"](?:reviews|ideas|saved)/);
  assert.match(source, /data\?\.item\?\.id/);
  assert.match(source, /target = '_top'/);
});

for (const kind of ['review', 'idea']) test(`${kind}: saved 201 response lost → reload/edit → 409 → explicit new submission → 201`, async () => {
  const rows = new Map(); const calls = []; let loseResponse = true; let persisted;
  const persist = draft => { persisted = JSON.parse(JSON.stringify(draft)); };
  const original = kind === 'review' ? { id: 'original-id', monster_id: 'charger', action_id: 'hurt', revision: 'r1', clip_id: 'clip', decision: 'needs_work', comment: '原稿', playback_ms: 12000 } : { id: 'original-id', title: '原提案', region: 'forest', details: '原稿' };
  const send = async payload => {
    calls.push({ ...payload });
    const old = rows.get(payload.id);
    if (old && JSON.stringify(old) !== JSON.stringify(payload)) { const error = new Error('同一提交已有其他内容'); error.status = 409; error.code = 'submission_conflict'; throw error; }
    rows.set(payload.id, { ...payload });
    if (loseResponse) { loseResponse = false; throw new Error('201响应在网络中丢失'); }
    return { item: { ...payload } };
  };
  let draft = { ...original };
  await assert.rejects(sendDraftSubmission(draft, original, send, persist), /丢失/);
  assert.equal(rows.size, 1); assert.equal(persisted.id, 'original-id');
  draft = JSON.parse(JSON.stringify(persisted)); // page reload preserves uncertain snapshot
  const field = kind === 'review' ? 'comment' : 'details'; draft[field] = '修改稿';
  const edited = { ...original, [field]: '修改稿' };
  await assert.rejects(sendDraftSubmission(draft, edited, send, persist), error => error.status === 409 && error.code === 'submission_conflict');
  assert.deepEqual(draft.last_submission, original); assert.equal(draft.id, 'original-id');
  assert.equal(draft.submission_error, 'submission_conflict'); assert.equal(rows.size, 1);
  draft = forkSubmissionDraft(draft, 'explicit-new-id'); // only the explicit recovery action does this
  assert.equal(draft[field], '修改稿'); assert.equal(draft.last_submission, null);
  const response = await sendDraftSubmission(draft, { ...edited, id: draft.id }, send, persist);
  assert.equal(response.item.id, 'explicit-new-id'); assert.equal(rows.size, 2);
  assert.deepEqual(rows.get('original-id'), original);
  assert.deepEqual(calls.map(item => item.id), ['original-id', 'original-id', 'explicit-new-id']);
});

test('exact replay retains the same ID and cannot insert another cloud row', async () => {
  const payload = { id: 'stable-id', comment: '原稿' }; let count = 0; const ids = new Set();
  const draft = { ...payload };
  const send = async value => { count++; ids.add(value.id); if (count === 1) throw new Error('unknown result'); return { item: value }; };
  await assert.rejects(sendDraftSubmission(draft, payload, send));
  draft.comment = '修改稿';
  const replay = await sendDraftSubmission(draft, draft.last_submission, send);
  assert.equal(replay.item.id, 'stable-id'); assert.equal(replay.item.comment, '原稿');
  assert.equal(draft.comment, '修改稿'); assert.equal(ids.size, 1);
});

test('revision_changed never exposes a new-ID bypass', async () => {
  const draft = { id: 'old-id', comment: '保留草稿' }; const error = new Error('版本已更新'); error.status = 409; error.code = 'revision_changed';
  await assert.rejects(sendDraftSubmission(draft, { id: draft.id, revision: 'old' }, async () => { throw error; }));
  assert.equal(draft.submission_error, 'revision_changed');
  assert.throws(() => forkSubmissionDraft(draft, 'new-id'), /版本变化/);
  assert.equal(draft.id, 'old-id');
});

test('a response without a confirmed item never turns a draft into a cloud record', async () => {
  const draft = { id: 'unconfirmed-id', comment: '保留' }; let saved;
  await assert.rejects(sendDraftSubmission(draft, { id: draft.id, comment: draft.comment }, async () => ({}), value => { saved = JSON.parse(JSON.stringify(value)); }), /未返回保存确认/);
  assert.equal(saved.id, draft.id); assert.equal(saved.submission_error, 'unconfirmed');
  assert.equal(saved.last_submission.comment, '保留');
});

test('HTML limits and visible descriptions match the API limits', async () => {
  const html = await readFile(new URL('../index.html', import.meta.url), 'utf8');
  assert.match(html, /id="comment"[^>]*maxlength="3000"/);
  assert.match(html, /id="idea-details"[^>]*maxlength="5000"/);
  assert.match(html, /id="idea-title"[^>]*maxlength="100"/);
  for (const limit of ['最多3000字', '最多5000字', '最多100字']) assert.ok(html.includes(limit));
});

test('zoom pan stays within original stage bounds and original view recentres', () => {
  assert.deepEqual(clampPan(999, -999, 2, 400, 225), { x: 200, y: -112.5 });
  assert.deepEqual(clampPan(999, -999, 4, 400, 225), { x: 600, y: -337.5 });
  assert.deepEqual(clampPan(999, -999, 1, 400, 225), { x: 0, y: -0 });
  assert.deepEqual(clampPan(30, 12, 2, 400, 225), { x: 30, y: 12 });
});
