import {sqliteTable, text, integer, index} from 'drizzle-orm/sqlite-core';
export const reviews = sqliteTable('monster_reviews', {
 id:text('id').primaryKey(), owner_id:text('owner_id').notNull(),
 monster_id:text('monster_id').notNull(),monster_name:text('monster_name').notNull(),
 action_id:text('action_id').notNull(),action_label:text('action_label').notNull(),
 revision:text('revision').notNull(),clip_id:text('clip_id').notNull(),clip_label:text('clip_label').notNull(),
 capture_source_commit:text('capture_source_commit').notNull(),media_sha256:text('media_sha256').notNull(),media_url:text('media_url').notNull(),
 playback_ms:integer('playback_ms'),decision:text('decision').notNull(),comment:text('comment').notNull(),
 created_at:text('created_at').notNull(),payload_hash:text('payload_hash').notNull()
},table=>[index('monster_reviews_owner_time').on(table.owner_id,table.created_at,table.id)]);
export const ideas = sqliteTable('monster_ideas',{
 id:text('id').primaryKey(),owner_id:text('owner_id').notNull(),title:text('title').notNull(),region:text('region').notNull(),details:text('details').notNull(),
 status:text('status').notNull(),created_at:text('created_at').notNull(),payload_hash:text('payload_hash').notNull()
},table=>[index('monster_ideas_owner_time').on(table.owner_id,table.created_at,table.id)]);
