import {readFile,writeFile,mkdir,rm,cp,readdir} from 'node:fs/promises';
import {resolve} from 'node:path';
import {validateCatalog} from '../worker/index.js';
const root=resolve(import.meta.dirname,'..');const out=resolve(root,'dist');
const manifest=JSON.parse(await readFile(resolve(root,'.openai/hosting.json'),'utf8'));
const catalog=JSON.parse(await readFile(resolve(root,'data/catalog.json'),'utf8'));
if(!manifest.project_id)throw new Error('Site identity required');
validateCatalog(catalog);
const assets={};
for(const [file,type] of [['index.html','text/html; charset=utf-8'],['styles.css','text/css; charset=utf-8'],['app.js','text/javascript; charset=utf-8']])assets['/'+file]={body:await readFile(resolve(root,'ui',file),'utf8'),type};
try{for(const file of await readdir(resolve(root,'data/posters'))){if(!/^[a-zA-Z0-9_-]+\.(png|jpg|webp)$/.test(file))throw new Error('Unsafe poster name');assets['/posters/'+file]={base64:true,body:(await readFile(resolve(root,'data/posters',file))).toString('base64'),type:file.endsWith('.png')?'image/png':file.endsWith('.webp')?'image/webp':'image/jpeg'};}}catch(error){if(error.code!=='ENOENT')throw error;}
await rm(out,{recursive:true,force:true});await mkdir(resolve(out,'server'),{recursive:true});await mkdir(resolve(out,'.openai'),{recursive:true});
const source=await readFile(resolve(root,'worker/index.js'),'utf8');
await writeFile(resolve(out,'server/index.js'),source+'\nconst CATALOG='+JSON.stringify(catalog)+';\nconst ASSETS='+JSON.stringify(assets)+';\nexport default createWorkshop({catalog:CATALOG,assets:ASSETS});\n');
await writeFile(resolve(out,'.openai/hosting.json'),JSON.stringify(manifest,null,2)+'\n');
await cp(resolve(root,'drizzle'),resolve(out,'drizzle'),{recursive:true});
console.log('Built self-contained Sites Worker; '+catalog.monsters.length+' creatures, assets='+Object.keys(assets).length);
