CREATE TABLE `monster_ideas` (
	`id` text PRIMARY KEY NOT NULL,
	`owner_id` text NOT NULL,
	`title` text NOT NULL,
	`region` text NOT NULL,
	`details` text NOT NULL,
	`status` text NOT NULL,
	`created_at` text NOT NULL,
	`payload_hash` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `monster_ideas_owner_time` ON `monster_ideas` (`owner_id`,`created_at`,`id`);--> statement-breakpoint
CREATE TABLE `monster_reviews` (
	`id` text PRIMARY KEY NOT NULL,
	`owner_id` text NOT NULL,
	`monster_id` text NOT NULL,
	`monster_name` text NOT NULL,
	`action_id` text NOT NULL,
	`action_label` text NOT NULL,
	`revision` text NOT NULL,
	`clip_id` text NOT NULL,
	`clip_label` text NOT NULL,
	`capture_source_commit` text NOT NULL,
	`media_sha256` text NOT NULL,
	`media_url` text NOT NULL,
	`playback_ms` integer,
	`decision` text NOT NULL,
	`comment` text NOT NULL,
	`created_at` text NOT NULL,
	`payload_hash` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `monster_reviews_owner_time` ON `monster_reviews` (`owner_id`,`created_at`,`id`);