class_name PlainsJointRecoilPlan
extends RefCounted
## One semantic challenge source. Collision planes, whole bank volume, visual
## interfaces and protected action space all derive from this source, not Tiles.
const VERSION := "plains-joint-recoil-v3-structured-painted-contour"
const SOURCE_SHA256 := "7e36f24789d104b23e1c2a33a1ae88e761f24ac978d56170dbb79d812fecb314"
const SOURCE_TEXTURE := "res://assets/visual_development/p1_joint_recoil/whole_banks.png"
const MODULE_ID := "plains_recoil_span"
const BANK_DEPTH := 260.0

static func _base_spec() -> Dictionary:
	return {"version":VERSION,"module_id":MODULE_ID,"landing_planes":[{"id":"departure","bank":"bank_left","a":[0.0,600.0],"b":[300.0,600.0],"minimum_solid_depth":40.0},{"id":"receiving","bank":"bank_right","a":[560.0,600.0],"b":[800.0,600.0],"minimum_solid_depth":40.0}],"inner_cliff_shoulders":{"bank_left":[[300.0,600.0],[300.0,650.0],[296.0,675.0],[284.0,701.0],[263.0,722.0],[252.0,751.0]],"bank_right":[[560.0,600.0],[560.0,650.0],[564.0,686.0],[572.0,722.0],[584.0,758.0]]},"lower_contours":{"bank_left":[[252.0,751.0],[226.0,778.0],[180.0,802.0],[116.0,819.0],[62.0,842.0],[0.0,860.0]],"bank_right":[[584.0,758.0],[610.0,788.0],[652.0,814.0],[702.0,823.0],[756.0,844.0],[800.0,860.0]]},"outer_connections":[{"id":"entry_bank_seam","bank":"bank_left","standing_point":[0.0,600.0],"root_point":[0.0,860.0],"direction":[-1.0,0.0]},{"id":"exit_bank_seam","bank":"bank_right","standing_point":[800.0,600.0],"root_point":[800.0,860.0],"direction":[1.0,0.0]}],"ports":{"entry":[20.0,582.0],"exit":[780.0,582.0]},"protected_action_gap":{"rect":[300.0,0.0,260.0,720.0],"minimum_clear_width":120.0,"actual_clear_width":260.0,"meaning":"original standing gap and full upper flight space; no new support within gap"},"ownership_rect":[0.0,600.0,800.0,260.0],"material_coordinates":{"space":"continuous_world","world_origin":[0.0,0.0],"horizontal_period":780.0,"bank_depth":BANK_DEPTH,"surface_y":600.0}}

static func source_spec() -> Dictionary:
	var spec:=_base_spec()
	# Actual final source measurements, sealed to the unaltered PNG. Only
	# non-standing contour/paint registration is calibrated; the original
	# complete 40px slabs, 260px action gap and outer seams stay invariant.
	var samples: Array=[[110,803,1156],[150,800,1155],[190,799,1155],[219,788,1166],[250,715,1227],[300,634,1299],[340,598,1327],[380,571,1361],[420,547,1385],[460,526,1415],[500,507,1426],[540,493,1464],[580,485,1483],[620,507,1472],[660,525,1462],[700,560,1443],[740,578,1422],[780,615,1388],[820,645,1367]]
	var refs: Dictionary={"bank_left":[49.0,110.0,754.0,710.0],"bank_right":[1156.0,110.0,613.0,710.0]}
	var curves: Dictionary={}
	for role: String in ["bank_left","bank_right"]:
		var ref: Array=refs[role]
		var left:=0.0 if role=="bank_left" else 560.0
		var width:=300.0 if role=="bank_left" else 240.0
		var top_inner:=left+width if role=="bank_left" else left
		var source_inner:=float(ref[0])+float(ref[2]) if role=="bank_left" else float(ref[0])
		var source_outer:=float(ref[0]) if role=="bank_left" else float(ref[0])+float(ref[2])
		var inner: Array=[[top_inner,600.0],[top_inner,640.0]]
		# Keep the original solid's complete inner face visible. The 219px
		# painted edge is registered to the 40px end through an explicit UV
		# control, rather than transparently cutting six world pixels away.
		var inner_uv: Array=[[source_inner,110.0],[788.0 if role=="bank_left" else 1166.0,219.0]]
		for row: Array in samples:
			if int(row[0])<=219: continue
			var source_x:=float(row[1] if role=="bank_left" else row[2])
			var world_y:=600.0+(float(row[0])-110.0)/710.0*BANK_DEPTH
			var source_at_solid_end:=788.0 if role=="bank_left" else 1166.0
			var upper_correction:=top_inner-(left+(source_at_solid_end-float(ref[0]))/float(ref[2])*width)
			# Distribute the <=6 world-pixel original-slab correction over the
			# complete lower depth, avoiding a high-shear UV triangle directly
			# below the preserved slab. The measured bottom flare stays exact.
			var recovery:=clampf((860.0-world_y)/220.0,0.0,1.0)
			inner.append([left+(source_x-float(ref[0]))/float(ref[2])*width+upper_correction*recovery,world_y])
			inner_uv.append([source_x,float(row[0])])
		var points: Array=[]
		var visual: Array=[]
		var uv: Array=[]
		var grass_top:=600.0+(10.0-110.0)/710.0*BANK_DEPTH
		if role=="bank_left":
			points.append([left,600.0]);points.append_array(inner.duplicate(true));points.append([left,860.0])
			visual.append([left,grass_top]);uv.append([source_outer,10.0])
			visual.append([top_inner,grass_top]);uv.append([source_inner,10.0])
			visual.append_array(inner.duplicate(true));uv.append_array(inner_uv.duplicate(true))
			visual.append([left,860.0]);uv.append([source_outer,820.0])
		else:
			points.append([left,600.0]);points.append([left+width,600.0]);points.append([left+width,860.0])
			var reverse_inner: Array=inner.duplicate(true);reverse_inner.reverse()
			var reverse_uv: Array=inner_uv.duplicate(true);reverse_uv.reverse()
			points.append_array(reverse_inner.slice(0,reverse_inner.size()-1))
			visual.append([left,grass_top]);uv.append([source_inner,10.0])
			visual.append([left+width,grass_top]);uv.append([source_outer,10.0])
			visual.append([left+width,860.0]);uv.append([source_outer,820.0])
			visual.append_array(reverse_inner);uv.append_array(reverse_uv)
		curves[role]={"physical_points":points,"local_visual_points":visual,"source_uv_px":uv,"physical_reference_rect_px":ref.duplicate(),"source_sha256":SOURCE_SHA256,"source_texture":SOURCE_TEXTURE,"render_mesh":_row_mesh(visual,uv,role)}
		spec.inner_cliff_shoulders[role]=inner.slice(0,5)
		spec.lower_contours[role]=inner.slice(4)
	spec.bank_contours=curves
	spec.paint_registration={"source_sha256":SOURCE_SHA256,"source_texture":SOURCE_TEXTURE,"source_dimensions":[1816,866],"physical_reference_rects_px":refs,"measured_inner_contour_samples_px":samples,"source_standing_y_px":110.0,"source_visual_top_y_px":10.0,"original_solid_depth_world":40.0,"method":"source-measured lower flare plus explicit upper-cliff UV correspondence; physical planes and action gap unchanged"}
	return spec

static func _row_mesh(visual: Array, source_uv: Array, role: String) -> Dictionary:
	# The same measured boundary and source coordinates, with wide cross-bank
	# sections instead of skinny boundary ears. No physics or UV is changed.
	var rows: Array=[]
	var row_uv: Array=[]
	var outer_x:=float(visual[0][0] if role=="bank_left" else visual[1][0])
	var outer_uv_x:=float(source_uv[0][0] if role=="bank_left" else source_uv[1][0])
	if role=="bank_left":
		rows=visual.slice(1,visual.size()-1)
		row_uv=source_uv.slice(1,source_uv.size()-1)
	else:
		rows=[visual[0].duplicate()]
		row_uv=[source_uv[0].duplicate()]
		var reversed_rows: Array=visual.slice(3);reversed_rows.reverse()
		var reversed_uv: Array=source_uv.slice(3);reversed_uv.reverse()
		rows.append_array(reversed_rows);row_uv.append_array(reversed_uv)
	var vertices: Array=[]
	var uv: Array=[]
	var indices: Array=[]
	for index: int in rows.size():
		var inner: Array=rows[index]
		var inner_uv: Array=row_uv[index]
		var outer: Array=[outer_x,inner[1]]
		var outer_uv: Array=[outer_uv_x,inner_uv[1]]
		if role=="bank_left":
			vertices.append(outer);vertices.append(inner.duplicate())
			uv.append(outer_uv);uv.append(inner_uv.duplicate())
		else:
			vertices.append(inner.duplicate());vertices.append(outer)
			uv.append(inner_uv.duplicate());uv.append(outer_uv)
		if index>0:
			var previous: int=(index-1)*2
			indices.append_array([previous,previous+1,previous+2,previous+1,previous+3,previous+2])
	return {"method":"versioned_cross_bank_row_mesh","vertices":vertices,"source_uv_px":uv,"indices":indices,"row_count":rows.size(),"boundary_unchanged":true,"physics_unchanged":true}

static func definition_from_spec(spec: Dictionary) -> PlatformingModuleDefinition:
	var original:=RandomStageGenerator.new().definition_for(MODULE_ID,false,false)
	var result:=original.duplicate(true) as PlatformingModuleDefinition
	result.platforms.clear()
	for plane: Dictionary in spec.landing_planes:
		var a:=_point(plane.a);var b:=_point(plane.b)
		result.platforms.append(Rect2(a,Vector2(b.x-a.x,float(plane.minimum_solid_depth))))
	# All non-geometric challenge requirements, damage, ports and timing remain
	# the original admitted resource. No tuning or capability is invented here.
	return result

static func build_local() -> Dictionary:
	var spec:=source_spec()
	var bodies: Array=[]
	for plane: Dictionary in spec.landing_planes:
		var curve: Dictionary=spec.bank_contours[plane.bank]
		bodies.append({"id":plane.bank,"source_role":plane.bank,"points":curve.physical_points.duplicate(true),"local_visual_points":curve.local_visual_points.duplicate(true),"source_uv_px":curve.source_uv_px.duplicate(true),"source_sha256":curve.source_sha256,"source_texture":curve.source_texture,"physical_reference_rect_px":curve.physical_reference_rect_px.duplicate(),"render_mesh":curve.render_mesh.duplicate(true),"surface_profile":[plane.a.duplicate(),plane.b.duplicate()],"neighbor_interfaces":spec.outer_connections.filter(func(row: Dictionary)->bool:return row.bank==plane.bank).duplicate(true),"material_coordinates":spec.material_coordinates.duplicate(true)})
	return {"version":VERSION,"module_id":MODULE_ID,"semantic_source":spec,"terrain_bodies":bodies,"cutout_rects":[spec.ownership_rect.duplicate()],"keep_clear":[{"kind":"protected_joint_recoil_action_gap","rect":spec.protected_action_gap.rect.duplicate()}],"platforms":definition_from_spec(spec).platforms.map(func(r: Rect2)->Array:return [r.position.x,r.position.y,r.size.x,r.size.y])}

static func instantiate(node: Dictionary) -> Dictionary:
	var local:=build_local()
	var offset:=_point(node.offset)
	var bodies: Array=[]
	for body: Dictionary in local.terrain_bodies:
		var result: Dictionary=body.duplicate(true)
		result.local_points=body.points.duplicate(true)
		result.points=_translate_points(body.points,offset)
		result.visual_points=_translate_points(body.local_visual_points,offset)
		result.local_render_mesh=body.render_mesh.duplicate(true)
		result.render_mesh.vertices=_translate_points(body.render_mesh.vertices,offset)
		result.surface_profile=_translate_points(body.surface_profile,offset)
		for seam: Dictionary in result.neighbor_interfaces:
			seam.standing_point=_translate_point(seam.standing_point,offset)
			seam.root_point=_translate_point(seam.root_point,offset)
		result.material_coordinates.world_origin=[0.0,0.0]
		result.material_coordinates.surface_y=600.0+offset.y
		result.id=str(node.id)+"/"+str(body.id)
		bodies.append(result)
	var cutouts: Array=[]
	for r: Array in local.cutout_rects: cutouts.append([float(r[0])+offset.x,float(r[1])+offset.y,r[2],r[3]])
	var clear: Array=[]
	for row: Dictionary in local.keep_clear:
		var r: Array=row.rect
		clear.append({"kind":row.kind,"owner":node.id,"rect":[float(r[0])+offset.x,float(r[1])+offset.y,r[2],r[3]]})
	return {"version":VERSION,"node_id":node.id,"module_id":MODULE_ID,"offset":node.offset.duplicate(),"semantic_source":local.semantic_source,"terrain_bodies":bodies,"cutout_rects":cutouts,"keep_clear":clear,"derived_platforms":local.platforms,"physics_owner":"actual_joint_bank_polygons_in_region_assembler","production_pool":false}

static func clip_supports(supports: Array, cutouts: Array) -> Array:
	var output: Array=[]
	for raw: Array in supports:
		var pieces: Array[Rect2]=[Rect2(raw[0],raw[1],raw[2],raw[3])]
		for cut: Array in cutouts:
			var obstacle:=Rect2(cut[0],cut[1],cut[2],cut[3])
			var next: Array[Rect2]=[]
			for source: Rect2 in pieces:
				if not source.intersects(obstacle): next.append(source);continue
				var overlap:=source.intersection(obstacle)
				var candidates: Array[Rect2]=[Rect2(source.position,Vector2(overlap.position.x-source.position.x,source.size.y)),Rect2(Vector2(overlap.end.x,source.position.y),Vector2(source.end.x-overlap.end.x,source.size.y)),Rect2(Vector2(overlap.position.x,source.position.y),Vector2(overlap.size.x,overlap.position.y-source.position.y)),Rect2(Vector2(overlap.position.x,overlap.end.y),Vector2(overlap.size.x,source.end.y-overlap.end.y))]
				# Exact clipping keeps even narrow outside ownership strips. The
				# regional mass producer's 12px fragment pruning must not apply.
				for piece: Rect2 in candidates:
					if piece.has_area(): next.append(piece)
			pieces=next
		for piece: Rect2 in pieces: output.append([piece.position.x,piece.position.y,piece.size.x,piece.size.y])
	return output

static func errors(recorded: Dictionary) -> Array[String]:
	var failures: Array[String]=[]
	var expected:=build_local()
	if recorded!=expected: failures.append("Joint semantic source, geometry or interfaces differ from the admitted bounded source")
	return failures

static func _point(value: Array) -> Vector2:return Vector2(float(value[0]),float(value[1]))
static func _translate_point(value: Array, offset: Vector2)->Array:return [float(value[0])+offset.x,float(value[1])+offset.y]
static func _translate_points(values: Array, offset: Vector2)->Array:
	var output: Array=[]
	for value: Array in values: output.append(_translate_point(value,offset))
	return output
