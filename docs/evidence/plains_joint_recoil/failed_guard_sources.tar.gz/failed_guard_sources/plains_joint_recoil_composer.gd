class_name PlainsJointRecoilComposer
extends "res://scripts/art/plains_regional_composer.gd"
## Candidate opt-in: one shared challenge specification owns physical bank
## polygons, neighbor cuts and the complete painted-bank mesh projection.
const JOINT_CATALOG := "res://resources/visual_development/p1_joint_recoil_assets.json"

func _build_layers() -> void:
	if (_plan.get("joint_modules",[]) as Array).is_empty():
		super._build_layers()
		return
	# Actual sky and transparent distant geology are already installed by the
	# inherited global background. Do not add the rejected flat wall belts.
	_facts["joint_background"]={"global_painted_background_preserved":true,"middle_wall_belts_retired":true,"per_seed_images":false}

func _build_terrain() -> void:
	var modules: Array=_plan.get("joint_modules",[])
	if modules.is_empty():
		super._build_terrain()
		return
	var cuts: Array=[]
	for module: Dictionary in modules:
		for raw: Array in module.get("cutout_rects",[]):cuts.append(_rect(raw))
	var original_plan:=_plan
	var projection:=_plan.duplicate(false)
	projection.geological_bodies=_neighbor_projection(cuts)
	_plan=projection
	super._build_terrain()
	_plan=original_plan
	_facts["joint_terrain"]=[]
	_facts["joint_cutouts"]=[]
	for cut: Rect2 in cuts:_facts.joint_cutouts.append([cut.position.x,cut.position.y,cut.size.x,cut.size.y])
	if not FileAccess.file_exists(JOINT_CATALOG):
		_facts.omitted.append({"reason":"joint_recoil_catalog_missing","source":JOINT_CATALOG});return
	var parsed: Variant=JSON.parse_string(FileAccess.get_file_as_string(JOINT_CATALOG))
	if not parsed is Dictionary:
		_facts.omitted.append({"reason":"joint_recoil_catalog_invalid"});return
	var catalog: Dictionary=parsed
	_facts["joint_catalog_path"]=JOINT_CATALOG
	_facts["joint_catalog_sha256"]=FileAccess.get_sha256(JOINT_CATALOG)
	for module: Dictionary in modules:
		for body: Dictionary in module.get("terrain_bodies",[]):
			_install_joint_body(module,body,catalog)

func _neighbor_projection(cuts: Array) -> Array:
	var bodies: Array=[]
	var sources: Dictionary={}
	for solid: Dictionary in _plan.get("solids",[]):sources[str(solid.id)]=solid
	for body: Dictionary in _plan.get("geological_bodies",[]):
		var polygon:=_points(body.get("points",body.get("polygon",[])))
		if polygon.is_empty():continue
		var bounds:=Rect2(polygon[0],Vector2.ZERO)
		for point: Vector2 in polygon:bounds=bounds.expand(point)
		var intersects:=false
		for cut: Rect2 in cuts:
			if bounds.intersects(cut):intersects=true;break
		if not intersects:
			bodies.append(body);continue
		# Exact source rectangles preserve holes and every neighbor outside the
		# plan-owned bank cut. No backdrop erasure, guessed collar or new floor.
		for source_id: String in body.get("source_ids",[]):
			if not sources.has(source_id):continue
			var fragments: Array=[_rect(sources[source_id].rect)]
			for cut: Rect2 in cuts:
				var next: Array=[]
				for fragment: Rect2 in fragments:next.append_array(_subtract_rect(fragment,cut))
				fragments=next
			for fragment: Rect2 in fragments:
				bodies.append({"id":str(body.id)+"/joint_neighbor/"+str(bodies.size()),"points":[[fragment.position.x,fragment.position.y],[fragment.end.x,fragment.position.y],[fragment.end.x,fragment.end.y],[fragment.position.x,fragment.end.y]],"source_ids":[source_id],"holes":[],"joint_cutout_projection":true})
	return bodies

func _install_joint_body(module: Dictionary,body: Dictionary,catalog: Dictionary) -> void:
	var role:=str(body.get("source_role",""))
	var family: Dictionary=catalog.get("terrain",catalog.get("bodies",{}))
	if not family.has(role):
		_facts.omitted.append({"reason":"joint_complete_bank_source_missing","body_id":body.get("id",""),"role":role});return
	var spec: Dictionary=family[role]
	var texture:=_texture(str(spec.get("texture","")))
	if texture==null:return
	var source_sha:=FileAccess.get_sha256(str(spec.texture))
	if str(body.get("source_sha256",""))!=source_sha:
		_facts.omitted.append({"reason":"joint_frozen_source_sha_mismatch","body_id":body.get("id","")});return
	var physical_polygon:=_points(body.get("points",[]))
	var polygon:=_points(body.get("visual_points",body.get("points",[])))
	var indices:=Geometry2D.triangulate_polygon(polygon)
	if physical_polygon.size()<3 or polygon.size()<3 or indices.is_empty():
		_facts.omitted.append({"reason":"joint_shared_bank_polygon_invalid","body_id":body.get("id","")});return
	var bounds:=Rect2(physical_polygon[0],Vector2.ZERO)
	for point: Vector2 in physical_polygon:bounds=bounds.expand(point)
	var region_raw: Array=spec.get("source_region_px",[0.0,0.0,float(texture.get_width()),float(texture.get_height())])
	var source:=_rect(spec.get("physical_reference_rect_px",region_raw))
	if not source.has_area() or bounds.size.x<=0.0 or bounds.size.y<=0.0:
		_facts.omitted.append({"reason":"joint_source_reference_invalid","body_id":body.get("id","")});return
	var uv:=PackedVector2Array()
	var explicit: Array=body.get("source_uv_px",[])
	if explicit.size()!=polygon.size():
		_facts.omitted.append({"reason":"joint_versioned_source_uv_missing","body_id":body.get("id","")});return
	uv=_points(explicit)
	for point: Vector2 in uv:
		if not point.is_finite() or point.x<0.0 or point.y<0.0 or point.x>texture.get_width() or point.y>texture.get_height():
			_facts.omitted.append({"reason":"joint_source_uv_outside_original","body_id":body.get("id","")});return
	var scales:=Vector2(bounds.size.x/source.size.x,bounds.size.y/source.size.y)
	var aspect_warp:=maxf(scales.x,scales.y)/maxf(0.000001,minf(scales.x,scales.y))
	var admitted_warp:=minf(1.35,float(spec.get("max_aspect_warp",1.35)))
	var local_warp:=_maximum_triangle_warp(polygon,uv,indices)
	aspect_warp=maxf(aspect_warp,local_warp)
	if not is_finite(aspect_warp) or aspect_warp>admitted_warp:
		_facts.omitted.append({"reason":"joint_whole_painting_aspect_warp_refused","body_id":body.get("id",""),"actual_aspect_warp":aspect_warp,"admitted_aspect_warp":admitted_warp});return
	var node:=Polygon2D.new()
	node.name="JointWholeBank_"+str(body.get("id",role)).validate_node_name()
	node.polygon=polygon
	node.uv=uv
	node.texture=texture
	node.texture_repeat=CanvasItem.TEXTURE_REPEAT_DISABLED
	node.z_index=-2
	add_child(node)
	var source_uv: Array=[]
	var actual_points: Array=[]
	for point: Vector2 in uv:source_uv.append([point.x,point.y])
	for point: Vector2 in node.polygon:
		var actual:=node.global_transform*point
		actual_points.append([actual.x,actual.y])
	var receipt: Dictionary={"id":body.get("id",role),"module_id":module.get("node_id",""),"source_role":role,"source":spec.texture,"source_sha256":FileAccess.get_sha256(str(spec.texture)),"source_dimensions":[texture.get_width(),texture.get_height()],"source_region_px":region_raw,"physical_reference_rect_px":[source.position.x,source.position.y,source.size.x,source.size.y],"shared_physical_polygon":body.get("points",[]),"source_uv_px":source_uv,"actual_world_polygon":actual_points,"shared_surface_profile":body.get("surface_profile",[]),"neighbor_interfaces":body.get("neighbor_interfaces",[]),"actual_aspect_warp":aspect_warp,"admitted_aspect_warp":admitted_warp,"node_path":str(node.get_path()),"mapping":"one explicit complete-volume mesh; no per-fragment surface search, mirrored core, alpha strips or texture repeat","collision_written":false,"physical_geometry_source":"same joint specification; renderer does not author physics"}
	_facts.joint_terrain.append(receipt)
	_facts.terrain.append(receipt.duplicate(true))

static func _maximum_triangle_warp(points: PackedVector2Array,uv: PackedVector2Array,indices: PackedInt32Array) -> float:
	var worst:=1.0
	for index: int in range(0,indices.size(),3):
		var a:=indices[index];var b:=indices[index+1];var c:=indices[index+2]
		var u:=uv[b]-uv[a];var v:=uv[c]-uv[a]
		var p:=points[b]-points[a];var q:=points[c]-points[a]
		var determinant:=u.cross(v)
		if absf(determinant)<0.000001 or determinant*p.cross(q)<=0.0:return INF
		var x:=(p*v.y-q*u.y)/determinant
		var y:=(q*u.x-p*v.x)/determinant
		var trace:=x.length_squared()+y.length_squared()
		var area:=x.cross(y)
		var discriminant:=sqrt(maxf(0.0,trace*trace-4.0*area*area))
		var lower:=(trace-discriminant)*0.5
		if lower<=0.0000000001:return INF
		worst=maxf(worst,sqrt((trace+discriminant)*0.5/lower))
	return worst

static func _subtract_rect(source: Rect2,cut: Rect2) -> Array:
	if not source.intersects(cut):return [source]
	var overlap:=source.intersection(cut)
	var fragments: Array=[]
	if overlap.position.y>source.position.y:fragments.append(Rect2(source.position,Vector2(source.size.x,overlap.position.y-source.position.y)))
	if overlap.end.y<source.end.y:fragments.append(Rect2(Vector2(source.position.x,overlap.end.y),Vector2(source.size.x,source.end.y-overlap.end.y)))
	if overlap.position.x>source.position.x:fragments.append(Rect2(Vector2(source.position.x,overlap.position.y),Vector2(overlap.position.x-source.position.x,overlap.size.y)))
	if overlap.end.x<source.end.x:fragments.append(Rect2(Vector2(overlap.end.x,overlap.position.y),Vector2(source.end.x-overlap.end.x,overlap.size.y)))
	return fragments
