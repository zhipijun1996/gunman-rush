"""Independent Git-object/source-review chain binding; does not execute gameplay."""
import ast,hashlib,json,pathlib,re,subprocess
ROOT=pathlib.Path.cwd();BASE='6c61faadd511c48a267b975550da897e701fd09f';S1='7ba2e92d2c3cb5449ac6648b820f79679548ee89';D=ROOT/'docs/quality/reviews/FOREST-GRAPPLE-02';OUT=ROOT/'build/verification/verifier_migration_review'
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
def load(name):return json.loads((D/name).read_text())
changed=git('diff','--name-only',BASE,S1,'--','tests','tools').decode().splitlines();card=json.loads((ROOT/'docs/quality/records/FOREST-GRAPPLE-CONSUMERS-02.json').read_text())
matrixpath=ROOT/'build/forest_grapple02/matrix16_final02/receipt.json';matrix=json.loads(matrixpath.read_text());matrix_review=load('verifier_matrix16_appendix01.json')
checks={'exact_commit_exists':git('rev-parse',S1).decode().strip()==S1,'all_final_test_tool_paths_covered_by_child':set(changed)=={p for p in card['affected_paths'] if p.startswith(('tests/','tools/'))},'exact_40_changed_tests_tools':len(changed)==40,'matrix_receipt_same_independent_review_hash':hashlib.sha256(matrixpath.read_bytes()).hexdigest()==matrix_review['receipt_sha256'],'matrix_source_inventory_still_exact':matrix['source_before']==matrix['source_after_import']==matrix['source_after'] and matrix['source_stable'] is True}
process=subprocess.Popen(['git','cat-file','--batch'],cwd=ROOT,stdin=subprocess.PIPE,stdout=subprocess.PIPE)
bindings={};mismatches=[]
for path,expected in matrix['source_after'].items():
 process.stdin.write((S1+':'+path+'\n').encode());process.stdin.flush();header=process.stdout.readline().decode().strip().split()
 if len(header)!=3 or header[1]!='blob':raise RuntimeError('Unexpected Git object header '+str(header))
 blob,_,count=header;remaining=int(count);digest=hashlib.sha256()
 while remaining:
  chunk=process.stdout.read(min(remaining,1<<20))
  if not chunk:raise RuntimeError('Truncated Git blob')
  digest.update(chunk);remaining-=len(chunk)
 if process.stdout.read(1)!=b'\n':raise RuntimeError('Git blob delimiter missing')
 current=digest.hexdigest();bindings[path]={'sha256':current,'git_blob':blob,'bytes':int(count)}
 if current!=expected:mismatches.append({'path':path,'original_native_sha256':expected,'git_sha256':current})
process.stdin.close();process.stdout.close();code=process.wait();checks['independent_all2127_Git_blob_bindings']=len(bindings)==2127 and not mismatches and code==0
# Exact frozen reader-review chain. This creates a new binding, not rewriting old records.
chain=dict(load('verifier_counterexamples04.json')['reviewed_sha256']);evidence={p:'verifier_counterexamples04.json' for p in chain}
for row in load('verifier_marker_appendix01.json')['changed']:chain[row['path']]=row['current_sha256'];evidence[row['path']]='verifier_marker_appendix01.json'
chain['tools/harness/profiles.json']=load('verifier_output_token_appendix01.json')['current_sha256'];evidence['tools/harness/profiles.json']='verifier_output_token_appendix01.json'
for name in ['verifier_rhr_appendix01.json','verifier_canopy_derivation_appendix01.json','verifier_return_aperture_appendix01.json']:
 for p,h in load(name)['source_sha256'].items():chain[p]=h;evidence[p]=name
reviewed={};chain_gaps=[]
for p in changed:
 info=bindings[p];h=info['sha256'];reason=evidence.get(p)
 if chain.get(p)!=h:
  if p in ['tests/forest_root_retry_runner.gd.uid','tests/forest_vertical_shortcut_runner.gd.uid']:
   content=git('show',S1+':'+p).decode();uid_valid=bool(re.fullmatch(r'uid://[a-z0-9]+\n',content));duplicates=[q for q in bindings if q.endswith('.uid') and git('show',S1+':'+q).decode()==content];reason='S1 independent single-line UID/uniqueness + original same-source2127 native inventory'
   if not uid_valid or duplicates!=[p]:chain_gaps.append(p)
  else:chain_gaps.append(p)
 reviewed[p]={**info,'review_chain_evidence':reason,'working_bytes_equal_commit':hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==h}
checks['all_40_paths_review_chain_or_UID_metadata_covered']=not chain_gaps;checks['all_40_working_bytes_equal_commit']=all(v['working_bytes_equal_commit'] for v in reviewed.values())
# Original cases/profiles/readers retained, with one authorized exact marker update.
oldprofiles=json.loads(git('show',BASE+':tools/harness/profiles.json'));profiles=json.loads(git('show',S1+':tools/harness/profiles.json'))
checks['old_profile_check_order_retained']=all([name for name in profiles['profiles'][key] if name in oldlist]==oldlist for key,oldlist in oldprofiles['profiles'].items())
checks['original_check_configs_except_exact18_marker_preserved']=all(profiles['checks'][name]==(dict(value,success_pattern='^FOREST AIR CHAIN SUITE: passed / 18 cases$') if name=='forest-air-chain' else value) for name,value in oldprofiles['checks'].items())
def assignment(s,name):return next(ast.literal_eval(n.value) for n in ast.parse(s).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in n.targets))
oldair=assignment(git('show',BASE+':tools/run_forest_air_chain.py').decode(),'SUITE_CASES');newair=assignment(git('show',S1+':tools/run_forest_air_chain.py').decode(),'SUITE_CASES');checks['original9_and_full18_suite_retained']=len(oldair)==9 and len(newair)==18 and newair[:9]==oldair
checks['strict_output_token_marker_retained']=profiles['checks']['forest-vertical-shortcut']['argv'][-1]=='build/verification/forest-vertical-shortcut/harness-{check_token}' and profiles['checks']['forest-vertical-shortcut']['success_pattern']=='^FOREST VERTICAL SHORTCUT: passed$'
def fn(s,name):return ast.get_source_segment(s,next(n for n in ast.parse(s).body if isinstance(n,ast.FunctionDef) and n.name==name))
oldregion=git('show',BASE+':tools/run_forest_depth_region.py').decode();newregion=git('show',S1+':tools/run_forest_depth_region.py').decode();checks['original_full_projectile_causal_reader_unchanged']=fn(oldregion,'actual_projectile_energy_credits')==fn(newregion,'actual_projectile_energy_credits')
oldversions=git('show',BASE+':tools/run_forest_depth_versions.py').decode();newversions=git('show',S1+':tools/run_forest_depth_versions.py').decode();checks['all3_original_version_readers_unchanged']=all(fn(oldversions,n)==fn(newversions,n) for n in ['validate','validate_recorded_current','validate_current'])
checks['original_forged_credit_REJECT_history_preserved']=load('verifier_counterexamples02.json')['forged_shortcut_credit_rejected'] is False and load('verifier_counterexamples04.json')['forged_shortcut_credit_rejected'] is True
checks['original_attachment_forgery_REJECT_history_preserved']=all(c['errors']==[] for c in load('verifier_recovery_counterexamples01.json')['cases']) and all(c['errors'] for c in load('verifier_recovery_counterexamples02.json')['cases'] if c['kind']!='positive')
checks['matrix_raw_source_head_not_retagged']=matrix['source_head']==BASE
r={'task_id':'FOREST-GRAPPLE-CONSUMERS-02','reviewer':'/root/verifier_migration_review','review_type':'commit-bound consumer integration review','baseline_commit':BASE,'reviewed_commit':S1,'scope':'Only final test/tool contract migrations and byte binding of prior actual representative evidence; no new native/full-test execution or content/player/device admission','checks':checks,'independent_Git_input_count':len(bindings),'independent_Git_mismatches':mismatches,'chain_gaps':chain_gaps,'affected_tests_tools_sha256':reviewed,'native_inventory_sha256':hashlib.sha256(json.dumps(matrix['source_after'],sort_keys=True,separators=(',',':')).encode()).hexdigest(),'matrix_receipt_original_source_head':matrix['source_head'],'matrix_receipt_sha256':hashlib.sha256(matrixpath.read_bytes()).hexdigest(),'parent_root_binding_reference':'build/forest_grapple02/committed_native_binding01.json','evidence_chain':['docs/quality/reviews/FOREST-GRAPPLE-02/'+name for name in ['verifier_review01.md','verifier_review02.md','verifier_counterexamples04.json','verifier_marker_appendix01.json','verifier_output_token_appendix01.json','verifier_rhr_appendix01.md','verifier_canopy_harness_appendix01.md','verifier_harness_load_tests_appendix01.json','verifier_return_aperture_appendix01.md','verifier_matrix16_appendix01.md']],'unverified':['Final original80-route corpus','Final full89-check CI','Whole region gameplay/fun/visual/audio acceptance','Physical device/player acceptance','Web release of S1']}
r['verdict']='ACCEPT' if all(checks.values()) else 'REJECT';(OUT/'commit_s1_review.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'verdict':r['verdict'],'checks':checks,'affected_count':len(reviewed),'Git_inputs':len(bindings),'chain_gaps':chain_gaps},indent=2))
