from pathlib import Path
import sys,json,time,contextlib,os,subprocess,hashlib,zipfile
ROOT=Path('/tmp/gunman-forest-variety-03/module-runtime-snapshot')
BASE_ROOT=Path('/workspace/gunman-rush')
os.environ.setdefault('GUNMAN_TOOLCHAIN_ROOT',str(BASE_ROOT.parent/'toolchains'))
os.chdir(ROOT);sys.path.insert(0,str(ROOT/'tools'))
from run_tests import run_engine
from forest_bible_world_sources import inventory
out=ROOT/'build/variety-round03';out.mkdir(parents=True,exist_ok=False)
r={'scope':'eight_isolated_candidates_actual_Router_Motor_not_world_FUN_or_formal_damage_policy','engine_lease':'root_only_independent_complete_runtime_snapshot','import_cap':90,'native_cap':240,'exit_code':1};t=time.monotonic()
try:
 with (out/'prepare-import.log').open('w') as log,contextlib.redirect_stdout(log):run_engine(['--headless','--path','.','--editor','--quit'],90)
 before=inventory();(out/'source-before.json').write_text(json.dumps(before,sort_keys=True));r['source_paths']=len(before)
 blobs={}
 for row in subprocess.check_output(['git','ls-tree','-r','-z','ee0b646e779b4680319e9a377518b27c10bfbe87'],cwd=BASE_ROOT).split(b'\0'):
  if not row:continue
  meta,path=row.split(b'\t',1);blobs[path.decode()]=meta.split()[2].decode()
 changed=[]
 with zipfile.ZipFile(out/'changed-source.zip','x',zipfile.ZIP_DEFLATED) as z:
  for path,sha in before.items():
   data=(ROOT/path).read_bytes();assert hashlib.sha256(data).hexdigest()==sha,path
   oid=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
   if blobs.get(path)!=oid:z.writestr(path,data);changed.append(path)
 (out/'source-closure.json').write_text(json.dumps({'baseline_commit':'ee0b646e779b4680319e9a377518b27c10bfbe87','source_paths':len(before),'changed_paths':changed,'complete_inventory':'source-before.json','changed_bytes':'changed-source.zip','unchanged':'exact baseline Git blob equality'},indent=2))
 results=[]
 ids=['forked_bough_hh','side_root_rh','rooted_double_window','descending_borer_elbow','fallen_arch_canopy','thorn_side_outlet','l_hollow_reward_loop','z_hollow_inner_cache']
 for module_id in ids:
  try:
   with (out/(module_id+'.log')).open('w') as log,contextlib.redirect_stdout(log):
    text=run_engine(['--headless','--fixed-fps','60','--path','.','--script','tests/forest_varied_module_runner.gd','--','--layout='+module_id,'--output=res://build/variety-round03/'+module_id+'.json'],240)
   data=json.loads((out/(module_id+'.json')).read_text());ok=data.get('passed') is True and 'FOREST VARIED LOCAL: PASS' in text
   row={'module':module_id,'passed':ok,'reached':data.get('reached'),'failure':data.get('failure'),'frames':len(data.get('frames',[]))}
  except Exception as e:row={'module':module_id,'passed':False,'error':str(e)}
  results.append(row);print(json.dumps(row),flush=True)
 r['cases']=results;r['exit_code']=0 if all(x['passed'] for x in results) else 1
 after=inventory();(out/'source-after.json').write_text(json.dumps(after,sort_keys=True));r['source_stable']=before==after
 if before!=after:r['exit_code']=1
except Exception as e:r['error']=str(e)
r['seconds']=time.monotonic()-t;(out/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)
