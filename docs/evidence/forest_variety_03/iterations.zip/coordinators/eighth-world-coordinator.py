from pathlib import Path
import sys,json,time,contextlib,subprocess,hashlib,zipfile,os
ROOT=Path('/workspace/gunman-rush');sys.path.insert(0,str(ROOT/'tools'))
from run_tests import run_engine
from forest_bible_world_sources import inventory
out=Path('/tmp/gunman-forest-variety-03/round08');out.mkdir(parents=True,exist_ok=False)
link=ROOT/'build/region_bible_v2/forest-variety-03-round08';link.symlink_to(out,target_is_directory=True)
r={'scope':'actual_v17_composition_and_local_full_world_connections_not_release','import_cap':90,'native_cap':240,'exit_code':1};start=time.monotonic();before=None
try:
 with (out/'prepare-import.log').open('w') as log,contextlib.redirect_stdout(log):run_engine(['--headless','--path','.','--editor','--quit'],90)
 before=inventory();(out/'source-before.json').write_text(json.dumps(before,sort_keys=True));r['source_paths']=len(before)
 blobs={}
 for row in subprocess.check_output(['git','ls-tree','-r','-z','HEAD'],cwd=ROOT).split(b'\0'):
  if row:
   meta,path=row.split(b'\t',1);blobs[path.decode()]=meta.split()[2].decode()
 changed=[]
 with zipfile.ZipFile(out/'changed-source.zip','x',zipfile.ZIP_DEFLATED) as z:
  for path,sha in before.items():
   data=(ROOT/path).read_bytes();assert hashlib.sha256(data).hexdigest()==sha
   if blobs.get(path)!=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest():z.writestr(path,data);changed.append(path)
 (out/'source-closure.json').write_text(json.dumps({'baseline_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'source_paths':len(before),'changed_paths':changed,'complete_inventory':'source-before.json','changed_bytes':'changed-source.zip','unchanged':'exact baseline Git blob equality'},indent=2))
 git_before=subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all'],cwd=ROOT);r['git_head']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
 cases=[]
 for index,route in [(1,'varied_main_trial'),(1,'varied_outer_trial'),(1,'varied_l_trial')]:
  cases.append(('fixture-'+route,'tests/forest_varied_fixture_runner.gd',['--route='+route,'--map='+str(index),'--seed=forest-variety-00','--output=res://build/region_bible_v2/forest-variety-03-round08/fixture-'+route+'.json']))
 cases.append(('formal-annex','tests/forest_varied_motor_runner.gd',['--route=varied_annex_approach','--map=1','--seed=forest-variety-00','--output=res://build/region_bible_v2/forest-variety-03-round08/formal-annex.json']))
 displaybin=ROOT/'build/forest_revision04/display-final-W6/runtime/usr/bin/Xvfb'
 xvfb=subprocess.Popen([str(displaybin),'-displayfd','1','-screen','0','1280x720x24','-nolisten','tcp','-ac'],stdout=subprocess.PIPE,stderr=(out/'xvfb.log').open('w'))
 display=xvfb.stdout.readline().decode().strip();os.environ.update(DISPLAY=':'+display,LIBGL_ALWAYS_SOFTWARE='1',OMP_NUM_THREADS='1',LP_NUM_THREADS='1')
 try:
  with (out/'actual-golden.log').open('w') as log,contextlib.redirect_stdout(log):gpu=run_engine(['--path','.','--rendering-method','gl_compatibility','--audio-driver','Dummy','--script','tests/forest_varied_golden_runner.gd','--','--output=res://build/region_bible_v2/forest-variety-03-round08/golden'],90)
  r['golden_passed']='FOREST VARIED GOLDEN: 14 images / 0 failures' in gpu
 finally:
  xvfb.terminate();xvfb.wait(timeout=10)
 results=[]
 for name,script,args in cases:
  try:
   with (out/(name+'.log')).open('w') as log,contextlib.redirect_stdout(log):text=run_engine(['--headless','--fixed-fps','60','--path','.','--script',script,'--',*args],240)
   results.append({'name':name,'passed':'FOREST VARIED WORLD:' in text and '0 failures' in text if name=='world' else 'FOREST EXPANDED MENU:' in text and '0 failures' in text if name=='menu' else ('FOREST VARIED FIXTURE: PASS' in text if name.startswith('fixture-') else 'FOREST VARIED MOTOR: PASS' in text)})
  except Exception as e:results.append({'name':name,'passed':False,'error':str(e)})
  print(json.dumps(results[-1]),flush=True)
 r['cases']=results;r['source_stable']=inventory()==before;r['git_stable']=git_before==subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all'],cwd=ROOT)
 r['exit_code']=0 if r['golden_passed'] and all(x['passed'] for x in results) and r['source_stable'] and r['git_stable'] else 1
except Exception as e:r['error']=str(e)
finally:
 if before is not None:(out/'source-after.json').write_text(json.dumps(inventory(),sort_keys=True))
 r['seconds']=time.monotonic()-start;(out/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)
