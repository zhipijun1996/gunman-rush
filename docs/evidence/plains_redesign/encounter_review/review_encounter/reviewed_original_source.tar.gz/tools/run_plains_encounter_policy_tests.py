"""Original Harness specialty: actual input, causal receipts and versioned replay.

Native fixtures are labelled fixtures. Four paired formal captures and a live
normal-failure/retry retain failures; a captured route failure is not a pass.
"""
from __future__ import annotations
import copy
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
import time

import harness
import level_formal as formal
import level_experience as experience
from level_design import ROOT, read, write
from run_plains_action_golden_tests import frozen_project

MARKER = r"^PLAINS ENCOUNTER POLICY: [1-9]\d* assertions, 0 failures, [1-9]\d* cases$"
ERRORS = r"SCRIPT ERROR:|Parse Error:|SHADER ERROR:|ERROR: Failed to load script"
CASES = [("level-design-v2-baseline",1,"return"), ("level-design-v2-baseline",2,"fast"),
         ("level-design-v2-baseline",2,"growth"), ("level-design-v2-baseline/01",1,"fast")]


def require(ok, reason):
    if not ok: raise ValueError(reason)


def validate_native(data, recovery=False):
    require(data.get("artifact_kind")=="actual_encounter_policy_proof" and data.get("schema_version")==1 and data.get("failures")==0 and data.get("assertions",0)>0,"empty/failed native proof")
    rows=data.get("cases",[])
    require(isinstance(rows,list) and bool(rows),"missing actual cases")
    expected={"formal_pit_return_retry"} if recovery else {"solid_occlusion","cooldown_rejected","air_energy_rejected"}|{"kill_and_dead_"+b for b in ["patrol","charger","diver","hopper","sentry","fan_sentry"]}|{"bait_state_"+b for b in ["charger","diver","hopper","sentry","fan_sentry"]}
    require({r.get("id") for r in rows}==expected and len(rows)==len(expected),"actual case matrix incomplete/repeated")
    for row in rows:
        frames=row.get("frames"); events=row.get("events")
        require(isinstance(frames,list) and bool(frames) and isinstance(events,list),"empty actual trajectory")
        require([f.get("tick") for f in frames]==list(range(1,len(frames)+1)),"discontinuous actual physics observation")
        if recovery:
            require(row.get("scope")=="actual_live_DemoApp_normal_start" and row.get("same_scene") is True,"wrong formal consumer")
            returns=[e for e in events if e.get("kind")=="segment_returned"]
            damage=[e for e in events if e.get("kind")=="damage_committed" and e.get("target")=="player" and e.get("damage_kind")==1]
            require(len(returns)==1 and len(damage)==1 and returns[0]["tick"]==damage[0]["tick"],"failure/recovery lacks actual environment causality")
            require(row["before_health"]-row["after_health"]==1 and row["after_session"]==row["before_session"]+1 and row.get("recovery_count")==1,"invalid selective recovery")
            require(row.get("latch_open") is True and row.get("claimed_after") is True and row["wallet_before"]==row["wallet_after"],"committed world/reward state not retained")
            require(any(e.get("kind")=="jump_accepted" and e["tick"]>returns[0]["tick"] for e in events),"missing actual retry jump")
            require(sum((a-b)**2 for a,b in zip(row["retry_position"],row["expected_exit"]))<4 and frames[-1]["grounded"],"retry never reaches grounded exit")
            require(any(o.get("kind")=="actual_cache_claim" and o.get("claimed") and o.get("chest")==row["reward_id"] for o in row.get("policy_observations",[])),"reward was never actually claimed before failure")
            observations={o.get("kind"):o for o in row.get("policy_observations",[])}
            require(observations.get("unopened_modal_rejected",{}).get("accepted") is False,"unopened UI callback not rejected")
            wrong=observations.get("actual_wrong_choice_rejected",{})
            require(wrong.get("queued") is True and wrong.get("rejected") is True and wrong.get("claimed") is False and wrong.get("modal_opened") is True,"invalid queued choice bypassed transaction rejection")
            duplicate=observations.get("actual_duplicate_claim_rejected",{})
            require(duplicate.get("accepted") is False and duplicate.get("rejected") is True and duplicate.get("balance")==row["wallet_after"],"duplicate claim accepted or double granted")
            require(row["after_actor_epoch"]==row["before_actor_epoch"]+1,"selective return actor epoch did not advance")
            energy=row["before_resources"]["shot_energy"]["current"]
            recovery_rate=row["before_resources"]["shot_energy"]["ground_energy_recovery"]/row["before_resources"]["physics_hz"]
            for frame in frames[row["failure_start_tick"]:row["return_tick"]]:
                require(frame["shot_energy"]-energy <= recovery_rate+.0001,"return injected shooting energy")
                energy=frame["shot_energy"]
            require(row["before_runtime"]["enemy_count"]==row["returned_runtime"]["enemy_count"] and row["before_runtime"]["claimed_ids"]==row["returned_runtime"]["claimed_ids"],"return reset committed world state")
            continue
        require(row.get("scope")=="normally_scheduled_real_physics_fixture_not_formal_region","fixture scope cannot sign formal route")
        shots=[e for e in events if e.get("kind")=="shot"]
        committed=[e for e in events if e.get("kind")=="committed" and e.get("target")=="fixture_enemy"]
        receipts=row.get("receipts",[])
        inputs=[a for f in frames for a in f.get("requests",[])]
        require((bool(inputs) or any(f.get("axis")!=0 for f in frames)) and all(any(a.get("type")=="shoot_release" for a in frames[e["tick"]-1]["requests"]) for e in shots),"accepted shot without actual Router input")
        ids={s.get("event_id") for s in shots}
        require(len(ids)==len(shots) and all(e.get("event_id") in ids for e in committed),"damage not bound to actual accepted projectile")
        require(all(any(r["event_id"]==f"shot/{row['session']}/{s['shot_id']}" and r["status"]==0 and r["operation"]=="consume" and r["amount_applied"]==-r["requested_amount"] for r in receipts) for s in shots),"missing APPLIED actual shot consumption")
        if row["id"].startswith("kill_and_dead_"):
            require(row.get("enemy_terminal") is True and row.get("enemy_health")==0 and len(committed)==3 and committed[-1].get("lethal") is True,"metadata-only enemy kill")
            require(len(shots)>len(committed) and shots[-1]["tick"]>committed[-1]["tick"],"missing actual post-death shot")
            require(not any(r["event_id"]==f"hit/{row['session']}/{shots[-1]['shot_id']}" for r in receipts),"dead target gave refund")
            require(row.get("initial_engagement_ineligible") is True and frames[0].get("actor_processing") is True,"inactive fixture was engine-disabled")
        elif row["id"]=="solid_occlusion":
            require(len(shots)==1 and not committed and row["enemy_health"]>0,"real blocker failed to block damage")
        elif row["id"]=="cooldown_rejected":
            require(len(shots)==1 and any(e.get("kind")=="rejected" and e.get("reason")=="cooldown" for e in events),"real cooldown did not reject")
        elif row["id"]=="air_energy_rejected":
            require(len(shots)==5 and frames[-1]["energy"]==0 and not frames[-1]["grounded"] and any(e.get("kind")=="rejected" and e.get("reason")=="energy" for e in events),"no actual zero-energy air rejection")
        else:
            states={e.get("state") for e in events if e.get("kind")=="enemy_state"}
            require({"telegraph","attack","recovery"}<=states and row.get("enemy_health",0)>0 and row.get("observed_recovery") is True,"bait was not actual living AI phase")
            if not row["id"].endswith(("sentry","fan_sentry")):require(row.get("body_moved") is True,"moving-away label lacks body motion")
    return True


def native_run(folder, recovery=False):
    output=folder/("recovery.json" if recovery else "native.json"); log=output.with_suffix(".log")
    command=["bash","tools/godot.sh","--headless","--fixed-fps","60","--path",".","--script","tests/plains_encounter_policy_runner.gd","--","--output=res://"+output.relative_to(ROOT).as_posix()]
    if recovery:command.append("--recovery-only")
    result=harness.run_check({"argv":command,"timeout_seconds":180,"success_pattern":MARKER},log,ROOT)
    require(result["status"]=="passed" and not re.search(ERRORS,log.read_text()),"actual native/recovery process failed")
    data=read(output);validate_native(data,recovery)
    return {"output":str(output.relative_to(ROOT)),"sha256":formal.file_hash(output),"log":str(log.relative_to(ROOT)),"log_sha256":formal.file_hash(log),"command":command,"process":result},data


def policy_tamper_checks(capture):
    # Same actual capture, deliberate mutations. These only test the verifier.
    mutations={"empty_frames":lambda d:d.update(frames=[]),
               "missing_shot_receipt":lambda d:d.update(resource_receipts=[r for r in d["resource_receipts"] if r["operation"]!="consume"]),
               "missing_shot_event":lambda d:d.update(events=[e for e in d["events"] if e["kind"]!="shot_accepted"]),
               "forged_damage_event":lambda d:next(e for e in d["events"] if e["kind"]=="damage_committed" and str(e.get("source","")).startswith("player_projectile:")).update(event_id="fake"),
               "missing_driver_dependency":lambda d:d["policy_basis"]["driver_sources"].pop(next(iter(d["policy_basis"]["driver_sources"]))),
               "missing_core_dependency":lambda d:d["policy_basis"]["core_invariants"].pop("res://scripts/player/player_motor.gd"),
               "unknown_mode":lambda d:d.update(encounter_policy="all_fun_pass")}
    rejected=[]
    for name,mutate in mutations.items():
        bad=copy.deepcopy(capture);mutate(bad)
        try:experience.validate_capture(bad)
        except (ValueError,KeyError):rejected.append(name)
        else:raise ValueError("causal tamper accepted: "+name)
    return rejected


def main():
    base=ROOT/"build/verification/plains-encounter";base.mkdir(parents=True,exist_ok=True)
    folder=Path(tempfile.mkdtemp(prefix="run_",dir=base));before=formal.source_files()
    verifier_sources={p:formal.file_hash(ROOT/p) for p in ["tools/run_plains_encounter_policy_tests.py","tools/level_experience.py"]}
    receipt={"schema_version":1,"status":"failed","source_before":before,"source_commit":subprocess.check_output(["git","rev-parse","HEAD"],cwd=ROOT,text=True).strip(),"scope":"technical actual-input fixtures/live recovery/paired old-new observation; not all routes, device or subjective acceptance","runs":[],"verifier_sources":verifier_sources}
    try:
        native,native_data=native_run(folder);receipt["runs"].append(native)
        recovery,recovery_data=native_run(folder,True);receipt["runs"].append(recovery)
        rejected=[]
        for name,data,mutate,recovery_flag in [
            ("remove_committed",native_data,lambda d:next(c for c in d["cases"] if c["id"].startswith("kill_and_dead_")).update(events=[]),False),
            ("remove_input",native_data,lambda d:[f.update(requests=[]) for c in d["cases"] for f in c["frames"]],False),
            ("remove_return",recovery_data,lambda d:d["cases"][0].update(events=[e for e in d["cases"][0]["events"] if e["kind"]!="segment_returned"]),True),
            ("fake_claim",recovery_data,lambda d:d["cases"][0].update(claimed_after=False),True),
            ("fake_ui_rejection",recovery_data,lambda d:next(o for o in d["cases"][0]["policy_observations"] if o.get("kind")=="actual_wrong_choice_rejected").update(rejected=False),True)]:
            bad=copy.deepcopy(data);mutate(bad)
            try:validate_native(bad,recovery_flag)
            except ValueError:rejected.append(name)
            else:raise ValueError("native tamper accepted "+name)
        receipt["native_tamper_rejected"]=rejected
        project,frozen=frozen_project(folder/"frozen_v9")
        unchanged={name:formal.file_hash(project/name) for name in frozen["members"] if name.startswith(("scripts/","scenes/","resources/","config/","shaders/")) or name=="project.godot"}
        closure=formal.driver_source_paths()
        for name in closure:
            destination=project/name;destination.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ROOT/name,destination)
        require(all(formal.file_hash(project/name)==formal.file_hash(ROOT/name) for name in closure),"old/new driver bytes differ")
        receipt["shared_driver_sources"]={name:formal.file_hash(ROOT/name) for name in sorted(closure)}
        receipt["frozen_original_runtime"]=unchanged
        env=os.environ.copy();env["GUNMAN_TOOLCHAIN_ROOT"]=str(Path(os.environ.get("GUNMAN_TOOLCHAIN_ROOT",ROOT.parent/"toolchains")).resolve())
        imported=harness.run_check({"argv":["bash",str(ROOT/"tools/godot.sh"),"--headless","--path",str(project),"--editor","--quit"],"timeout_seconds":90,"success_pattern":r"^Godot Engine v4[.]7[.]2"},folder/"old_import.log",ROOT,env)
        require(imported["status"]=="passed","frozen old actual project import failed")
        cohorts={"before":[],"after":[]}
        for side in ("before","after"):
            for i,(seed,map_index,strategy) in enumerate(CASES):
                target=folder/side/f"case_{i}"/"capture.json"
                if side=="after":
                    result=formal.capture_one(seed,map_index,strategy,target,max_ticks=15000,encounter_policy="kill_from_bank_v1")
                    require(result["captured"],"actual current formal capture rejected: "+str(result))
                else:
                    relative=target.relative_to(ROOT)
                    command=["python3","-c","import level_formal as f,sys,json; print(json.dumps(f.capture_one(sys.argv[1],int(sys.argv[2]),sys.argv[3],sys.argv[4],max_ticks=15000,encounter_policy='kill_from_bank_v1')))",seed,str(map_index),strategy,str(project/relative)]
                    old_env=dict(env);old_env["PYTHONPATH"]=str(project/"tools")
                    process=subprocess.run(command,cwd=project,env=old_env,capture_output=True,text=True,timeout=250)
                    (folder/f"old_capture_{i}.log").write_text(process.stdout+process.stderr)
                    require(process.returncode==0,"old formal producer failed")
                    result=json.loads(process.stdout.strip().splitlines()[-1]);require(result["captured"],"old formal capture rejected: "+str(result))
                    shutil.copytree((project/relative).parent,target.parent)
                data=read(target)
                # Validates actual accepted events/resources and failed outcomes too.
                experience.validate_capture(data)
                cohorts[side].append(str(target.relative_to(ROOT)))
        require(unchanged=={name:formal.file_hash(project/name) for name in unchanged},"old runtime/art/resources were overwritten")
        receipt["paired_cases"]=cohorts
        # Root runs the full80-per-side and rendered matrix after final freeze.
        before_report=experience.report([ROOT/p for p in cohorts["before"]]);after_report=experience.report([ROOT/p for p in cohorts["after"]])
        write(folder/"before_report.json",before_report);write(folder/"after_report.json",after_report)
        write(folder/"comparison.json",experience.compare(before_report,after_report))
        capture=next(read(ROOT/p) for p in cohorts["after"] if any(e["kind"]=="shot_accepted" for e in read(ROOT/p)["events"]))
        receipt["causal_tamper_rejected"]=policy_tamper_checks(capture)
        # Additional explicit non-kill policy, retaining any later route failure.
        bait=formal.capture_one("level-design-v2-baseline",1,"fast",folder/"bait"/"capture.json",max_ticks=10000,encounter_policy="bait_then_bypass_v1")
        require(bait["captured"],"nonkill formal capture failed")
        bait_data=read(ROOT/bait["capture"]);experience.validate_capture(bait_data)
        require(any(o.get("kind")=="actual_nonkill_bypass" and o.get("enemy_health",0)>0 for o in bait_data["policy_observations"]),"no actual live non-kill bypass")
        receipt["bait_capture"]=bait
        require(before==formal.source_files(),"source drift during actual specialty")
        require(verifier_sources=={p:formal.file_hash(ROOT/p) for p in verifier_sources},"verifier source drift")
        receipt.update(status="passed",source_after=formal.source_files())
        print("PLAINS ENCOUNTER POLICY: actual live input and causal counterexamples validated")
        return 0
    finally:
        receipt.setdefault("source_after",formal.source_files());write(folder/"receipt.json",receipt)
        print("PLAINS ENCOUNTER RECEIPT: "+str((folder/"receipt.json").relative_to(ROOT)),flush=True)

if __name__=="__main__":raise SystemExit(main())
