extends SceneTree
## Default v10 consumer / recorded generated geometry. Motor proof excludes enemies;
## the unchanged region suites separately exercise the real fan/diver encounter.
var assertions:=0
var failures:=0
var output:=""
var broken:=false
var observations: Array=[]
var manifests: Array=[]
class RouteTrace extends "res://tests/plains_region_trace.gd":
	var frames: Array=[]
	func tick(n: int=1) -> void:
		for unused: int in n:
			await super.tick(1)
			frames.append({"tick":trace_ticks,"position":[motor.global_position.x,motor.global_position.y],"grounded":motor.is_on_floor(),"normal_velocity":[motor.normal_velocity.x,motor.normal_velocity.y],"recoil_velocity":[motor.recoil_velocity.x,motor.recoil_velocity.y],"energy":controller.actor_resources.stamina.current,"energy_capacity":controller.actor_resources.stamina.capacity,"shots":shots,"session":controller.session_id,"motor":motor.get_instance_id(),"safe":safe_trace,"continuous":continuous_trace})
func _initialize() -> void:
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--output="): output=arg.trim_prefix("--output=")
		if arg=="--delete-receiver": broken=true
	run.call_deferred()
func check(ok: bool,message: String) -> void:
	assertions+=1
	if not ok: failures+=1;printerr("FAIL: "+message)
func run() -> void:
	var g:=PlainsRegionGenerator.new()
	var tuning:=PlayerTuning.load_default()
	for seed_index: int in (1 if broken else 10):
		var root_seed: String="level-design-v2-baseline"+("" if seed_index==0 else "/%02d"%seed_index)
		for map_index: int in (1 if broken else 2):
			var difficulty: String="intro" if map_index==0 else "advanced"
			var seed_value:=PlainsRegionCampaign.seed_for(root_seed,map_index+1)
			var generated:=g.generate(seed_value,tuning,false,"",difficulty)
			check(generated.ok,"default generated "+seed_value)
			if not generated.ok: continue
			var m: Dictionary=generated.manifest
			manifests.append(m)
			check(m.version=="plains-region-v10" and m.fallback_id.is_empty(),"actual v10 default without fallback")
			check(m.streams.derivation_version=="plains-region-v4","existing named random derivation retained")
			check(m.merchant_id=="area_2_1" and m.route_intents.main_recovery=="area_1_1","authored short path rejoins real camp")
			var widths: Dictionary={}
			for i: int in range(1,m.topology.column_positions.size()): widths[float(m.topology.column_positions[i])-float(m.topology.column_positions[i-1])]=true
			check(widths.size()>=2,"world interval allocation has multiple real challenge clearances")
			check(g.validate(JSON.parse_string(JSON.stringify(m)),tuning),"native JSON roundtrip replay identity")
			var old: Dictionary=m.duplicate(true);old.version="plains-region-v9";old.manifest_hash=g._hash(old)
			check(not g.validate(old,tuning),"relabelled historical v9 manifest rejected")
			var changed: Dictionary=m.duplicate(true);changed.nodes[0].geometry.platforms[0][2]=1;changed.manifest_hash=g._hash(changed)
			check(not g.validate(changed,tuning),"rehashed missing supported receiver rejected")
			var edge: Dictionary={}
			for candidate: Dictionary in m.connections:
				if candidate.a=="area_0_1" and candidate.b=="area_1_1":edge=candidate
			check(not edge.is_empty() and edge.recipe=="well_arch_phrase" and edge.modules.size()==2,"default first short chain is validated dual-use/low-headroom phrase")
			var trace:=RouteTrace.new();trace.tree=self;trace.check=check
			check(await trace.fixture(m,tuning),"default real recorded assembler fixture")
			check(await trace.tutorial(),"actual continuous tutorial reaches first choice")
			var entry_energy: float=trace.controller.actor_resources.stamina.current
			if seed_index%2==1:
				var stamina: StaminaState=trace.controller.actor_resources.stamina
				check(stamina.consume_continuous(stamina.current,stamina.epoch).accepted(),"legal zero initial energy boundary")
				entry_energy=stamina.current
				check(entry_energy==0,"zero boundary read back before phrase")
			if broken:
				var well: PlatformingModule=trace.stage.modules[int(edge.modules[0])]
				well.get_node("Platform1").free() # Remove the actual right bank collider, not a reported coordinate.
			var before_shots: int=trace.shots
			var forward: bool=await trace.walk_edge(edge,true)
			check(forward,"actual first phrase reaches grounded receiver")
			var reverse:=false
			if forward: reverse=await trace.walk_edge(edge,false)
			if not broken:
				check(reverse,"same-body phrase returns along opened mechanism")
				check(trace.safe_trace and trace.continuous_trace,"all-frame full-body sweep and no teleport")
				check(trace.shots>before_shots,"short chain actually releases shot to open gate")
			observations.append({"seed":root_seed,"map_index":map_index+1,"manifest_hash":m.manifest_hash,"entry_energy":entry_energy,"forward":forward,"reverse":reverse,"safe":trace.safe_trace,"continuous":trace.continuous_trace,"frames":trace.frames,"shots":trace.shots-before_shots,"enemy_scope":"no enemies in input-only assembler; formal live cohort and unchanged pressure suite are separate"})
			trace.world.free()
	var data: Dictionary={"version":PlainsRegionGenerator.VERSION,"assertions":assertions,"failures":failures,"deleted_receiver":broken,"manifests":manifests,"observations":observations}
	if not output.is_empty():
		var f:=FileAccess.open(output,FileAccess.WRITE);f.store_string(JSON.stringify(data));f.close()
	print("PLAINS REDESIGN SPATIAL: %s assertions, %s failures"%[assertions,failures])
	quit(1 if failures else 0)
