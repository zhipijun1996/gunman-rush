"""Current default v10 native maps/chains plus physical broken-bank counterexample."""
import copy
import hashlib
import math
import json
import re
import subprocess
import tempfile
from pathlib import Path

import harness
import level_formal
from run_tests import REPO


def validate_native(data, negative=False):
    expected = 1 if negative else 20
    observations = data.get("observations", [])
    manifests = data.get("manifests", [])
    if data.get("version") != "plains-region-v10" or data.get("deleted_receiver") is not negative or len(observations) != expected or len(manifests) != expected:
        return False
    if negative:
        return data.get("failures", 0) > 0 and observations[0].get("forward") is False and len(observations[0].get("frames", [])) > 10 and observations[0]["frames"][-1]["position"][1] > 500
    if data.get("failures") != 0 or data.get("assertions", 0) < 700:
        return False
    seen = set()
    zeros = 0
    for observation, manifest in zip(observations, manifests):
        key = (observation.get("seed"), observation.get("map_index"))
        if key in seen or key[1] not in (1, 2): return False
        seen.add(key)
        if not all(observation.get(name) is True for name in ("forward", "reverse", "safe", "continuous")) or observation.get("shots", 0) < 1:
            return False
        if manifest.get("version") != "plains-region-v10" or manifest.get("manifest_hash") != observation.get("manifest_hash") or manifest.get("fallback_id") != "":
            return False
        frames = observation.get("frames", [])
        if len(frames) < 200: return False
        session = (frames[0].get("session"), frames[0].get("motor"))
        previous = None
        for frame in frames:
            if (frame.get("session"), frame.get("motor")) != session or frame.get("safe") is not True or frame.get("continuous") is not True:
                return False
            values = frame.get("position", []) + frame.get("normal_velocity", []) + frame.get("recoil_velocity", []) + [frame.get("energy")]
            if len(values) != 7 or not all(isinstance(v, (int, float)) and math.isfinite(v) for v in values): return False
            if not isinstance(frame.get("energy_capacity"), (int, float)) or not 0 < frame["energy_capacity"] or not 0 <= frame["energy"] <= frame["energy_capacity"]: return False
            if previous:
                if frame["tick"] != previous["tick"] + 1: return False
                # Independent artifact continuity envelope, deliberately far above the
                # unchanged native Motor speed; native fullbody sweep is stricter.
                if math.dist(frame["position"], previous["position"]) > 35: return False
            previous = frame
        if frames[-1].get("grounded") is not True or math.dist(frames[-1]["position"], [0, 0]) > 2: return False
        if observation.get("entry_energy") == 0: zeros += 1
    return len(seen) == 20 and zeros == 10


def source_snapshot():
    result = level_formal.source_files()
    result["tools/run_plains_redesign_spatial_tests.py"] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    return result


def main():
    base = REPO / "build/plains_redesign/spatial"
    base.mkdir(parents=True, exist_ok=True)
    folder = Path(tempfile.mkdtemp(prefix="run_", dir=base))
    before = source_snapshot()
    receipt = {"status": "failed", "source_before": before, "source_commit": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=REPO, text=True).strip(), "scope": "default v10 20 generated maps; real same-body main phrase forward/return, zero energy boundary; no formal whole-route enemy or subjective/device claim", "runs": []}
    try:
        for negative in (False, True):
            name = "deleted_receiver" if negative else "positive"
            output = folder / (name + ".json")
            command = ["bash", "tools/godot.sh", "--headless", "--fixed-fps", "60", "--path", ".", "--script", "tests/plains_redesign_spatial_runner.gd", "--", "--output=" + str(output)]
            if negative:
                command.append("--delete-receiver")
            result = harness.run_check({"argv": command, "timeout_seconds": 180, "success_pattern": r"^PLAINS REDESIGN SPATIAL: [1-9]\d* assertions, 0 failures$"}, folder / (name + ".log"), REPO)
            text = (folder / (name + ".log")).read_text()
            data = json.loads(output.read_text()) if output.is_file() else {}
            valid = (result["exit_code"] == 1 if negative else result["status"] == "passed") and validate_native(data, negative)
            valid = bool(valid and not re.search(r"SCRIPT ERROR:|Parse Error:|SHADER ERROR:|ERROR: Failed to load script", text))
            receipt["runs"].append({"argv": command, "process": result, "validated": valid, "expected_exit": 1 if negative else 0, "output": str(output.relative_to(REPO)), "output_sha256": hashlib.sha256(output.read_bytes()).hexdigest() if output.is_file() else None})
            if not valid:
                raise RuntimeError("Actual default spatial proof failed: " + str(folder))
        receipt["source_after"] = source_snapshot()
        if before != receipt["source_after"]:
            raise RuntimeError("Source changed during spatial proof")
        positive = json.loads((folder / "positive.json").read_text())
        refusals = []
        for name in ("empty_frames", "duplicate_map", "teleport", "missing_energy", "wrong_version"):
            corrupt = copy.deepcopy(positive)
            if name == "empty_frames": corrupt["observations"][0]["frames"] = []
            elif name == "duplicate_map": corrupt["observations"][1]["seed"] = corrupt["observations"][0]["seed"]; corrupt["observations"][1]["map_index"] = corrupt["observations"][0]["map_index"]
            elif name == "teleport": corrupt["observations"][0]["frames"][20]["position"][0] += 1000
            elif name == "missing_energy": del corrupt["observations"][0]["frames"][20]["energy"]
            else: corrupt["version"] = "plains-region-v999"
            refused = not validate_native(corrupt)
            refusals.append({"case": name, "refused": refused})
            if not refused: raise RuntimeError("Artifact validator accepted corruption: " + name)
        (folder / "validator_refusals.json").write_text(json.dumps(refusals, indent=2) + "\n")
        receipt["status"] = "passed"
        print("PLAINS REDESIGN SPATIAL: actual default semantic maps and physical counterexamples validated", flush=True)
    finally:
        (folder / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
        print("PLAINS SPATIAL RECEIPT: " + str(folder / "receipt.json"), flush=True)


if __name__ == "__main__":
    main()
