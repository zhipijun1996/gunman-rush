extends SceneTree
class Driver extends RefCounted:
	var tree: SceneTree
	var owner: Node
	func run() -> void:
		if "--immortal" in OS.get_cmdline_user_args():
			while true: await tree.process_frame
		else:
			await Signal(owner, &"never_resume")
func _initialize() -> void: run.call_deferred()
func run() -> void:
	var owner := Node.new();owner.add_user_signal("never_resume");root.add_child(owner)
	var driver := Driver.new();driver.tree=self;driver.owner=owner
	driver.run()
	owner.queue_free();await process_frame
	driver=null
	print("TERMINAL OWNER PROBE completed; immortal=", "--immortal" in OS.get_cmdline_user_args())
	quit(0)
