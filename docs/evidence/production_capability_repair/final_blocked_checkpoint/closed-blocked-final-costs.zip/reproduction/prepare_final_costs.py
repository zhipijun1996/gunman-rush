#!/usr/bin/env python3
"""READ-ONLY input aggregation. Writes only a NEW named build/harness output directory.

Run after a controller explicitly supplies completed delivery/CI/public receipts; never
starts workers, tools, engines, downloads, or publication. As-of mode is the default.
CI receipts, if supplied, must contain actual run/job started/completed timestamps;
source equality never collapses independently executed local and CI work.
"""
import argparse
import datetime as dt
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import subprocess
import sys
sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[3]
OUTROOT = ROOT / 'build/production_repair/harness'
SPEC = importlib.util.spec_from_file_location('observed_timing', ROOT/'tools/production_timing.py')
TIMING = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(TIMING)
STAGES = TIMING.STAGES + ("unattributed_mixed",)
POLICY = {
    'status': 'as_of_partial_unless_explicit_final_receipts',
    'time_basis': 'actual observed timestamps or original elapsed duration, never file mtime/lease/expiry',
    'command_duration': 'monotonic elapsed where exposed; includes wait/tool overhead, never model compute',
    'global_wall': 'union of observed actual intervals across execution domains; simultaneous local/CI counted once as wall',
    'execution_work': 'per-domain command envelopes remain separate; same source digest does not deduplicate distinct executions',
    'nested': 'parent/child envelopes overlap; do not add them as serial work',
    'mixed_component_placement': 'actual native pipeline outer interval goes to unattributed_mixed; native/validation/encoding component durations kept separately when boundaries are not exposed',
    'network': 'toolchain elapsed includes transfer plus local setup; only actual transfer_attempt_seconds is transfer-attempt wall, never call entire setup pure network wait',
    'non_overlapping': 'endpoint sweep reports seconds with exactly one active phase and shared phase sets separately; no arbitrary priority assignment',
    'rework': 'tag on canonical work event; image alias or failed-release alias never creates another interval',
    'duration_only': 'reported independently; cannot be added to wall union/exclusive time without timestamps',
    'unknown': 'unknown is not zero; old V3 missing model/integration/network intervals remain unknown',
    'usage': {'pure_model_seconds': 'not_exposed', 'tokens': 'not_exposed', 'price': 'not_exposed'},
}
INPUTS = []

def read(path):
    p = Path(path)
    if not p.is_absolute(): p = ROOT/p
    raw=p.read_bytes()
    INPUTS.append({'path':str(p.relative_to(ROOT)) if p.is_relative_to(ROOT) else str(p), 'sha256':hashlib.sha256(raw).hexdigest(), 'bytes':len(raw)})
    return json.loads(raw)

def interval(value):
    if type(value) in (int,float) and math.isfinite(value): return float(value)
    if isinstance(value,str): return dt.datetime.fromisoformat(value.replace('Z','+00:00')).timestamp()
    raise ValueError('Actual finite numeric or ISO timestamp required')

def valid(e):
    a,b=e.get('started_at_unix'),e.get('ended_at_unix')
    return type(a) in (int,float) and type(b) in (int,float) and math.isfinite(a) and math.isfinite(b) and b>=a

def sweep(events):
    """Each elementary interval belongs to one active phase-set, irrespective of nesting."""
    points=sorted({float(e[k]) for e in events for k in ('started_at_unix','ended_at_unix')})
    groups={}; domains={}; segments=[]
    for a,b in zip(points,points[1:]):
        active=[e for e in events if e['started_at_unix']<b and e['ended_at_unix']>a]
        if not active: continue
        phases=tuple(sorted({e['stage'] for e in active})); key='+'.join(phases)
        groups[key]=groups.get(key,0)+(b-a)
        ds=tuple(sorted({e['execution_domain'] for e in active})); dk='+'.join(ds)
        domains[dk]=domains.get(dk,0)+(b-a)
        segments.append({'started_at_unix':a,'ended_at_unix':b,'seconds':b-a,'active_phases':list(phases),'execution_domains':list(ds),'active_event_ids':[e['id'] for e in active]})
    return {'union_seconds':sum(groups.values()),'exclusive_phase_seconds':{s:groups.get(s,0) for s in STAGES},'shared_phase_set_seconds':{k:v for k,v in groups.items() if '+' in k},'execution_domain_set_seconds':domains,'segments':segments}

def stageof(argv):
    if any('foundry.py' in str(x) or 'foundry_export_stamp.gd' in str(x) for x in argv): return 'game_integration'
    if any(str(x).endswith('tools/build.py') or str(x).endswith('/build.py') for x in argv): return 'release'
    return 'verification'

def validate_composite(manifest, loader=read, original_hash=None):
    """Receipt linkage only. Never execute verification or promote tools/deliver status.

    Public HTTP has no trustworthy CI labels; equal full PCK SHA/bytes binds it
    to the API-bound ZIP. Native capture is source-only, explicitly not that Web pack.
    """
    errors=[]; receipts={}; ids={k:manifest.get(k) for k in ('source_commit','run_id','run_attempt','artifact_id','zip_sha256','pack_sha256','pack_bytes','build_id')}
    def need(condition,message):
        if not condition: errors.append(message)
    def digest(x): return isinstance(x,str) and len(x)==64 and all(c in '0123456789abcdef' for c in x)
    need(manifest.get('kind')=='composite_ci_artifact_delivery','Composite kind absent/wrong')
    need(isinstance(ids['source_commit'],str) and len(ids['source_commit'])==40 and all(c in '0123456789abcdef' for c in ids['source_commit']),'Exact40-character source commit required')
    for k in ('run_id','run_attempt','artifact_id','pack_bytes'):need(type(ids[k]) is int and ids[k]>0,k+' must be positive actual integer')
    for k in ('zip_sha256','pack_sha256'):need(digest(ids[k]),k+' must be full SHA256')
    need(isinstance(ids['build_id'],str) and digest(ids['pack_sha256']) and ids['pack_sha256'][:12]==ids['build_id'],'build_id must match full pack hash prefix')
    keys=('ci_run','ci_jobs','artifact_api','browser','native_capture','public_pack','public_review')
    for key in keys:
        reference=manifest.get('receipts',{}).get(key)
        if not isinstance(reference,dict) or not reference.get('path') or not digest(reference.get('sha256')):
            errors.append(key+' needs original receipt path and SHA256');continue
        try:
            d=loader(reference['path']);raw_hash=original_hash(reference['path']) if original_hash else None
            if raw_hash is None:
                p=Path(reference['path']); p=p if p.is_absolute() else ROOT/p
                raw_hash=hashlib.sha256(p.read_bytes()).hexdigest()
            need(raw_hash==reference['sha256'],key+' original bytes SHA mismatch')
            need(isinstance(d,dict),key+' receipt must be a JSON object')
            if isinstance(d,dict):receipts[key]=d
        except (OSError,ValueError,TypeError) as ex:errors.append(key+' receipt unavailable/invalid: '+str(ex))
    if len(receipts)!=len(keys):return {'status':'pending_missing_raw_receipts','identity':ids,'errors':errors,'scope':'Explicit composite receipt linkage; no tools/deliver pass invented','timing_events':[]}
    run,jobs,api,browser,capture,public,review=(receipts[k] for k in keys)
    need(run.get('id')==ids['run_id'] and run.get('run_attempt')==ids['run_attempt'] and run.get('head_sha')==ids['source_commit'],'CI run/source/attempt mismatch')
    need(run.get('status')=='completed' and run.get('conclusion')=='success','CI must be terminal success')
    need(str(run.get('path','')).split('@')[0]=='.github/workflows/environment.yml','CI must be formal environment.yml workflow')
    need(run.get('event')=='workflow_dispatch','CI must be explicitly dispatched formal release run')
    rows=jobs.get('jobs',[])
    need(jobs.get('total_count')==len(rows),'CI full jobs inventory incomplete')
    for name in ('prepare','core','windows','web','deploy_web','verify_public'):
        matches=[x for x in rows if x.get('name')==name]
        need(len(matches)==1 and matches[0].get('status')=='completed' and matches[0].get('conclusion')=='success','Missing/non-success required CI job '+name)
    # Require the workflow's actual expensive checks, not just green job names.
    required_steps={'core':('harness.py --profile gameplay --profile art --jobs 1 --release','Check actual platform pixels','audio_lifecycle_runner.gd','foundry_lab_runner.gd','foundry_touch_runner.gd','foundry_feedback_runner.gd'),'windows':('tools/build.py windows',),'web':('harness.py --profile web --release',)}
    for name,markers in required_steps.items():
        selected=[j for j in rows if j.get('name')==name]
        steps=selected[0].get('steps',[]) if len(selected)==1 else []
        for marker in markers:need(any(marker in x.get('name','') and x.get('status')=='completed' and x.get('conclusion')=='success' for x in steps),'Required actual CI step missing/non-success: '+marker)
    for job in rows:
        need(job.get('run_id')==ids['run_id'],'CI job different run')
        if 'run_attempt' in job:need(job['run_attempt']==ids['run_attempt'],'CI job different attempt')
        if 'head_sha' in job:need(job['head_sha']==ids['source_commit'],'CI job different source')
    wf=api.get('workflow_run',{})
    need(api.get('id')==ids['artifact_id'] and wf.get('id')==ids['run_id'] and wf.get('head_sha')==ids['source_commit'],'Artifact API run/source/artifact mismatch')
    need(api.get('name')=='gunman-rush-web-playtest' and api.get('expired') is False,'Expected nonexpired tested Web artifact required')
    need(api.get('digest')=='sha256:'+str(ids['zip_sha256']),'Artifact API digest/ZIP mismatch')
    need(browser.get('status')=='passed' and browser.get('source_commit')==ids['source_commit'] and browser.get('run_id')==ids['run_id'],'Browser status/source/run mismatch')
    ar=browser.get('artifact_receipt',{});info=browser.get('build_info',{})
    for key in ('artifact_id','zip_sha256','pack_sha256','pack_bytes'):need(ar.get(key)==ids[key],'Browser artifact '+key+' mismatch')
    need(ar.get('zip_bytes')==api.get('size_in_bytes') and type(ar.get('zip_bytes')) is int,'Browser ZIP/API size mismatch')
    need(info.get('source_commit')==ids['source_commit'] and info.get('build_id')==ids['build_id'] and info.get('pack_bytes')==ids['pack_bytes'],'Browser build-info mismatch')
    before,after=browser.get('web_inventory_before'),browser.get('web_inventory_after')
    need(isinstance(before,dict) and bool(before) and before==after,'Served CI artifact inventory changed/missing')
    need(isinstance(before,dict) and before.get(info.get('pack'))==ids['pack_sha256'],'Served actual PCK hash mismatch')
    result=browser.get('browser_results',[])
    expected={'verify_action_budget_browser.py','verify_studio_click_browser.py','verify_all_weapon_browser.py'}
    actual=[]
    for item in result:
        names=[Path(str(x)).name for x in item.get('command',[]) if str(x).endswith('.py')];actual.extend(names)
        need(item.get('exit_code')==0 and digest(item.get('log_sha256')) and digest(item.get('script_sha256')),'Browser exit/log/script receipt invalid')
        need(valid(item),'Browser actual timestamp interval missing')
    need(len(result)==3 and len(actual)==3 and set(actual)==expected,'Exactly three distinct required browser scripts required')
    native=capture.get('native_report',capture)
    need(capture.get('status')=='passed' and native.get('commit')==ids['source_commit'] and digest(native.get('media_sha256')),'Native capture status/source/media hash mismatch')
    if 'native_report' in capture:
        need(capture.get('source_commit')==ids['source_commit'] and capture.get('exit_code')==0,'Native wrapper source/exit mismatch')
        need(bool(capture.get('source_before')) and capture.get('source_before')==capture.get('source_after'),'Native wrapper actual source inventory changed/missing')
    need(native.get('capture',{}).get('status')=='passed' and native.get('capture',{}).get('exit_code')==0,'Native capture actual strict check did not pass')
    need(public.get('status')=='passed' and public.get('source_commit')==ids['source_commit'] and public.get('build_id')==ids['build_id'],'Public actual build/source mismatch')
    need(public.get('pack_sha256')==ids['pack_sha256'] and public.get('pack_bytes')==ids['pack_bytes'],'Public full actual PCK hash/size mismatch; prefix-only receipt insufficient')
    need(review.get('status')=='accept' and review.get('source_commit')==ids['source_commit'] and review.get('pack_sha256')==ids['pack_sha256'],'Public independent review status/source/PCK mismatch')
    need(review.get('reviewed_receipt_sha256')==manifest['receipts']['public_pack']['sha256'],'Public independent review must bind original actual public receipt bytes')
    need(isinstance(review.get('agent_id'),str) and review['agent_id']!=manifest.get('implementation_agent','/root'),'Distinct independent reviewer required')
    timing=[]
    # Raw GitHub updated_at is not a completion timestamp. Only actual job endpoints.
    for job in rows:
        if job.get('conclusion')=='skipped':continue
        if job.get('started_at') and job.get('completed_at'):
            a,b=interval(job['started_at']),interval(job['completed_at'])
            need(b>=a,'Reversed CI job actual interval')
            if b>=a:timing.append({'id':f'ci:job:{job.get("id")}','stage':'release','execution_domain':'ci','evidence':manifest['receipts']['ci_jobs']['path'],'started_at_unix':a,'ended_at_unix':b,'duration_seconds':b-a,'measurement_scope':'actual CI job inclusive; parallel jobs union only for wall; no runner-price estimate','tags':[]})
    for item in result:
        if valid(item):timing.append({'id':'composite-browser:'+str(item.get('log_sha256')),'stage':'verification','execution_domain':'local','evidence':manifest['receipts']['browser']['path'],'started_at_unix':item['started_at_unix'],'ended_at_unix':item['ended_at_unix'],'duration_seconds':item['ended_at_unix']-item['started_at_unix'],'measurement_scope':'actual browser coordinator envelope; nested timing ledger is not additive','tags':[]})
    c=capture if 'native_report' in capture else native.get('capture',{})
    if valid(c):timing.append({'id':'composite-native:'+str(native.get('media_sha256')),'stage':'game_integration','execution_domain':'local','evidence':manifest['receipts']['native_capture']['path'],'started_at_unix':c['started_at_unix'],'ended_at_unix':c['ended_at_unix'],'duration_seconds':c['duration_seconds'],'measurement_scope':'actual source-bound native capture command envelope; media duration is NOT production runtime; no invented exclusive encode split','tags':[]})
    return {'status':'verified_composite' if not errors else 'rejected_receipt_mismatch','identity':ids,'errors':errors,'scope':'CI+same API-bound ZIP/PCK three browsers+source-bound native capture+same full public PCK+distinct independent review; local tools/deliver remains interrupted/failed','native_capture_binding':'source only, explicitly not Web movie or CI PCK capture','timing_events':timing}

REDACTED_URI = '<ephemeral-authenticated-download-url-redacted>'


def authenticated_uri(value):
    """Recognize credential-bearing HTTP URI query keys, including percent encoding."""
    from urllib.parse import unquote, urlsplit
    import re
    try:
        decoded=unquote(value)
        parsed=urlsplit(decoded)
        if parsed.scheme.lower() not in ('http','https'):return False
        if parsed.username or parsed.password:return True
        return bool(re.search(r'(?:^|[&;?])(?:sig|signature|token|access_token|auth|authorization|api[_-]?key|subscription[_-]?key|awsaccesskeyid|googleaccessid|x-amz-(?:signature|credential|security-token)|x-goog-(?:signature|credential))=',parsed.query,re.I))
    except ValueError:return False


def portable_redact(value, origins=None, pointer='', context=None):
    """Redact portable output only; immutable original ledger hashes locate raw bytes."""
    import re
    origins=origins or {};notes=[]
    def walk(item,path,owner):
        if isinstance(item,dict):
            if item.get('id') in origins:owner=origins[item['id']]
            return {k:walk(v,path+'/'+str(k).replace('~','~0').replace('/','~1'),owner) for k,v in item.items()}
        if isinstance(item,list):return [walk(v,path+'/'+str(i),owner) for i,v in enumerate(item)]
        if not isinstance(item,str):return item
        def replace(match):
            uri=match.group(0)
            if not authenticated_uri(uri):return uri
            notes.append({'redaction_path':path,'replacement':REDACTED_URI,**(owner or {'provenance':'original assembled report field; see input snapshot hashes'})})
            return REDACTED_URI
        return re.sub(r'https?://[^\s<>"\']+',replace,item)
    return walk(value,pointer,context),notes


def portable_ledger_copies(ledgers, folder, cutoff=None):
    """Keep untouched raw lines byte-identical; only affected records are reserialized."""
    inventory=[];all_notes=[];origins={}
    for name in ledgers:
        raw=(ROOT/name).read_bytes();ledger_sha=hashlib.sha256(raw).hexdigest()
        for line in raw.splitlines():
            if not line.strip():continue
            event=json.loads(line)
            origins[event['id']]={'original_event_id':event['id'],'original_event_sha256':hashlib.sha256(line).hexdigest(),'original_event_hash_basis':'exact original JSONL record bytes excluding line terminator','original_ledger_sha256':ledger_sha,'original_ledger_path':name}
        safe=[];notes=[];omitted=[]
        for index,line in enumerate(raw.splitlines(keepends=True)):
            if not line.strip():safe.append(line);continue
            event=json.loads(line)
            if cutoff is not None and event['started_at_unix']>=cutoff:
                omitted.append({'id':event['id'],'original_event_sha256':origins[event['id']]['original_event_sha256']});continue
            if cutoff is not None and event['ended_at_unix']>cutoff:raise ValueError('Command straddles closed window; no invented partial command cost')
            clean,changes=portable_redact(event,origins,pointer='/records/'+str(index))
            safe.append((json.dumps(clean,ensure_ascii=False)+'\n').encode() if changes else line)
            notes.extend(changes)
        target=folder/('-'.join(Path(name).parts[2:]))
        target.parent.mkdir(parents=True,exist_ok=True)
        with target.open('xb') as handle:handle.write(b''.join(safe))
        inventory.append({'original_path':name,'original_ledger_sha256':ledger_sha,'portable_path':str(target.relative_to(ROOT)),'portable_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'redactions':len(notes),'omitted_postclosure_records':omitted,'preservation':'Original file never written. Unchanged records copied as original bytes; affected JSON records change only credential-bearing URI strings.'})
        all_notes.extend(notes)
    return inventory,all_notes,origins

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--output-dir',type=Path,required=True)
    ap.add_argument('--delivery-report',action='append',default=[])
    ap.add_argument('--closed-blocked-receipt',help='Controller decision closes observed-cost accounting as blocked; never a successful release')
    ap.add_argument('--reported-duration',action='append',default=[],help='Additional STAGE=JSON with original seconds/duration_seconds and no interval')
    ap.add_argument('--duration-report',action='append',default=[],help='STAGE=JSON with nested original seconds-only records; retain individually without inferred placement or additive total')
    ap.add_argument('--composite-receipt',help='Explicit original-receipt manifest for composite CI+CI-pack-browser+native+public delivery')
    ap.add_argument('--harness-report',action='append',default=[])
    ap.add_argument('--ci-harness-report',action='append',default=[],help='Actual downloaded CI Harness report; check intervals stay in CI domain')
    ap.add_argument('--ci-receipt',action='append',default=[],help='Actual gh run JSON, optionally with jobs[]; started_at/run_started_at,completed_at required for interval')
    ap.add_argument('--public-receipt',action='append',default=[],help='Original public fingerprint/verification receipt; status only, never invent time')
    ap.add_argument('--final',action='store_true',help='Require exact-source complete traditional or explicit composite CI/browser/native/public original receipts; never promote failed local deliver.')
    ap.add_argument('--verified-source',help='Exact source commit for successful delivery or blocked-window binding; never assume docs HEAD equals shipped code')
    args=ap.parse_args()
    if args.final and args.closed_blocked_receipt:raise ValueError('Success-only --final and closed-blocked accounting are mutually exclusive')
    out=args.output_dir.resolve()
    if not out.is_relative_to(OUTROOT.resolve()) or out==OUTROOT.resolve(): raise ValueError('Output must be a NEW subdirectory of build/production_repair/harness')
    if out.exists(): raise ValueError('Refuse overwrite: choose a fresh output-dir')
    closure_pre=read(args.closed_blocked_receipt) if args.closed_blocked_receipt else None
    cutoff=interval(closure_pre['closed_at_unix']) if closure_pre and 'closed_at_unix' in closure_pre else None
    old=read('docs/evidence/production_capability_repair/harness/v3-evidence-audit.json')
    oldlogs=read('build/production_repair/harness/v3-terminal-log-audit.json')
    loop=read('build/production_repair/harness/actual-loop-result.json')
    stale=read('build/production_repair/harness/actual-stale-source-reject.json')
    command=read('build/production_repair/harness/report-command.json')
    # Reuse the existing collector; curated native timing excludes the whole-loop orchestration alias.
    ledgers=[command[i+1] for i,x in enumerate(command) if x=='--ledger']
    prod=[command[i+1] for i,x in enumerate(command) if x=='--production-dir']
    duration=[command[i+1] for i,x in enumerate(command) if x=='--reported-duration']+args.reported_duration
    for p in ledgers + [x.split('=',1)[1] for x in duration] + [str(p.relative_to(ROOT)) for folder in prod for p in (ROOT/folder).rglob('*.json')]:
        raw=(ROOT/p).read_bytes(); INPUTS.append({'path':p,'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)})
    ledger_snapshots={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in ledgers}
    raw_report=TIMING.collect([ROOT/p for p in ledgers],[ROOT/p for p in prod],(),[x.split('=')[0]+'='+str(ROOT/x.split('=',1)[1]) for x in duration])
    extra_duration_intervals=[]
    for reference in args.duration_report:
        stage,sep,name=reference.partition('=')
        if not sep or stage not in STAGES:raise ValueError('Duration report requires STAGE=JSON_FILE')
        d=read(name)
        def visit(node,pointer='',owner=None):
            if isinstance(node,dict):
                field=next((k for k in ('seconds','duration_seconds') if type(node.get(k)) in (int,float)),None)
                if field and not valid(node):
                    seconds=node[field]
                    if not math.isfinite(seconds) or seconds<0:raise ValueError('Invalid original reported duration')
                    raw_report['unknown_records'].append({'evidence':name,'record_pointer':pointer,'stage':stage,'reported_seconds':seconds,'exit_code':node.get('exit_code',node.get('exit')),'reason':'Actual seconds-only record; component interval unknown, never inferred from mtime/order','measurement_scope':'Original reported elapsed; records may nest and are NOT added to timeline or an additive total','original_record':{k:v for k,v in node.items() if k not in ('source_before','source_after','source_files','frozen_runtime_before','frozen_runtime_after','source_sha256','final_source_sha256','recipe_before','recipe_after')},'original_full_record_canonical_sha256':hashlib.sha256(json.dumps(node,ensure_ascii=False,sort_keys=True).encode()).hexdigest()})
                if field and valid(node):
                    extra_duration_intervals.append({'id':'actual-nested-native:'+name+pointer,'stage':stage,'execution_domain':'local','evidence':name,'record_pointer':pointer,'started_at_unix':node['started_at_unix'],'ended_at_unix':node['ended_at_unix'],'duration_seconds':node[field],'exit_code':node.get('exit_code'),'expected_exit_code':(owner or {}).get('expected_exit_code'),'validated':(owner or {}).get('validated'),'measurement_scope':'Actual nested producer process interval; expected negative exit remains distinct from extra resource diagnostics','tags':[]})
                for key,value in node.items():visit(value,pointer+'/'+str(key),node)
            elif isinstance(node,list):
                for i,value in enumerate(node):visit(value,pointer+'/'+str(i),owner)
        visit(d)
    probe='build/production_repair/release/frozen-assets-a4/frozen-inventory-probe-stopped.json'
    if (ROOT/probe).is_file():
        d=read(probe)
        if 'stopped at25seconds' in d.get('reason',''):raw_report['unknown_records'].append({'evidence':probe,'stage':'verification','reported_seconds':25,'precision':'producer statement to whole-second resolution','original_producer_statement':d['reason'],'reason':'Stopped optional Git inventory probe; no actual interval exposed; not native validation and not a proved inventory','additivity':'No position or exclusive network split inferred'})
    events=extra_duration_intervals; aliases=[]; missing_products=[]
    for e in raw_report['events']:
        if e.get('image_event_id'):
            aliases.append({'alias_id':e['id'],'canonical_id':e['image_event_id'],'tag':'rework','evidence':e['evidence']}); continue
        e={**e,'execution_domain':'local','tags':[]}
        if e.get('is_rework'): e['tags'].append('rework')
        if e['stage']=='release' and e.get('exit_code') not in (None,0) and any(str(x).endswith('tools/deliver.py') for x in e.get('command',[])):
            e['tags'] += ['rework','failed_release','stopped_on_actual_native_diagnostics']
            e['duration_interpretation']='Original interrupted outer command; retain duration once. Inner child spans are overlapping detail.'
        if 'actual movie lossy share derivative' in e.get('label',''):
            e['release_scope']='share_encoding_only_not_build_or_publish'
        if any(str(x).endswith('tools/publish_playtest.py') for x in e.get('command',[])):
            log=e.get('captured_log',{}).get('path')
            if log and (ROOT/log).is_file():
                for line in (ROOT/log).read_text(errors='replace').splitlines():
                    try:diagnostic=json.loads(line)
                    except ValueError:continue
                    if isinstance(diagnostic,dict) and diagnostic.get('failure_kind')=='ci_failed':
                        e['failure_classification']='remote_CI_terminal_failure; inspect exact run/jobs/check cause; no automatic redispatch'
                    if isinstance(diagnostic,dict) and diagnostic.get('failure_kind')=='poll_timeout':
                        e['failure_classification']='bounded_CI_wait_checkpoint_resume; not observed code/native/artifact failure'
                        e['tags'].append('recoverable_publication_wait')
        e['measurement_scope']=e.get('measurement_scope','inclusive_command_envelope')
        if e['id']=='06a94ffc52ff4813bc94a1bba7e2dc56':e['failure_classification']='source_snapshot_guard_after_two_generated_UID_files; inner terrain native passed; not assertion/native-exit/network failure'
        if e['stage']=='model_implementation': e['measurement_scope']='inclusive_worker_envelope_with_tools_and_wait; pure_model_time_not_exposed'
        for p in e.get('outputs',[]):
            if p.get('status')=='missing': missing_products.append({'event_id':e['id'],**p})
        events.append(e)
    components=[]
    # These reports expose a real outer interval plus inclusive component durations,
    # but no exact component boundaries. Keep components off the wall timeline.
    for name in ('build/production_repair/ecology/pilot_wide_movie_01/report.json',
                 'build/production_repair/ecology/pilot_tight_movie_01/report.json',
                 'build/production_repair/ecology/default_wide_final_01/report.json',
                 'build/production_repair/ecology/default_tight_final_01/report.json',
                 'build/production_repair/ecology/portable_final_01/report.json',
                 'build/root_bell/production_repair_g1_final_01/report.json'):
        if not (ROOT/name).is_file(): continue
        d=read(name)
        start=d.get('started_at_unix',d.get('started_epoch'))
        end=d.get('ended_at_unix',d.get('finished_epoch'))
        if start is not None and end is not None:
            events.append({'id':'native-report:'+name,'stage':'verification' if 'production_repair_g1_final' in name else 'unattributed_mixed','execution_domain':'local','evidence':name,'started_at_unix':start,'ended_at_unix':end,'duration_seconds':end-start,'status':d.get('status'),'measurement_scope':'actual outer native pipeline; components below lack interval boundaries, not assigned invented placement','tags':[]})
        phase_fields={'native_integration_seconds':'game_integration','native_verification_seconds':'verification','verification_seconds':'verification','encoding_seconds':'release','fresh_import_seconds':'game_integration','spaces_command_seconds':'verification','engine_lock_wait_seconds':'engine_lock_wait_not_network','shared_host_lock_wait_seconds':'engine_lock_wait_not_network'}
        for field,phase in phase_fields.items():
            if type(d.get(field)) in (int,float): components.append({'evidence':name,'field':field,'stage':phase,'reported_seconds':d[field],'component_interval':'unknown; not inferred from field order or total','additivity':'not added to timeline; may nest wrapper/child native durations','scope':'movie encoding is media production, not deploy or publication' if field=='encoding_seconds' else 'original actual native component duration'})
    for name in ('build/production_repair/release/connector-artifact-12035647459-timing.json','build/production_repair/release/api-read-503-recovery.json','build/production_repair/harness/failed-ci-38875599430/raw-api/run-timing.json','build/production_repair/harness/failed-ci-38875599430/raw-api/jobs-timing.json','build/production_repair/harness/failed-ci-38875599430/raw-api/harness-artifact-timing.json'):
        if not (ROOT/name).is_file():continue
        d=read(name)
        if 'connector-artifact' in name:
            if valid(d):events.append({**d,'source_receipt':name,'execution_domain':'local','tags':[]})
        elif 'failed-ci-38875599430/raw-api' in name:
            if valid(d):events.append({'id':'actual-terminal-api-GET:'+name,'stage':'network_wait','source_receipt':name,'evidence':name,'execution_domain':'local','started_at_unix':d['started_at_unix'],'ended_at_unix':d['ended_at_unix'],'duration_seconds':d['duration_seconds'],'measurement_scope':'Actual bounded read-only terminal CI metadata GET envelope; includes process/transport overhead; no dispatch and not model/native time','tags':[]})
        elif valid(d):
            events.append({'id':'actual-api-retry-after-503:'+name,'stage':'network_wait','source_receipt':name,'evidence':name,'execution_domain':'local','started_at_unix':d['started_at_unix'],'ended_at_unix':d['ended_at_unix'],'duration_seconds':d['ended_at_unix']-d['started_at_unix'],'measurement_scope':'Actual successful GET retry after observed HTTP503. Prior failed GET duration unknown. Not CI code failure; no dispatch.','tags':[]})
    region_history=[]
    region_dir=ROOT/'build/production_repair/release/region-fresh-a2'
    for basename in ('cohesion-before-run.json','cohesion-owner-run.json','fresh-run-attempt1.json','fresh-run-before-order-correction.json','interactive-lifecycle-final.json','fresh-run.json'):
        path=region_dir/basename
        if not path.is_file():continue
        name=str(path.relative_to(ROOT));d=read(name)
        item={'evidence':name,'status':d.get('status'),'exit_code':d.get('exit'),'reported_seconds':d.get('seconds'),'scope':d.get('scope'),'terminal_leak':d.get('terminal_leak'),'acceptance':'rejected_pre_unload_observation_order' if basename=='fresh-run-before-order-correction.json' else 'native_terminal_leak_not_clean' if d.get('terminal_leak') else 'original reported result; full final driver separately bounded','interval':'unknown'}
        if basename=='fresh-run.json' and d.get('started_utc') and d.get('ended_utc'):
            a,b=interval(d['started_utc']),interval(d['ended_utc']);item['interval']='actual endpoints'
            item['source_count']=len(d.get('source_before',{}));item['source_unchanged']=d.get('source_unchanged')
            events.append({'id':'region-final:'+name,'stage':'verification','execution_domain':'local','evidence':name,'started_at_unix':a,'ended_at_unix':b,'duration_seconds':d['seconds'],'exit_code':d.get('exit'),'status':d.get('status'),'measurement_scope':'actual complete original15 fail-fast driver;16 source hashes; not whole deliver','tags':['rework']})
        region_history.append(item)
    late=region_dir/'interactive-lifecycle-late-capture-failed.log'
    if late.is_file():region_history.append({'evidence':str(late.relative_to(ROOT)),'sha256':hashlib.sha256(late.read_bytes()).hexdigest(),'acceptance':'actual late-capture failure retained','reported_seconds':None,'interval':'unknown; not inferred from mtime'})
    deliveries=[]; checks=[]
    for name in args.delivery_report:
        d=read(name); deliveries.append({'evidence':name,**{k:d.get(k) for k in ('commit','source_digest','status','build_info','build_info_sha256')}})
        for i,c in enumerate(d.get('steps',[])):
            if valid(c):
                events.append({'id':f'delivery:{Path(name).resolve()}:{i}','stage':stageof(c.get('argv',[])),'execution_domain':'local','evidence':name,'command':c.get('argv',[]),'status':c.get('status'),'exit_code':c.get('exit_code'),'failure_reason':c.get('failure_reason'),'started_at_unix':c['started_at_unix'],'ended_at_unix':c['ended_at_unix'],'duration_seconds':c['duration_seconds'],'measurement_scope':'inclusive_delivery_step','tags':['rework'] if d.get('status') in ('failed','interrupted') else []})
            else: checks.append({'evidence':name,'step':i,'status':c.get('status'),'reason':'No completed actual interval; excluded from wall'})
    for name,domain in [(p,'local') for p in args.harness_report]+[(p,'ci') for p in args.ci_harness_report]:
        d=read(name)
        for c in d.get('checks',[]):
            if c.get('reused'): checks.append({'evidence':name,'id':c['id'],'status':'reused','execution_seconds':None}); continue
            if valid(c): events.append({'id':f'{domain}-harness:{Path(name).resolve()}:{c["id"]}','stage':'verification','execution_domain':domain,'evidence':name,'check':c['id'],'status':c.get('status'),'exit_code':c.get('exit_code'),'failure_reason':c.get('failure_reason'),'started_at_unix':c['started_at_unix'],'ended_at_unix':c['ended_at_unix'],'duration_seconds':c['duration_seconds'],'measurement_scope':'inclusive_actual_check','tags':['rework'] if domain=='ci' and d.get('status')=='failed' else []})
            else: checks.append({'evidence':name,'id':c['id'],'status':c.get('status'),'reason':'No completed actual interval; excluded from wall'})
    ci=[]
    ci_documents={name:read(name) for name in args.ci_receipt}
    failed_run_ids={d.get('id') for d in ci_documents.values() if d.get('conclusion')=='failure'}
    for name in args.ci_receipt:
        d=ci_documents[name]
        rows=([d] if d.get('id') or d.get('databaseId') else [])+d.get('jobs',[])
        for i,row in enumerate(rows):
            run=row.get('databaseId',row.get('id',d.get('databaseId',d.get('id'))))
            item={'evidence':name,'run_or_job_id':run,'status':row.get('status'),'conclusion':row.get('conclusion'),'headSha':row.get('headSha',row.get('head_sha',d.get('headSha',d.get('head_sha'))))}
            if row.get('conclusion')=='skipped':
                item.update(observed_interval=False,reason='Skipped job has no executed cost; raw GitHub metadata may contain reversed timestamps')
                ci.append(item);continue
            a=row.get('started_at',row.get('startedAt',row.get('run_started_at'))); b=row.get('completed_at',row.get('completedAt'))
            if a is not None and b is not None:
                a,b=interval(a),interval(b)
                if b<a: raise ValueError('CI reversed timestamps')
                events.append({'id':f'ci:{"run" if i==0 else "job"}:{run}','stage':'release','execution_domain':'ci','evidence':name,'started_at_unix':a,'ended_at_unix':b,'duration_seconds':b-a,'status':row.get('status'),'conclusion':row.get('conclusion'),'measurement_scope':'actual_CI_inclusive_run_or_job; runner_cost_not_exposed','tags':['rework'] if row.get('conclusion')=='failure' or row.get('run_id') in failed_run_ids else []})
                item['observed_interval']=True
            else: item['observed_interval']=False
            ci.append(item)
    run_documents=[d for d in ci_documents.values() if d.get('id') and d.get('head_sha') and d.get('run_attempt')]
    source_runs={}
    for d in run_documents:source_runs.setdefault(d['head_sha'],set()).add((d['id'],d['run_attempt']))
    ci_attempt_accounting={'scope':'Only actual explicitly supplied CI run API receipts; never infer attempts from elapsed time or other GitHub activity','observed_distinct_sources':len(source_runs),'observed_distinct_run_attempts':sum(len(v) for v in source_runs.values()),'same_source_additional_run_attempts_observed':sum(max(0,len(v)-1) for v in source_runs.values()),'runs':[{'source_commit':source,'run_attempts':[{'run_id':i,'attempt':a} for i,a in sorted(v)]} for source,v in source_runs.items()]}
    public=[{'evidence':p,'receipt':read(p)} for p in args.public_receipt]
    composite=validate_composite(read(args.composite_receipt)) if args.composite_receipt else {'status':'pending','errors':['No composite receipt supplied'],'timing_events':[]}
    events.extend(composite['timing_events'])
    # Deduplicate only the same actual identity or exact same interval/domain/command.
    # In particular, source SHA alone is NEVER a deduplication identity.
    unique={}; duplicates=[]; by_id={}
    for e in events:
        if e['id'] in by_id:
            previous=by_id[e['id']]
            if any(e[k]!=previous[k] for k in ('execution_domain','started_at_unix','ended_at_unix','stage')): raise ValueError('Conflicting actual timing identity: '+e['id'])
            duplicates.append({'duplicate_id':e['id'],'retained_id':previous['id']}); continue
        by_id[e['id']]=e
        ident=(e['execution_domain'],e['started_at_unix'],e['ended_at_unix'],tuple(e.get('command',[])))
        if ident in unique and (e['id']==unique[ident]['id'] or e.get('command')):
            duplicates.append({'duplicate_id':e['id'],'retained_id':unique[ident]['id']}); continue
        unique[(ident,e['id']) if ident in unique else ident]=e
    events=list(unique.values())
    excluded_after_closure=[]
    if cutoff is not None:
        excluded_after_closure=[{'id':e['id'],'evidence':e['evidence'],'started_at_unix':e['started_at_unix'],'ended_at_unix':e['ended_at_unix']} for e in events if e['started_at_unix']>=cutoff]
        events=[e for e in events if e['started_at_unix']<cutoff]
        if any(e['ended_at_unix']>cutoff for e in events):raise ValueError('Observed command straddles explicit closed window; do not invent a partial elapsed cost')
    # All tags refer to canonical events, avoiding additive image/release rework aliases.
    for a in aliases:
        target=next((e for e in events if e['id']==a['canonical_id']),None)
        if target and a['tag'] not in target['tags']: target['tags'].append(a['tag'])
    stats=sweep(events)
    gross={}
    for s in STAGES:
        es=[e for e in events if e['stage']==s]
        gross[s]={'observed_events':len(es),'summed_inclusive_command_seconds':sum(e['duration_seconds'] for e in es) if es else None,'observed_interval_union_seconds':TIMING.union_seconds([(e['started_at_unix'],e['ended_at_unix']) for e in es]) if es else None,'exclusive_phase_seconds':stats['exclusive_phase_seconds'][s] if es else None,'pure_model_seconds':None if s=='model_implementation' else 'not_applicable'}
    rework=[e for e in events if 'rework' in e.get('tags',[])]
    failures=[e for e in events if e.get('exit_code') not in (None,0)]
    im=[e for e in events if e['stage']=='image_generation']
    network_measurement=read('build/production_repair/release/toolchain-efficiency.json')
    oldaccount=old['accounting']
    comparison={
      'claims_limited_by_different_scope':True,
      'v3':{'host_calls':oldaccount['created_unique_requests'],'host_elapsed_visible_calls':oldaccount['host_invocation_durations_visible'],'host_elapsed_inclusive_sum_seconds':oldaccount['visible_host_role_seconds_sum_not_wall_or_inference'],'image_calls':oldaccount['image_calls'],'image_visible_tool_calls':oldaccount['image_calls_with_tool_wall'],'image_tool_wall_sum_seconds':oldaccount['visible_image_tool_wall_seconds_sum'],'delivery_reported_step_seconds_sum':sum(x['duration_seconds'] for x in old['delivery']['steps']),'delivery_old_status':old['delivery']['status'],'strict_raw_log_audit':oldlogs['summary'],'missing_inner_native_logs_are':'unknown; not clean','unknown_phase_costs':['pure_model','actual_game_integration_exclusive','rework_exclusive','network_only','tokens','price']},
      'current':{'real_bounded_production_loop':loop,'stale_source_counterexample':stale,'image_calls':len(im),'image_tool_wall_sum_seconds':sum(e.get('tool_call_wall_seconds',0) for e in im),'image_supervisor_envelope_seconds':TIMING.union_seconds([(e['started_at_unix'],e['ended_at_unix']) for e in im]),'toolchain_duration_only_actual':network_measurement,'failed_release':[{k:e.get(k) for k in ('id','label','duration_seconds','exit_code','evidence','tags')} for e in rework if 'failed_release' in e.get('tags',[])],'full_delivery':deliveries[-1]['status'] if deliveries else 'pending until explicit terminal report supplied','composite_delivery':composite['status'],'ci':ci[-1] if ci else 'raw CI supplied within composite; see composite linkage status' if args.composite_receipt and composite['status']=='verified_composite' else 'pending; explicit new CI may be running, not yet a completed receipt','public':'receipt supplied; controller must independently verify' if public else 'pending until explicit fingerprint receipt supplied','commercial_art_goal':'not achieved; bounded plants admission does not make full cliff family accepted'},
      'permitted_efficiency_findings':[
        {'claim':'Actual consumer-specific calibration rejects frozen bad source before artistic/GPU promotion; distinct reviewer and exact same-source resume did not spend extra host calls.','positive':'real original implementation+independent review, 2 calls; same-source resume 0 new calls','negative':'raw cliff core .9845010336343344 < .995; source/spec unchanged; content_complete=false'},
        {'claim':'Source freshness has a real blocking counterexample, rather than trusting only status.','positive':'completed actual mission accepts exact source','negative':'isolated injected external source rejects exit1; state/calls unchanged; exact source restored'},
        {'claim':'Assertions/exit0 are insufficient native acceptance. First current delivery was stopped and charged; old V3 raw terminal diagnostics remain visible.','positive':'scoped repaired checks are evidence for those scopes only','negative':'old V3 3 observed outer checks/14 suite blocks leak; hidden inner summary checks remain unknown'},
        {'claim':'Call counts and image counts represent bounded scope, not a normalized speedup.','limitation':'V3 covered a much larger production batch; current 2-call loop is one engineering stage and 3 image attempts include failed cliffs. No44→2 or14→3 productivity percentage.'},
        {'claim':'Historical sparse input and lost inner log defects have actual preflight/log-capture fixes and failures retained.','limitation':'Old duration-only network/setup records cannot be placed on timeline or split into invented download/SHA costs.'},
      ],
      'forbidden_claims':['pure model or token/price estimate','all observed toolwall equals production elapsed','old passed status means native clean','full/publish success from an in-progress report','full cliff art goal completed','cross-scope call/image decrease is a speedup percentage']}
    status={'mode':'as_of','delivery':deliveries,'ci':ci,'public':public,'unfinished_records':checks,'composite_delivery':composite,'ci_attempt_accounting':ci_attempt_accounting,'local_tools_deliver_status_not_promoted':True,'final_totals_authorized':False}
    if args.final:
        terminal_delivery=any(d.get('status')=='passed' and d.get('commit')==args.verified_source for d in deliveries)
        terminal_ci=any(c.get('conclusion')=='success' and c.get('headSha')==args.verified_source for c in ci)
        terminal_public=any(p['receipt'].get('verified') is True and p['receipt'].get('source_commit')==args.verified_source for p in public)
        composite_ok=composite['status']=='verified_composite' and composite['identity']['source_commit']==args.verified_source
        if not (args.verified_source and ((terminal_delivery and terminal_ci and terminal_public) or composite_ok)): raise ValueError('Final needs source-bound complete traditional receipts or explicit fully verified composite CI/browser/native/public receipts. Local failed tools/deliver is never upgraded. Composite errors: '+str(composite.get('errors')))
        status['mode']='final_receipts_supplied';status['final_totals_authorized']=True
    if args.closed_blocked_receipt:
        closure=closure_pre
        if not (isinstance(args.verified_source,str) and len(args.verified_source)==40 and all(c in '0123456789abcdef' for c in args.verified_source) and closure.get('status')=='closed_blocked' and closure.get('decision')=='stop_publication' and closure.get('production_window_closed') is True and closure.get('observed_costs_final') is True and closure.get('new_ci_or_publication_authorized') is False and closure.get('source_commit')==args.verified_source and isinstance(closure.get('reason'),str) and closure['reason'].strip() and closure.get('evidence')):
            raise ValueError('Closed-blocked accounting requires explicit controller source-bound stop decision and actual blocking evidence; it is never a release success')
        for ref in closure['evidence']:
            path=Path(ref['path']);path=path if path.is_absolute() else ROOT/path
            if hashlib.sha256(path.read_bytes()).hexdigest()!=ref['sha256']:raise ValueError('Closed-blocked original evidence SHA mismatch')
        status.update(mode='closed_blocked_observed_costs',observed_cost_accounting_closed=True,complete_project_total=False,full_release_accepted=False,release_admission='blocked_not_published',closed_blocked_receipt=closure)
        comparison['current'].update(public='blocked_not_published_for_current_source',publication_decision='STOP; no third CI or current-source public success claimed')
    data={'schema_version':1,'generated_at_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'source_commit_read_only':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'status':status,'policy':POLICY,'observed_as_of':{'phases_inclusive_not_additive':gross,'non_overlapping':stats,'rework_tag_interval_union_seconds':TIMING.union_seconds([(e['started_at_unix'],e['ended_at_unix']) for e in rework]),'closed_window_excluded_records':excluded_after_closure,'nonzero_or_interrupted_commands':[{k:e.get(k) for k in ('id','stage','label','exit_code','duration_seconds','evidence','failure_classification')} for e in failures],'duration_only_unknown_interval':raw_report['unknown_records'],'nested_components_without_intervals_not_added':components,'region_repair_history':region_history,'missing_declared_products':missing_products,'alias_records_not_added':aliases,'duplicate_actual_records_not_added':duplicates},'efficiency_comparison':comparison,'events':events,'input_snapshot':INPUTS}
    if any(hashlib.sha256((ROOT/p).read_bytes()).hexdigest()!=ledger_snapshots[p] for p in ledgers):raise ValueError('A live timing ledger appended during collection; retry read-only aggregation with a new output directory')
    out.mkdir(parents=True)
    copies,ledger_redactions,event_origins=portable_ledger_copies(ledgers,out/'portable-ledgers',cutoff)
    data,report_redactions=portable_redact(data,event_origins)
    data['portable_evidence']={'original_ledgers_untouched':True,'ledger_copies':copies,'redactions':ledger_redactions+report_redactions,'redaction_policy':'Replace credential-bearing HTTP URI strings only; numeric durations, byte counts, identity and all other command arguments remain exact. Raw local ledgers are never published or modified.'}
    (out/'phase-costs-as-of.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
    md=['本文件是只读计时准备稿，完整交付/CI/公开指纹以显式原件为准。','',f"源：{data['source_commit_read_only']}；记录生成：{data['generated_at_utc']}。",'',f"已观测区间并集 {stats['union_seconds']:.3f} 秒。这是有记录片段的并集，既非项目总工时，也非模型计算时间。",'','阶段包络与嵌套子检查不能相加；只给一个阶段的区间与跨阶段重叠分别输出，duration-only记录不强行放到时间轴。CI与本地相同源码仍是各自真实执行；并发只在墙钟并集去重，不能抹掉额外验证工作。','',f"已记录失败/中断deliver：{[(round(e['duration_seconds'],6),e.get('exit_code')) for e in rework if 'failed_release' in e.get('tags',[])]}秒/退出码；每次各保留为发布阶段的一次真实命令，同时标记返工。旧V3原始57日志中的3个外层check、14个suite有退出诊断；summary隐藏的内层日志未知，不再把旧passed当作严格clean。",'',f"旧V3：44真实生产调用，27条可见角色包络合计17682.785秒；14图生中的13条可见工具wall合计636.724秒。本轮：真实校准loop2调用，独立审查、同源恢复0新调用；3图生工具wall合计{comparison['current']['image_tool_wall_sum_seconds']:.3f}秒、监督包络217秒。任务范围不同，不能据此计算加速比。",'','实际负例保留：冻结岩壁core覆盖率.984501 < .995，工程阶段可完成而艺术内容未完成；不扩阈值或用增加重试伪造成功。商业美术总目标未达。','',f"当前导入local delivery原件{len(deliveries)}份；组合交付状态{composite['status']}。组合交付只由完整CI、同CI包三浏览器、source-bound原生电影及同完整公开PCK与独审原件验证；不把local tools/deliver改称通过。没有原件的结果仍pending；模型纯耗时、token、价格不可见。",'','复用命令见同目录 refresh-command.txt；仅计算报告，不触发引擎、生产worker或发布。']
    if args.closed_blocked_receipt:
        md[0]='本轮生产窗口已关闭，发布受阻。本报告结清最终已观测成本；它不是完整项目总耗时，也不是成功发布。'
        md += ['',data['status']['closed_blocked_receipt']['reason'],'','正式CI只有两个不同源的attempt1；不触发第三CI或继续发布。所有未观测阶段仍unknown；原始失败与失败修复尝试均保留。']
    (out/'report-draft.md').write_text('\n'.join(md)+'\n')
    (out/'refresh-command.txt').write_text('PYTHONDONTWRITEBYTECODE=1 python3 build/production_repair/harness/prepare_final_costs.py --output-dir build/production_repair/harness/final-costs-NEW --delivery-report build/verification/delivery/20261016T071003Z/report.json --delivery-report build/verification/delivery/20261016T075233Z/report.json --composite-receipt ACTUAL_COMPOSITE_MANIFEST\nAdd --harness-report ACTUAL_HARNESS_REPORT for nested diagnostic costs; this does not add duplicate wall time. Add --final --verified-source EXACT_SHA only once the controller has supplied all actual terminal receipts. Composite manifest original receipts must all bind exact source/run/attempt/API artifact/ZIP/PCK. Public HTTP is bound by full actual PCK hash/bytes; native movie only binds source, never Web PCK. See build/production_repair/harness/composite-receipt-template.json and contract-counterexamples.json. Two local deliver failures remain unchanged.\nCI timestamp contract: id/databaseId, headSha, status, conclusion, run_started_at/started_at/startedAt and completed_at/completedAt; optional jobs[] uses the same fields. Missing timestamps stay unknown.\n')
    print(json.dumps({'output':str(out.relative_to(ROOT)),'mode':status['mode'],'event_count':len(events),'pending_final':not (status['final_totals_authorized'] or status.get('observed_cost_accounting_closed')),'successful_release_final':status['final_totals_authorized'],'observed_cost_accounting_closed':status.get('observed_cost_accounting_closed',False)},ensure_ascii=False))

if __name__=='__main__': main()
