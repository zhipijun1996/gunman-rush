class_name PaintedTerrainGrammar
extends Node2D
## One finite painted cross-section, continuously mapped along real bank contours.
var _design: Dictionary
var _spec: Dictionary
static var _underside_profiles: Dictionary={}
var _facts: Dictionary = {"method":"arc-length continuous full-depth section mesh", "source_repeated":false,"banks":[]}

func configure(design: Dictionary, specification: Dictionary) -> void:
	_design=design
	_spec=specification

func _ready() -> void:
	var path := str(_spec.texture)
	var texture := load(path) as Texture2D if ResourceLoader.exists(path) else null
	if texture==null:
		push_error("Painted bank section source missing: "+path)
		return
	for top: Dictionary in _design.top_polylines:
		var key := str(top.id).trim_suffix("_grass")
		for solid: Dictionary in _design.solid_polygons:
			if str(solid.id).trim_suffix("_shore")==key:_bank(solid,top,texture)

func measured_nodes() -> Dictionary:
	return _facts.duplicate(true)

func _points(raw: Array) -> PackedVector2Array:
	var result := PackedVector2Array()
	for p: Array in raw:result.append(Vector2(p[0],p[1]))
	return result

func _bank(solid: Dictionary, top: Dictionary, texture: Texture2D) -> void:
	var first_child := get_child_count()
	var outline := _points(solid.points)
	var curve := _points(top.points)
	var bottom := outline[0].y
	for p: Vector2 in outline:bottom=maxf(bottom,p.y)
	var points := PackedVector2Array()
	var distances := PackedFloat32Array()
	var length := 0.0
	for index: int in curve.size()-1:
		var steps := maxi(1,ceili(curve[index].distance_to(curve[index+1])/12.0))
		for step: int in steps:
			var p := curve[index].lerp(curve[index+1],float(step)/steps)
			if not points.is_empty():length+=points[-1].distance_to(p)
			points.append(p);distances.append(length)
	length+=points[-1].distance_to(curve[-1]);points.append(curve[-1]);distances.append(length)
	var offset := float(_spec.source_x_offsets.get(str(solid.id),0.0))
	var end := offset+length*float(_spec.source_pixels_per_world_unit)
	if end>texture.get_width():
		push_error("Finite bank source exhausted; refusing repeat or full-strip compression: "+str(solid.id))
		return
	var front := {"vertices":PackedVector2Array(),"uv":PackedVector2Array(),"indices":PackedInt32Array()}
	var back := {"vertices":PackedVector2Array(),"uv":PackedVector2Array(),"indices":PackedInt32Array()}
	for index: int in points.size()-1:
		for mode: String in ["back","lip","upper_side","deep_side"]:
			_append_band(back if mode=="back" else front,points[index],points[index+1],distances[index],distances[index+1],offset,bottom,mode,outline,texture.get_size(),Vector2(curve[0].x,curve[-1].x),Vector2(curve[0].y,curve[-1].y))
	_install_mesh(back,texture,-3,"PaintedTop_"+str(solid.id))
	_install_mesh(front,texture,-2,"PaintedContinuousFace_"+str(solid.id))
	for side: String in ["left","right"]:
		if _spec.get("ends",{}).has(side):_end_strip(outline,curve[0] if side=="left" else curve[-1],bottom,side,_spec.ends[side])
	for patch: Dictionary in _spec.get("face_patches",[]):
		if str(patch.bank)==str(solid.id):_face_patch(outline,patch)
	if _spec.has("visible_underside"):
		var underside: Dictionary=_spec.visible_underside
		var underside_texture := load(str(underside.texture)) as Texture2D
		var bottom_profile := _bottom_profile(underside_texture)
		for index: int in range(first_child,get_child_count()):
			var mesh := get_child(index) as MeshInstance2D
			var material := ShaderMaterial.new()
			material.shader=load("res://scripts/art/painted_formal_underside.gdshader") as Shader
			material.set_shader_parameter("underside",underside_texture)
			material.set_shader_parameter("underside_size",underside_texture.get_size())
			material.set_shader_parameter("bottom_profile",bottom_profile)
			material.set_shader_parameter("bank_bottom",bottom)
			material.set_shader_parameter("bank_left",curve[0].x)
			material.set_shader_parameter("source_start",float(underside.source_start))
			material.set_shader_parameter("source_pixels_per_world_unit",float(_spec.source_pixels_per_world_unit))
			material.set_shader_parameter("blend_top",float(underside.world_blend_depth[0]))
			material.set_shader_parameter("blend_bottom",float(underside.world_blend_depth[1]))
			mesh.material=material
	_facts.banks.append({"id":solid.id,"source_span":[offset,end],"arc_length_world":length,"samples":points.size(),"source_surface_profile":_spec.source_surface_profile,"front_vertices":front.vertices.size(),"back_vertices":back.vertices.size(),"collision_changed":false,"coverage":_coverage(front,outline,curve,bottom),"end_connections":"finite60world inward turn faces; GPU alignment unverified"})

func _bottom_profile(texture: Texture2D) -> Texture2D:
	var path := texture.resource_path
	if _underside_profiles.has(path):return _underside_profiles[path]
	var original := texture.get_image()
	if original.is_compressed():original.decompress()
	# Sampling metadata, not a painted replacement: every source column keeps
	# its original pixels and records its last alpha>=128 standing boundary.
	var profile := Image.create(original.get_width(),1,false,Image.FORMAT_RG8)
	for x: int in original.get_width():
		var bottom := 0
		for y: int in range(original.get_height()-1,-1,-1):
			if original.get_pixel(x,y).a>=128.0/255.0:bottom=y;break
		profile.set_pixel(x,0,Color(floorf(float(bottom)/256.0)/255.0,float(bottom%256)/255.0,0,1))
	var result := ImageTexture.create_from_image(profile)
	_underside_profiles[path]=result
	return result

func _source_surface(x: float) -> float:
	var profile: Array=_spec.source_surface_profile
	for index: int in profile.size()-1:
		var a: Array=profile[index]
		var b: Array=profile[index+1]
		if x<=float(b[0]):return lerpf(float(a[1]),float(b[1]),clampf((x-float(a[0]))/maxf(.001,float(b[0])-float(a[0])),0,1))
	return float(profile[-1][1])

func _contour_point(top: Vector2, depth: float, outline: PackedVector2Array, span: Vector2, bottom: float) -> Vector2:
	if depth<=0:return top+Vector2(0,depth)
	var y := top.y+depth
	var q := clampf((top.x-span.x)/maxf(.001,span.y-span.x),0,1)
	var exponent := 1.0+31.0*exp(-depth/maxf(1,float(_spec.lip_world_depth)))
	var left := _edge_at(outline,minf(y,bottom-.001),true)
	var right := _edge_at(outline,minf(y,bottom-.001),false)
	return Vector2(top.x+(left-span.x)*pow(1-q,exponent)+(right-span.y)*pow(q,exponent),y)

func _append_band(data: Dictionary, a: Vector2, b: Vector2, arc_a: float, arc_b: float, source_offset: float, bottom: float, mode: String, outline: PackedVector2Array, texture_size: Vector2, span: Vector2, end_heights: Vector2) -> void:
	var upper := -float(_spec.back_world_depth) if mode=="back" else 0.0 if mode=="lip" else float(_spec.lip_world_depth) if mode=="upper_side" else float(_spec.upper_side_world_depth)
	var lower_a := 0.0 if mode=="back" else float(_spec.lip_world_depth) if mode=="lip" else float(_spec.upper_side_world_depth) if mode=="upper_side" else bottom-a.y
	var lower_b := 0.0 if mode=="back" else float(_spec.lip_world_depth) if mode=="lip" else float(_spec.upper_side_world_depth) if mode=="upper_side" else bottom-b.y
	# A shallower existing bank crops the shoulder at its real bottom. Never
	# generate a reversed deep band or squeeze all painted depth into a slab.
	if mode!="back":
		lower_a=minf(lower_a,bottom-a.y);lower_b=minf(lower_b,bottom-b.y)
		if lower_a<=upper and lower_b<=upper:return
	var rows := maxi(1,ceili(maxf(lower_a-upper,lower_b-upper)/24.0))
	# Shared row fractions include every actual outer-edge corner on either end.
	# Thus the front boundary follows the whole polygon, including outward wedges.
	var fractions: Array[float]=[]
	for row: int in rows+1:fractions.append(float(row)/rows)
	if mode!="back":
		for height: float in [end_heights.x,end_heights.y]:
			var lower := bottom-height if mode=="deep_side" else lower_a
			for point: Vector2 in outline:
				var t := (point.y-height-upper)/maxf(.001,lower-upper)
				if t>0 and t<1 and not fractions.has(t):fractions.append(t)
	fractions.sort()
	var source_a := source_offset+arc_a*float(_spec.source_pixels_per_world_unit)
	var source_b := source_offset+arc_b*float(_spec.source_pixels_per_world_unit)
	for row: int in fractions.size()-1:
		var d0a := lerpf(upper,lower_a,fractions[row])
		var d0b := lerpf(upper,lower_b,fractions[row])
		var d1a := lerpf(upper,lower_a,fractions[row+1])
		var d1b := lerpf(upper,lower_b,fractions[row+1])
		var quad := PackedVector2Array([_contour_point(a,d0a,outline,span,bottom),_contour_point(b,d0b,outline,span,bottom),_contour_point(b,d1b,outline,span,bottom),_contour_point(a,d1a,outline,span,bottom)])
		var uv := PackedVector2Array([Vector2(source_a,_end_source_y(d0a,bottom-a.y,_source_surface(source_a),texture_size.y))/texture_size,Vector2(source_b,_end_source_y(d0b,bottom-b.y,_source_surface(source_b),texture_size.y))/texture_size,Vector2(source_b,_end_source_y(d1b,bottom-b.y,_source_surface(source_b),texture_size.y))/texture_size,Vector2(source_a,_end_source_y(d1a,bottom-a.y,_source_surface(source_a),texture_size.y))/texture_size])
		for ids: Array in [[0,1,2],[0,2,3]]:
			var triangle := PackedVector2Array([quad[ids[0]],quad[ids[1]],quad[ids[2]]])
			var source_uv := PackedVector2Array([uv[ids[0]],uv[ids[1]],uv[ids[2]]])
			_append_clipped_triangle(data,triangle,source_uv,outline,mode=="back")

func _append_clipped_triangle(data: Dictionary, triangle: PackedVector2Array, source_uv: PackedVector2Array, outline: PackedVector2Array, unclipped: bool=false) -> void:
	var denominator := (triangle[1]-triangle[0]).cross(triangle[2]-triangle[0])
	if absf(denominator)<.00001:return
	var pieces: Array[PackedVector2Array]=[]
	if unclipped:pieces.append(triangle)
	else:pieces=Geometry2D.intersect_polygons(triangle,outline)
	for piece: PackedVector2Array in pieces:
		var base: int=data.vertices.size()
		for point: Vector2 in piece:
			var relative := point-triangle[0]
			var wb := relative.cross(triangle[2]-triangle[0])/denominator
			var wc := (triangle[1]-triangle[0]).cross(relative)/denominator
			data.vertices.append(point);data.uv.append(source_uv[0]*(1-wb-wc)+source_uv[1]*wb+source_uv[2]*wc)
		for index: int in Geometry2D.triangulate_polygon(piece):data.indices.append(base+index)

func _covered(data: Dictionary, point: Vector2) -> bool:
	for i: int in range(0,data.indices.size(),3):
		var triangle := PackedVector2Array([data.vertices[data.indices[i]],data.vertices[data.indices[i+1]],data.vertices[data.indices[i+2]]])
		if Geometry2D.is_point_in_polygon(point,triangle):return true
	return false

func _coverage(data: Dictionary, outline: PackedVector2Array, curve: PackedVector2Array, bottom: float) -> Dictionary:
	var top := curve[0].y
	for p: Vector2 in curve:top=maxf(top,p.y)
	var checks: Array=[]
	var success := true
	for fraction: float in [.15,.5,.85]:
		var y := lerpf(top,bottom,fraction)
		var left := _edge_at(outline,y,true)
		var right := _edge_at(outline,y,false)
		for x: float in [left+.5,lerpf(left,right,.25),lerpf(left,right,.5),lerpf(left,right,.75),right-.5,left-2,right+2]:
			var point := Vector2(x,y)
			var actual := Geometry2D.is_point_in_polygon(point,outline)
			var covered := _covered(data,point)
			success=success and actual==covered
			checks.append({"point":[x,y],"inside_actual_solid":actual,"covered_by_actual_front_triangles":covered,"legacy_top_x_domain":x>=curve[0].x and x<=curve[-1].x})
	return {"all_samples_match_actual_solid":success,"scope":"actual mesh geometry, not texture opacity or artistic approval","samples":checks}

func _face_patch(outline: PackedVector2Array, spec: Dictionary) -> void:
	var texture := load(str(spec.texture)) as Texture2D
	if texture==null:return
	var origin := Vector2(spec.position[0],spec.position[1])
	var size := Vector2(spec.world_size[0],spec.world_size[1])
	var region := Rect2(spec.source_region[0],spec.source_region[1],spec.source_region[2],spec.source_region[3])
	var data := {"vertices":PackedVector2Array(),"uv":PackedVector2Array(),"indices":PackedInt32Array(),"colors":PackedColorArray()}
	for row: int in 8:
		for column: int in 8:
			var quad := PackedVector2Array([origin+size*Vector2(column,row)/8.0,origin+size*Vector2(column+1,row)/8.0,origin+size*Vector2(column+1,row+1)/8.0,origin+size*Vector2(column,row+1)/8.0])
			for piece: PackedVector2Array in Geometry2D.intersect_polygons(quad,outline):
				var base: int=data.vertices.size()
				for point: Vector2 in piece:
					var q := (point-origin)/size
					data.vertices.append(point);data.uv.append((region.position+region.size*q)/texture.get_size())
					var fade := smoothstep(0,.15,minf(minf(q.x,1-q.x),minf(q.y,1-q.y)))
					data.colors.append(Color(1,1,1,fade))
				for index: int in Geometry2D.triangulate_polygon(piece):data.indices.append(base+index)
	_install_mesh(data,texture,0,"InertPaintedReceiverRepair")

func _install_mesh(data: Dictionary, texture: Texture2D, order: int, label: String) -> void:
	if data.indices.is_empty():return
	var arrays: Array=[]
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX]=data.vertices
	arrays[Mesh.ARRAY_TEX_UV]=data.uv
	arrays[Mesh.ARRAY_INDEX]=data.indices
	if data.has("colors"):arrays[Mesh.ARRAY_COLOR]=data.colors
	var mesh := ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES,arrays,[],{},Mesh.ARRAY_FLAG_USE_2D_VERTICES)
	var node := MeshInstance2D.new()
	node.mesh=mesh;node.texture=texture
	node.texture_repeat=CanvasItem.TEXTURE_REPEAT_DISABLED
	node.z_as_relative=false;node.z_index=order;node.name=label
	add_child(node)


func _edge_at(outline: PackedVector2Array, y: float, left: bool) -> float:
	var crossings: Array[float]=[]
	for index: int in outline.size():
		var a := outline[index]
		var b := outline[(index+1)%outline.size()]
		if (a.y<=y and b.y>y) or (b.y<=y and a.y>y):crossings.append(lerpf(a.x,b.x,(y-a.y)/(b.y-a.y)))
	crossings.sort()
	if crossings.is_empty():return outline[0].x
	return crossings[0] if left else crossings[-1]

func _end_source_y(depth: float, maximum: float, surface: float, height: float) -> float:
	if depth<=0:return surface+depth/float(_spec.back_world_depth)*float(_spec.back_source_depth)
	if depth<=float(_spec.lip_world_depth):return surface+depth/float(_spec.lip_world_depth)*float(_spec.lip_source_depth)
	if depth<=float(_spec.upper_side_world_depth):return lerpf(surface+float(_spec.lip_source_depth),surface+float(_spec.upper_side_source_depth),(depth-float(_spec.lip_world_depth))/(float(_spec.upper_side_world_depth)-float(_spec.lip_world_depth)))
	return lerpf(surface+float(_spec.upper_side_source_depth),height-1,(depth-float(_spec.upper_side_world_depth))/maxf(1,maximum-float(_spec.upper_side_world_depth)))

func _outer_source(profile: Array, y: float) -> float:
	for index: int in profile.size()-1:
		if y<=float(profile[index+1][0]):return lerpf(float(profile[index][1]),float(profile[index+1][1]),clampf((y-float(profile[index][0]))/(float(profile[index+1][0])-float(profile[index][0])),0,1))
	return float(profile[-1][1])

func _end_strip(outline: PackedVector2Array, foot: Vector2, bottom: float, side: String, spec: Dictionary) -> void:
	var texture := load(str(spec.texture)) as Texture2D
	if texture==null:return
	var left := side=="left"
	var direction := 1.0 if left else -1.0
	var width := float(spec.world_width)
	var depths: Array[float]=[-float(_spec.back_world_depth),0]
	for depth: float in [float(_spec.lip_world_depth),float(_spec.upper_side_world_depth)]:
		if depth<bottom-foot.y:depths.append(depth)
	var next := depths[-1]+24.0
	while next<bottom-foot.y:depths.append(next);next+=24.0
	depths.append(bottom-foot.y)
	var columns: Array[float]=[0,.45,.8,1]
	var front := {"vertices":PackedVector2Array(),"uv":PackedVector2Array(),"indices":PackedInt32Array(),"colors":PackedColorArray()}
	var back := {"vertices":PackedVector2Array(),"uv":PackedVector2Array(),"indices":PackedInt32Array(),"colors":PackedColorArray()}
	for row: int in depths.size()-1:
		var ya := foot.y+depths[row]
		var yb := foot.y+depths[row+1]
		var xa := foot.x if depths[row]<=0 else _edge_at(outline,minf(ya,bottom-.001),left)
		var xb := foot.x if depths[row+1]<=0 else _edge_at(outline,minf(yb,bottom-.001),left)
		for column: int in columns.size()-1:
			var u0 := columns[column]
			var u1 := columns[column+1]
			var quad := PackedVector2Array([Vector2(xa+direction*width*u0,ya),Vector2(xa+direction*width*u1,ya),Vector2(xb+direction*width*u1,yb),Vector2(xb+direction*width*u0,yb)])
			var pieces: Array[PackedVector2Array]=[]
			if depths[row]<0:pieces.append(quad)
			else:pieces=Geometry2D.intersect_polygons(quad,outline)
			var data: Dictionary=back if depths[row]<0 else front
			for piece: PackedVector2Array in pieces:
				var base: int=data.vertices.size()
				for p: Vector2 in piece:
					var t := clampf((p.y-ya)/maxf(.001,yb-ya),0,1)
					var edge := lerpf(xa,xb,t)
					var u := clampf((p.x-edge)/(direction*width),0,1)
					var source_y := _end_source_y(p.y-foot.y,bottom-foot.y,float(spec.source_surface_y),texture.get_height())
					var profile: Array=spec.outer_profile
					var source_x := _outer_source(profile,source_y)+direction*float(spec.source_width)*u
					data.vertices.append(p);data.uv.append(Vector2(source_x,source_y)/texture.get_size())
					var opacity := 1-smoothstep(float(spec.get("blend_start",.45)),1,u)
					data.colors.append(Color(1,1,1,opacity))
				for triangle: int in Geometry2D.triangulate_polygon(piece):data.indices.append(base+triangle)
	_install_mesh(front,texture,-1,"PaintedEnd_"+side)
	_install_mesh(back,texture,-2,"PaintedEndTop_"+side)
