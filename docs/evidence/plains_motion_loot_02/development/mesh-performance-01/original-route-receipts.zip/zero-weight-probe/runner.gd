extends SceneTree
func _initialize() -> void:
	var original: Script=load("res://build/plains-ci-41001060607/zero-weight-probe/reference_ground.gd")
	var tested:=0
	var different:=0
	var max_error:=0.0
	var poses: Array=[]
	for phase: float in [0.0,0.13,0.37,0.65,0.97,1.0]:
		poses.append({"clock":phase*17.3,"stride":phase*8.2,"travel":phase,"drive":phase*2.0-1.0,"body_follow":phase*.8,"appendage_follow":phase*.7,"load":phase,"strike":1.0-phase,"recovery":phase*.5,"hurt":phase,"turn":phase,"air":phase>.5,"dead":false})
		poses.append({"clock":12.3,"stride":9.1,"travel":1.0,"drive":-.4,"appendage_follow":.8,"load":.8,"strike":.2,"recovery":.3,"hurt":.7,"turn":-.6,"air":false,"dead":true,"death":phase})
	for kind: StringName in [&"patrol",&"charger",&"hopper"]:
		var size: Vector2=PlainsRevisionSkin.SIZES[kind]
		for pose: Dictionary in poses:
			for y: int in 25:
				for x: int in 25:
					var uv:=Vector2(float(x)/24.0,float(y)/24.0)
					var p:=Vector2(-size.x*.5,-size.y)+uv*size
					var a: Vector2=original.call("deform",p,uv,size,pose,kind)
					var b:=PlainsRevisionGround.deform(p,uv,size,pose,kind)
					tested+=1
					if PackedVector2Array([a]).to_byte_array()!=PackedVector2Array([b]).to_byte_array():different+=1
					max_error=maxf(max_error,a.distance_to(b))
	print("ZERO_WEIGHT_PROBE ",JSON.stringify({"vertices":tested,"different_bytes":different,"max_coordinate_error":max_error}))
	quit(0 if different==0 else 1)
