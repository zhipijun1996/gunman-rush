extends SceneTree
func _initialize() -> void:
	var original: Script=load("res://build/plains-ci-41001060607/zero-weight-probe/reference_ground.gd")
	var candidate: Script=load("res://build/plains-ci-41001060607/prepared-probe/candidate_ground.gd")
	var units:=PackedVector2Array()
	for y: int in 25:
		for x: int in 25: units.append(Vector2(float(x)/24.0,float(y)/24.0))
	var weights: PackedFloat64Array=candidate.call("prepare_charger_weights",units)
	var poses: Array[Dictionary]=[{}, {"clock":0.0,"stride":0.0,"load":0.0,"strike":0.0}]
	var values: Array[float]=[-.4,0.0,.13,.58,1.0,1.4]
	for i: int in 96:
		var pose: Dictionary={"clock":float(i)*1.731,"stride":float(i)*.631,"travel":values[i%6],"drive":values[(i*5+1)%6]*2.0-1.0,"load":values[(i*3+2)%6],"strike":values[(i*5+3)%6],"recovery":values[(i*7+4)%6],"hurt":values[(i*11+5)%6],"turn":values[(i*13+3)%6],"air":i%2==0,"dead":false,"_unknown_token":"retained"}
		if i%3: pose.appendage_follow=values[(i+4)%6]
		poses.append(pose)
	var tested:=0
	var different:=0
	var changed_pose:=0
	var max_error:=0.0
	var examples: Array=[]
	for size: Vector2 in [Vector2(40.5,30.375),Vector2(16,16),Vector2(100,80)]:
		for pose: Dictionary in poses:
			var before:=JSON.stringify(pose)
			var frame: RefCounted=candidate.call("prepare_charger",size,pose)
			for i: int in units.size():
				var uv:=units[i]
				var p:=Vector2(-size.x*.5,-size.y)+uv*size
				var a: Vector2=original.call("deform",p,uv,size,pose,&"charger")
				var b: Vector2=candidate.call("deform_charger_prepared",p,weights,i*7,frame)
				tested+=1
				if PackedVector2Array([a]).to_byte_array()!=PackedVector2Array([b]).to_byte_array():
					different+=1
					if examples.size()<5:examples.append({"size":[size.x,size.y],"pose":pose.duplicate(true),"uv":[uv.x,uv.y],"old":[a.x,a.y],"new":[b.x,b.y]})
				max_error=maxf(max_error,a.distance_to(b))
			if before!=JSON.stringify(pose):changed_pose+=1
	var result: Dictionary={"vertices":tested,"different_bytes":different,"max_coordinate_error":max_error,"changed_caller_poses":changed_pose,"poses":poses.size(),"sizes":3,"examples":examples}
	var f:=FileAccess.open("res://build/plains-ci-41001060607/prepared-probe/result.json",FileAccess.WRITE);f.store_string(JSON.stringify(result,"  "));f.close()
	print("PREPARED_PROBE ",JSON.stringify(result))
	quit(0 if different==0 and changed_pose==0 else 1)
