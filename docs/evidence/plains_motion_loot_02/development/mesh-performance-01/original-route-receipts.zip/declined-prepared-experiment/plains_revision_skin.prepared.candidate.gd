class_name PlainsRevisionSkin
extends RefCounted
## One authored body and continuous joints through live, hurt and death.
## Coordinates are in world units; source resolution never sets pixel size.
const GRID := 24
const TEXTURES := {
	&"patrol": preload("res://assets/plains_revision_01/patrol.png"),
	&"charger": preload("res://assets/plains_revision_01/charger.png"),
	&"hopper": preload("res://assets/plains_revision_01/hopper.png"),
	&"sentry": preload("res://assets/plains_revision_01/sentry.png"),
	&"fan_sentry": preload("res://assets/plains_revision_01/fan_sentry.png"),
	&"root_bell": preload("res://assets/plains_revision_01/root_bell.png")
}
# Relative to the measured visible bodies, not the source PNG dimensions.
const SIZES := {&"patrol":Vector2(41.4,39.33),&"charger":Vector2(40.5,30.375),&"hopper":Vector2(41.4,33.12),&"sentry":Vector2(41.4,42.46),&"fan_sentry":Vector2(41.4,30),&"root_bell":Vector2(49.5,60)}
var texture: Texture2D
var bounds := Rect2()
var kind: StringName
var _mesh := ArrayMesh.new()
var _points := PackedVector2Array()
var _units := PackedVector2Array()
var _charger_weights := PackedFloat64Array()

static func supports(definition: EnemyDefinition) -> bool:
	return definition != null and definition.stable_id in [&"patrol_drone",&"graybox_patrol_drone",&"plains_charger",&"plains_hopper",&"plains_sentry",&"plains_fan_sentry",&"plains_root_bell"]

func _init(behavior: StringName = &"patrol") -> void:
	kind = behavior
	texture = TEXTURES.get(kind)
	var size: Vector2 = SIZES.get(kind,Vector2(36,36))
	bounds = Rect2(Vector2(-size.x*.5,-size.y),size)
	var uvs := PackedVector2Array()
	var indices := PackedInt32Array()
	for y: int in GRID+1:
		for x: int in GRID+1:
			var uv := Vector2(float(x)/GRID,float(y)/GRID)
			_units.append(uv)
			_points.append(bounds.position+uv*size)
			uvs.append(uv)
	if kind == &"charger":
		_charger_weights = PlainsRevisionGround.prepare_charger_weights(_units)
	for y: int in GRID:
		for x: int in GRID:
			var i := y*(GRID+1)+x
			indices.append_array(PackedInt32Array([i,i+1,i+GRID+2,i,i+GRID+2,i+GRID+1]))
	var arrays: Array = []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = _points
	arrays[Mesh.ARRAY_TEX_UV] = uvs
	arrays[Mesh.ARRAY_INDEX] = indices
	_mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES,arrays,[],{},Mesh.ARRAY_FLAG_USE_2D_VERTICES|Mesh.ARRAY_FLAG_USE_DYNAMIC_UPDATE)

func deform(point: Vector2, uv: Vector2, pose: Dictionary) -> Vector2:
	var master := point
	if kind==&"fan_sentry":
		# The new broad fan source devotes more area to wings. Fit its copper
		# abdomen to the previous body's ~13wu mass (+about 7.5%), independently
		# of the wing envelope's +15%. Stretching the entire source made it small.
		var body := (1.0-smoothstep(.12,.27,absf(uv.x-.42)))*smoothstep(.43,.59,uv.y)*(1.0-smoothstep(.87,.99,uv.y))
		var center := Vector2((.42-.5)*bounds.size.x,(.70-1.0)*bounds.size.y)
		master = point.lerp(center+(point-center)*1.55,body)
	var p := PlainsRevisionGround.deform(master,uv,bounds.size,pose,kind) if kind in [&"patrol",&"charger",&"hopper"] else PlainsRevisionFlora.deform(master,uv,bounds.size,pose,kind)
	# Contact impulse moves the mass, while the supporting feet retain the floor.
	if bool(pose.get("dead",false)):
		p.y -= float(pose.get("landing",0.0))*bounds.size.y*.025*(1.0-smoothstep(.77,1.0,uv.y))
	return p

func draw_pose(canvas: Node2D, pose: Dictionary, tint: Color = Color.WHITE) -> void:
	if texture == null: return
	if not PlainsMotion02.body_mesh_visible(canvas,bounds): return
	var vertices := PackedVector2Array()
	vertices.resize(_points.size())
	if kind == &"charger" and _charger_weights.size() == _points.size() * PlainsRevisionGround.CHARGER_WEIGHT_COUNT and not bool(pose.get("dead", false)):
		var frame := PlainsRevisionGround.prepare_charger(bounds.size, pose)
		for i: int in _points.size():
			vertices[i] = PlainsRevisionGround.deform_charger_prepared(_points[i], _charger_weights, i * PlainsRevisionGround.CHARGER_WEIGHT_COUNT, frame)
	else:
		for i: int in _points.size(): vertices[i] = deform(_points[i],_units[i],pose)
	_mesh.surface_update_vertex_region(0,0,vertices.to_byte_array())
	if canvas.material is ShaderMaterial:
		canvas.material.set_shader_parameter("death_progress",float(pose.get("death",0.0)) if bool(pose.get("dead",false)) else 0.0)
		canvas.material.set_shader_parameter("eye_center",Vector2(.86,.39) if kind==&"patrol" else Vector2(.87,.52) if kind==&"hopper" else Vector2(.79,.46))
		canvas.material.set_shader_parameter("plant_body",kind in [&"root_bell",&"sentry"])
		canvas.material.set_shader_parameter("kind_code",1 if kind==&"fan_sentry" else 2 if kind==&"root_bell" else 0)
	canvas.draw_mesh(_mesh,texture,Transform2D.IDENTITY,tint)
