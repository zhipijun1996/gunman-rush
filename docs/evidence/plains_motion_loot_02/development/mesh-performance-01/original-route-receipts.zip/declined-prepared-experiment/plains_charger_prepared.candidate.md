# Charger draw preparation candidate — not applied or run

Files: `/tmp/plains_revision_ground.prepared.candidate.gd`, `/tmp/plains_revision_skin.prepared.candidate.gd`, `/tmp/plains_charger_prepared.candidate.patch`.

This is a deliberately bounded response to the measured charger hotspot. Ground's existing full source is retained byte-for-byte as the candidate's unchanged prefix. Its public `deform` API, live/vitality/death helpers and direct callers therefore keep the reference path. Skin's public `deform` is unchanged. Only drawing a live charger opts into a prepared path; lethal `dead=true,death=0`, transitional deaths, final corpses and all other kinds use the original draw deformation. The625 points, GRID24, UVs, indices, topology, draw call, shader updates, visibility gate, tint, texture, phase and size stay unchanged.

A Skin computes the charger's seven immutable UV mask weights once. These are float64 scalar values, preserving GDScript calculation precision. Each visible live-charger draw constructs a fresh typed ChargerFrame, samples current pose and size without writing pose, and calculates common gait/breath/trig coefficients and fixed pivots once. Vertex processing applies the original ordered operations with those values. The frame is never cached across draws, epochs, pause changes or reload. There is no mesh/final-corpse cache and no headless branch.

The candidate retains native Vector2.rotated and lerp calls. Their per-vertex rotations still evaluate native trig: manually substituting scalar sine/cosine basis multiplication risks changing float32 vector rounding. Shared scalar sine/cosine and UV masks are moved out of the vertex loop; the native rotation is a conscious remaining cost. `quiet` still clamps the sum of raw load+strike, preserving unusual out-of-range caller inputs rather than recomputing it from separately clamped values.

Expected work reduction, not a measured speed claim: common dictionary reads/scalar trig/mask smoothsteps/fixed pivot conversion move from625 evaluations per visible charger draw to one frame preparation (UV masks once per rig). All625 vertices still perform all eight ordered native joints. Preparation does not skip zero-weight operations, lower resolution, interpolate prior frames, reduce amplitude or hide any observer/draw work.

The added Ground helper block is136lines. This duplicates the charger's arithmetic in one explicitly named prepared path while keeping the old direct path available as a reference-compatible fallback. An equivalence consumer is required to prevent future formula drift; if same-machine route profiling shows an insignificant benefit, this duplication should not be landed merely to claim optimization.

No engine was launched and no numerical equivalence/performance pass is claimed by the author. Root must load frozen96bf reference and candidate in the same Godot build, compare all625 points against actual prepared draw vertices for many clocks/strides, all action phases, hurt/drive/follow extremes, missing keys, raw negative/over-range load+strike, varying bounds sizes, and unchanged direct/death paths. Goal is bit equality or strict maximum absolute coordinate error≤1e-6, not approximate visual similarity. Pose must compare byte-equal before/after preparation. Then root must repeat the original2154-frame/28-leg route and original80-route/600s tests with unchanged budgets and assertions; only the measured result can support retaining this candidate. Independent review remains separate from authoring.

Original Ground SHA: `f7af6a538d7eecd9a1deaa0bf657e164a729e559e8c2cf872eb848d1d4604b74`.
Candidate Ground SHA: `b51f3b09d960f25f35eff2c6d26e2d53b1d401859f7fcfa2d7bf29baac0fad72`.
Original Skin SHA: `10a76c7e0a0cc804c13eccf5faadbf2bfdc9e755202e7bbf59ffa454f0e8ae34`.
Candidate Skin SHA: `e53588795f3c8d0a389956435d028323f109bdcd6f6c5f86e5012f5265c836d1`.

A per-draw weight-count guard retains the original path if the public kind field is externally changed on a rig initialized for a different species; the fast path cannot index an absent/incorrect weight block.
