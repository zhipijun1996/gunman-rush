extends "res://scripts/enemies/plains_revision_skin.gd"
var calls:=0
var observed:=PackedVector2Array()
func _init(behavior: StringName = &"patrol") -> void:
	super(behavior)
func deform(point: Vector2, uv: Vector2, pose: Dictionary) -> Vector2:
	calls+=1
	var result:=super.deform(point,uv,pose)
	observed.append(result)
	return result
