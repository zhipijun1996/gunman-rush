extends Node2D
var rig: RefCounted
var pose: Dictionary={}
var draws:=0
func _draw() -> void:
	draws+=1
	if rig!=null:rig.call("draw_pose",self,pose)
