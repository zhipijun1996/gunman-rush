extends SceneTree
func _initialize() -> void:run.call_deferred()
func run() -> void:
	var rig: RefCounted=load("res://build/plains-ci-41001060607/cache-draw-probe/skin.gd").new(&"charger")
	var canvas: Node2D=load("res://build/plains-ci-41001060607/cache-draw-probe/canvas.gd").new()
	canvas.set("rig",rig);canvas.set("pose",{"dead":true,"death":1.0,"landing":0.0,"clock":.3,"death_clock":2.0});canvas.position=Vector2(180,220);root.add_child(canvas)
	for _i: int in 3:await process_frame
	print("CACHE_FIRST ",JSON.stringify({"calls":rig.get("calls"),"draws":canvas.get("draws"),"cached":rig.get("_rest_cached"),"viewport":[root.size.x,root.size.y]}))
	rig.set("calls",0)
	var pose: Dictionary=canvas.get("pose");pose.death_clock=4.0;canvas.queue_redraw()
	for _i: int in 3:await process_frame
	print("CACHE_SECOND ",JSON.stringify({"calls":rig.get("calls"),"draws":canvas.get("draws"),"cached":rig.get("_rest_cached")}))
	canvas.set("rig",null);canvas.free();rig=null
	for _i: int in 2:await process_frame
	quit()
