from pathlib import Path
import json,subprocess,time
R=Path('/workspace/gunman-rush');O=R/'build/main-closeout'
def git(*args):return subprocess.check_output(['git',*args],cwd=R,text=True).strip()
main=git('rev-parse','origin/main');head=git('rev-parse','HEAD');assert main==head
candidate='2c31c00e01731860dba698e64ed2c299e5f08b25';assert git('rev-parse',main+'^{tree}')==git('rev-parse',candidate+'^{tree}')
rows=[]
for ref in git('for-each-ref','--format=%(refname:short)','refs/remotes/origin').splitlines():
 if ref=='origin' or ref.startswith(('origin/playtest/','origin/deploy/')):continue
 tip=git('rev-parse',ref);r=subprocess.run(['git','merge-base','--is-ancestor',tip,main],cwd=R);rows.append({'ref':ref,'tip':tip,'in_main':r.returncode==0});assert r.returncode==0,ref
for ref in git('for-each-ref','--format=%(refname:short)','refs/heads').splitlines():assert subprocess.run(['git','merge-base','--is-ancestor',ref,main],cwd=R).returncode==0,ref
receipt={'task_id':'MAIN-CLOSEOUT-20261022','exit_code':0,'source_commit':main,'scope':'Actual remote main contains all source tips and local development tips; entire tree equals reviewed candidate; deployment-only refs excluded','verified_at':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'main_before':'7be8c340372d1e20db6685cbd6a559191821eb0e','main_merge':main,'candidate':candidate,'main_tree':git('rev-parse',main+'^{tree}'),'candidate_tree':git('rev-parse',candidate+'^{tree}'),'refs':rows,'source_refs_including_main':len(rows),'source_refs_missing':[],'command':'python3 /tmp/verify-gunman-main-closeout.py','environment':'Linux Git ordinary merge; exact origin/main fetched after GitHub PR102 merge; no engine or runtime mutation'}
(O/'main-verification.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:v for k,v in receipt.items() if k!='refs'}))
