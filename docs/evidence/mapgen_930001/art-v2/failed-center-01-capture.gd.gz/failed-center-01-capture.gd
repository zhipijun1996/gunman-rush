extends "res://tests/mapgen_delivery_tests.gd"
var media := "res://build/mapgen_930001/art-v2-final-media/"
var ledger: Array[Dictionary] = []
func _run() -> void:
 root.size = Vector2i(1280,720)
 world = FIXED_SCENE.instantiate()
 root.add_child(world)
 for n: int in 120:
  await _frames(1)
  if world.loaded: break
 player = world.player
 motor = world.motor
 await _frames(30)
 await _capture("spawn")
 await _frames(75)
 var latch: ShotLatch = _instance("M01").cells.latches[0]
 _shoot_at(_instance("M01").to_global(latch.bell_position))
 await _frames(45)
 player.router.set_move_axis(1.0)
 await _frames(65)
 player.router.set_move_axis(0.0)
 await _frames(20)
 await _capture("start-bell-open")
 ledger.append({"chapter":"spawn","fixture":false,"bell_open":latch.is_open,"hp":player.actor_resources.health.current,"position":str(motor.global_position)})
 # Explicit inspection fixture; the original player/actors/health stay live.
 _fixture_place(_instance("M06").to_global(Vector2(240,206)))
 world._camera.offset = Vector2(160,80)
 await _frames(5)
 await _capture("M06-sentry-diver")
 await _frames(80)
 var sentry: EnemyActor
 for actor: EnemyActor in _instance("M06").cells.enemies:
  if actor.definition.stable_id == &"plains_sentry": sentry = actor
 for hit: int in 5:
  _shoot_at(sentry.motor.global_position)
  await _frames(10)
  if hit == 0: await _capture("M06-sentry-hit")
  await _frames(40)
 await _capture("M06-sentry-after")
 ledger.append({"chapter":"M06","fixture_position":[240,206],"species":"plains_sentry","health":sentry.health.current,"renderer":sentry.motor.get_node("Presentation").get_script().resource_path})
 _fixture_place(_instance("M28").to_global(Vector2(220,238)))
 world._camera.offset = Vector2(36,0)
 await _frames(3)
 await _capture("M28-charger")
 await _frames(60)
 var charger: EnemyActor = _instance("M28").cells.enemies[0]
 for hit: int in 5:
  _shoot_at(charger.motor.global_position)
  await _frames(45)
 await _capture("M28-charger-after")
 ledger.append({"chapter":"M28","fixture_position":[220,238],"species":"plains_charger","health":charger.health.current,"renderer":charger.motor.get_node("Presentation").get_script().resource_path})
 _fixture_place(_instance("M29").to_global(Vector2(208,45.75)))
 world._camera.offset = Vector2(0,72)
 await _frames(8)
 await _capture("M29-closed")
 await _frames(45)
 _native_key(KEY_W,true); _native_key(KEY_W,false)
 await _process_frames(8)
 var consumer: Node = _instance("M29").original_region_chests
 await _capture("M29-native-choice")
 var click := Vector2.ZERO
 if consumer.app.reward_modal.opened:
  for card: ItemCard in consumer.app.reward_modal._options.get_children():
   if card.item is ResourceRewardChoice and card.item.resource_kind == "coin":
    var buttons := card.find_children("*","Button",true,false)
    if not buttons.is_empty(): click = (buttons[0] as Button).get_global_rect().get_center()
 if click != Vector2.ZERO:
  _native_mouse(true,click); await _process_frames(2)
  _native_mouse(false,click); await _process_frames(6)
 await _frames(45)
 await _capture("M29-open")
 var chest: Sprite2D = world.plains_presentation.get_node("NativeChest_M29_0")
 ledger.append({"chapter":"M29","fixture_position":[208,45.75],"actual_W":true,"mouse_click":str(click),"modal_open":consumer.app.reward_modal.opened,"claimed":consumer.stage.chests[0].claimed,"actual_open_pose":chest.get_meta("underworld_chest_open"),"coins":world.wallet.balance,"choice_api_called":false})
 var file := FileAccess.open(media+"capture.json",FileAccess.WRITE)
 file.store_string(JSON.stringify({"seed":930001,"viewport":[1280,720],"chapters":ledger,"whole_map_continuous_traversal":"NOT_RUN"},"  ")); file.close()
 await TEARDOWN.drain_world(world)
 world.queue_free(); await process_frame; await process_frame; quit()
func _shoot_at(point: Vector2) -> void:
 var direction := (point-motor.global_position).normalized()
 var visual := motor.get_node("CourierVisual") as CourierVisual
 for iteration: int in 8: direction = (point-visual.muzzle_position(direction)).normalized()
 player.router.request_action(&"shoot_release",direction)
func _capture(label: String) -> void:
 await RenderingServer.frame_post_draw
 root.get_texture().get_image().save_png(media+label+".png")
 print("MAPGEN ART FRAME ",JSON.stringify({"label":label,"frame":Engine.get_process_frames(),"player":str(motor.global_position),"hp":player.actor_resources.health.current}))
