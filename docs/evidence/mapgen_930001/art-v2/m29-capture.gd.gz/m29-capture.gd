extends "res://tests/mapgen_delivery_tests.gd"
func _run() -> void:
 root.size = Vector2i(1280,720)
 world = FIXED_SCENE.instantiate(); root.add_child(world)
 for n: int in 120:
  await _frames(1)
  if world.loaded: break
 player=world.player; motor=world.motor
 _fixture_place(_instance("M29").to_global(Vector2(208,45.75)))
 world._camera.offset = Vector2(0,72)
 await _frames(1)
 await _capture("closed")
 var standing := motor.is_on_floor()
 _native_key(KEY_W,true); _native_key(KEY_W,false)
 await _process_frames(8)
 var consumer: Node = _instance("M29").original_region_chests
 var opened: bool = consumer.app.reward_modal.opened
 await _capture("menu")
 var click := Vector2.ZERO
 if opened:
  for card: ItemCard in consumer.app.reward_modal._options.get_children():
   if card.item is ResourceRewardChoice and card.item.resource_kind=="coin":
    var buttons := card.find_children("*","Button",true,false)
    if not buttons.is_empty():click = (buttons[0] as Button).get_global_rect().get_center()
 if click != Vector2.ZERO:
  _native_mouse(true,click); await _process_frames(2)
  _native_mouse(false,click); await _process_frames(8)
 await _frames(3)
 await _capture("open")
 var sprite: Sprite2D = world.plains_presentation.get_node("NativeChest_M29_0")
 var receipt := {"fixture_position":[208,45.75],"natural_arrival":false,"grounded_before_W":standing,"actual_W":true,"modal_opened":opened,"actual_mouse_click":str(click),"choice_api_called":false,"claimed":consumer.stage.chests[0].claimed,"coins":world.wallet.balance,"actual_open_pose":sprite.get_meta("underworld_chest_open"),"modal_closed":not consumer.app.reward_modal.opened}
 print("MAPGEN M29 GUI ",JSON.stringify(receipt))
 var f := FileAccess.open("res://build/mapgen_930001/art-v2/M29-gui.json",FileAccess.WRITE);f.store_string(JSON.stringify(receipt,"  "));f.close()
 paused = false
 await TEARDOWN.drain_world(world);world.queue_free();await process_frame;await process_frame;quit()
func _capture(label: String) -> void:
 await RenderingServer.frame_post_draw
 root.get_texture().get_image().save_png("res://build/mapgen_930001/art-v2/M29-"+label+".png")
