extends "res://tests/mapgen_delivery_tests.gd"
func _run() -> void:
 world=FIXED_SCENE.instantiate();root.add_child(world)
 for n: int in 120:
  await _frames(1)
  if world.loaded:break
 player=world.player;motor=world.motor
 var result: Array[Dictionary] = []
 var instance := _instance("M29")
 for point: Vector2 in [Vector2(208,45.9),Vector2(270,45.9)]:
  var q:=PhysicsShapeQueryParameters2D.new();q.shape=motor.get_node("CollisionShape2D").shape;q.transform=Transform2D(0,instance.to_global(point));q.collision_mask=motor.collision_mask;q.exclude=[motor.get_rid()];q.margin=0
  var hits:=motor.get_world_2d().direct_space_state.intersect_shape(q)
  var names: Array[String] = []
  for hit: Dictionary in hits:names.append(str(hit.collider.get_path()))
  result.append({"local_body_center":str(point),"native_overlap_colliders":names})
 _fixture_place(instance.to_global(Vector2(270,20)))
 await _frames(30)
 result.append({"fixture_start":[270,20],"local_final":str(instance.to_local(motor.global_position)),"grounded":motor.is_on_floor(),"claim_radius":80,"distance_to_native_chest":motor.global_position.distance_to(instance.to_global(Vector2(208,46))),"natural_route":false})
 print("MAPGEN M29 LANDING ",JSON.stringify(result))
 var f:=FileAccess.open("res://build/mapgen_930001/art-v2/M29-landing.json",FileAccess.WRITE);f.store_string(JSON.stringify(result,"  "));f.close()
 await TEARDOWN.drain_world(world);world.queue_free();await process_frame;await process_frame;quit()
