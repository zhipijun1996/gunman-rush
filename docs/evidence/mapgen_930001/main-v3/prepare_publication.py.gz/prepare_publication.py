#!/usr/bin/env python3
"""Prepare a verified full-game Pages bundle; never push or deploy anything."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import html
import json
from pathlib import Path
import re
import shlex
import shutil
import subprocess
import sys
import urllib.request

REPO = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO / "tools"))
from cloud_delivery import validate_bundle  # noqa: E402
from style_exploration_delivery import reconstruct_pack  # noqa: E402

SOURCE_REPOSITORY = "zhipijun1996/gunman-rush"
OLD_PREPARED_COMMIT = "153e8a3105fbc1fd42b89d52a4b42d934098ee06"
OLD_PATHS = ("audio-before", "perf-04", "perf-actions")
CURRENT_SITE = "https://zhipijun1996.github.io/gunman-rush/"
MAP_SCENE = "res://scenes/mapgen/seed_930001.tscn"
SITE_LIMIT = 900 * 1024 * 1024
PAGES_ONE_GB = 1_000_000_000


def digest(path: Path) -> str:
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def write_json(path: Path, value: dict) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def bytes_in(folder: Path) -> int:
    return sum(path.stat().st_size for path in folder.rglob("*") if path.is_file())


def archived_metadata(name: str) -> tuple[bytes, dict, str]:
    url = (
        "https://raw.githubusercontent.com/" + SOURCE_REPOSITORY + "/"
        + OLD_PREPARED_COMMIT + "/" + name + "/build-info.json"
    )
    request = urllib.request.Request(url, headers={"User-Agent": "gunman-rush-mapgen-publication"})
    with urllib.request.urlopen(request, timeout=30) as response:
        payload = response.read(1_048_577)
    if len(payload) > 1_048_576:
        raise ValueError("Historical build metadata unexpectedly exceeds 1 MiB: " + name)
    data = json.loads(payload)
    if (
        not re.fullmatch(r"[0-9a-f]{40}", str(data.get("source_commit", "")))
        or not re.fullmatch(r"[0-9a-f]{12}", str(data.get("build_id", "")))
        or data.get("pack") != "index." + str(data["build_id"]) + ".pck"
        or not isinstance(data.get("pack_bytes"), int)
        or data["pack_bytes"] <= 0
    ):
        raise ValueError("Invalid historical build identity at immutable commit: " + name)
    return payload, data, url


def archive_page(name: str, data: dict) -> str:
    source_tree = (
        "https://github.com/" + SOURCE_REPOSITORY + "/tree/"
        + OLD_PREPARED_COMMIT + "/" + name
    )
    return """<!doctype html>
<html lang="zh-CN"><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>旧诊断版本已归档 · NAME</title>
<style>body{background:#132126;color:#eee6ce;font:18px/1.8 system-ui;max-width:760px;margin:7vh auto;padding:24px}a{color:#b9e3d0}code{overflow-wrap:anywhere}</style>
<h1>旧诊断版本已归档</h1>
<p><code>NAME</code> 是此前的诊断版本。此路径现在提供归档告示，不再加载旧游戏包。</p>
<p>原版本与内容寻址分块仍保留在确切的不可变 Git 提交中；这不表示旧版本已经重新验证，也不将当前首页冒充为旧版。</p>
<p>原游戏源码：<code>SOURCE</code><br>原构建：<code>BUILD</code></p>
<p><a href="TREE">查看原始归档文件与分块</a> · <a href="archived-build-info.json">查看原始构建元数据</a></p>
<p><a href="HOME">进入当前主游戏试玩首页</a></p>
<p>独立开发预览站中的已有预览与媒体保持原样。</p>
</html>
""".replace("NAME", html.escape(name)).replace("SOURCE", html.escape(data["source_commit"])).replace("BUILD", html.escape(data["build_id"])).replace("TREE", html.escape(source_tree, quote=True)).replace("HOME", CURRENT_SITE)


def instructions(output: Path, info: dict, pack: dict, source_ref: str) -> str:
    prepared_branch = "deploy/mapgen930001-" + info["source_commit"][:12]
    quoted_output = shlex.quote(str(output))
    quoted_branch = shlex.quote(prepared_branch)
    quoted_ref = shlex.quote(source_ref)
    return f"""# 固定地图主游戏试玩发布准备

状态：仅准备，未推送、未 dispatch、未上线。此目录是完整主游戏的新 Pages 根；独立 gunman-rush-previews 仓库完全未动。
三个旧主站诊断路径 audio-before、perf-04、perf-actions 将明确显示归档告示；原元数据位于各自 archived-build-info.json，原包与分块仍在不可变提交 {OLD_PREPARED_COMMIT}。
没有在这些归档路径放置 build-info.json，现有 prepared workflow 因而不会重建旧 PCK。

游戏源码：{info['source_commit']}
构建：{info['build_id']}
完整 PCK：{pack['pack']} / {pack['pack_bytes']} bytes / SHA-256 {pack['pack_sha256']}
完整原导出 report、worker、引擎与许可证保持字节一致；仅运输目录不含 raw PCK，部署时由原内容寻址 chunks 重建。
本准备器验证原 export 报告、精确 HEAD、地图场景在 PCK 中、复制字节和完整 PCK SHA；这些检查不替代实际菜单/玩法/Web GUI、设备或完整 CI 验证。

## root 后续步骤（尚未执行）

先确认 publication-receipt.json 的 prepared_only 状态及展开后容量；不要把 queued workflow 当发布成功。
以下在新独立 Git 目录创建无父提交的 prepared 支线；它不合入主游戏 main。

```sh
git -C {quoted_output} init --initial-branch {quoted_branch}
git -C {quoted_output} add .
git -C {quoted_output} commit -m 'Prepare integrated fixed-map 930001 playtest'
git -C {quoted_output} remote add origin https://github.com/{SOURCE_REPOSITORY}.git
git -C {quoted_output} push --set-upstream origin HEAD:refs/heads/{prepared_branch}
MAPGEN_PREPARED_COMMIT=$(git -C {quoted_output} rev-parse HEAD)
gh workflow run deploy-prepared-playtest.yml --repo {SOURCE_REPOSITORY} --ref {quoted_ref} -f prepared_ref="$MAPGEN_PREPARED_COMMIT"
```

dispatch 的 source ref 必须已推送并仍包含本次精确源码及现有 deployment helper；发布前再次核对，不合 main、不 force push。
等待实际 workflow 成功后检查公开 {CURRENT_SITE}build-info.json 的 source_commit/build_id；下载完整 {CURRENT_SITE}{pack['pack']}，逐字节核对上面的长度与 SHA-256。
随后用实际浏览器从标题进入 Home，点击普通出发，确认地图930001、唯一玩家、奖励/暂停/回家。原生、浏览器、人工设备与完整连续通关结果分别记录。
再访问三个归档路径，确认明确归档文字、元数据与不可变 Git 链接；检查隔离预览站已有入口仍可访问。
"""


def prepare(bundle: Path, output: Path) -> dict:
    bundle, output = bundle.resolve(), output.resolve()
    if output.exists():
        raise ValueError("Output already exists; preserve prior prepared attempts: " + str(output))
    if output == bundle or output.is_relative_to(bundle) or bundle.is_relative_to(output):
        raise ValueError("Output and original bundle must be separate trees")
    # Includes exact committed source identity, unchanged export artifact hashes,
    # successful original export report and actual PCK scene presence.
    info, source_pack = validate_bundle(bundle, REPO, MAP_SCENE)
    originals = {
        path.relative_to(bundle).as_posix(): digest(path)
        for path in bundle.rglob("*") if path.is_file() and path.suffix != ".pck"
    }
    for name in OLD_PATHS:
        if (bundle / name).exists():
            raise ValueError("Original bundle already contains an archive path; refusing overwrite: " + name)
    historical = {name: archived_metadata(name) for name in OLD_PATHS}
    source_ref = subprocess.check_output(
        ["git", "-C", str(REPO), "branch", "--show-current"], text=True
    ).strip() or info["source_commit"]
    output.parent.mkdir(parents=True, exist_ok=True)
    shutil.copytree(bundle, output, ignore=shutil.ignore_patterns("*.pck", ".git"))
    try:
        archives = []
        for name, (payload, old_info, url) in historical.items():
            folder = output / name
            folder.mkdir()
            (folder / "archived-build-info.json").write_bytes(payload)
            (folder / "index.html").write_text(archive_page(name, old_info), encoding="utf-8")
            archives.append({
                "path": name, "status": "explicit_archive_notice",
                "old_prepared_commit": OLD_PREPARED_COMMIT, "original_metadata_url": url,
                "metadata_sha256": hashlib.sha256(payload).hexdigest(),
                "source_commit": old_info["source_commit"], "build_id": old_info["build_id"],
                "old_pack_reconstructed": False,
            })
        for name, expected in originals.items():
            if digest(output / name) != expected:
                raise ValueError("Original export bytes changed during copy: " + name)
        rebuilt = reconstruct_pack(output)
        identity_fields = ("source_commit", "build_id", "pack", "pack_bytes", "pack_sha256", "failed")
        if any(rebuilt[key] != source_pack[key] for key in identity_fields):
            raise ValueError("Transport reconstruction differs from original verified PCK receipt")
        for name in OLD_PATHS:
            if (output / name / "build-info.json").exists():
                raise ValueError("Historical build-info.json would trigger old workflow reconstruction: " + name)
        (output / "PUBLICATION-STEPS.md").write_text(
            instructions(output, info, rebuilt, source_ref), encoding="utf-8"
        )
        receipt = {
            "schema": "gunman-rush/mapgen-main-publication-preparation/v1",
            "status": "prepared_only", "published": False,
            "prepared_utc": datetime.now(timezone.utc).isoformat(),
            "source_commit": info["source_commit"], "source_ref": source_ref,
            "build_id": info["build_id"], "original_bundle": str(bundle),
            "copied_export_files": originals, "pack_verification": rebuilt,
            "archive_notices": archives,
            "isolated_preview_repository_modified": False,
            "limits": {"900_mib": SITE_LIMIT, "one_decimal_gb": PAGES_ONE_GB},
            "scope": "Original export/copy/PCK bytes verified; browser/menu/runtime/CI/device acceptance require separate evidence.",
        }
        # Include this receipt and instructions in the capacity calculation.
        # Stabilize the digit lengths before committing the final measured size.
        report_path = output / "publication-receipt.json"
        for _ in range(10):
            write_json(report_path, receipt)
            expanded = bytes_in(output)
            transport = expanded - rebuilt["pack_bytes"]
            if receipt.get("expanded_site_bytes") == expanded and receipt.get("git_transport_bytes") == transport:
                break
            receipt.update(expanded_site_bytes=expanded, git_transport_bytes=transport)
        else:
            raise ValueError("Capacity receipt did not stabilize")
        if expanded >= SITE_LIMIT or expanded >= PAGES_ONE_GB:
            raise ValueError("Prepared site exceeds unchanged site budget after complete PCK reconstruction: " + str(expanded))
        # Revalidate exact original source after all copying/network work.
        final_info, final_pack = validate_bundle(bundle, REPO, MAP_SCENE)
        if final_info != info or final_pack != source_pack:
            raise ValueError("Original source/bundle changed while preparing publication")
        (output / rebuilt["pack"]).unlink()
        too_large = [str(path.relative_to(output)) for path in output.rglob("*") if path.is_file() and path.stat().st_size >= 100 * 1024 * 1024]
        if too_large:
            raise ValueError("Git transport files exceed 100 MiB: " + ", ".join(too_large))
        if bytes_in(output) != receipt["git_transport_bytes"]:
            raise ValueError("Final transport size differs from capacity receipt")
        return receipt
    except BaseException as error:
        # Preserve failed attempts and their exact bytes for diagnosis.
        (output / "PREPARATION_FAILED.txt").write_text(str(error) + "\nNot published. Do not dispatch this directory.\n", encoding="utf-8")
        raise


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bundle", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    receipt = prepare(args.bundle, args.output)
    print(json.dumps({
        key: receipt[key] for key in ("status", "published", "source_commit", "build_id", "expanded_site_bytes", "git_transport_bytes", "limits")
    }, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, ValueError, KeyError, subprocess.SubprocessError) as error:
        raise SystemExit("Publication preparation failed: " + str(error)) from error
