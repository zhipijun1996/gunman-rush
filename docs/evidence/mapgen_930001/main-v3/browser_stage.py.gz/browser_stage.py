import asyncio,json,sys,time
from pathlib import Path
from playwright.async_api import async_playwright
async def main():
 url=sys.argv[1];out=Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=False)
 async with async_playwright() as p:
  b=await p.chromium.launch(headless=True,args=['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'])
  c=await b.new_context(viewport={'width':1280,'height':720},device_scale_factor=1)
  page=await c.new_page();logs=[];errors=[]
  page.on('console',lambda m:logs.append({'type':m.type,'text':m.text}))
  page.on('pageerror',lambda e:errors.append(str(e)))
  await page.goto(url,wait_until='domcontentloaded',timeout=60000)
  await page.wait_for_function('window.PLAYTEST_LOADING_DONE===true',timeout=150000)
  await page.wait_for_timeout(1200)
  await page.screenshot(path=str(out/'01-title.png'))
  await page.mouse.click(226,188);await page.wait_for_timeout(1500)
  await page.screenshot(path=str(out/'02-home.png'))
  await page.keyboard.down('KeyD');await page.wait_for_timeout(11200);await page.keyboard.up('KeyD');await page.wait_for_timeout(300)
  await page.screenshot(path=str(out/'03-home-gate.png'))
  await page.keyboard.press('KeyW');await page.wait_for_timeout(500)
  await page.screenshot(path=str(out/'04-departure.png'))
  (out/'console.json').write_text(json.dumps({'url':url,'logs':logs,'page_errors':errors,'build':await page.locator('#playtest-version').get_attribute('data-build-id')},indent=2))
  await b.close()
asyncio.run(main())
