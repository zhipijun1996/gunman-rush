import json,hashlib,time,urllib.request,sys
from pathlib import Path
root='https://zhipijun1996.github.io/gunman-rush/';out=Path('build/mapgen_main/public-byte-verification.json');expected=json.loads(Path('build/web/build-info.json').read_text());expected_pack=json.loads(Path('build/mapgen_main/packed-delivery-final.json').read_text());report={'status':'running','source_commit':expected['source_commit'],'build_id':expected['build_id'],'url':root,'scope':'Public metadata and complete raw PCK bytes; browser and physical-device results separate'}
def get(url):return urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'gunman-mapgen-verification'}),timeout=60)
def save():out.write_text(json.dumps(report,indent=2)+'\n')
try:
 with get(root+'build-info.json?verify='+expected['build_id']) as response:
  actual=json.load(response);assert response.status==200
 assert actual==expected,(actual,expected)
 report['metadata']=actual;save()
 with get(root+'index.html?verify='+expected['build_id']) as response:
  page=response.read().decode();assert expected['pack'] in page;assert 'cloud-preview-entry' not in page
 report['ordinary_main_html']=True;save()
 total=0;digest=hashlib.sha256();started=time.monotonic()
 with get(root+expected['pack']) as response:
  assert response.status==200
  report['pack_response_headers']=dict(response.headers)
  while True:
   block=response.read(1024*1024)
   if not block:break
   total+=len(block);digest.update(block)
 assert total==expected['pack_bytes'] and digest.hexdigest()==expected_pack['pack_sha256'],(total,digest.hexdigest())
 report['pack']={'http_status':200,'bytes':total,'sha256':digest.hexdigest(),'seconds':time.monotonic()-started};save()
 archives=[]
 for name in ['audio-before','perf-04','perf-actions']:
  with get(root+name+'/') as response:
   text=response.read().decode();assert '旧诊断版本已归档' in text and '153e8a3105fbc1fd42b89d52a4b42d934098ee06' in text
  with get(root+name+'/archived-build-info.json') as response:metadata=response.read()
  local=Path('build/mapgen_main/prepared-final')/name/'archived-build-info.json';assert metadata==local.read_bytes()
  archives.append({'path':name,'archive_notice':True,'original_metadata_sha256':hashlib.sha256(metadata).hexdigest()})
 report['archive_paths']=archives
 with get('https://zhipijun1996.github.io/gunman-rush-previews/') as response:report['isolated_preview_index_http_status']=response.status
 report['status']='passed';save();print(json.dumps(report))
except Exception as e:
 report.update(status='failed',error=repr(e));save();raise
