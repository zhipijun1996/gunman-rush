import asyncio,json,sys,time
from pathlib import Path
from playwright.async_api import async_playwright
async def main():
 url=sys.argv[1];out=Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=False);logs=[];errors=[];actions=[]
 def save(): (out/'console.json').write_text(json.dumps({'url':url,'logs':logs,'page_errors':errors,'actions':actions},indent=2))
 async with async_playwright() as p:
  b=await p.chromium.launch(headless=True,args=['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'])
  c=await b.new_context(viewport={'width':1280,'height':720},device_scale_factor=1)
  page=await c.new_page()
  def log(m):logs.append({'type':m.type,'text':m.text});save()
  def error(e):errors.append(str(e));save()
  page.on('console',log);page.on('pageerror',error)
  await page.goto(url,wait_until='domcontentloaded',timeout=60000)
  await page.wait_for_function('window.PLAYTEST_LOADING_DONE===true',timeout=150000)
  await page.wait_for_timeout(1200)
  await page.screenshot(path=str(out/'01-title.png'))
  await page.mouse.click(226,188);await page.wait_for_timeout(1500)
  await page.screenshot(path=str(out/'02-home.png'))
  await page.keyboard.down('KeyD');await page.wait_for_timeout(11700);await page.keyboard.up('KeyD');await page.wait_for_timeout(350)
  await page.screenshot(path=str(out/'03-home-gate.png'))
  await page.keyboard.press('KeyW');await page.wait_for_timeout(700)
  await page.screenshot(path=str(out/'04-departure.png'))
  (out/'ready.json').write_text(json.dumps({'build':await page.locator('#playtest-version').get_attribute('data-build-id'),'ordinary_home_walk':True,'script_fixture':False}))
  save();counter=1
  while counter<50:
   cmd=out/('cmd-%02d.json'%counter)
   if not cmd.exists():await asyncio.sleep(.2);continue
   steps=json.loads(cmd.read_text());close=False
   for step in steps:
    if 'click' in step:await page.mouse.click(*step['click'])
    if 'move' in step:await page.mouse.move(*step['move'])
    if 'mouse' in step:
     if step['mouse']=='down':await page.mouse.down()
     else:await page.mouse.up()
    if 'key' in step:await page.keyboard.press(step['key'])
    if 'down' in step:await page.keyboard.down(step['down'])
    if 'up' in step:await page.keyboard.up(step['up'])
    if 'wait' in step:await page.wait_for_timeout(step['wait'])
    if 'size' in step:await page.set_viewport_size({'width':step['size'][0],'height':step['size'][1]})
    if 'screenshot' in step:await page.screenshot(path=str(out/(step['screenshot']+'.png')))
    if 'reload' in step:
     await page.reload(wait_until='domcontentloaded');await page.wait_for_function('window.PLAYTEST_LOADING_DONE===true',timeout=150000)
    if 'close' in step:close=True
   actions.append({'command':counter,'steps':steps});save()
   (out/('done-%02d.json'%counter)).write_text(json.dumps({'build':await page.locator('#playtest-version').get_attribute('data-build-id'),'page_errors':errors,'ready_markers':[x['text'] for x in logs if 'MAPGEN_MAIN_READY' in x['text']],'size':await page.evaluate('({width:innerWidth,height:innerHeight,dpr:devicePixelRatio,canvasWidth:document.querySelector("canvas").width,canvasHeight:document.querySelector("canvas").height})')}))
   counter+=1
   if close:break
  await b.close()
asyncio.run(main())
