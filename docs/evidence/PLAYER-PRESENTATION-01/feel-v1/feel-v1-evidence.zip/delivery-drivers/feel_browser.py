import asyncio,hashlib,json,sys,time,threading
from pathlib import Path
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from functools import partial
from playwright.async_api import async_playwright
root=Path('/workspace/player-presentation')
folder=Path(sys.argv[1]);out=Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=False)
class Quiet(SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(folder)))
threading.Thread(target=server.serve_forever,daemon=True).start()
log=[];errors=[]
async def run():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage','--use-angle=swiftshader','--enable-unsafe-swiftshader'])
  page=await browser.new_page(viewport={'width':1280,'height':720})
  page.on('console',lambda m:log.append({'type':m.type,'text':m.text}))
  page.on('pageerror',lambda e:errors.append(str(e)))
  await page.goto('http://127.0.0.1:'+str(server.server_port)+'/',wait_until='domcontentloaded',timeout=60000)
  for _ in range(480):
   if any('MOTION FEEL: actual Home player ready' in m['text'] for m in log):break
   await asyncio.sleep(.25)
  else:raise RuntimeError('Actual formal candidate browser readiness timeout')
  await asyncio.sleep(1)
  await page.screenshot(path=str(out/'01-idle-on.png'))
  await page.locator('canvas').focus()
  await page.keyboard.down('Space');await asyncio.sleep(.22)
  await page.screenshot(path=str(out/'02-jump-on.png'))
  await page.keyboard.up('Space');await asyncio.sleep(.3)
  await page.screenshot(path=str(out/'03-land-on.png'))
  await page.keyboard.down('d');await asyncio.sleep(.2);await page.keyboard.up('d');await asyncio.sleep(.1)
  await page.screenshot(path=str(out/'04-move-on.png'))
  await page.mouse.click(395,50);await asyncio.sleep(.2)
  await page.screenshot(path=str(out/'05-original-off.png'))
  count=sum('MOTION CANDIDATE: actual formal player ready' in m['text'] for m in log)
  await page.mouse.dblclick(505,50,delay=10)
  for _ in range(160):
   if sum('MOTION CANDIDATE: actual formal player ready' in m['text'] for m in log)>count:break
   await asyncio.sleep(.1)
  else:raise RuntimeError('Actual pointer restart did not create candidate')
  await asyncio.sleep(.4)
  await page.screenshot(path=str(out/'06-pointer-restart.png'))
  await page.mouse.click(675,50);await asyncio.sleep(.5)
  await page.screenshot(path=str(out/'07-home-full-game.png'))
  await page.mouse.click(820,50);await asyncio.sleep(.6)
  if sum('MOTION FEEL: actual Home player ready' in m['text'] for m in log)<2:raise RuntimeError('HOME DROP did not reopen actual Home candidate')
  await page.screenshot(path=str(out/'08-home-drop-reentry.png'))
  await browser.close()
try:
 asyncio.run(run())
 status='passed' if not errors and not any('SCRIPT ERROR:' in m['text'] or 'ERROR: Failed' in m['text'] for m in log) else 'failed'
except Exception as e:
 errors.append(type(e).__name__+':'+str(e));status='failed'
finally:
 server.shutdown();server.server_close()
 report={'status':status,'source_build_info':json.loads((folder/'build-info.json').read_text()),'driver_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'scope':'Actual local exported Web canvas; DOM keyboard and real pointer candidate toggle/restart/Home; screenshots require pixel review. Not public deploy, DOM touch, physical device, or user acceptance.','errors':errors,'console':log,'screenshots':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.glob('*.png')}}
 (out/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({'status':status,'errors':errors,'folder':str(out)}))
 sys.exit(0 if status=='passed' else 1)
