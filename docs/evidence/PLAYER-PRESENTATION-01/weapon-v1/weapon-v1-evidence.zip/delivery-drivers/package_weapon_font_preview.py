import sys,json,hashlib,shutil,zipfile
from pathlib import Path
root=Path('/workspace/player-presentation');sys.path.insert(0,str(root/'tools'))
import cloud_delivery
source=root/'build/web';base=root/'build/player_presentation_01/weapon-v1'
info,receipt=cloud_delivery.validate_bundle(source,root,'res://scenes/dev/player_presentation_01/weapon_feel.tscn')
target=base/'preview-weapon-v2';shutil.copytree(source,target)
original=hashlib.sha256((target/'index.html').read_bytes()).hexdigest()
(target/'index.html').write_text(cloud_delivery.inject_entry((target/'index.html').read_text(),'PLAYER-PRESENTATION-01','player-presentation-01/motion-01','scene','res://scenes/dev/player_presentation_01/weapon_feel.tscn'))
(target/'_tools').mkdir();shutil.copyfile(root/'tools/style_exploration_delivery.py',target/'_tools/style_exploration_delivery.py')
(target/'start_preview.py').write_text('''from pathlib import Path
import sys,webbrowser
from functools import partial
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
base=Path(__file__).resolve().parent
sys.path.insert(0,str(base/"_tools"))
from style_exploration_delivery import reconstruct_pack
print(reconstruct_pack(base))
server=ThreadingHTTPServer(("127.0.0.1",0),partial(SimpleHTTPRequestHandler,directory=str(base)))
url="http://127.0.0.1:"+str(server.server_port)+"/"
print("Open "+url+" ; Ctrl+C stops this local preview",flush=True)
webbrowser.open(url)
try: server.serve_forever()
except KeyboardInterrupt: server.server_close()
''')
(target/'README-PLAY.txt').write_text('PLAYER-PRESENTATION-01 多武器独立样板\n解压后运行 python3 start_preview.py，逐块核完整PCK后开本地浏览器，无需Godot。\n底部下拉选择15装备；鼠标按住瞄准/松开开火，激光按住；F召回/遥爆，Q三级技能（共鸣靠实际命中训练靶积累）。Space跳，A/D走。两枚靶为明确静止训练fixture，不代表正式敌人或武器成长授予。\n顶部WEAPON FX ON/ORIGINAL WEAPON FX仅对比武器反馈；移动候选在两边保持相同。RESTART SAMPLE打开真实正式平原主角，HOME DROP回家园武器样板，HOME/FULL GAME恢复原Home并移除训练靶。\n新增18短音源，尾迹/接触/束端/附着微光与薄爆炸断环；未改变Motor/伤害/资源/Definition。旧Runtime phase等音效保留，来源路由待总控。\n用户听感/审美/真机和全正式集成未验；共享站900MiB容量未解决，没有新公网Web入口。\n')
meta={'task':'PLAYER-PRESENTATION-01','source_commit':info['source_commit'],'build_id':info['build_id'],'seed':'player-presentation-01/motion-01','entry':'scene','scene':'res://scenes/dev/player_presentation_01/weapon_feel.tscn','original_html_sha256':original,'pack_verification':receipt,'publication':'NOT DEPLOYED;shared Pages900MiB cap rejected;ephemeral tunnel API direct network refused','validation':'Complete original export/PCK validated;standard inject_entry applied;package transports checked chunks and canonical reconstruct_pack restores original PCK. Browser package verification pending.','delivery_extras':['start_preview.py','README-PLAY.txt','_tools/style_exploration_delivery.py'],'files':{p.relative_to(target).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in target.rglob('*') if p.is_file()}}
(target/'preview.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n')
archive=base/('player-weapon-preview-'+info['build_id']+'.zip')
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=3) as z:
 for p in sorted(target.rglob('*')):
  if p.is_file() and p.name != info['pack']: z.write(p,p.relative_to(target))
extracted=base/'package-weapon-v2-smoke';extracted.mkdir()
with zipfile.ZipFile(archive) as z:z.extractall(extracted)
from style_exploration_delivery import reconstruct_pack
reconstructed=reconstruct_pack(extracted)
assert reconstructed['pack_sha256']==receipt['pack_sha256']
for name,expected in meta['files'].items():assert hashlib.sha256((extracted/name).read_bytes()).hexdigest()==expected
(base/'package-weapon-v2-receipt.json').write_text(json.dumps({'status':'passed','scope':'Extracted actual ZIP, canonical complete PCK reconstruction/SHA and every delivered byte checked;GUI separate','archive':archive.name,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_bytes':archive.stat().st_size,'metadata':meta,'reconstructed':reconstructed},ensure_ascii=False,indent=2)+'\n')
print(info['build_id'],archive.stat().st_size,info['source_commit'],flush=True)
