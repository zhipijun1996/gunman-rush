from pathlib import Path
import hashlib,json,shutil,zipfile,subprocess
root=Path('/workspace/player-presentation');base=root/'build/player_presentation_01/weapon-v1';out=root/'docs/evidence/PLAYER-PRESENTATION-01/weapon-v1';out.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=subprocess.check_output(['git','rev-parse','3a83203'],cwd=root,text=True).strip();native=subprocess.check_output(['git','rev-parse','5a1c640'],cwd=root,text=True).strip()
browser=json.loads((base/'browser-layout/report.json').read_text());assert browser['status']=='passed' and not browser['errors']
receipt=json.loads((base/'package-weapon-v3-receipt.json').read_text());assert receipt['metadata']['source_commit']==source
shutil.copy2(base/'native-final/comparison.mp4',out/'weapon-comparison.mp4')
shutil.copy2(base/'public-movie-download.json',out/'public-movie-download.json')
from PIL import Image
def centroid(p):
 im=Image.open(p).convert('RGB');xs=[]
 for y in range(425,490):
  for x in range(450):
   r,g,b=im.getpixel((x,y))
   if r>65 and r>g*1.65 and r>b*1.8:xs.append(x)
 assert len(xs)>=20
 return {'pixels':len(xs),'mean_x':sum(xs)/len(xs)}
move={name:centroid(base/'browser-layout'/('touch-move-'+name+'.png')) for name in ['before','after']};assert move['after']['mean_x']<move['before']['mean_x']-6
package={'task':'PLAYER-PRESENTATION-01','source_commit':source,'content_version':'weapon-feel-v1','build_id':receipt['metadata']['build_id'],'status':'passed','scope':'Local delivered actual exported ZIP/PCK/Chromium keyboard/pointer/DOM touch only;not public deploy,hearing,physical device or user acceptance','archive':receipt['archive'],'archive_sha256':receipt['archive_sha256'],'archive_bytes':receipt['archive_bytes'],'canonical_pack_sha256':receipt['reconstructed']['pack_sha256'],'package_receipt_sha256':sha(base/'package-weapon-v3-receipt.json'),'browser_report_sha256':sha(base/'browser-layout/report.json'),'audio_context_states_after_real_space_key':browser['audio_context_states_after_real_space_key'],'pointer_ids':[m['text'] for m in browser['console'] if 'WEAPON SAMPLE: selected' in m['text']],'real_touch_movement_pixel_measurement':move,'browser_driver_sha256':sha(Path('/workspace/scratch/weapon_layout_browser.py')),'prior_failures_retained':['browser-first/report.json','browser-font/report.json'],'deployment':{'status':'blocked','reason':(base/'public-web-layout-stage.log').read_text().strip(),'log_sha256':sha(base/'public-web-layout-stage.log')},'native_source_commit':native,'native_not_relabelled':'Only six-line task-preview UI diff after frozen5a;audio/consumer/projectile/profile unchanged'}
(out/'package-final.json').write_text(json.dumps(package,ensure_ascii=False,indent=2)+'\n')
files={}
for p in base.iterdir():
 if p.is_file() and p.suffix in ['.json','.log']:files['runs/'+p.name]=p
for name in ['native-final','browser-first','browser-font','browser-layout']:
 for p in (base/name).rglob('*'):
  if not (p.is_file() and p.suffix in ['.json','.log','.png','.mp4','.txt'] and p.name!='comparison.mp4'):continue
  if name=='browser-first' and p.suffix=='.png' and p.name not in ['01-idle-on.png','popup-3.png']:continue
  if name=='browser-font' and p.suffix=='.png' and p.name not in ['popup-0.png','popup-14.png','all-loadouts-pointer.png']:continue
  if name=='browser-layout' and p.name.startswith('popup-') and p.name not in ['popup-3.png','popup-14.png']:continue
  files[name+'/'+p.relative_to(base/name).as_posix()]=p
for name in ['package_weapon_preview.py','package_weapon_font_preview.py','package_weapon_layout_preview.py','weapon_browser.py','weapon_font_browser.py','weapon_layout_browser.py','archive_weapon_evidence.py']:
 p=Path('/workspace/scratch')/name
 if p.exists():files['delivery-drivers/'+name]=p
for name in ['package-final.json','public-movie-download.json','consumer-inventory-weapon-v1.json','ui-only-diff.patch']:
 files['receipts/'+name]=out/name
for rname in ['20261022T181912.014118Z','20261022T183146.860385Z']:
 r=root/'build/verification/harness'/rname
 for p in r.rglob('*'):
  if p.is_file() and p.suffix in ['.json','.log','.txt']:files['harness/'+rname+'/'+p.relative_to(r).as_posix()]=p
index={'task':'PLAYER-PRESENTATION-01','native_source_commit':native,'web_source_commit':source,'content_version':'weapon-feel-v1','scope':'Selected actual logs,including failed attempts,native movies+traces+36 actual extracts and all3 local browser attempts;large playable ZIP excluded but full byte receipt retained','members':{n:{'sha256':sha(p),'bytes':p.stat().st_size} for n,p in sorted(files.items())},'excluded':'*.import,Godot raw AVI,large playable ZIP and engine/PCK copies excluded;repeated equivalent intermediate popup screenshots selected once at first/last;all original report screenshot hashes retained and all36 independently reviewed native frames kept;canonical pack/playable archive receipts retained','previous_failed_attempts':{'lifecycle-first.log':'test stale previously freed projectile reference;interrupted manually;no fabricated completed JSON','lifecycle-second.log':'test inferred Variant parse error;no completedJSON','lifecycle-third.json':'overstrict rejected-skill audio check rejected legitimate existing projectile contact;1error retained;fixed to allow genuinecontact only','browser-first/report.json':'initial source5a CJK tofu and popup marker failure','browser-font/report.json':'fontfix2fc all15 real mouse selections but bottompopup openingtouch auto-selectedlast;failed realDOMtouch','harness-docs.log':'missing historical sparse checkout links;not fixed by weakeningcheck'}}
archive=out/'weapon-v1-evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for n,p in sorted(files.items()):z.write(p,n)
 z.writestr('manifest.json',json.dumps(index,ensure_ascii=False,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for n,d in index['members'].items():assert hashlib.sha256(z.read(n)).hexdigest()==d['sha256']
index.update(archive_sha256=sha(archive),archive_bytes=archive.stat().st_size,verification='ZIP CRC plus every member SHA reread and matched;original failed attempts retained')
(out/'evidence-index.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'archive_bytes':archive.stat().st_size,'members':len(files),'touch':move,'browser_status':browser['status']}))
