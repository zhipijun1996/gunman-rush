import asyncio,hashlib,json,sys,time,threading
from pathlib import Path
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from functools import partial
from playwright.async_api import async_playwright
root=Path('/workspace/player-presentation')
folder=Path(sys.argv[1]);out=Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=False)
class Quiet(SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(folder)))
threading.Thread(target=server.serve_forever,daemon=True).start()
log=[];errors=[];audio_states=[]
async def run():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage','--use-angle=swiftshader','--enable-unsafe-swiftshader'])
  page=await browser.new_page(viewport={'width':1280,'height':720},has_touch=True)
  page.on('console',lambda m:log.append({'type':m.type,'text':m.text}))
  page.on('pageerror',lambda e:errors.append(str(e)))
  await page.add_init_script("window.__motion_audio_contexts=[];const OriginalAudioContext=window.AudioContext;window.AudioContext=class extends OriginalAudioContext{constructor(...args){super(...args);window.__motion_audio_contexts.push(this);}};")
  await page.goto('http://127.0.0.1:'+str(server.server_port)+'/',wait_until='domcontentloaded',timeout=60000)
  for _ in range(480):
   if any('WEAPON SAMPLE: actual player ready' in m['text'] for m in log):break
   await asyncio.sleep(.25)
  else:raise RuntimeError('Actual formal candidate browser readiness timeout')
  await asyncio.sleep(1)
  await page.screenshot(path=str(out/'01-idle-on.png'))
  await page.locator('canvas').focus()
  await page.keyboard.down('Space');await asyncio.sleep(.22)
  await page.screenshot(path=str(out/'02-jump-on.png'))
  await page.keyboard.up('Space');await asyncio.sleep(.3)
  audio_states.extend(await page.evaluate('window.__motion_audio_contexts.map(c=>c.state)'))
  if 'running' not in audio_states:raise RuntimeError('Actual Web AudioContext did not resume after real key gesture')
  await page.screenshot(path=str(out/'03-land-on.png'))
  await page.keyboard.down('d');await asyncio.sleep(.2);await page.keyboard.up('d');await asyncio.sleep(.1)
  await page.screenshot(path=str(out/'04-move-on.png'))
  await page.mouse.move(600,380);await page.mouse.down();await asyncio.sleep(.18);await page.mouse.up();await asyncio.sleep(.08)
  await page.screenshot(path=str(out/'04b-real-pointer-fire-target.png'))
  await asyncio.sleep(.45)
  await page.mouse.move(130,220);await page.mouse.down();await asyncio.sleep(.18);await page.mouse.up();await asyncio.sleep(.08)
  await page.screenshot(path=str(out/'04c-real-pointer-fire-air.png'))
  await asyncio.sleep(.35)
  await page.mouse.click(395,50);await asyncio.sleep(.2)
  await page.screenshot(path=str(out/'05-original-off.png'))
  sys.path.insert(0,str(root/'tools'))
  from studio_gui_pointer import _weapon_popup_from_pixels as original_popup
  from collections import Counter
  def _weapon_popup_from_pixels(im,scale,start_y):
   try:return original_popup(im,scale,start_y)
   except AssertionError:pass
   im=im.convert('RGB'); background=Counter(im.getdata()).most_common(1)[0][0]
   import numpy as np
   rgb=np.asarray(im);mask=np.all(rgb==background,axis=2);ys,xs=np.where(mask)
   left,right,top,bottom=int(xs.min()),int(xs.max()),int(ys.min()),int(ys.max())
   if right-left<200 or bottom-top<300:raise AssertionError('Complete popup background not observed')
   strip=rgb[top+2:bottom-1,left+3:left+22];active=np.any(np.any(strip!=background,axis=2),axis=1)
   starts=[];groups=[]
   for n,value in enumerate(active):
    if value:
     if not groups or n-groups[-1][-1]>4:groups.append([])
     groups[-1].append(n)
   groups=[g for g in groups if 6<=g[-1]-g[0]+1<=24]
   if len(groups)!=15:raise AssertionError('Fifteen actual radio components missing:'+str(len(groups)))
   rows=[top+2+(g[0]+g[-1])/2 for g in groups]
   if min(b-a for a,b in zip(rows,rows[1:]))<20:raise AssertionError('Radio components overlap')
   return {'marker_x':left+12,'rows':rows}
  from PIL import Image
  import io
  ids=['pulse_gun','shadow_shuriken','recoil_bomb','triple_machine_gun','sustained_laser','fan_shuriken','remote_boomerang','magnetic_mine','collapse_singularity','machine_storm','laser_cannon','blade_bloom','moon_boomerang','magnetic_storm','star_collapse']
  cached_popup=None
  for index in [3,4,1,5,6,2,7,8,9,10,11,12,13,14,0]:
   await page.mouse.click(550,160);await asyncio.sleep(.2)
   raw=await page.screenshot(path=str(out/('popup-'+str(index)+'.png')))
   if cached_popup is None:cached_popup=_weapon_popup_from_pixels(Image.open(io.BytesIO(raw)),1,0)
   popup=cached_popup
   before=sum('WEAPON SAMPLE: selected '+ids[index] in m['text'] for m in log)
   await page.mouse.click(popup['marker_x'],popup['rows'][index]);await asyncio.sleep(.25)
   if sum('WEAPON SAMPLE: selected '+ids[index] in m['text'] for m in log)<=before:raise RuntimeError('Real pointer weapon selection failed:'+ids[index])
  await page.screenshot(path=str(out/'all-loadouts-pointer.png'))
  await page.touchscreen.tap(550,160);await asyncio.sleep(.2)
  await page.screenshot(path=str(out/'touch-popup-open.png'))
  popup=cached_popup
  before=sum('WEAPON SAMPLE: selected remote_boomerang' in m['text'] for m in log)
  await page.touchscreen.tap(popup['marker_x'],popup['rows'][6]);await asyncio.sleep(.35)
  if sum('WEAPON SAMPLE: selected remote_boomerang' in m['text'] for m in log)<=before:raise RuntimeError('Real DOM touch weapon selection failed')
  await page.screenshot(path=str(out/'touch-popup-selection.png'))
  def scarf_center(raw):
   im=Image.open(io.BytesIO(raw)).convert('RGB');points=[]
   for y in range(425,490):
    for x in range(0,450):
     red,green,blue=im.getpixel((x,y))
     if red>65 and red>green*1.65 and red>blue*1.8:points.append(x)
   if len(points)<20:raise RuntimeError('Visible scarf/body pixels not observed for touch movement')
   return sum(points)/len(points)
  await page.keyboard.down('d');await asyncio.sleep(.4);await page.keyboard.up('d');await asyncio.sleep(.2)
  before_x=scarf_center(await page.screenshot(path=str(out/'touch-move-before.png')))
  cdp=await page.context.new_cdp_session(page)
  await cdp.send('Input.dispatchTouchEvent',{'type':'touchStart','touchPoints':[{'x':114,'y':603,'id':31}]})
  await cdp.send('Input.dispatchTouchEvent',{'type':'touchMove','touchPoints':[{'x':65,'y':660,'id':31}]})
  await asyncio.sleep(.3)
  await cdp.send('Input.dispatchTouchEvent',{'type':'touchEnd','touchPoints':[]})
  await asyncio.sleep(.1)
  after_x=scarf_center(await page.screenshot(path=str(out/'touch-move-after.png')))
  if after_x>=before_x-6:raise RuntimeError('Actual lower-left diagonal touch drag did not move visible hero left')

  count=sum('MOTION CANDIDATE: actual formal player ready' in m['text'] for m in log)
  await page.mouse.dblclick(606,50,delay=10)
  for _ in range(160):
   if sum('MOTION CANDIDATE: actual formal player ready' in m['text'] for m in log)>count:break
   await asyncio.sleep(.1)
  else:raise RuntimeError('Actual pointer restart did not create candidate')
  await asyncio.sleep(.4)
  await page.screenshot(path=str(out/'06-pointer-restart.png'))
  await page.mouse.click(760,50);await asyncio.sleep(.5)
  await page.screenshot(path=str(out/'07-home-full-game.png'))
  await page.mouse.click(893,50);await asyncio.sleep(.6)
  if sum('MOTION FEEL: actual Home player ready' in m['text'] for m in log)<2:raise RuntimeError('HOME DROP did not reopen actual Home candidate')
  await page.screenshot(path=str(out/'08-home-drop-reentry.png'))
  await browser.close()
try:
 asyncio.run(run())
 status='passed' if not errors and not any('SCRIPT ERROR:' in m['text'] or 'ERROR: Failed' in m['text'] for m in log) else 'failed'
except Exception as e:
 errors.append(type(e).__name__+':'+str(e));status='failed'
finally:
 server.shutdown();server.server_close()
 report={'status':status,'audio_context_states_after_real_space_key':audio_states,'source_build_info':json.loads((folder/'build-info.json').read_text()),'driver_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'scope':'Actual local exported Web canvas; DOM keyboard and real pointer candidate toggle/restart/Home; screenshots require pixel review. Includes actual DOM touch popup and diagonal virtual-stick drag. Not public deploy, physical device, listening, or user acceptance.','errors':errors,'console':log,'screenshots':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.glob('*.png')}}
 (out/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({'status':status,'errors':errors,'folder':str(out)}))
 sys.exit(0 if status=='passed' else 1)
