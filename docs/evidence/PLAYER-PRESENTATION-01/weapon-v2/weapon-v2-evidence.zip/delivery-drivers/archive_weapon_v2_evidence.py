from pathlib import Path
import hashlib,json,shutil,zipfile,subprocess
from PIL import Image
root=Path('/workspace/player-presentation');base=root/'build/player_presentation_01/weapon-v2';out=root/'docs/evidence/PLAYER-PRESENTATION-01/weapon-v2';out.mkdir(parents=True,exist_ok=True)
source='3254984dcc4f0fc2c3c69b463fe5515f81d69010';version='weapon-feel-v2'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,d:p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
inv=json.loads((root/'docs/evidence/PLAYER-PRESENTATION-01/weapon-v1/consumer-inventory-weapon-v1.json').read_text())
inv.update(source_commit=source,content_version=version,scope='All15 prior consumer IDs retained plus actual V2 Home/Plains consumers. New presentation task-only;shared mine6s contract and optional interfaces affect production branch pending coordinator fullIntegration.')
for c in inv['consumers'][:11]:c['reason']='Prior complete source discovery retained;V2 visuals not adopted here;shared mine6s and additive interfaces need coordinator affected fullIntegration.'
for cid,reason in [('dev_home_weapon_feel_v2','Actual unchanged formal Home UnderworldPlayer with task leaf and explicit stationary TRAINING pillars;native and Web observed;not production adoption/all appearances'),('dev_plains_weapon_feel_v2','Actual DemoApp formal Plains UnderworldPlayer;V1 original-restore lifecycle retained and V2 Web restart/Home/reentry observed;not complete affected Integration')]:
 inv['consumers'].append(dict(id=cid,path='scenes/dev/player_presentation_01/weapon_feel_v2.tscn',runtime_observed=True,reason=reason,output='weapon-v2-evidence.zip'))
assert len(inv['consumers'])==17
write(out/'consumer-inventory-weapon-v2.json',inv)
browser=json.loads((base/'browser-final/report.json').read_text());receipt=json.loads((base/'package-final-receipt.json').read_text());assert browser['status']=='passed' and not browser['errors'];assert receipt['metadata']['source_commit']==source

def centroid(path):
 im=Image.open(path).convert('RGB');xs=[]
 for y in range(425,490):
  for x in range(450):
   r,g,b=im.getpixel((x,y))
   if r>65 and r>g*1.65 and r>b*1.8:xs.append(x)
 assert len(xs)>=20
 return dict(pixels=len(xs),mean_x=sum(xs)/len(xs))
move={name:centroid(base/'browser-final'/('touch-move-'+name+'.png')) for name in ['before','after']};assert move['after']['mean_x']<move['before']['mean_x']-6
package=dict(task='PLAYER-PRESENTATION-01',source_commit=source,content_version=version,build_id=receipt['metadata']['build_id'],status='passed',scope='Actual ZIP extracted, complete canonical PCK SHA, real exported Chromium keyboard/pointer/DOMtouch;not public playable Web, hearing/user/physical-device acceptance',archive=receipt['archive'],archive_sha256=receipt['archive_sha256'],archive_bytes=receipt['archive_bytes'],canonical_pack_sha256=receipt['reconstructed']['pack_sha256'],package_receipt_sha256=sha(base/'package-final-receipt.json'),browser_report_sha256=sha(base/'browser-final/report.json'),browser_driver_sha256=sha(Path('/workspace/scratch/weapon_v2_browser.py')),audio_context_states_after_real_space_key=browser['audio_context_states_after_real_space_key'],pointer_ids=[m['text'] for m in browser['console'] if 'WEAPON SAMPLE: selected' in m['text']],real_touch_movement_pixel_measurement=move,retained_browser_limits=['Generic404 response lacks URL;not network-all-zero','Autoplay warning before real user gesture;AudioContext running afterwards does not prove hearing'],licenses={k:v for k,v in receipt['metadata']['files'].items() if 'Freedoom' in k},deployment=dict(status='blocked',reason=(base/'public-web-final-stage.log').read_text().strip(),log_sha256=sha(base/'public-web-final-stage.log')),native_source_commit=source)
write(out/'package-final.json',package)
shutil.copy2(base/'native-hand-final/comparison.mp4',out/'weapon-v2-comparison.mp4');shutil.copy2(base/'public-movie-download.json',out/'public-movie-download.json')
protected={'scripts/underworld_plains/underworld_player.gd':'6ed4b00e1058a9d16808df58295f63bc8900e70653aeccc66a6752fb08412127'}
for p in root.glob('assets/**/animation_build.json'):
 if sha(p)=='65bb572735f8aead4a6b1e5ead2174b1dc784eb9d0ee8aeeafff6ac8d7eb49b3':protected[p.relative_to(root).as_posix()]=sha(p)
for pattern,expected in [('assets/**/run_sheet.png','64fe86b6de951bd671f511509104b2639f528527741774dd2561547f7ec5dd27'),('assets/**/states_sheet.png','01f6645fcedd24e14e06d56b6789ad0aa987ac0c75a63b39b0f16b40fe256744')]:
 for p in root.glob(pattern):
  if sha(p)==expected:protected[p.relative_to(root).as_posix()]=sha(p)
assert all(sha(root/p)==v for p,v in protected.items()) and len(protected)==4,protected
write(base/'protected-source-check.json',dict(status='passed',source_commit=source,files=protected,scope='Read-only shared body/style4;no PNG edits or old style SHA refresh'))
files={}
for p in base.iterdir():
 if p.is_file() and p.suffix in ['.json','.log']:files['runs/'+p.name]=p
files['foundry/foundry-before-local.zip']=base/'foundry-before-local.zip'
for name in ['native-hand-final','native-final','browser-final','foundry-rebuild-first']:
 for p in (base/name).rglob('*'):
  if not(p.is_file() and p.suffix in ['.json','.log','.png','.mp4','.txt']):continue
  if p.name=='comparison.mp4':continue
  if name=='native-final' and p.suffix=='.png' and p.name not in ['after-return_blade-646.png','after-return_blade-648.png','after-blackhole_hold-1215.png','after-blackhole_hold-1223.png','after-bomb-711.png','after-bomb-715.png']:continue
  if name=='browser-final' and p.name.startswith('popup-') and p.name not in ['popup-0.png','popup-14.png']:continue
  files[name+'/'+p.relative_to(base/name).as_posix()]=p
for name in ['package_weapon_v2_preview.py','weapon_v2_browser.py','archive_weapon_v2_evidence.py']:
 p=Path('/workspace/scratch')/name;files['delivery-drivers/'+name]=p
for name in ['package-final.json','public-movie-download.json','consumer-inventory-weapon-v2.json','engineering-review.json','runtime-review.json']:
 p=out/name
 if p.exists():files['receipts/'+name]=p
for name in ['20261023T003230.076560Z','20261023T003200.437857Z','20261022T235316.764578Z']:
 r=root/'build/verification/harness'/name
 for p in r.rglob('*'):
  if p.is_file() and p.suffix in ['.json','.log','.txt']:files['harness/'+name+'/'+p.relative_to(r).as_posix()]=p
for p in (root/'resources/foundry').rglob('*.json'):files['foundry/promoted-development/'+p.relative_to(root/'resources/foundry').as_posix()]=p
for name in ['build-info.json','build_report.json']:
 p=root/'build/web'/name;files['web-export/'+name]=p
index=dict(task='PLAYER-PRESENTATION-01',source_commit=source,content_version=version,scope='Actual raw attempts and failure logs;FINAL325 native both movies/traces/all32 original PNGs;firstfc55 both raw movies/traces plus6 selected rejected-detail PNGs;final Web report/selectedscreens;Foundry original failures and actual promoted development replays;not all are final-source proofs',source_identity=dict(final_native_web_all=source,first_native='fc55deee38fd6530bd14586d8fb5ecbf0af59026',hand_before_stamp='388ce50',core_harness='fc55deee38fd6530bd14586d8fb5ecbf0af59026'),members={n:dict(sha256=sha(p),bytes=p.stat().st_size) for n,p in sorted(files.items())},excluded='Godot AVI/imports/large playable ZIP/engine/PCK/orphan caches excluded;old PNGs can be re-extracted from preserved original MP4;all screenshot hashes/index retained. Empty interrupted foundry-before-source.tar.gz is NOT a backup;real foundry-before-local.zip preserved.',failures=dict(feedback_first='Invalid0HP test fixture and incorrect pause-state expectation;4 errors retained, corrected real fixture to281/868/0',mine_host_regression_before='Invalidhost at same deadline produced explosion;123/4 retained then validity-before-fuse fix123/0',harness_weapons_first='Actual inner weapon pass but outer source_changed: failed,not passed',harness_weapons_frozen='Interrupted/no completed outer report;not counted as pass',foundry_rebuild_first='Base24 and doublejump6 individually passed;continuous replay max_position_error10.378845 failed;no promote. Same parameters isolated once retry succeeded;rootcause/stability not signed',web_build_final='Old Foundry source basis export rejected before official actual pool rebuild',harness_docs_first='Sparse missing historical dependencies;not weakened or signed',public_web_final_stage='900MiB shared site capacity rejection;no new public playable Web',frozen_all_on='Earlier pressurecase4audio drops66preempt retained;final3250drops61preempt does not erase it'))
archive=out/'weapon-v2-evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for n,p in sorted(files.items()):z.write(p,n)
 z.writestr('manifest.json',json.dumps(index,ensure_ascii=False,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for n,d in index['members'].items():assert hashlib.sha256(z.read(n)).hexdigest()==d['sha256']
index.update(archive_sha256=sha(archive),archive_bytes=archive.stat().st_size,verification='ZIP CRC plus every member SHA reread matched')
write(out/'evidence-index.json',index)
print(json.dumps(dict(archive_bytes=archive.stat().st_size,members=len(files),touch=move)))
