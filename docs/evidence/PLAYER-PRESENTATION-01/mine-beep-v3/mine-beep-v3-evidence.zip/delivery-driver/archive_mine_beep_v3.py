from pathlib import Path
import json,hashlib,subprocess,zipfile,shutil
root=Path('/workspace/player-presentation');base=root/'build/player_presentation_01/mine-beep-v3';out=root/'docs/evidence/PLAYER-PRESENTATION-01/mine-beep-v3';out.mkdir(parents=True,exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,d:p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
source='4e5102af9abd16d322656375e94886a95deae38a';old='3254984dcc4f0fc2c3c69b463fe5515f81d69010'
native=base/'native-final';previous=root/'build/player_presentation_01/weapon-v2/native-hand-final'
report=json.loads((native/'report.json').read_text());assert report['status']=='passed' and report['source_stable'] and report['source_metadata']['commit']==source
pair=[json.loads((p/'after.json').read_text()) for p in [previous,native]]
fields=report['gameplay_comparison']['fields'];assert len(fields)==28
changes=[dict(sample=i,fields=[k for k in fields if a[k]!=b[k]]) for i,(a,b) in enumerate(zip(pair[0]['rows'],pair[1]['rows'])) if any(a[k]!=b[k] for k in fields)]
assert len(pair[0]['rows'])==len(pair[1]['rows'])==1294 and not changes and pair[0]['events']==pair[1]['events']
beeps=[x for x in pair[1]['audio_events'] if x['id']=='mine_beep'];gaps=[(b['tick']-a['tick'])/60 for a,b in zip(beeps,beeps[1:])];assert len(beeps)==11 and gaps[0]>.9 and gaps[-1]<.2
comparison=dict(status='passed',old_source=old,new_source=source,fields=fields,samples=[len(p['rows']) for p in pair],differences=changes,accepted_events_equal=True,old_after_sha256=sha(previous/'after.json'),new_after_sha256=sha(native/'after.json'),beep_events=beeps,beep_interval_seconds=gaps,new_audio_dropped=pair[1]['weapon_audio_dropped'],new_audio_preemptions=pair[1]['weapon_audio_preemptions'],scope='Actual prior325 V2 ON versus new4e V2 ON;only new timer sample binding differs;all28 gameplay fields and accepted events identical. Audio audibility/naturalness/user/device not signed.')
write(base/'old-v2-new-v3-parity.json',comparison)
for name,src in [('before',previous/'after.mp4'),('after',native/'after.mp4')]:
 dest=base/('timer-'+name+'.mp4')
 subprocess.run(['ffmpeg','-v','error','-y','-ss','13.2','-i',str(src),'-t','6.75','-c:v','libx264','-preset','fast','-crf','20','-pix_fmt','yuv420p','-c:a','aac','-b:a','192k',str(dest)],check=True)
(base/'timer-concat.txt').write_text("file 'timer-before.mp4'\nfile 'timer-after.mp4'\n")
subprocess.run(['ffmpeg','-v','error','-y','-f','concat','-safe','0','-i',str(base/'timer-concat.txt'),'-c','copy',str(out/'timer-comparison.mp4')],check=True)
shutil.copy2(base/'timer-after.mp4',out/'timer-countdown.mp4')
clips=dict(source_commit=source,content_version='mine-beep-v3',old_source=old,source_paths=dict(before=str(previous/'after.mp4'),after=str(native/'after.mp4')),source_movie_sha256=dict(before=sha(previous/'after.mp4'),after=sha(native/'after.mp4')),excerpt=dict(start_seconds=13.2,duration_seconds=6.75,method='Continuous actual Godot movie excerpts;no remixed/synthesized replacement game audio;before is prior325 V2 ON,after is new4e V2 ON',exact_tick_mapping='not claimed;MP4 presentation timestamps define cuts'),outputs={},limits=['Dummy audio MovieMaker captured48k stereo;not physical speaker/hearing approval','User taste/hearing/device and full formalIntegration remain unverified','New public playable Web not built/deployed for this narrow source-audio correction;prior6952 package retains old beep'])
for p in [out/'timer-comparison.mp4',out/'timer-countdown.mp4']:
 probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(p)]));clips['outputs'][p.name]=dict(sha256=sha(p),bytes=p.stat().st_size,probe=probe)
write(out/'clip-receipt.json',clips)
files={}
for p in base.iterdir():
 if p.is_file() and p.suffix in ['.json','.log','.html','.txt']:files['runs/'+p.name]=p
for p in native.iterdir():
 if p.is_file() and p.suffix in ['.json','.log','.mp4','.txt'] and p.name!='comparison.mp4':files['native-final/'+p.name]=p
for name in ['clip-receipt.json','engineering-review.json','Freedoom-LICENSE.txt','Freedoom-CREDITS.txt','TIMER-ATTRIBUTION.txt']:
 p=out/name
 if p.exists():files['receipts/'+name]=p
files['delivery-driver/archive_mine_beep_v3.py']=Path('/workspace/scratch/archive_mine_beep_v3.py')
index=dict(task='PLAYER-PRESENTATION-01',source_commit=source,content_version='mine-beep-v3',members={n:dict(sha256=sha(p),bytes=p.stat().st_size) for n,p in sorted(files.items())},scope='Real325-old vs4e-new audio correction;raw actual engine native pair and source-search/candidate downloads/legal snapshots;all original first/second fixture failures retained. Actual chosen upstream reference and license also committed under assets.',failures=dict(binding_feedback_first='Expected3audio services but actual Preview reuses1;271samples853checks1error,not production defect',binding_feedback_second='Deferred audit held transient reentry leaf past same-tick replacement;271samples857checks1error plus engine deferred freed-object ERROR;fixed to inspect preassigned leaf audio immediately,not relaxed consumer count',quality_diff_before_freeze='Exact affected_paths required;directory prefix did not cover8new production files;fixed exact explicit paths'),exclusions='AVI/imports,old large source captures,duplicate full comparison and newPlayableWeb excluded;old325 movie/trace binding retained bySHA and old versioned evidence,old timer excerpt included for independent hearing comparison')
archive=out/'mine-beep-v3-evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for n,p in sorted(files.items()):z.write(p,n)
 z.writestr('manifest.json',json.dumps(index,ensure_ascii=False,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for n,d in index['members'].items():assert hashlib.sha256(z.read(n)).hexdigest()==d['sha256']
index.update(archive_bytes=archive.stat().st_size,archive_sha256=sha(archive),verification='CRC and every member SHA reread matched');write(out/'evidence-index.json',index)
print(json.dumps(dict(status='passed',source=source,files=len(files),archive_bytes=archive.stat().st_size,new_tone='85ms CC0 timer sample',beeps=len(beeps),gaps=gaps)))
