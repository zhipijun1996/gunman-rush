extends SceneTree
func _initialize() -> void: run.call_deferred()
func run() -> void:
	var script: Script = load("res://scripts/demo/thorn_forest_h_slice.gd")
	print("LOADED ", script != null)
	script = null
	for unused: int in 6: await process_frame
	quit()
