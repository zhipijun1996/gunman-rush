import os,subprocess,selectors,json,sys,hashlib,time
from pathlib import Path
root=Path.cwd();folder=Path(sys.argv[1]);folder.mkdir(parents=True,exist_ok=True)
env=os.environ.copy();env.update(GODOT_BIN='/workspace/gunman-rush/build/region_production_v3/godot_locked.sh',LP_NUM_THREADS='1',OMP_NUM_THREADS='1',LIBGL_ALWAYS_SOFTWARE='1',PLAINS_SHARED_WIND='0')
log=(folder/'display.log').open('wb');display=subprocess.Popen(['/workspace/toolchains/xvfb/usr/bin/Xvfb','-displayfd','1','-screen','0','1280x720x24','-nolisten','tcp','-ac'],stdout=subprocess.PIPE,stderr=log)
try:
 with selectors.DefaultSelector() as s:
  s.register(display.stdout,selectors.EVENT_READ)
  if not s.select(20):raise RuntimeError('Xvfb timeout')
  env['DISPLAY']=':'+display.stdout.readline().decode().strip()
 cmd=['bash','tools/godot.sh','--path','.','--rendering-method','gl_compatibility','--audio-driver','Dummy','--script','build/region_production_v3/ridge_sample_optimization/benchmark.gd','--','--output=res://'+str(folder)]
 before={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in list((root/'scripts').rglob('*.gd'))+list((root/'scripts').rglob('*.gdshader'))+list((root/'shaders').rglob('*.gdshader')) if p.is_file()}
 start=time.monotonic();r=subprocess.run(cmd,env=env,capture_output=True,text=True,timeout=240);(folder/'native.log').write_text(r.stdout+r.stderr)
 (folder/'invocation.json').write_text(json.dumps({'command':cmd,'env':{k:env[k] for k in ['GODOT_BIN','LP_NUM_THREADS','OMP_NUM_THREADS','DISPLAY','LIBGL_ALWAYS_SOFTWARE','PLAINS_SHARED_WIND']},'exit_code':r.returncode,'seconds':time.monotonic()-start,'source_code_before':before},indent=2)+'\n')
 print('STATIC exit',r.returncode);print((r.stdout+r.stderr)[-1800:]);sys.exit(r.returncode)
finally:
 display.terminate();display.wait(timeout=10);log.close()
