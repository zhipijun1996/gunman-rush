extends SceneTree
var output:="res://build/region_production_v3/sky_sample_optimization"
var rows:Array[Dictionary]=[]
func _initialize()->void: run.call_deferred()
func wait_stage(app:DemoApp)->void:
 for unused:int in 120:
  await physics_frame;await process_frame
  if not app._stage_pending and app.stage is PlainsRegionStage:return
func find_landscape(n:Node)->PlainsSemanticLandscape:
 if n is PlainsSemanticLandscape:return n
 for c:Node in n.get_children():
  var x:=find_landscape(c)
  if x!=null:return x
 return null
func run()->void:
 root.size=Vector2i(1280,720)
 RenderingServer.viewport_set_measure_render_time(root.get_viewport_rid(),true)
 var app:=DemoApp.new();app.meta_persistence_enabled=false;root.add_child(app)
 app.start_plains("level-design-v2-baseline/08");await wait_stage(app)
 app.lifetime.stage_epoch+=1;app.lifetime.actor_epoch+=1;app.director._enter_stage(2,&"boss");app._stage_entered(DemoRunResult.new());await wait_stage(app)
 var stage:=app.stage as PlainsRegionStage
 var landscape:=find_landscape(stage)
 var background:=app.get_node("PlainsBackground") as PlainsBackground
 var manifest_before:=JSON.stringify(stage.generated.manifest)
 var sky:=background.panels[0].material as ShaderMaterial
 var ridge:=background.panels[1].material as ShaderMaterial
 for id:String in ["clock_regulator_court_v1","windmill_repair_workshop_complete_v1","woodland_two_depth_ridges_v1"]:
  var found:Dictionary={}
  for e:Dictionary in landscape.entries:
   if e.family.family_id==id:found=e;break
  if found.is_empty():printerr("missing actual family",id);quit(1);return
  var pos:Vector2
  if id=="woodland_two_depth_ridges_v1":
   var ref:Vector2=found.parallax_reference-Vector2(300,0)
   var best:=INF
   for support:Rect2 in landscape.supports:
    if support.size.x<100:continue
    var x:=clampf(ref.x,support.position.x+48,support.end.x-48)
    var distance:=Vector2(x,support.position.y-18).distance_squared_to(ref)
    if distance<best:best=distance;pos=Vector2(x,support.position.y-24)
  else:pos=Vector2(found.support.get_center().x,found.support.position.y-24)
  app.player.reset_at(pos)
  for unused:int in 36:await physics_frame;await process_frame
  paused=true
  for unused:int in 3:await process_frame
  for trial:int in 4:
   # ABBA controls warm/order bias; same live actor/camera/world frozen.
   var softness:float=0.45 if trial in [0,3] else 0.0
   sky.set_shader_parameter("softness",softness)
   for warm:int in 12:await RenderingServer.frame_post_draw
   var timings:Array[Dictionary]=[]
   for n:int in 45:
    var start:=Time.get_ticks_usec()
    await RenderingServer.frame_post_draw
    timings.append({"wall_ms":float(Time.get_ticks_usec()-start)/1000.0,"viewport_cpu_ms":RenderingServer.viewport_get_measured_render_time_cpu(root.get_viewport_rid()),"viewport_gpu_ms":RenderingServer.viewport_get_measured_render_time_gpu(root.get_viewport_rid()),"process_seconds":Performance.get_monitor(Performance.TIME_PROCESS)})
   var file:=output+"/"+id+"_softness_"+("045" if softness>0 else "000")+"_trial_"+str(trial)+".png"
   var error:=root.get_texture().get_image().save_png(file)
   var cam:=root.get_camera_2d()
   rows.append({"window":id,"trial":trial,"softness":softness,"ridge_softness":ridge.get_shader_parameter("softness"),"samples":timings,"actor":[app.player.global_position.x,app.player.global_position.y],"camera":[cam.global_position.x,cam.global_position.y],"file":file,"png_error":error,"background_nodes":background.measured_nodes(),"scope":"Actual formal DemoApp paused samecamera GPU ABBA uniform comparison; synthetic static pose, no traversal. Viewport GPU monitor0 means unavailable, not zero-cost. Wall time includes frame scheduling, CPU/GPU monitors may overlap."})
  sky.set_shader_parameter("softness",0.0)
  paused=false
 var f:=FileAccess.open(output+"/raw_benchmark.json",FileAccess.WRITE);f.store_string(JSON.stringify({"seed":"level-design-v2-baseline/08","map_index":2,"manifest_unchanged":manifest_before==JSON.stringify(stage.generated.manifest),"rows":rows})+"\n");f.close()
 app.free();await process_frame;print("SKY SAMPLE BENCHMARK: 3 real windows12ABBA trials540 measured frames");quit()
