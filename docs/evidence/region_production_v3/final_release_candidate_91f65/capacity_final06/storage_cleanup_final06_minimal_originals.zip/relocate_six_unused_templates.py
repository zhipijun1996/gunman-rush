from pathlib import Path
import os,stat,time,json,hashlib,shutil,uuid
ROOT=Path('/workspace/gunman-rush');OUT=ROOT/'build/region_production_v3/storage_cleanup_final06';DEST=Path('/tmp/gunman-v3-toolchain-capacity')
SOURCES=[Path('/workspace/toolchains/user-data/godot/export_templates/4.7.2.stable')/n for n in ['android_debug.apk','android_release.apk','linux_debug.arm32','linux_debug.arm64','linux_release.arm32','linux_release.arm64']]
assert len(SOURCES)==6 and ROOT.stat().st_dev!=Path('/tmp').stat().st_dev
DEST.mkdir(mode=0o700,exist_ok=True);assert not DEST.is_symlink() and DEST.stat().st_dev==Path('/tmp').stat().st_dev

def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while b:=f.read(1024*1024):h.update(b)
 return h.hexdigest()
def meta(p):
 s=p.lstat();return {'path':str(p),'bytes':s.st_size,'allocated_bytes':s.st_blocks*512,'mode':s.st_mode,'uid':s.st_uid,'gid':s.st_gid,'device':s.st_dev,'inode':s.st_ino,'nlink':s.st_nlink,'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns,'atime_ns':s.st_atime_ns}
def active(inodes):
 hits=[]
 for proc in Path('/proc').iterdir():
  if not proc.name.isdigit() or int(proc.name)==os.getpid():continue
  try:
   if (proc/'stat').read_text().split(') ',1)[1].split()[0]=='Z':continue
   for fd in (proc/'fd').iterdir():
    try:s=fd.stat()
    except (FileNotFoundError,PermissionError):continue
    if (s.st_dev,s.st_ino) in inodes:hits.append({'pid':int(proc.name),'fd':fd.name,'device':s.st_dev,'inode':s.st_ino})
  except (FileNotFoundError,ProcessLookupError,PermissionError):continue
 return hits
CAS=['bytes','mode','uid','gid','device','inode','nlink','mtime_ns','ctime_ns'];START=time.time();FREE=os.statvfs(ROOT).f_bavail*os.statvfs(ROOT).f_frsize
before=[]
for p in SOURCES:
 assert p.is_file() and not p.is_symlink();m=meta(p);assert stat.S_ISREG(m['mode']) and m['nlink']==1;m['sha256']=sha(p);before.append(m)
assert not active({(m['device'],m['inode']) for m in before}),'Archive is an active process input'
assert os.statvfs(DEST).f_bavail*os.statvfs(DEST).f_frsize>sum(x['bytes'] for x in before)+32*1024*1024
ops=[]
try:
 for row in before:
  source=Path(row['path']);target=DEST/source.name;assert not target.exists()
  shutil.copy2(source,target);assert sha(target)==row['sha256'];tm=meta(target);assert stat.S_IMODE(tm['mode'])==stat.S_IMODE(row['mode']) and tm['uid']==row['uid'] and tm['gid']==row['gid'] and tm['bytes']==row['bytes']
  now=meta(source);assert all(now[k]==row[k] for k in CAS) and sha(source)==row['sha256']
  check=active({(r['device'],r['inode']) for r in before});assert not check,check
  tmp=source.with_name('.'+source.name+'.tmpfs-link-'+uuid.uuid4().hex);os.symlink(str(target),tmp)
  try:
   now=meta(source);assert all(now[k]==row[k] for k in CAS);os.replace(tmp,source)
  finally:
   if tmp.is_symlink():tmp.unlink()
  assert source.is_symlink() and os.readlink(source)==str(target) and sha(source)==row['sha256']
  ops.append({'original_before':row,'tmpfs_target_after':meta(target),'original_path_symlink_after':meta(source),'symlink_target':os.readlink(source),'sha256_through_original_path_after':sha(source),'allocated_overlay_bytes_released':row['allocated_bytes'],'active_original_archive_fd_before_replace':[],'restore_command':['python3',str(OUT/'restore_toolchain_archives.py'),'--receipt',str(OUT/'toolchain_capacity_relocation_receipt.json'),'--source',str(source)],'restores_data_mode_owner_atime_mtime':True,'original_inode_ctime_restorable':False})
  (OUT/'toolchain_capacity_relocation_progress.json').write_text(json.dumps({'operations':ops},indent=2)+'\n')
 finalfree=os.statvfs(ROOT).f_bavail*os.statvfs(ROOT).f_frsize
 result={'status':'completed','kind':'Six authorized rebuildable Android/ARM toolchain templates only; no evidence moved to tmp','started_epoch':START,'finished_epoch':time.time(),'overlay_device':ROOT.stat().st_dev,'tmpfs_device':DEST.stat().st_dev,'original_archive_count':6,'original_archive_bytes_total':sum(x['bytes'] for x in before),'actual_released_overlay_allocated_bytes':sum(x['allocated_bytes'] for x in before),'free_before_bytes':FREE,'free_after_bytes':finalfree,'observed_overlay_free_delta_bytes':finalfree-FREE,'all_original_paths_preserved_as_symlinks':True,'all_content_SHA_mode_uid_gid_preserved_at_targets':True,'web_windows_x86_templates_engine_untouched':True,'repository_source_docs_evidence_unmodified':True,'engine_calls':0,'operations':ops,'limits':'tmpfs is ephemeral; preserve these paths until restored or toolchain reconstructed. No evidence/source/media moved. Logical capabilities/paths preserved, physical inode/ctime/type changed.'}
 (OUT/'toolchain_capacity_relocation_receipt.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='operations'},indent=2),flush=True)
except BaseException as e:(OUT/'toolchain_capacity_relocation_failed.json').write_text(json.dumps({'error':repr(e),'operations':ops,'epoch':time.time()},indent=2)+'\n');raise
