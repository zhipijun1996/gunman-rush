from pathlib import Path
import os,time,json,hashlib,subprocess,stat
ROOT=Path('/workspace/gunman-rush');BUILD=ROOT/'build';OUT=BUILD/'region_production_v3/storage_cleanup_final04'
assert subprocess.run(['git','check-ignore','-q',str(OUT)],cwd=ROOT).returncode==0
START=time.time();before=os.statvfs(ROOT);tracked=subprocess.check_output(['git','ls-files','-z'],cwd=ROOT);tracked_sha=hashlib.sha256(tracked).hexdigest()
def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  while data:=f.read(1024*1024):h.update(data)
 return h.hexdigest()
def meta(p):
 s=p.lstat();return {'path':str(p),'size':s.st_size,'allocated_bytes':s.st_blocks*512,'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns,'mode':s.st_mode,'inode':s.st_ino,'device':s.st_dev,'nlink':s.st_nlink,'uid':s.st_uid,'gid':s.st_gid}
processes=[]
for proc in Path('/proc').iterdir():
 if not proc.name.isdigit():continue
 try:
  state=(proc/'stat').read_text().split(') ',1)[1].split()[0]
  if state=='Z':continue
  command=(proc/'cmdline').read_bytes();exe=os.readlink(proc/'exe');cwd=os.readlink(proc/'cwd')
  relevant=any(x in command.lower() for x in [b'godot',b'tools/harness.py',b'tools/deliver.py',b'tools/run_'])
  if relevant:processes.append({'pid':int(proc.name),'exe':exe,'cwd':cwd,'command_sha256':hashlib.sha256(command).hexdigest(),'godot':b'godot' in command.lower()})
 except (FileNotFoundError,PermissionError,ProcessLookupError):continue
caches=[];symlinks=[];missing=[]
for folder,dirs,files in os.walk(BUILD,followlinks=False):
 for d in list(dirs):
  path=Path(folder)/d
  if path.is_symlink():
   symlinks.append({'path':str(path),'target':os.readlink(path),'action':'protected; never followed'});dirs.remove(d)
  elif d=='.godot':
   dirs.remove(d);project=path.parent
   if not(project/'project.godot').is_file():missing.append({'cache':str(path),'reason':'No adjacent actual project.godot; not eligible'});continue
   entries=[];newest=max(path.stat().st_mtime_ns,path.stat().st_ctime_ns);haslink=False
   for here,subdirs,names in os.walk(path,followlinks=False):
    for name in subdirs+names:
     f=Path(here)/name;data=meta(f);newest=max(newest,data['mtime_ns'],data['ctime_ns'])
     if f.is_symlink():haslink=True;data['symlink']=os.readlink(f)
     elif stat.S_ISREG(data['mode']):data['sha256']=sha(f)
     entries.append(data)
   cache_tracked=subprocess.check_output(['git','ls-files','--',str(path)],cwd=ROOT,text=True).splitlines()
   age=(START-newest/1e9)/3600;reasons=[]
   if age<2:reasons.append('Recent cache mutation/creation less than two hours; protected')
   if haslink:reasons.append('Symlink in cache; protected')
   if cache_tracked:reasons.append('Tracked cache file; protected')
   if any(Path(p['cwd'])==project or project in Path(p['cwd']).parents for p in processes):reasons.append('Live process cwd in project; protected')
   if not reasons:reasons.append('No deletion performed in final audit; no fully qualified old-idle candidate was established')
   pg=project/'project.godot';caches.append({'cache':str(path),'project':str(project),'actual_project_godot':meta(pg),'project_godot_sha256_before':sha(pg),'project_godot_sha256_after':sha(pg),'allocated_bytes':sum(e['allocated_bytes'] for e in entries if stat.S_ISREG(e['mode'])),'cache_files_sha256_metadata':entries,'age_hours':age,'tracked_cache_files':cache_tracked,'protection_reasons':reasons,'action':'preserved','rebuild_command':['Godot4.7.2','--headless','--editor','--quit','--path',str(project)],'rebuild_executed':False})
audit={'kind':'actual_readonly_final_cache_audit','start_epoch':START,'finished_epoch':time.time(),'allowed_deletion_scope':'Only old idle actual frozen/project Godot .godot caches within ROOT/build; every recent/active/symlink/tracked cache protected','root_cache_absolutely_protected':meta(ROOT/'.godot'),'running_relevant_processes':processes,'project_caches':caches,'other_godot_paths_missing_project':missing,'symlink_directories_not_followed':symlinks,'delete_operations':0,'engine_calls':0,'tracked_path_list_before_sha256':tracked_sha,'tracked_path_list_after_sha256':hashlib.sha256(subprocess.check_output(['git','ls-files','-z'],cwd=ROOT)).hexdigest()}
(OUT/'cache_audit.json').write_text(json.dumps(audit,indent=2)+'\n')
after=os.statvfs(ROOT);receipt={'schema_version':1,'agent_id':'/root/action_finalizer','kind':'actual_zero_deletion_receipt','status':'no_eligible_old_idle_cache_within_authorized_scope','before_free_bytes':before.f_bavail*before.f_frsize,'after_free_bytes':after.f_bavail*after.f_frsize,'filesystem_free_delta_bytes':after.f_bavail*after.f_frsize-before.f_bavail*before.f_frsize,'actual_deleted_cache_count':0,'actual_deleted_file_count':0,'actual_released_bytes_from_deletions':0,'target_released_bytes':1000000000,'target_met':False,'preserved_root_cache':str(ROOT/'.godot'),'all_candidate_project_godot_SHA_unchanged':all(c['project_godot_sha256_before']==c['project_godot_sha256_after'] for c in caches),'source_evidence_deletions':0,'source_evidence_mutations':0,'source_evidence_full_SHA_comparison':'Not claimed: no deletion or mutation executed anywhere; only protected project.godot hashes checked. Cache files full SHA/metadata retained in audit.','CAS_deletion_steps':[],'reason':'Only actual eligible-project cache is less than2h old and protected; no expansion to sources/media/archives/JSON/log/failed evidence or root cache','audit_sha256':sha(OUT/'cache_audit.json'),'engine_calls':0,'finished_epoch':time.time()}
(OUT/'cache_delete_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:v for k,v in receipt.items() if k not in ['source_evidence_full_SHA_comparison','audit_sha256']},indent=2));print('protected_project_caches',len(caches),'symlink_dirs_preserved',len(symlinks),'no_project_cache_dirs',len(missing))
