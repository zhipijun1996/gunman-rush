from pathlib import Path
import os,stat,time,json,hashlib,subprocess,uuid,shlex
ROOT=Path('/workspace/gunman-rush');BASE=ROOT/'build/root_bell';OUT=ROOT/'build/region_production_v3/storage_cleanup_final04'
NAMES=['g1_routing_python_final01','v3_final_g1_default_01','v3_integrated_g1_final01','independent_ecology_admission_verify','independent_parent_final_27_plus9','parent_evidence_repair_r2_02'];SCOPES=[BASE/n for n in NAMES]
assert subprocess.run(['git','check-ignore','-q',str(OUT)],cwd=ROOT).returncode==0
CAS_KEYS=['size','mode','uid','gid','device','inode','nlink','mtime_ns','ctime_ns']
def meta(p):
 s=p.lstat();assert stat.S_ISREG(s.st_mode),p
 return {'path':str(p),'size':s.st_size,'allocated_bytes':s.st_blocks*512,'mode':s.st_mode,'uid':s.st_uid,'gid':s.st_gid,'device':s.st_dev,'inode':s.st_ino,'nlink':s.st_nlink,'atime_ns':s.st_atime_ns,'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns}
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while b:=f.read(1024*1024):h.update(b)
 return h.hexdigest()
def equal(a,b):
 with a.open('rb') as f,b.open('rb') as g:
  while True:
   x=f.read(1024*1024);y=g.read(1024*1024)
   if x!=y:return False
   if not x:return True
def linksafe(p):
 assert p.is_relative_to(BASE) and p.is_file() and not p.is_symlink(),p
 q=p
 while q!=ROOT:
  assert not q.is_symlink(),q
  q=q.parent
 assert any(p.is_relative_to(s) for s in SCOPES)
def busy():
 hits=[];denied=[]
 for proc in Path('/proc').iterdir():
  if not proc.name.isdigit() or int(proc.name)==os.getpid():continue
  try:
   state=(proc/'stat').read_text().split(') ',1)[1].split()[0]
   if state=='Z':continue
   cmd=(proc/'cmdline').read_bytes().decode(errors='replace').split('\0')
   if any(str(scope) in arg for scope in SCOPES for arg in cmd):hits.append({'pid':int(proc.name),'kind':'command_scope_reference'})
   try:
    cwd=os.readlink(proc/'cwd')
    if any(cwd==str(s) or cwd.startswith(str(s)+'/') for s in SCOPES):hits.append({'pid':int(proc.name),'kind':'cwd_scope_reference','path':cwd})
   except PermissionError:denied.append({'pid':int(proc.name),'kind':'cwd'})
   try:
    for fd in (proc/'fd').iterdir():
     try:target=os.readlink(fd)
     except (FileNotFoundError,PermissionError):continue
     if any(target==str(s) or target.startswith(str(s)+'/') for s in SCOPES):hits.append({'pid':int(proc.name),'kind':'open_fd_scope_reference','path':target})
   except PermissionError:denied.append({'pid':int(proc.name),'kind':'fd'})
  except (FileNotFoundError,ProcessLookupError):continue
  except PermissionError:denied.append({'pid':int(proc.name),'kind':'proc'})
 return {'hits':hits,'inaccessible_process_observations':denied,'epoch':time.time()}
def save(name,data):
 p=OUT/name;p.write_text(json.dumps(data,indent=2)+'\n')
BEFORE_FREE=os.statvfs(ROOT).f_bavail*os.statvfs(ROOT).f_frsize;START=time.time();proof=[];all_files=[];candidates=[]
for scope in SCOPES:
 assert scope.is_dir() and not scope.is_symlink()
 report=scope/'report.json';r=json.loads(report.read_text());assert r.get('status')=='passed',scope
 pure=scope
 if scope.name in ['v3_final_g1_default_01','v3_integrated_g1_final01']:pure=scope/'native165/strict_formal_python'
 pr=pure/'report.json';p=json.loads(pr.read_text());assert p.get('status')=='passed' and 'NO NATIVE/MOVIE' in p.get('scope',''),pure
 proof.append({'scope':str(scope),'report':str(report),'report_sha256':sha(report),'status':r['status'],'scope_text':r.get('scope'),'pure_python_directory':str(pure),'python_report_sha256':sha(pr),'python_scope':p['scope']})
 for folder,dirs,files in os.walk(scope,followlinks=False):
  assert not any((Path(folder)/d).is_symlink() for d in dirs)
  for name in sorted(files):
   f=Path(folder)/name;linksafe(f);m=meta(f);m['sha256']=sha(f);m['metadata_after_hash']=meta(f);all_files.append(m)
 for f in sorted(pure.glob('*/capture.json')):candidates.append(f)
assert len(candidates)==54,len(candidates)
assert not subprocess.check_output(['git','ls-files','--',*[str(s) for s in SCOPES]],cwd=ROOT,text=True)
activity=busy();assert not activity['hits'],activity['hits']
lookup={x['path']:x for x in all_files};groups={}
for f in candidates:
 m=lookup[str(f)];key=(m['size'],m['sha256'],m['mode'],m['uid'],m['gid'],m['device']);groups.setdefault(key,[]).append(f)
plan=[]
for key,files in groups.items():
 if len(files)<2:continue
 files.sort(key=lambda f:(-meta(f)['nlink'],str(f)));canonical=files[0]
 for target in files[1:]:
  if meta(target)['inode']==meta(canonical)['inode']:continue
  if meta(target)['nlink']!=1:continue
  assert equal(canonical,target)
  plan.append({'canonical':str(canonical),'target':str(target),'sha256':key[1],'before_canonical':meta(canonical),'before_target':meta(target),'byte_compare':True})
audit={'kind':'terminal_pure_python_capture_hardlink_deduplication','started_epoch':START,'authorized_scope_exact':[str(s) for s in SCOPES],'terminal_reports':proof,'activity_before':activity,'all_source_evidence_before':all_files,'candidate_count':len(candidates),'plan':plan,'expected_released_allocated_bytes':sum(x['before_target']['allocated_bytes'] for x in plan),'engine_calls':0,'original_report_log_edits':0}
save('dedup_audit_before.json',audit);print('PLAN',len(plan),'links; expected bytes',audit['expected_released_allocated_bytes'],flush=True)
operations=[]
try:
 for item in plan:
  canonical=Path(item['canonical']);target=Path(item['target']);linksafe(canonical);linksafe(target)
  current_activity=busy();assert not current_activity['hits'],current_activity['hits']
  t=meta(target);expected=item['before_target'];assert all(t[k]==expected[k] for k in CAS_KEYS),(target,'target CAS changed')
  c=meta(canonical);original=item['before_canonical'];assert all(c[k]==original[k] for k in ['size','mode','uid','gid','device','inode','mtime_ns']),(canonical,'canonical changed')
  assert sha(target)==item['sha256']==sha(canonical) and equal(canonical,target)
  tmp=target.with_name('.'+target.name+'.dedup-'+uuid.uuid4().hex);assert not tmp.exists()
  os.link(canonical,tmp,follow_symlinks=False)
  try:
   now=meta(target);assert all(now[k]==t[k] for k in CAS_KEYS),(target,'target final CAS changed')
   os.replace(tmp,target)
  finally:
   if tmp.exists():tmp.unlink()
  after=meta(target);assert after['inode']==meta(canonical)['inode'];assert sha(target)==item['sha256']
  operations.append({**item,'CAS_before_target':t,'CAS_before_canonical':c,'after_target':after,'after_canonical':meta(canonical),'released_allocated_bytes':t['allocated_bytes'],'restore':{'command':['python3',str(OUT/'restore_deduplicated_json.py'),'--receipt',str(OUT/'dedup_delete_receipt.json'),'--target',str(target)],'mtime_ns':t['mtime_ns'],'atime_ns':expected['atime_ns'],'mode':t['mode'],'uid':t['uid'],'gid':t['gid'],'ctime_restorable':False,'original_inode_restorable':False},'atomic_replace_epoch':time.time()})
  save('dedup_progress.json',{'operations_completed':operations})
 after_files=[]
 for before in all_files:
  f=Path(before['path']);m=meta(f);m['sha256']=sha(f);assert m['sha256']==before['sha256'] and m['size']==before['size'],f;after_files.append(m)
 save('dedup_audit_after.json',{'all_source_evidence_after':after_files,'all_paths_bytes_sha256_unchanged':True,'reports_logs_all_unchanged':True,'metadata_difference_policy':'Hardlink inode/ctime/nlink and target mtime/atime may change; exact before/after retained, no metadata identity claim','finished_epoch':time.time()})
 after_free=os.statvfs(ROOT).f_bavail*os.statvfs(ROOT).f_frsize
 receipt={'status':'completed','actual_started_epoch':START,'actual_finished_epoch':time.time(),'exact_authorized_scope':[str(s) for s in SCOPES],'candidate_count':len(candidates),'actual_hardlink_replacements':len(operations),'logical_evidence_paths_removed':0,'actual_released_allocated_bytes':sum(x['released_allocated_bytes'] for x in operations),'before_free_bytes':BEFORE_FREE,'after_free_bytes':after_free,'observed_filesystem_free_delta_bytes':after_free-BEFORE_FREE,'all_authorized_directory_file_bytes_and_SHA_unchanged':True,'reports_logs_unmodified':True,'metadata_identity_preserved':False,'protected_rootcache_media_currentfullrelease_sources_untouched':True,'operations':operations,'restore_script':str(OUT/'restore_deduplicated_json.py'),'engine_calls':0}
 save('dedup_delete_receipt.json',receipt);print('RESULT',json.dumps({k:v for k,v in receipt.items() if k!='operations'}),flush=True)
except BaseException as e:
 save('dedup_failed_receipt.json',{'status':'failed','error':repr(e),'operations_completed':operations,'epoch':time.time()});raise
