from pathlib import Path
import os,stat,json,time,hashlib,subprocess
ROOT=Path('/workspace/gunman-rush');RUN=ROOT/'build/level_autonomy/golden/run_zxlpc7gu';PROJECT=RUN/'frozen_v9/project';CACHE=PROJECT/'.godot';OUT=ROOT/'build/region_production_v3/storage_cleanup_final05'
assert subprocess.run(['git','check-ignore','-q',str(OUT)],cwd=ROOT).returncode==0
assert CACHE!=ROOT/'.godot' and CACHE.is_relative_to(ROOT/'build') and 'run_mzfl1hrz' not in str(CACHE)
assert json.loads((RUN/'receipt.json').read_text())['status']=='passed'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while b:=f.read(1024*1024):h.update(b)
 return h.hexdigest()
def meta(p):
 s=p.lstat();return {'path':str(p),'size':s.st_size,'allocated_bytes':s.st_blocks*512,'mode':s.st_mode,'uid':s.st_uid,'gid':s.st_gid,'device':s.st_dev,'inode':s.st_ino,'nlink':s.st_nlink,'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns}
def inventory(root,exclude_cache=False):
 rows=[]
 for folder,ds,fs in os.walk(root,followlinks=False):
  assert not any((Path(folder)/d).is_symlink() for d in ds)
  if exclude_cache and '.godot' in ds:ds.remove('.godot')
  for n in fs:
   f=Path(folder)/n;assert not f.is_symlink();m=meta(f);assert stat.S_ISREG(m['mode']);m['sha256']=sha(f);rows.append(m)
 return sorted(rows,key=lambda x:x['path'])
def busy():
 own={os.getpid()};p=os.getpid()
 while p>1:
  try:p=int(Path('/proc',str(p),'stat').read_text().split(') ',1)[1].split()[1]);own.add(p)
  except (FileNotFoundError,ProcessLookupError):break
 hits=[]
 for proc in Path('/proc').iterdir():
  if not proc.name.isdigit() or int(proc.name) in own:continue
  try:
   if (proc/'stat').read_text().split(') ',1)[1].split()[0]=='Z':continue
   cmd=(proc/'cmdline').read_bytes().decode(errors='replace');parts=[str(RUN),RUN.relative_to(ROOT).as_posix(),'run_zxlpc7gu']
   if any(x in cmd for x in parts):hits.append({'pid':int(proc.name),'reason':'run reference in command'})
   for name in ['cwd']:
    try:
     value=os.readlink(proc/name)
     if value==str(RUN) or value.startswith(str(RUN)+'/'):hits.append({'pid':int(proc.name),'reason':name,'path':value})
    except PermissionError:pass
   try:
    for fd in (proc/'fd').iterdir():
     try:value=os.readlink(fd)
     except (FileNotFoundError,PermissionError):continue
     if value==str(RUN) or value.startswith(str(RUN)+'/'):hits.append({'pid':int(proc.name),'reason':'open descriptor','path':value})
   except PermissionError:pass
  except (FileNotFoundError,ProcessLookupError,PermissionError):continue
 return hits
assert not busy(),'Active run reference'
assert (PROJECT/'project.godot').is_file() and any((PROJECT/'scripts').rglob('*.gd')) and any((PROJECT/'assets').rglob('*.png'))
assert not subprocess.check_output(['git','ls-files','--',str(CACHE)],cwd=ROOT,text=True)
cache=inventory(CACHE);assert all(x['nlink']==1 for x in cache),'Shared inode cache protected'
source=inventory(PROJECT,True);evidence=[{'path':str(p),'sha256':sha(p)} for p in RUN.iterdir() if p.is_file()]
free_before=os.statvfs(ROOT).f_bavail*os.statvfs(ROOT).f_frsize
before={'actual_epoch':time.time(),'cache':str(CACHE),'project':str(PROJECT),'terminal_receipt_sha256':sha(RUN/'receipt.json'),'passed_terminal':True,'recent_cache_exception':'Root explicitly authorizes this just-completed passed run only; original2h protection remains for all other runs','cache_files_full_SHA_metadata':cache,'source_assets_before':source,'run_evidence_before':evidence,'tracked_cache_files':0,'active_process_references':busy(),'root_cache_protected':str(ROOT/'.godot'),'active_spatial_protected':'build/plains_redesign/spatial/run_mzfl1hrz','rebuild_command':['Godot4.7.2','--headless','--editor','--quit','--path',str(PROJECT)],'engine_executed':False}
assert not before['active_process_references'];(OUT/'cache_audit_before.json').write_text(json.dumps(before,indent=2)+'\n')
# Verify every cache object immediately before mutation; no content can be removed after a mismatch.
current=inventory(CACHE);assert current==cache,'Cache changed during audit'
assert not busy(),'Run became active'
for row in cache:
 p=Path(row['path']);now=meta(p);assert all(now[k]==row[k] for k in ['size','mode','uid','gid','device','inode','nlink','mtime_ns','ctime_ns']) and sha(p)==row['sha256'];p.unlink()
for folder,dirs,files in os.walk(CACHE,topdown=False):
 assert not files;Path(folder).rmdir()
after=inventory(PROJECT,True);assert [(x['path'],x['sha256']) for x in source]==[(x['path'],x['sha256']) for x in after]
for x in evidence:assert sha(Path(x['path']))==x['sha256']
free_after=os.statvfs(ROOT).f_bavail*os.statvfs(ROOT).f_frsize
receipt={'status':'completed','cache_deleted':str(CACHE),'actual_deleted_cache_files':len(cache),'actual_released_allocated_bytes':sum(x['allocated_bytes'] for x in cache),'free_before_bytes':free_before,'free_after_bytes':free_after,'observed_free_delta_bytes':free_after-free_before,'all_project_source_originalPNG_SHA_unchanged':True,'all_run_receipt_JSON_logs_SHA_unchanged':True,'all_file_CAS_checks_passed':True,'root_cache_and_active_spatial_untouched':True,'engine_calls':0,'rebuild_command':before['rebuild_command'],'audit_before_sha256':sha(OUT/'cache_audit_before.json'),'finished_epoch':time.time()}
(OUT/'cache_delete_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');(OUT/'source_evidence_after.json').write_text(json.dumps({'source_assets_after':after,'run_evidence_after':evidence},indent=2)+'\n');print(json.dumps(receipt,indent=2))
