"""Restore independent file + original mode/owner/atime/mtime; inode/ctime cannot be restored."""
import argparse,json,os,hashlib,shutil,uuid
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--receipt',required=True);p.add_argument('--target',required=True);a=p.parse_args();r=json.loads(Path(a.receipt).read_text());row=next(x for x in r['operations'] if x['target']==a.target);target=Path(a.target);original=row['before_target'];assert hashlib.sha256(target.read_bytes()).hexdigest()==row['sha256'];tmp=target.with_name('.'+target.name+'.restore-'+uuid.uuid4().hex)
with target.open('rb') as source,tmp.open('xb') as dest:shutil.copyfileobj(source,dest,1024*1024);dest.flush();os.fsync(dest.fileno())
os.chmod(tmp,original['mode'] & 0o7777);os.chown(tmp,original['uid'],original['gid']);assert hashlib.sha256(tmp.read_bytes()).hexdigest()==row['sha256'];os.utime(tmp,ns=(original['atime_ns'],original['mtime_ns']));os.replace(tmp,target);print('Restored independent file and original mode/owner/atime/mtime:',target,'; original inode/ctime are not restorable')
