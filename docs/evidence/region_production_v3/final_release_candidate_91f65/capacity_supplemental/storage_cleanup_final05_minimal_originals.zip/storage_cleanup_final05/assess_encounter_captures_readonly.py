from pathlib import Path
import os,json,stat,time,hashlib
ROOT=Path('/workspace/gunman-rush');BASE=ROOT/'build/verification/plains-encounter';OUT=ROOT/'build/region_production_v3/storage_cleanup_final05'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while b:=f.read(1024*1024):h.update(b)
 return h.hexdigest()
def equal(a,b):
 with a.open('rb') as f,b.open('rb') as g:
  while True:
   x=f.read(1024*1024);y=g.read(1024*1024)
   if x!=y:return False
   if not x:return True
active=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  if (p/'stat').read_text().split(') ',1)[1].split()[0]=='Z':continue
  args=(p/'cmdline').read_bytes().decode(errors='replace')
  if str(BASE) in args or 'build/verification/plains-encounter/run_' in args:active.append(int(p.name))
 except (FileNotFoundError,PermissionError,ProcessLookupError):continue
rows=[];excluded=[];groups={}
for run in sorted(BASE.glob('run_*')):
 receipt=run/'receipt.json'
 if run.is_symlink() or not receipt.is_file():excluded.append({'path':str(run),'reason':'missing terminal receipt or symlink'});continue
 d=json.loads(receipt.read_text())
 if d.get('status') not in ['passed','failed']:excluded.append({'path':str(run),'reason':'nonterminal receipt'});continue
 for folder,ds,fs in os.walk(run,followlinks=False):
  ds[:]=[x for x in ds if x not in ['.godot','.git'] and not (Path(folder)/x).is_symlink()]
  if 'capture.json' not in fs:continue
  p=Path(folder)/'capture.json'
  if p.is_symlink():continue
  s=p.stat();digest=sha(p);r={'path':str(p),'size':s.st_size,'allocated_bytes':s.st_blocks*512,'mode':s.st_mode,'uid':s.st_uid,'gid':s.st_gid,'device':s.st_dev,'inode':s.st_ino,'nlink':s.st_nlink,'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns,'sha256':digest,'run_status':d['status'],'receipt_sha256':sha(receipt)};rows.append(r);groups.setdefault((s.st_size,digest,s.st_mode,s.st_uid,s.st_gid,s.st_dev),[]).append(r)
proposals=[]
for k,items in groups.items():
 inode_groups={}
 for r in items:inode_groups.setdefault((r['device'],r['inode']),[]).append(r)
 if len(inode_groups)<2:continue
 items.sort(key=lambda r:(-r['nlink'],r['path']));canonical=items[0];targets=[]
 for r in items[1:]:
  if r['inode']==canonical['inode'] or r['nlink']!=1:continue
  if equal(Path(canonical['path']),Path(r['path'])):targets.append(r)
 if targets:proposals.append({'canonical':canonical,'targets_nlink1_only':targets,'byte_comparison':True,'potential_release_bytes':sum(r['allocated_bytes'] for r in targets)})
report={'read_only':True,'actual_epoch':time.time(),'scope':str(BASE),'files_hashed':len(rows),'source_bytes_modified':0,'hardlinks_created':0,'active_reference_pids_observed':active,'all_capture_metadata_SHA':rows,'excluded':excluded,'proposals':proposals,'potential_release_bytes_nlink1_only':sum(x['potential_release_bytes'] for x in proposals),'intentional_different_bytes_never_merged':True,'limits':'No files modified or linked; this is a proposal requiring explicit Root path authorization. Existing nlink2 duplicate pairs excluded as targets, even where full SHA matches other inodes.'}
(OUT/'encounter_capture_dedup_proposal.json').write_text(json.dumps(report,indent=2)+'\n');print('READONLY',report['files_hashed'],'captures; proposals',len(proposals),'targets',sum(len(x['targets_nlink1_only']) for x in proposals),'potentialbytes',report['potential_release_bytes_nlink1_only']);
for x in proposals:print(x['potential_release_bytes'],x['canonical']['path'],'TARGETS',[r['path'] for r in x['targets_nlink1_only']])
