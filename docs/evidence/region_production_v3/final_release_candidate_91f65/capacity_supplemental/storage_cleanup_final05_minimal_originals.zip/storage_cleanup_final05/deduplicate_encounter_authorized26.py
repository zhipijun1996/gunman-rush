from pathlib import Path
import os,stat,time,json,hashlib,subprocess,uuid
ROOT=Path('/workspace/gunman-rush');OUT=ROOT/'build/region_production_v3/storage_cleanup_final05';BASE=ROOT/'build/verification/plains-encounter';PROPOSAL=OUT/'encounter_capture_dedup_proposal.json';D=json.loads(PROPOSAL.read_text());PLAN=[]
for group in D['proposals']:
 for target in group['targets_nlink1_only']:PLAN.append({'canonical':group['canonical'],'target':target})
assert len(PLAN)==26 and all('run_iagykdbc' not in x[k]['path'] for x in PLAN for k in ['canonical','target'])
FILES={x[k]['path'] for x in PLAN for k in ['canonical','target']};RUNS={BASE/Path(p).relative_to(BASE).parts[0] for p in FILES};CAS=['size','mode','uid','gid','device','inode','nlink','mtime_ns','ctime_ns']
def meta(p):
 s=p.lstat();assert stat.S_ISREG(s.st_mode);return {'path':str(p),'size':s.st_size,'allocated_bytes':s.st_blocks*512,'mode':s.st_mode,'uid':s.st_uid,'gid':s.st_gid,'device':s.st_dev,'inode':s.st_ino,'nlink':s.st_nlink,'atime_ns':s.st_atime_ns,'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns}
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while data:=f.read(1024*1024):h.update(data)
 return h.hexdigest()
def equal(a,b):
 with a.open('rb') as f,b.open('rb') as g:
  while True:
   x=f.read(1024*1024);y=g.read(1024*1024)
   if x!=y:return False
   if not x:return True
def busy():
 own={os.getpid()};pid=os.getpid()
 while pid>1:
  try:pid=int(Path('/proc',str(pid),'stat').read_text().split(') ',1)[1].split()[1]);own.add(pid)
  except (FileNotFoundError,ProcessLookupError):break
 hits=[]
 for p in Path('/proc').iterdir():
  if not p.name.isdigit() or int(p.name) in own:continue
  try:
   if (p/'stat').read_text().split(') ',1)[1].split()[0]=='Z':continue
   cmd=(p/'cmdline').read_bytes().decode(errors='replace')
   if any(str(run) in cmd or run.relative_to(ROOT).as_posix() in cmd for run in RUNS):hits.append({'pid':int(p.name),'kind':'command_reference'})
   try:
    cwd=os.readlink(p/'cwd')
    if any(cwd==str(r) or cwd.startswith(str(r)+'/') for r in RUNS):hits.append({'pid':int(p.name),'kind':'cwd','path':cwd})
   except PermissionError:pass
   try:
    for fd in (p/'fd').iterdir():
     try:value=os.readlink(fd)
     except (FileNotFoundError,PermissionError):continue
     if any(value==str(r) or value.startswith(str(r)+'/') for r in RUNS):hits.append({'pid':int(p.name),'kind':'fd','path':value})
   except PermissionError:pass
  except (FileNotFoundError,ProcessLookupError,PermissionError):continue
 return hits

def inventory():
 rows=[];memo={}
 for run in sorted(RUNS):
  assert run.is_dir() and not run.is_symlink();assert json.loads((run/'receipt.json').read_text())['status'] in ['passed','failed']
  for folder,ds,fs in os.walk(run,followlinks=False):
   assert not any((Path(folder)/d).is_symlink() for d in ds),'Symlink in terminal project'
   for name in fs:
    p=Path(folder)/name;assert not p.is_symlink();m=meta(p);key=(m['device'],m['inode'],m['size'],m['mtime_ns'],m['ctime_ns']);digest=memo.get(key)
    if digest is None:digest=sha(p);memo[key]=digest
    rows.append({**m,'sha256':digest})
 return sorted(rows,key=lambda x:x['path'])
def save(name,data):(OUT/name).write_text(json.dumps(data,indent=2)+'\n')
assert not busy(),'Active historical candidate';assert not (OUT/'encounter_dedup_receipt.json').exists()
START=time.time();FREE=os.statvfs(ROOT).f_bavail*os.statvfs(ROOT).f_frsize;BEFORE=inventory();lookup={r['path']:r for r in BEFORE}
for row in PLAN:
 c=row['canonical'];t=row['target'];assert all(lookup[t['path']][k]==t[k] for k in CAS),t['path'];assert lookup[c['path']]['sha256']==c['sha256']==t['sha256'];assert t['nlink']==1
save('encounter_dedup_audit_before.json',{'actual_epoch':START,'authorization':'Root explicit26 exact proposal targets only','proposal_sha256':sha(PROPOSAL),'exact_plan':PLAN,'all_selected_terminal_run_files_before':BEFORE,'active_candidate_references':busy(),'active_iagykdbc_protected':True,'root_cache_protected':True})
OPS=[]
try:
 for row in PLAN:
  c=Path(row['canonical']['path']);t=Path(row['target']['path']);old=row['target'];before_c=meta(c);before_t=meta(t)
  assert not busy();assert all(before_t[k]==old[k] for k in CAS);assert before_t['nlink']==1
  assert all(before_c[k]==before_t[k] for k in ['size','mode','uid','gid','device']) and sha(c)==sha(t)==old['sha256'] and equal(c,t)
  tmp=t.with_name('.'+t.name+'.dedup-'+uuid.uuid4().hex);os.link(c,tmp,follow_symlinks=False)
  try:
   now=meta(t);assert all(now[k]==before_t[k] for k in CAS);os.replace(tmp,t)
  finally:
   if tmp.exists():tmp.unlink()
  assert sha(t)==old['sha256'] and meta(t)['inode']==meta(c)['inode']
  OPS.append({'canonical':str(c),'target':str(t),'sha256':old['sha256'],'before_canonical':before_c,'before_target':before_t,'after_canonical':meta(c),'after_target':meta(t),'released_allocated_bytes':before_t['allocated_bytes'],'restore_command':['python3',str(OUT/'restore_deduplicated_json.py'),'--receipt',str(OUT/'encounter_dedup_receipt.json'),'--target',str(t)],'original_mtime_ns':before_t['mtime_ns'],'ctime_original_inode_restorable':False})
  save('encounter_dedup_progress.json',{'operations':OPS})
 AFTER=inventory();assert [(x['path'],x['sha256']) for x in BEFORE]==[(x['path'],x['sha256']) for x in AFTER]
 save('encounter_dedup_audit_after.json',{'all_selected_terminal_run_files_after':AFTER,'all_paths_and_bytes_SHA_unchanged':True,'finished_epoch':time.time()})
 finalfree=os.statvfs(ROOT).f_bavail*os.statvfs(ROOT).f_frsize;result={'status':'completed','actual_started_epoch':START,'finished_epoch':time.time(),'actual_hardlink_replacements':len(OPS),'actual_released_allocated_bytes':sum(x['released_allocated_bytes'] for x in OPS),'free_before_bytes':FREE,'free_after_bytes':finalfree,'observed_free_delta_bytes':finalfree-FREE,'selected_terminal_runs':len(RUNS),'all_selected_terminal_files_checked':len(BEFORE),'all_logical_paths_bytes_SHA_unchanged':True,'metadata_identity_preserved':False,'original_mtime_mode_uid_gid_and_restore_recorded':True,'root_cache_active_iagykdbc_sources_docs_untouched':True,'logical_evidence_paths_removed':0,'engine_calls':0,'operations':OPS};save('encounter_dedup_receipt.json',result);print(json.dumps({k:v for k,v in result.items() if k!='operations'},indent=2),flush=True)
except BaseException as e:save('encounter_dedup_failed.json',{'error':repr(e),'operations':OPS,'epoch':time.time()});raise
