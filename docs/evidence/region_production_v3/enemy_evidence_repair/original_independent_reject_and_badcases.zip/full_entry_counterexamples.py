"""Whole actual Python main entry; explicitly simulated process transport, NEVER native evidence."""
import contextlib,io,json,pathlib,sys,time,types
from unittest.mock import patch
ROOT=pathlib.Path('/workspace/gunman-v3-enemy');sys.path.insert(0,str(ROOT/'tools'))
import run_root_bell_formal as rf
OUT=ROOT/'build/region_production_v3/independent/enemy_encounter_v2'
SIMROOT=ROOT/'build/root_bell/INDEPENDENT_SIMULATION_NOT_NATIVE';SIMROOT.mkdir(exist_ok=True)
(SIMROOT/'SCOPE.txt').write_text('Explicit pure-Python fault injection at subprocess boundary. No Godot or media encoding executed. All captures are copied/modified historical data, not new native evidence.\n')
results={};original_run=rf.subprocess.run
for name in ['all_return_motion_erased','all_real_resource_receipts_replaced_by_unbound_fake','coherent_ghost_root_identity_not_in_manifest']:
 candidate=json.loads((OUT/(name+'.json')).read_text());folder=SIMROOT/(name+'_'+str(time.time_ns()))
 def fake_run(command,*args,**kwargs):
  if command[:2]==['bash','tools/godot.sh']:
   output_arg=next(a for a in command if a.startswith('--output=res://'))
   capture=ROOT/output_arg.removeprefix('--output=res://');capture.write_text(json.dumps(candidate)+'\n')
   (capture.parent/'SIMULATION_NOT_NATIVE.json').write_text(json.dumps({'scope':'Actual Python main executed with synthetic process transport only; NOT native Godot execution','counterexample':str((OUT/(name+'.json')).relative_to(ROOT))})+'\n')
   log='INDEPENDENT PURE-PYTHON FAULT INJECTION: THIS IS NOT A NEW NATIVE PROCESS\nLEVEL FORMAL CAPTURE: '+str(len(candidate['frames']))+' frames, '+str(len(candidate['edges']))+' edges, outcome=route_target_reached, capture_errors=0\n'
   kwargs['stdout'].write(log);kwargs['stdout'].flush()
   return types.SimpleNamespace(returncode=0)
  return original_run(command,*args,**kwargs)
 output=io.StringIO()
 try:
  with patch.object(sys,'argv',['run_root_bell_formal.py','--output-dir',str(folder.relative_to(ROOT))]),patch.object(rf.subprocess,'run',side_effect=fake_run),contextlib.redirect_stdout(output):rf.main()
  result={'accepted':True,'entry_status':json.loads((folder/'report.json').read_text())['status']}
 except Exception as e:result={'accepted':False,'error':type(e).__name__+': '+str(e)}
 finally:
  if (folder/'report.json').exists():
   report=json.loads((folder/'report.json').read_text());report['scope']='INDEPENDENT SYNTHETIC PROCESS TRANSPORT COUNTEREXAMPLE ONLY — NOT NATIVE EXECUTION';report['independent_simulation']=True;(folder/'report.json').write_text(json.dumps(report,indent=2)+'\n')
 result.update(scope='Full Python main validation only; producer transport was explicitly simulated and must never count as fresh native/content evidence',simulation_folder=str(folder.relative_to(ROOT)),stdout=output.getvalue(),consumer_sha256=rf.sha(pathlib.Path(rf.__file__)))
 results[name]=result;print(name,'FULL ENTRY ACCEPTED' if result['accepted'] else 'FULL ENTRY REJECTED')
(OUT/'full_entry_counterexample_results.json').write_text(json.dumps(results,indent=2)+'\n')
