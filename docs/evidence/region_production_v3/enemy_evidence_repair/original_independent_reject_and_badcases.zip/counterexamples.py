"""Independent data-only rejection probes; not a native engine execution."""
import copy,json,pathlib,sys,hashlib
ROOT=pathlib.Path('/workspace/gunman-v3-enemy');sys.path.insert(0,str(ROOT/'tools'))
import run_root_bell_formal as rf
OUT=ROOT/'build/region_production_v3/independent/enemy_encounter_v2'
base=json.loads((OUT/'original_movie02_capture.json').read_text());results={}
def consume(name,data):
 p=OUT/(name+'.json');p.write_text(json.dumps(data,separators=(',',':'))+'\n')
 try:results[name]={'accepted':True,'consumer_observed':rf.validate(data)}
 except Exception as e:results[name]={'accepted':False,'error':type(e).__name__+': '+str(e)}
 results[name].update(capture_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),scope='Independent copied native-trace mutation, not native execution')
consume('baseline',base)
x=copy.deepcopy(base);case=x['root_bell_cases'][-1];first=x['frames'][case['start_tick']-1]
for f in x['frames'][case['start_tick']-1:]:
 f['position']=copy.deepcopy(first['position']);f['velocity']=[0,0];f['displacement']=0;f['axis']=0;f['input_requests']=[];f['accepted_events']=[];f['grounded']=True;f['collisions']=copy.deepcopy(first['collisions'])
case['position']=copy.deepcopy(first['position'])
for e in x['events']:
 if e['kind']=='root_case_end' and e.get('id')==case['id']:e['position']=copy.deepcopy(first['position'])
x['events']=[e for e in x['events'] if e['tick']<case['start_tick'] or e['kind'] in ('root_case_begin','root_case_end')]
x['resource_receipts']=[r for r in x['resource_receipts'] if r['tick']<case['start_tick']]
consume('all_return_motion_erased',x)
x=copy.deepcopy(base);x['resource_receipts']=[{'tick':c['start_tick']+1,'operation':'consume','amount_applied':-.01,'event_id':'foreign-not-the-real-shot','epoch':999,'current':10000000,'capacity':1} for c in x['root_bell_cases'] if c['id'].startswith('real_projectile')];consume('all_real_resource_receipts_replaced_by_unbound_fake',x)
x=copy.deepcopy(base)
for f in x['frames']:f['shot_energy']=10000000
consume('frame_budget_above_actual_capacity',x)
x=copy.deepcopy(base);case=x['root_bell_cases'][-1]
for f in x['frames'][case['start_tick']-1:]:f['health']=0
case['health']=0
for e in x['events']:
 if e['kind']=='root_case_end' and e.get('id')==case['id']:e['health']=0
consume('player_dead_during_complete_return',x)
x=copy.deepcopy(base);real=x['root_bell_identity'];alias='ghost-absent-from-actual-manifest';x['root_bell_identity']=alias;x['manifest']['root_bell_admission']['id']=alias
for f in x['frames']:f['root_bell']['id']=alias
for e in x['events']:
 for k in ['enemy','target']:
  if e.get(k)==real:e[k]=alias
for c in x['root_bell_cases']:
 if 'actual_admission' in c:c['actual_admission']['id']=alias
consume('coherent_ghost_root_identity_not_in_manifest',x)
results['consumer_sha256']=hashlib.sha256(pathlib.Path(rf.__file__).read_bytes()).hexdigest()
results['original_27_refusals']=rf.tamper(base)
(OUT/'counterexample_results.json').write_text(json.dumps(results,indent=2)+'\n')
for name,v in results.items():
 if isinstance(v,dict):print(name,'ACCEPTED' if v['accepted'] else 'REJECTED',v.get('error',''))
print('original_negative_count',len(results['original_27_refusals']))
