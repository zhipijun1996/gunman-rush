# V3-ENCOUNTER-V2-01 — actual independent review

**REJECT current G0/G1 candidate pending proof-consumer fixes.** Reviewer `/root/v3_independent_engineering` is distinct from actual implementer `/root/v3_enemy_ecology`. Actual request `b47202bb8002b6719b71cecc8ab6efb5557f18033ffb15dc372a20fa072b15ce`, nonce `abe97272b9994433becbd06615144d62`, frozen source digest `3e330d64396362d839db306d8eb0f3b689d69344b47a74eb9a76988bbb5fccd8` and all four professional Skill hashes were checked. Lease was live and not revoked. Reviewed Python consumer SHA is `23f880b5554033e40952ab9201b2825257e4c08a9abdc66326d62f6fc1a6bb63`.

The observed new game content is not rejected as a demonstrated gameplay failure. The concrete blocking defects are in the new admission evidence consumer: it accepts erased essential traversal and false resource/entity evidence while claiming all fifteen cases passed. Baseline native data passing and the original27 negatives do not repair these actual counterexamples.

## V3-ENCOUNTER-V2-INDEP-001 — essential return reduced to self-reported flags

High, G1 technical proof. Location `tools/run_root_bell_formal.py::validate`, case loop near line59 and final edge test near line92.

`all_return_motion_erased.json` starts from the real movie02 trace. During all810 final-case ticks4336–5145, the copied trace holds the player stationary at its first bank position, zeroes motion/input/accepted-event fields, retains actual rooted enemy/world clocks, removes later shot/resource events, and updates the copied case/end-event position. The two original edge `reached=true` flags remain. Actual `validate()` accepts with fifteen cases/5145 frames/nine pulses. The complete actual Python `main()` also accepts this data when its process transport alone is explicitly simulated. No real engine is run by this fault injection.

A separate `player_dead_during_complete_return.json` sets player HP0 throughout the final return and updates the case/end-event health, while keeping the claimed success. The semantic validator also accepts. `frame_budget_above_actual_capacity.json` sets recorded energy to10000000 and is accepted as well.

Expected: derive required forward/reverse terminal/port crossings and supported return from the real Manifest/module geometry and actual frame intervals; bind reached/terminal/case summaries to that evidence. Validate positive bounded player health, legal resource ranges and relevant actual accepted movement/input chain. Do not replace these with a different threshold or delete existing assertions.

## V3-ENCOUNTER-V2-INDEP-002 — resource and root identity are not causally bound

High, G1 technical proof. Location `tools/run_root_bell_formal.py::validate`, admission/identity setup near line36 and real-projectile checks near line78–84.

`all_real_resource_receipts_replaced_by_unbound_fake.json` erases every original resource receipt and supplies only three fake negative consumes, one in each shooting case: foreign event ID, epoch999, capacity1/current10000000, amount_applied−0.01. It retains the actual recorded shots/hits and their case chronology. The validator accepts because it tests only whether some negative consume occurred between case start and hit. Full Python main also returns passed with the explicitly simulated producer transport. Expected: exact accepted shot event/resource/session/epoch identity, actual debit amount and before/after/capacity accounting from the real resource contract, preserving legitimate clamps and other transactions.

`coherent_ghost_root_identity_not_in_manifest.json` changes admission/root-frame/event target identity consistently to `ghost-absent-from-actual-manifest`; actual Manifest enemy inventory contains no such actor. Validator and full Python main still accept. Expected: derive the actual Root Bell actor/definition/home from the real Manifest, require its unique expected formal instance, and bind event targets and observed snapshots to it. Shared suffix or a self-reported admission ID is insufficient.

## Actual execution and reproducibility

- `counterexamples.py` independently accepted the real positive trace, reproduced all five bad variants above, and reran every original27 mutation rejection unchanged.
- `full_entry_counterexamples.py` exercised the actual complete Python main entry for erased return, false resource ledger and ghost identity. All three returned passed. Its subprocess transport is explicitly simulated; all generated folders/logs/reports are labeled `INDEPENDENT_SIMULATION_NOT_NATIVE`. This tests the consumer, not Godot, formal gameplay, or process authenticity. See `full_entry_counterexample_results.json`; synthetic output is under `build/root_bell/INDEPENDENT_SIMULATION_NOT_NATIVE/`.
- Review changed no production source, original native trace, movie, old assertion, quality record or tracked file. All mutations are review-owned ignored copies. The source digest remained identical through the review.

## Positives independently checked, without broadening acceptance

All42 portable index artifacts match recorded bytes/SHA. Current-source native movie/headless/fresh165/audit receipts have equal source-before/after and exactly match the current972-file closure. All31 modified source files inside the frozen byte ZIP match the current tree; its32nd entry is the explanatory source_manifest, not a missing production source.

The v1 placement class, RootBellBehavior, Definition, original165 tests/runner and original body master remain byte-identical to the prior audited receipt. Existing raw original40 manifest strings remain; the recorded actual current audit reports40/40 legacy byte equality, only1/40 qualified maps (intro0/20, advanced1/20, one root), all default gates false, ten physical refusals. Actual old map2 captured-state→detached restore→new pilot loader evidence preserves v10 hash `cef733dea0b6b90966f5d5c41528887b56447349cf7fe4035dcda985d5e67ae8`,21 actors and zero Root Bell. These are inspected native receipts/source, not engine runs repeated by this reviewer.

The actual new native trace is5145ticks/fifteen cases/nine pulses; original movie SHA, capture SHA and runtime log SHA independently match. Fresh165/41content+9receipt refusals and controller core `ALL TESTS: 5676 assertions, 0 failures` are retained actual producer evidence, not independent reruns. Their unchanged old tests cannot cover the newly introduced semantic consumer holes.

Physical v2 is explicitly versioned v11; the ordinary generator defaults to legacy_v10 and PRODUCTION_ADMITTED remains false. It retains560 minimum and current620 double_gear geometry class, two150px observation/retreat spans, supported floor and adjacent hazard exclusions. No Seed whitelist or core Motor/weapon/resource/RNG/save-rule change was found in the reviewed slice. This single physical candidate does not establish ecological breadth or default-pool completion.

## Actual pixel observation and limits

This reviewer actually opened all four1280×720 portable decoded frames, zero-based2669,2703,2784,4029 (44.483s/45.05s/46.4s/67.15s video time). They visibly show a clear fixed ground mark behind the player, a separate hand-drawn rooted pulse cluster, a jump above the live body, and a single hurt body during projectile interruption. The burst cluster is visually separate from the actor rather than a full second-body crossfade. Four static frames do not establish onset/recovery continuity, normal-speed readability, complete animation/audio quality or commercial G2.

No film playback, audio listening, device session, user approval, new image generation, Godot, ffmpeg or heavy native suite occurred in this review. The original failed ferry movie before Root Bell is preserved; the newer camp/stair approach is a changed legitimate strategy, not same-condition content optimization. Current rendered exit warnings10 ObjectDB/4 resources and compatibility warnings20/17 remain explicit; lifecycle cleanup/G3 is unverified. The earlier two original G1 failed full-frame sequences remain irrecoverably lost as already recorded; new preserved formal failures do not restore that historical loss.

The controller requests only G0/G1 stage. This REJECT does not demand commercial G2/G5, player, target-device or final default promotion evidence prematurely. It requires that the implemented G1 proof consumer reject the concrete false essential-case evidence above. Any further repair/review must remain within the parent budget and use a fresh source-bound request; no extra creative round or default admission is authorized by this report.
