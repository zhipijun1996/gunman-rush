from pathlib import Path
import subprocess,json,os,time,sys
ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT/'tools'))
import level_formal
name=sys.argv[1];script=sys.argv[2];output=ROOT/'build/region_production_v3/root_bell_run_replay_fix'/name
command=['bash','tools/godot.sh','--headless','--fixed-fps','60','--path','.', '--script',script]
if 'root_bell_formal_runner' in script:command+=['--','--output=res://'+str(output.with_suffix('.json').relative_to(ROOT))]
env=os.environ.copy();env.update(GODOT_BIN=str(ROOT/'build/region_production_v3/godot_locked.sh'),LP_NUM_THREADS='1',OMP_NUM_THREADS='1')
before=level_formal.source_files();start=time.time();inv={'argv':command,'started_unix':start,'source_before':before,'status':'running','scope':'Actual native formal RunManifest contract regression, not input-only traversal/combat/device claim'}
invpath=output.with_suffix('.invocation.json');assert not invpath.exists();invpath.write_text(json.dumps(inv,indent=2)+'\n')
with output.with_suffix('.log').open('wb') as f:
 p=subprocess.Popen(command,stdout=f,stderr=subprocess.STDOUT,cwd=ROOT,env=env,start_new_session=True)
 inv['actual_process_group_leader']=p.pid;invpath.write_text(json.dumps(inv,indent=2)+'\n')
 while p.poll() is None:
  text=output.with_suffix('.log').read_text(errors='replace')
  if 'SCRIPT ERROR:' in text or 'Parse Error:' in text or time.time()-start>180:
   import signal
   os.killpg(p.pid,signal.SIGTERM);p.wait(timeout=10);break
  time.sleep(.1)
inv.update(finished_unix=time.time(),exit_code=p.returncode,source_after=level_formal.source_files());inv['source_stable']=before==inv['source_after'];inv['status']='passed' if p.returncode==0 and inv['source_stable'] else 'failed';invpath.write_text(json.dumps(inv,indent=2)+'\n');print(json.dumps({k:v for k,v in inv.items() if not k.startswith('source_')}));print(output.with_suffix('.log').read_text()[-5000:])
