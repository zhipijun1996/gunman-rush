extends SceneTree
func _initialize() -> void:
	var data: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://build/region_production_v3/root_bell_run_replay_fix/audit_02.json"))
	for mode: String in ["v2", "legacy_v10"]:
		var stored: Dictionary = data.run_manifest_replay.actual_snapshots[mode]
		var result := RunManifest.from_snapshot(stored)
		print("REPLAY DIAG ", mode, " accepted=", result != null, " identical_input_representation=", result != null and result.canonical_json() == JSON.stringify(stored, "", true))
	quit(0)
