
func run_manifest_replay(tree: SceneTree) -> Dictionary:
	# Replay contract fixture: real DemoApp generation/recording and the existing
	# explicit mini-Boss outcome fixture. No traversal/combat/device claim.
	var failures: Array = []
	var cases: Array = []
	var negatives: Array = []
	var snapshots: Dictionary = {}
	for mode: String in ["v2", "legacy_v10"]:
		var app := DemoApp.new()
		app.meta_persistence_enabled = false
		tree.root.add_child(app)
		for child: Node in app.get_children():
			if child is GameAudio: child.volume = 0
		var started := app.start_plains("v3-root-bell-pilot-1")
		# _load_stage is deferred; pin the explicit legacy fixture before it runs.
		if mode == "legacy_v10": app._root_bell_run_mode = "legacy_v10"
		var ready := started and await wait_map(tree, app, 1)
		if not ready:
			failures.append(mode + "/first_map_not_ready")
		else:
			var first_native := app.director.manifest.snapshot()
			var first_json: Dictionary = JSON.parse_string(app.director.manifest.canonical_json())
			var first_native_replay := RunManifest.from_snapshot(first_native)
			var first_json_replay := RunManifest.from_snapshot(first_json)
			var first_ok := first_native_replay != null and first_json_replay != null
			if first_ok: first_ok = first_native_replay.canonical_json() == app.director.manifest.canonical_json() and first_json_replay.canonical_json() == app.director.manifest.canonical_json()
			cases.append({"mode": mode, "case": "first_map_native_json_exact", "passed": first_ok, "version": first_native.versions.generated_layout})
			if not first_ok: failures.append(mode + "/first_map_roundtrip")
			# Explicit lawful Definition fixture; this is not a reward acquisition proof.
			var item_added := app.build.add_item(&"run_manifest_replay_fixture", load("res://resources/items/brake_boots.tres"))
			var transitioned: bool = item_added and await load("res://tests/plains_campaign_fixture.gd").second_map(app, tree)
			if not transitioned:
				failures.append(mode + "/second_map_not_ready")
			else:
				var native := app.director.manifest.snapshot()
				var json_data: Dictionary = JSON.parse_string(app.director.manifest.canonical_json())
				var native_replay := RunManifest.from_snapshot(native)
				var json_replay := RunManifest.from_snapshot(json_data)
				var typed_items: Array = native.stages[1].outputs.capability_snapshot.items
				var has_string_name := typed_items.has(&"brake_boots") and typed_items.any(func(id: Variant) -> bool: return id is StringName)
				var roundtrip_ok := native_replay != null and json_replay != null and has_string_name
				if roundtrip_ok: roundtrip_ok = native_replay.canonical_json() == app.director.manifest.canonical_json() and json_replay.canonical_json() == app.director.manifest.canonical_json()
				var expected := PlainsRootBellEncounterV2.CONTENT_VERSION if mode == "v2" else PlainsRegionGenerator.VERSION
				var all_versions_match := str(native.versions.generated_layout) == expected and str(native.versions.encounters) == expected
				var regeneration_ok := true
				for entry: Dictionary in native.stages:
					var output: Dictionary = entry.outputs
					all_versions_match = all_versions_match and output.stage_generator.version == expected and output.enemy_layout.version == expected and output.generated_layout.version == expected
					var generator := PlainsRegionGenerator.new()
					generator.root_bell_mode = mode
					var regenerated := generator.generate(output.generated_layout.seed, RunManifest._region_tuning(output), false, "", output.generated_layout.difficulty)
					regeneration_ok = regeneration_ok and regenerated.ok and JSON.stringify(regenerated.manifest) == JSON.stringify(output.generated_layout)
				var root_count: int = native.stages[1].outputs.generated_layout.enemies.filter(func(e: Dictionary) -> bool: return e.behavior_id == "root_bell").size()
				var passed := roundtrip_ok and all_versions_match and regeneration_ok and root_count == (1 if mode == "v2" else 0)
				cases.append({"mode": mode, "case": "two_maps_native_json_modifier_and_exact_regeneration", "passed": passed, "native_StringName_item": has_string_name, "root_bell_count": root_count, "versions_match": all_versions_match, "regenerated_exact_manifest_strings": regeneration_ok})
				if not passed: failures.append(mode + "/two_map_replay")
				snapshots[mode] = json_data
		app.abandon_run()
		await tree.process_frame
		await tree.process_frame
		app.queue_free()
		await tree.process_frame
		await tree.process_frame
	if snapshots.has("v2"):
		for mutation: String in ["unknown_root_version", "mixed_root_versions", "mixed_stage_generator", "mixed_manifest_version", "mixed_enemy_version", "rehashed_enemy_position", "rehashed_root_bell_behavior", "unearned_resource_tuning"]:
			var data: Dictionary = snapshots.v2.duplicate(true)
			var output: Dictionary = data.stages[1].outputs
			if mutation == "unknown_root_version":
				data.versions.generated_layout = "plains-region-v999"
				data.versions.encounters = "plains-region-v999"
			elif mutation == "mixed_root_versions": data.versions.encounters = PlainsRegionGenerator.VERSION
			elif mutation == "mixed_stage_generator": output.stage_generator.version = PlainsRegionGenerator.VERSION
			elif mutation == "mixed_manifest_version":
				output.generated_layout.version = PlainsRegionGenerator.VERSION
				output.generated_layout.manifest_hash = PlainsRegionGenerator.new()._hash(output.generated_layout)
			elif mutation == "mixed_enemy_version": output.enemy_layout.version = PlainsRegionGenerator.VERSION
			elif mutation == "unearned_resource_tuning": output.stage_tuning.max_air_shots += 1
			else:
				if mutation == "rehashed_enemy_position": output.generated_layout.enemies[0].position[0] += 1
				else:
					for enemy: Dictionary in output.generated_layout.enemies:
						if enemy.behavior_id == "root_bell": enemy.behavior_id = "patrol"; break
				output.generated_layout.manifest_hash = PlainsRegionGenerator.new()._hash(output.generated_layout)
				output.enemy_layout.enemies = output.generated_layout.enemies.duplicate(true)
			var refused := RunManifest.from_snapshot(data) == null
			negatives.append({"mutation": mutation, "refused": refused})
			if not refused: failures.append("false_accept/" + mutation)
	var rejected_api := RunManifest.new("explicit-version-api", RunProfile.formal())
	var untouched := rejected_api.canonical_json()
	var unknown_refused := not rejected_api.enable_plains_region("plains-region-v999") and rejected_api.canonical_json() == untouched
	negatives.append({"mutation": "unknown_enable_version_is_atomic", "refused": unknown_refused})
	if not unknown_refused: failures.append("unknown_enable_version")
	var legacy_api := RunManifest.new("legacy-default-api", RunProfile.formal())
	var legacy_default := legacy_api.enable_plains_region() and legacy_api.snapshot().versions.generated_layout == PlainsRegionGenerator.VERSION
	cases.append({"case": "default_enable_api_keeps_v10", "passed": legacy_default})
	if not legacy_default: failures.append("legacy_default_enable_version")
	return {"passed": failures.is_empty(), "failures": failures, "cases": cases, "negatives": negatives, "actual_snapshots": snapshots, "scope": "Real current DemoApp two-map versioned RunManifest snapshots/reconstruction; explicit lawful item and mini-Boss outcome fixtures, not input-only traversal/combat, save schema or device acceptance"}
