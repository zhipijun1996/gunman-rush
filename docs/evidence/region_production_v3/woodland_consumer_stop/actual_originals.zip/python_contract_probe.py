"""SYNTHETIC subprocess transport only; never native evidence."""
import importlib.util,tempfile,os,json,types,contextlib,io
from pathlib import Path
from unittest.mock import patch
import sys
r=Path('/workspace/gunman-rush');sys.path.insert(0,str(r/'tools'));s=importlib.util.spec_from_file_location('directed',r/'tools/run_plains_directed_space_tests.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);results=[]
for variant in ['valid_matrix','default_protocol_missing','legacy_below_original50']:
 with tempfile.TemporaryDirectory() as d:
  root=Path(d);(root/'build').mkdir();calls=[]
  def fake(command,**kwargs):
   if '--editor' in command:return types.SimpleNamespace(returncode=0,stdout='SYNTHETIC import transport\n',stderr='')
   env=kwargs['env'];legacy=env['PLAINS_LEGACY_WOODLAND_FIXTURE']=='1';neg='--prove-failure' in command;calls.append({'legacy':legacy,'negative':neg,'wood':env['PLAINS_LEGACY_WOODLAND_FIXTURE'],'highland':env['PLAINS_HIGHLAND_PILOT'],'single_seed':'--single-seed' in command});dest=Path(next(x for x in command if x.startswith('--output=')).removeprefix('--output='));count=49 if variant=='legacy_below_original50' and legacy else 50;body={'assertions':count,'failures':1 if neg else 0}
   if not legacy and variant!='default_protocol_missing':body['consumer_mode']='default_stopped_woodland_with_limited_highland'
   dest.write_text(json.dumps(body));return types.SimpleNamespace(returncode=1 if neg else 0,stdout=f'DIRECTED SPACE: {count} assertions, {body["failures"]} failures\n',stderr='')
  with patch.object(m,'ROOT',root),patch.object(m.subprocess,'run',side_effect=fake),patch.object(m.level_formal,'source_files',return_value={'SYNTHETIC':'stable'}),patch.dict(os.environ,{'PLAINS_LEGACY_WOODLAND_FIXTURE':'externally_invalid','PLAINS_HIGHLAND_PILOT':'externally_invalid'}),contextlib.redirect_stdout(io.StringIO()):code=m.run()
  if variant=='valid_matrix':
   assert code==0 and len(calls)==4 and [(x['wood'],x['highland']) for x in calls]==[('1','0'),('1','0'),('0','1'),('0','1')];assert [x['single_seed'] for x in calls]==[False,True,False,True]
  else:assert code==1
  results.append({'scope':__doc__,'variant':variant,'exit_code':code,'calls':calls})
(r/'build/region_production_v3/woodland_consumer_stop/python_contract_probe.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results))
