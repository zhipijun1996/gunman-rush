"""Independent evidence-consumer mutations, not engine/model execution."""
import sys,json,copy,hashlib,importlib.util,zipfile
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/'tools'))
import production_loop as p
spec=importlib.util.spec_from_file_location('root_bell','tools/run_root_bell_tests.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
OUT=Path('build/region_production_v3/independent/enemy_round1')
PORT=Path('docs/evidence/region_production_v3/enemy')
req=json.loads(Path('build/verification/v3-enemy/V3-ENEMY-01/1/review/host_request.json').read_text())
sha=lambda path:hashlib.sha256(Path(path).read_bytes()).hexdigest()
report=json.loads((PORT/'g1_report.json').read_text());data=json.loads((PORT/'g1_capture.json').read_text())
assert req['source_hash']==p.digest(p.snapshot())
assert req['request_hash']==p.digest({k:v for k,v in req.items() if k!='request_hash'})
assert report['source_before']==report['source_after']==m.sources()
assert report['capture_sha256']==sha(PORT/'g1_capture.json')
assert report['runtime_log_sha256']==sha(PORT/'g1_runtime.log')
assert 'ROOT BELL: 165 assertions, 0 failures' in (PORT/'g1_runtime.log').read_text()
index=json.loads((PORT/'artifact_index.json').read_text())['files']
assert all(sha(PORT/f)==r['sha256'] and (PORT/f).stat().st_size==r['bytes'] for f,r in index.items())
movie=json.loads((PORT/'movie_source_v1.json').read_text())
with zipfile.ZipFile(PORT/'movie_source_v1.zip') as z:
 assert all(hashlib.sha256(z.read(f)).hexdigest()==r['sha256']==movie['source_before'][f] for f,r in movie['files'].items())
records={'request_hash':req['request_hash'],'scope':'Independent pure-Python evidence consumer review; no Godot/ffmpeg/model execution','source_sha256':m.sources(),'portable_hashes_match':True,'movie_archive_14_hashes_match':True,'baseline_validates':False,'mutations':[]}
m.validate_capture(data);records['baseline_validates']=True
records['existing_five_erasure_tests']=m.tamper_checks(data)
mutations={}
def remove_cases(d):d['cases']=[c for c in d['cases'] if c['id'] not in ['pause_actor_epoch','inactive_target','actual_stage_capture_and_ledger_roundtrip','duplicate_hit_does_not_interrupt']]
mutations['erase_pause_inactive_save_duplicate_cases']=remove_cases

def erase_warning_frames(d):
 for c in d['cases']:
  if c['id']=='real_projectile_interrupt':
   c['frames']=[f for f in c['frames'] if f['state']!='telegraph']
mutations['erase_interrupt_warning_frames']=erase_warning_frames

def erase_restored_trace(d):
 for c in d['cases']:
  if c['id']=='restored_pending_pulse_is_cancelled':c['frames']=[];c['events']=[]
mutations['erase_all_restored_cancel_trace']=erase_restored_trace

def one_width(d):
 original=next(c for c in d['cases'] if c.get('calibration',{}).get('width')==400 and c['calibration']['direction']==1)
 d['cases']=[c for c in d['cases'] if 'calibration' not in c]
 for i in range(6):
  duplicate=copy.deepcopy(original);duplicate['id']='renamed_duplicate_'+str(i);d['cases'].append(duplicate)
mutations['replace_six_width_directions_with_one_run_copies']=one_width

def relabel_source(d):d['scope']='FORGED wrong source/version/consumer';d['source_commit']='0'*40;d['consumer']='scripts/demo/action_studio.gd';d['production_pool']=True
mutations['wrong_declared_source_scope_and_formal_claim']=relabel_source
for name,mutate in mutations.items():
 altered=copy.deepcopy(data);mutate(altered)
 try:m.validate_capture(altered);r={'mutation':name,'rejected':False}
 except (ValueError,KeyError,IndexError,TypeError) as e:r={'mutation':name,'rejected':True,'error':str(e)}
 (OUT/(name+'.json')).write_text(json.dumps(altered,indent=2)+'\n')
 records['mutations'].append(r)
records['source_unchanged']=req['source_hash']==p.digest(p.snapshot())
(OUT/'counterexample_results.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in records.items() if k!='source_sha256'},ensure_ascii=False,indent=2))
