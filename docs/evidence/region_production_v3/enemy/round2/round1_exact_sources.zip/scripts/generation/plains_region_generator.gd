class_name PlainsRegionGenerator
extends RefCounted
## Topology is committed before terrain/content. No player tuning changes.
const VERSION := "plains-region-v10"
const RNG_VERSION := "plains-region-v4"
const FAMILIES := ["woven_layers", "linked_rings", "crossroads"]
const SAMPLE_DX := 1400.0 # Frozen small regression fixture only.
const SAMPLE_DY := 700.0 # Formal macros use measured phrase intervals and terrace rises.
const HALF := 200.0
const ATTEMPTS := 4

func generate(seed_value: String, tuning: PlayerTuning, sample := false, force_family := "", difficulty := "advanced") -> Dictionary:
	if difficulty not in ["intro","advanced"] or seed_value.is_empty() or tuning.max_jumps < 1 or tuning.max_air_shots < 1:
		return {"ok": false, "error": "Plains requires the existing base jump and recoil shot"}
	for attempt: int in ATTEMPTS:
		var m := _candidate(seed_value, sample, force_family, attempt,difficulty)
		if validate(m, tuning): return _result(m)
	return verified_fallback(seed_value,tuning,difficulty)

func verified_fallback(seed_value: String,tuning: PlayerTuning,difficulty := "advanced") -> Dictionary:
	var fallback := _candidate("region-woven_layers", false, "woven_layers", 0,difficulty)
	fallback.seed = seed_value
	fallback.fallback_id = "verified_exploration_region"
	fallback.manifest_hash = _hash(fallback)
	return _result(fallback) if validate(fallback, tuning) else {"ok": false, "error": "Region fallback failed validation"}

func _candidate(seed_value: String, sample: bool, forced: String, attempt: int,difficulty := "advanced") -> Dictionary:
	var topology := RunRandomStream.new(seed_value, "region_topology", str(attempt), RNG_VERSION)
	var content := RunRandomStream.new(seed_value, "region_content", str(attempt), RNG_VERSION)
	var reward := RunRandomStream.new(seed_value, "region_reward", str(attempt), RNG_VERSION)
	var drawn_family: String=FAMILIES[topology.next_int(3)]
	var family: String = forced if forced in FAMILIES else drawn_family
	var cols := 3 if sample else 5 + topology.next_int(2)
	if difficulty=="intro" and not sample: cols=5
	var prep_row := 1 if sample else topology.next_int(3)
	var m := {"version": VERSION, "difficulty":difficulty, "player_tuning_hash":FileAccess.get_sha256("res://config/player_tuning.json"), "seed": seed_value, "region": "plains", "layout_id": "connected_region", "family": family, "attempt": attempt, "fallback_id": "", "sample": sample, "areas": [], "connections": [], "nodes": [], "rewards": [], "pickups": [], "enemies": [], "terminal_exits": [], "budget": {"ordinary_coins": 24, "medium": 2, "high": 1, "region_top": 1, "finite_hearts": 3,"cache_coin_limit":122,"cache_heart_limit":11,"cache_note_limit":8}, "streams": {"topology": "region_topology", "content": "region_content", "reward": "region_reward", "phases": "region_phases", "generation_seed": seed_value,"derivation_version":RNG_VERSION}}
	var footprint: Dictionary={"cells":[],"recipe":"fixed_sample"}
	if sample:
		for row: int in 3:
			for col: int in cols: footprint.cells.append([col,row])
	else: footprint=PlainsExplorationTopology.make(topology,family,15 if difficulty=="intro" else (15 if topology.next_int(2)==0 else 18))
	m.topology=footprint
	if not sample:
		m.topology.semantic_routes=PlainsExplorationTopology.route_specs()
		m.route_intents={"convergence":"area_2_1","main_recovery":"area_1_1","meaning":"short shot-recoil/headroom path, upper sightline discovery, and creek phase detour deliberately rejoin known camp"}
		for route_id: String in m.topology.semantic_routes:
			m.route_intents[route_id]=m.topology.semantic_routes[route_id].areas.duplicate()
	cols=0
	for cell: Array in footprint.cells:
		var col: int=cell[0];var row: int=cell[1]
		cols=maxi(cols,col+1)
		var label: String=["BELL WOODS","GRASS COURT","CREEK VAULT","REPAIR WELL","OLD CLOCK PIT"][row]
		m.areas.append({"id":"area_%s_%s" % [col,row],"position":[col*SAMPLE_DX,(row-1)*SAMPLE_DY] if sample else [0.0,0.0],"label":label,"row":row,"col":col,"role":"junction","ports":[]})
	var candidates: Array=[]
	for a: Dictionary in m.areas:
		var col: int=a.col;var row: int=a.row
		var right: String="area_%s_%s" % [col+1,row]
		var up: String="area_%s_%s" % [col,row-1]
		if not _area(m,right).is_empty(): candidates.append([a.id,right,"horizontal",col,row])
		if not _area(m,up).is_empty(): candidates.append([a.id,up,"stairs",col,row-1])
	for c: Array in candidates: _edge(m,c[0],c[1],c[2])
	var prep_candidates: Array=m.areas.filter(func(a: Dictionary): return a.col>=cols-2 and _area(m,"area_%s_%s" % [int(a.col)+1,int(a.row)]).is_empty() and _degree(m,a.id)>=2)
	if prep_candidates.is_empty(): prep_candidates=m.areas.filter(func(a: Dictionary): return a.col==cols-2 and _degree(m,a.id)>=2)
	var chosen_prep: Dictionary=prep_candidates[topology.next_int(prep_candidates.size())]
	prep_row=int(chosen_prep.row)
	m.prep_id=str(chosen_prep.id)
	# Cut galleries at different columns. No uninterrupted parallel highways.
	if not sample:
		for row: int in 5:
			var horizontal: Array=m.connections.filter(func(e: Dictionary): return e.kind=="horizontal" and int(_area(m,e.a).row)==row and not _semantic_edge(m,str(e.a),str(e.b)))
			if horizontal.is_empty(): continue
			var cut: Dictionary=horizontal[topology.next_int(horizontal.size())]
			var at: int=m.connections.find(cut);m.connections.remove_at(at)
			if not _connected(m) or _cycles(m)<5 or _degree(m,m.prep_id)<2: m.connections.insert(at,cut)
	# Seed changes traversal, not only content. Remove non-bridge edges while
	# retaining three independent cycles and two incoming prep routes.
	for unused: int in 4 if not sample else 0:
		var removable: Array=m.connections.filter(func(e: Dictionary): return e.kind=="horizontal" and not _semantic_edge(m,str(e.a),str(e.b)))
		if removable.is_empty(): break
		var candidate: Dictionary=removable[topology.next_int(removable.size())]
		var at: int=m.connections.find(candidate)
		m.connections.remove_at(at)
		if not _connected(m) or _cycles(m) < 5 or _degree(m,m.prep_id) < 2:
			m.connections.insert(at, candidate)
	if sample:
		_edge(m, "area_0_1", "area_1_0", "diagonal", "open", false)
	# Keep the authored outer creek arm a circuit rather than a 700-unit
	# descent whose only exit repeats the same shaft. No new reward budget.
	if not sample and not _area(m,"area_4_3").is_empty() and not _area(m,"area_3_3").is_empty() and m.prep_id != "area_4_3" and _degree(m,"area_4_3") == 1:
		_edge(m,"area_3_3","area_4_3","horizontal")
		m.connections[-1].outer_return = true
		m.topology.outer_return = {"areas":["area_3_3","area_4_3","area_4_2"],"purpose":"water_crossing_returns_by_forward_shaft_instead_of_repeating_entry"}
	# Two genuine extra vertical shortcuts; locked from their upper side.
	var shortcuts := 0
	for c: Array in candidates:
		if c[2] != "stairs" or _has_edge(m, c[0], c[1]): continue
		_edge(m, c[0], c[1], "stairs", "backside")
		shortcuts += 1
		if shortcuts == 2: break
	if shortcuts < 2:
		# Convert redundant stair connections into locked shortcuts, never a bridge.
		for e: Dictionary in m.connections:
			if shortcuts == 2: break
			# Reserve the authored upper discovery→known fork descent in well rings.
			if not sample and family=="linked_rings" and e.a=="area_1_1" and e.b=="area_1_0": continue
			if _semantic_edge(m,str(e.a),str(e.b)) or e.kind != "stairs" or e.condition != "open" or (sample and e.b == "area_1_0") or m.prep_id in [e.a,e.b]: continue
			e.condition = "backside"
			if not _connected(m) or _cycles(m) < 3: e.condition = "open"
			else: shortcuts += 1
	# Well-rings deliberately use one-way descent arms and separate climb returns.
	# Courtyard weave retains bidirectional crossings; hub satellites use lifts.
	if not sample and family=="linked_rings":
		var converted:=0
		for e: Dictionary in m.connections:
			if converted==2: break
			if _semantic_edge(m,str(e.a),str(e.b)) or e.kind!="stairs" or e.condition!="open" or m.prep_id in [e.a,e.b]: continue
			var lower: String=e.a;var upper: String=e.b;e.a=upper;e.b=lower;e.kind="drop";e.bidirectional=false
			if not _connected(m): e.a=lower;e.b=upper;e.kind="stairs";e.bidirectional=true
			else: converted+=1
	var camps: Array=m.areas.filter(func(a: Dictionary): return a.id not in ["area_0_1",m.prep_id] and a.row==1 and a.col in [1,2])
	content.next_int(camps.size()) # Preserve named content stream consumption, placement is authored.
	m.merchant_id="area_2_1"
	_area(m, m.prep_id).role = "prep"
	_area(m, m.prep_id).label = "WINDKEEPER APPROACH"
	_area(m, m.merchant_id).role = "merchant"
	_area(m, m.merchant_id).label = "CAMP / MERCHANT"
	# Authored identities are consumers of topology: terrain/recipes/ecology and
	# the scene compositor share this field. Merchant is a protected convergence.
	for a: Dictionary in m.areas:
		if sample: content.next_int(5) # Exact legacy fixture random stream alignment.
		a.identity="repair_gallery" if a.id==m.merchant_id else "clock_court" if a.row==0 else "creek_well" if a.row>=2 else "windmill_plateau"
		a.landmark={"repair_gallery":"ivy","clock_court":"ruin_arch","creek_well":"stones","windmill_plateau":"windmill"}[a.identity]
		a.label={"repair_gallery":"REPAIR GALLERY","clock_court":"BROKEN CLOCK COURT","creek_well":"CREEK RETURN","windmill_plateau":"WINDMILL MEADOW"}[a.identity] if a.role=="junction" else a.label
		a.spatial_intent="observe_routes_and_recover" if a.id==m.merchant_id else "look_across_water" if a.identity=="creek_well" else "frame_clock_sightline" if a.identity=="clock_court" else "open_meadow_landing"
	if not sample:
		# Plan phrases before allocating world space. Each interval is sized from
		# its actual authored modules; no single rectangular grid spacing.
		var spans: Array=[0.0,0.0,0.0,0.0]
		m.recipe_history=[]
		for e: Dictionary in m.connections:
			if e.kind!="horizontal": continue
			var area: Dictionary=_area(m,e.a)
			e.purpose="outer_return" if e.get("outer_return",false) else "creek_discovery" if e.a=="area_1_2" and e.b=="area_2_2" else "first_short_chain" if e.a=="area_0_1" else "rejoin_repair_camp" if e.b==m.merchant_id else "explore_creek_return" if area.identity=="creek_well" else "learn_clock_sightline" if area.identity=="clock_court" else "meadow_crossing"
			e.design_recipe=PlainsRouteRecipes.choose(content,m.recipe_history,difficulty=="intro",e.purpose,str(area.identity))
			var width:=0.0
			for module_id: String in e.design_recipe.modules: width+=RandomStageGenerator.new().definition_for(module_id,false,false).world_bounds.size.x
			spans[int(area.col)]=maxf(float(spans[int(area.col)]),width+HALF*2.0+80.0)
		var xs: Array=[0.0]
		for span: float in spans: xs.append(float(xs[-1])+maxf(1080.0,span))
		for a: Dictionary in m.areas: a.position=[xs[int(a.col)],footprint.terrace_heights[int(a.row)]]
		m.topology.column_positions=xs
		m.topology.embedding="phrase_clearance_and_authored_terraces"
	# Multipoint platforms and real ascending/descending stair shafts.
	for a: Dictionary in m.areas:
		var drop: bool = m.connections.any(func(e: Dictionary) -> bool: return (e.kind=="stairs" and e.b==a.id) or (e.kind=="drop" and e.a==a.id))
		var recovery_half:=320.0 if not sample and a.id in ["area_1_1","area_3_1"] else HALF
		var d := _floor_definition("region_junction",Rect2(-recovery_half,18,recovery_half*2,32),drop)
		_add_inline(m, a.id, _point(a.position), d)
	for e: Dictionary in m.connections:
		_fill_edge(m, e, content)
	# A real side-island in the optional creek, not another cache on the direct route.
	if not sample:
		for e: Dictionary in m.connections:
			if e.get("purpose","")!="creek_discovery":continue
			var ferry_node: Dictionary=m.nodes[int(e.modules[0])]
			var bank:=_floor_definition("creek_cache_bank",Rect2(350,210,140,18),true)
			bank.world_bounds=Rect2(350,100,140,160)
			_add_inline(m,"creek_cache_bank",_point(ferry_node.offset),bank)
			m.creek_discovery={"module":ferry_node.id,"bank":"creek_cache_bank","entry_area":e.a,"exit_area":e.b,"camp":"area_2_1","reward_id":"plains/chest/medium_1","safe_observation":"entry dock; island; receiving dock","return":"receiving dock -> area_2_2 -> protected climb -> known camp","hint_from":"area_1_1"}
	# Compact tutorial is a single world prefix, not a separately loaded level.
	var first := _area(m, "area_0_1")
	var tutorial_start := Vector2(-1870, 0)
	m.spawn = [tutorial_start.x + 20, tutorial_start.y]
	m.areas.append({"id": "tutorial_jump", "position": m.spawn, "label": "HOLD JUMP / LAND / AIM BACK TO RECOIL", "role": "tutorial", "ports": []})
	m.areas.append({"id": "tutorial_bell", "position": [-660, 0], "label": "FIRST ENEMY / SHOOT THE BELL", "role": "tutorial", "ports": []})
	_edge(m, "tutorial_jump", "tutorial_bell", "tutorial")
	_edge(m, "tutorial_bell", first.id, "tutorial")
	_add_existing(m, "tutorial_gap", "plains_meadow_gap", tutorial_start)
	_add_existing(m, "tutorial_recoil", "plains_recoil_span", tutorial_start + Vector2(470, 0))
	_add_existing(m, "tutorial_bell_module", "plains_windchime_lesson", Vector2(-600, 0))
	_add_inline(m, "tutorial_join", Vector2(-120, 0), _floor_definition("region_join", Rect2(0,18,100,32)))
	# Safe catch below recoil lesson, with basic stair return; no free refill.
	var catch := _floor_definition("region_tutorial_recovery", Rect2(0, 138, 310, 24))
	catch.world_bounds.size.x = 420
	catch.platforms.append(Rect2(275, 78, 90, 18))
	_add_inline(m, "tutorial_recovery", Vector2(-1100, 0), catch)
	var prep := _point(_area(m, m.prep_id).position)
	var arena_offset := prep + Vector2(HALF, -582)
	_add_existing(m, "windkeeper_arena", "plains_bellstrider_arena" if difficulty=="intro" else "plains_boss_arena", prep + Vector2(HALF, 0))
	m.boss_arena = [arena_offset.x + 100, arena_offset.y + 250, 920, 350]
	m.areas.append({"id": "windkeeper", "position": [prep.x + 760, prep.y], "label": "WINDKEEPER / THREE PHASES", "role": "boss", "ports": []})
	_edge(m, m.prep_id, "windkeeper", "boss")
	m.prep_position = [prep.x, prep.y]
	m.merchant_position = _area(m, m.merchant_id).position.duplicate()
	# Optional difficulty loops have a hard ascending arm, one-way drop escape,
	# and a different return junction; never an easy reverse entrance to a chest.
	if not sample:
		for route: Dictionary in footprint.challenge_routes:
			_deep_loop(m,str(route.entry),str(route["return"]),str(route.tier),content)
	for a: Dictionary in m.areas:
		for e: Dictionary in m.connections:
			if e.a != a.id and e.b != a.id: continue
			var other := _area(m, e.b if e.a == a.id else e.a)
			var direction := (_point(other.position) - _point(a.position)).normalized()
			a.ports.append({"connection": e.id, "position": a.position.duplicate(), "direction": [direction.x, direction.y], "actions": _connection_actions(m,e), "condition": e.condition, "safe_landing": a.position.duplicate(), "outgoing": e.bidirectional or e.a == a.id})
	# Fixed total reward budget, independent of map size; position/risk determines tier.
	for i: int in 2:
		var preferred: Array=["area_1_1"] if i==0 else ["area_2_2"] if not sample else ["area_1_0","area_2_2"]
		var eligible: Array=m.areas.filter(func(a: Dictionary): return a.role=="junction" and a.id in preferred and not m.rewards.any(func(c: Dictionary): return c.area==a.id))
		if eligible.is_empty(): eligible=m.areas.filter(func(a: Dictionary): return a.role=="junction" and a.id!="area_0_1" and not m.rewards.any(func(c: Dictionary): return c.area==a.id))
		var area_id: String=eligible[reward.next_int(eligible.size())].id
		var p := _point(_area(m, area_id).position)
		if i==1 and m.has("creek_discovery"):
			var ferry_node: Dictionary=m.nodes.filter(func(n:Dictionary):return n.id==m.creek_discovery.module)[0]
			p=_point(ferry_node.offset)+Vector2(520,192)
		m.rewards.append({"id": "plains/chest/medium_%s" % i, "area": area_id, "tier": "medium", "position": [p.x - 100, p.y], "coins": 8, "items": ["damage_blue", "health_blue"], "risk": {"depth": 2, "platforming": 1, "timing": 1, "pressure": 1, "return": 1}})
	if m.has("creek_discovery"):
		for cache: Dictionary in m.rewards:
			if cache.id==m.creek_discovery.reward_id:cache.approach=m.creek_discovery.duplicate(true)
	var enemy_limit: int=26 if difficulty=="intro" else 36
	m.pressure={"version":"plains-pressure-v2","enemy_limit":enemy_limit,"simultaneous_attacks":1 if difficulty=="intro" else 2}
	var ordinary: Array = m.areas.filter(func(a: Dictionary) -> bool: return a.role == "junction" or a.role == "prep")
	for i: int in 12:
		var p := _point(ordinary[i % ordinary.size()].position)
		m.pickups.append({"id": "plains/coin/%s" % i, "kind": "coin", "amount": 2, "position": [p.x + 70, p.y - 10]})
	for i: int in 3:
		var a: Dictionary = _area(m,m.merchant_id) if i==0 else ordinary[content.next_int(ordinary.size())]
		var p := _point(a.position)
		m.pickups.append({"id": "plains/supply/%s" % i, "kind": "heart", "amount": 1, "position": [p.x - 60, p.y]})
	m.pickups.append({"id": "plains/note/tutorial", "kind": "note", "amount": 1, "position": [-180, -30]})
	# Reserve encounter budget for authored movement windows before junction guards.
	# Each placement records its real module, mechanism and safe escape; no key gates.
	for wanted_pattern: String in ["ferry_air_intercept","bell_window_intercept","gear_landing_intercept","ferry_fan_crossfire"]:
		var per_pattern:=0
		for n: Dictionary in m.nodes:
			if per_pattern >= (2 if difficulty=="intro" else 3): break
			if n.has("geometry") or str(n.id).begins_with("tutorial") or n.id=="windkeeper_arena": continue
			# First creek demonstration teaches one diver; fan remains on later ordinary ferries.
			if m.has("creek_discovery") and n.id==m.creek_discovery.module and wanted_pattern!="ferry_air_intercept":continue
			if not sample and str(n.id).begins_with("plains/passage/area_0_1/area_1_1"):continue
			var d:=definition(n)
			var local:=Vector2.ZERO
			var pattern:=""
			var behavior:="diver"
			var mechanism:=""
			if not d.ferries.is_empty():
				var ferry: ModuleMovingPlatformDefinition=d.ferries[0]
				local=(ferry.start+ferry.finish)*.5+Vector2(-120,-165) if wanted_pattern=="ferry_fan_crossfire" else (ferry.start+ferry.finish)*.5+Vector2(0,-115)
				behavior="fan_sentry" if wanted_pattern=="ferry_fan_crossfire" else "diver"
				pattern="ferry_fan_crossfire" if wanted_pattern=="ferry_fan_crossfire" else "ferry_air_intercept";mechanism=str(ferry.platform_id)
			elif not d.saws.is_empty():
				# Low arches reserve headroom. A recessed wheel must not silently move an aerial guard below the old ceiling filter.
				if d.module_id==&"plains_low_arch":continue
				# Aerial pressure at the approach, not an unavoidable stack over the saw.
				local=d.saws[0].envelope().get_center()+Vector2(85,-105)
				pattern="gear_landing_intercept";mechanism=str(d.saws[0].source_id)
			elif "windchime" in str(n.module_id):
				local=d.exit_port.position+Vector2(-90,-105)
				pattern="bell_window_intercept";mechanism="shot_latch"
			else: continue
			if m.has("creek_discovery") and n.id==m.creek_discovery.module:local=Vector2(260,165) # visible intercept beside launch; never patrol the island/only receiver
			if pattern!=wanted_pattern: continue
			var blocked:=false
			var patrol_box:=Rect2(local-Vector2(55,25),Vector2(110,50))
			if not d.world_bounds.encloses(patrol_box): continue
			for slab: Rect2 in d.platforms:
				if slab.intersects(patrol_box): blocked=true
			for saw: ModuleSawDefinition in d.saws:
				if saw.envelope().grow(20).intersects(patrol_box): blocked=true
			if blocked: continue
			var p:=local+Vector2(n.offset[0],n.offset[1])
			m.enemies.append({"id":"plains/enemy/window/"+n.id+"/"+pattern,"position":[p.x,p.y],"aerial":true,"patrol_radius":35,"behavior_id":behavior,"area":n.id,"pattern":pattern,"mechanism":mechanism,"dive_depth":115.0,"escape":"wait_telegraph_then_cross_or_take_other_connection"})
			per_pattern+=1
	# Landing-pressure encounter: green cells remain usable without killing the guard.
	for n:Dictionary in m.nodes:
		if n.module_id!="plains_thorn_cells" or m.enemies.size()>=enemy_limit-1:continue
		var pos:=Vector2(n.offset[0]+460,n.offset[1]+282)
		m.enemies.append({"id":"plains/enemy/landing/"+n.id,"position":[pos.x,pos.y],"aerial":false,"patrol_radius":35,"behavior_id":"hopper","area":n.id,"pattern":"safe_cell_ambush","escape":"choose_another_green_cell_or_wait_for_locked_lunge"})
	# Put pressure inside long connections too, away from junction/spawn anchors.
	for n: Dictionary in m.nodes:
		if m.enemies.size()>=enemy_limit-1 or n.module_id!="region_connection" or not n.has("geometry"): continue
		var floor_data: Array=n.geometry.platforms[0]
		if float(floor_data[2])<420: continue
		var p:=Vector2(n.offset[0]+floor_data[0]+floor_data[2]*0.5,n.offset[1]+floor_data[1]-18)
		var behavior: String="sentry" if content.next_int(2)==0 else "charger"
		m.enemies.append({"id":"plains/enemy/lane/"+n.id,"position":[p.x,p.y],"aerial":false,"patrol_radius":35 if behavior=="charger" else 0,"behavior_id":behavior,"area":n.id})
	for a: Dictionary in ordinary:
		if m.enemies.size()>=enemy_limit-1 or a.id in ["area_0_1","area_1_1","area_1_2","area_2_2", m.prep_id, m.merchant_id] or content.next_int(4 if difficulty=="intro" else 6) == 0: continue
		var behavior: String=["charger","sentry","diver","hopper"][content.next_int(4)]
		var aerial: bool=behavior=="diver"
		var p := _point(a.position) + (Vector2(70,-110) if aerial else Vector2(130,0))
		# The approach and known upper return bank share an observation/recoil
		# role. Reserve the right-hand receiver/retreat band from generic bodies.
		if _trial_observation_bank(m,a):p=_point(a.position)+(Vector2(-130,-65) if aerial else Vector2(-130,0))
		m.enemies.append({"id": "plains/enemy/" + a.id, "position": [p.x, p.y], "aerial": aerial, "patrol_radius": 40 if aerial else 35 if behavior=="hopper" else 25 if behavior=="charger" else 0, "behavior_id": behavior, "area": a.id})
	m.enemies.push_front({"id": "plains/enemy/tutorial", "position": [-655, 0], "aerial": false, "patrol_radius": 35, "behavior_id": "charger", "area": "tutorial_bell"})
	for reward_data: Dictionary in m.rewards:
		var pool: Array=["damage_blue","health_blue","efficient_grip","stability_blue","braided_cord","quick_hammer","brake_boots"] if reward_data.tier=="medium" else ["region_damage_purple","region_health_purple","echo_magazine","shot_purple","region_recoil_purple","cooling_fin","field_medic"] if reward_data.tier=="high" else ["region_damage_gold","region_health_gold","echo_gold"]
		var items_rng:=RunRandomStream.new(seed_value,"region_items",str(reward_data.id),"plains-items-v2")
		reward_data.reward_mode="item_resource" if reward_data.tier!="medium" else ("resources" if items_rng.next_int(3)==0 else "item_resource")
		reward_data.resources=[]
		var value: int=16 if reward_data.tier=="medium" else 36 if reward_data.tier=="high" else 54
		reward_data.resources.append({"kind":"coin","amount":value})
		var kind: String="heart" if items_rng.next_int(2)==0 else "note"
		reward_data.resources.append({"kind":kind,"amount":(2 if reward_data.tier=="medium" else 3 if reward_data.tier=="high" else 4) if kind=="heart" else 1 if reward_data.tier=="medium" else 2 if reward_data.tier=="high" else 4})
		if reward_data.reward_mode=="item_resource" and items_rng.next_int(2)==1: reward_data.resources.reverse()
		reward_data.items=[]
		for unused: int in 2:
			var chosen:=items_rng.next_int(pool.size())
			reward_data.items.append(pool[chosen]);pool.remove_at(chosen)
		var pressure_count: int=m.enemies.filter(func(e: Dictionary): return e.has("pattern") and str(e.area).begins_with(str(reward_data.area)+"_")).size()
		if pressure_count>0: reward_data.risk.pressure=mini(3,pressure_count)
	if PlainsRootBellPlacement.PRODUCTION_ADMITTED:
		m.root_bell_admission = PlainsRootBellPlacement.apply(m)
	m.enemy_drops={}
	var drops:=EnemyDropService.new()
	drops.configure(seed_value,"plains_region")
	var left: Dictionary={"coin":12,"note":3,"heart":2}
	var sorted_enemies: Array=m.enemies.duplicate(true)
	sorted_enemies.sort_custom(func(a: Dictionary,b: Dictionary): return str(a.id)<str(b.id))
	for e: Dictionary in sorted_enemies:
		var drop:=drops.settle(StringName(e.id))
		if drop.kind!="none":
			drop.amount=mini(int(drop.amount),int(left[drop.kind]))
			left[drop.kind]-=int(drop.amount)
			if drop.amount==0: drop.kind="none"
		m.enemy_drops[e.id]=drop
	m.ground_supports=[]
	for a: Dictionary in m.areas:
		if a.get("row",-1)==int(footprint.get("grid_height",3))-1:
			m.ground_supports.append([a.position[0]-200, a.position[1]+50,400,192])
	var geometry_bounds:=Rect2(_point(m.spawn),Vector2.ONE)
	for node: Dictionary in m.nodes:
		var d:=definition(node)
		geometry_bounds=geometry_bounds.merge(Rect2(_point(node.offset)+d.world_bounds.position,d.world_bounds.size))
	geometry_bounds=geometry_bounds.grow(320.0)
	m.world_bounds = [geometry_bounds.position.x,geometry_bounds.position.y,geometry_bounds.size.x,geometry_bounds.size.y]
	if not sample: m.ground_supports = PlainsGroundSupports.region_plan(m)
	m.shot_latch_plan = PlainsShotLatchPlanner.recorded_plan(m)
	m.stream_positions={"topology":topology.position(),"content":content.position(),"reward":reward.position()}
	var shop_rng:=RunRandomStream.new(seed_value,"region_shop",str(attempt),RNG_VERSION)
	var shop_pool: Array=["damage_blue","health_blue","efficient_grip","stability_blue","braided_cord","quick_hammer","brake_boots"]
	m.shop={"item":shop_pool[shop_rng.next_int(shop_pool.size())],"price":5,"stock":1}
	m.streams.shop="region_shop"
	m.streams.items="region_items"
	m.item_version="plains-items-v2"
	m.shot_energy_version="plains-shot-energy-v1"
	m.manifest_hash = _hash(m)
	return m

func _trial_observation_bank(m:Dictionary,a:Dictionary) -> bool:
	for edge:Dictionary in m.connections:
		if edge.kind=="challenge" and edge.a==a.id:return true
		if edge.kind!="drop" or not edge.has("return_polyline"):continue
		# Real generated evacuation points, not fixed column/Seed coordinates.
		for point:Array in edge.return_polyline.slice(1):
			if _point(point).distance_to(_point(a.position))<1.0:return true
	return false

func _deep_loop(m: Dictionary, entry_id: String, return_id: String, tier: String, rng: RunRandomStream) -> void:
	var base := _point(_area(m,entry_id).position)
	var id := "deep_" + tier
	# Existing two-level moving ferry then precise recoil rise, fully in upper air.
	var variant:=rng.next_int(3)
	var recipe_ids: Array
	if tier=="high":
		recipe_ids=["plains_recoil_step","plains_remote_sequence"] if variant==0 else ["plains_ferry_two","plains_recoil_step"] if variant==1 else ["plains_windchime_timed","plains_recoil_double"]
	else:
		recipe_ids=["plains_ferry_gears" if m.difficulty=="advanced" else "plains_ferry_two","plains_recoil_double"] if variant==0 else ["plains_recoil_double","plains_windchime_sequence" if m.difficulty=="advanced" else "plains_windchime_timed"] if variant==1 else ["plains_windchime_sequence" if m.difficulty=="advanced" else "plains_windchime_timed","plains_recoil_double"]
	var selected_reason := "authored_variant"
	if tier=="high" and m.difficulty=="advanced" and variant==0:
		recipe_ids=["plains_recoil_step","plains_windchime_rush"]
		selected_reason="main_taught_double_sightline_high_combines_recoil_rise_and_deadline"
	var entry_steps := _floor_definition("region_deep_entry",Rect2(-190,18,80,24),true)
	entry_steps.world_bounds=Rect2(-320,-380,520,450)
	for i: int in 3:
		var x: float=[90.0,-90.0,-230.0][i]
		entry_steps.platforms.append(Rect2(x-70,-82-i*100,140,18));entry_steps.one_way_platform_indices.append(entry_steps.platforms.size()-1)
	_add_inline(m,id+"_entry",base,entry_steps)
	var cursor:=base+Vector2(-150,-400)
	var trial_modules: Array=[]
	for index: int in recipe_ids.size():
		var module_id: String=recipe_ids[index]
		var node_id: String=id+("_ferry" if index==0 else "_recoil")
		_add_existing(m,node_id,module_id,cursor)
		trial_modules.append(node_id)
		var d:=RandomStageGenerator.new().definition_for(module_id)
		cursor+=d.exit_port.position-d.entry_port.position+Vector2(20,0)
	var landing:=cursor+Vector2(20,0)
	var return_point:=_point(_area(m,return_id).position)
	# A wider optional ferry chain may legitimately rejoin the farther Boss-side
	# meadow. Choose a real authored recovery anchor near its physical exit.
	if tier=="region_top" and landing.x>return_point.x+100.0:
		return_id="area_4_1"
		return_point=_point(_area(m,return_id).position)
	var landing_width:=maxf(180,return_point.x+80-landing.x)
	_add_inline(m,id+"_landing",landing,_floor_definition("region_drop_exit",Rect2(0,18,landing_width,24),true))
	var reward_position:=Vector2(maxf(landing.x+35,return_point.x),landing.y)
	m.areas.append({"id": id, "position": [reward_position.x, reward_position.y], "label": "DEEP TRIAL / " + tier.to_upper(), "role": "challenge_reward", "ports": []})
	_edge(m,entry_id,id,"challenge","open",false)
	_edge(m, id, return_id, "drop", "open", false)
	var drop_edge: Dictionary=m.connections[-1]
	drop_edge.escape_x=reward_position.x
	var clear_y: float=landing.y
	for node_id: String in trial_modules:
		var node: Dictionary=m.nodes.filter(func(n: Dictionary): return n.id==node_id)[0]
		var d:=definition(node)
		for danger: Rect2 in d.danger_bounds: clear_y=maxf(clear_y,float(node.offset[1])+danger.end.y+24)
		for saw: ModuleSawDefinition in d.saws: clear_y=maxf(clear_y,float(node.offset[1])+saw.envelope().end.y+24)
	drop_edge.clear_y=maxf(clear_y,return_point.y-18.0)
	drop_edge.return_intent="drop_to_known_upper_bank_open_real_return_control_then_descend_to_recovery"
	drop_edge.return_polyline=[[reward_position.x,reward_position.y],[return_point.x,base.y],[return_point.x,return_point.y]]
	m.rewards.append({"id": "plains/chest/" + tier, "area": id, "tier": tier, "position": [reward_position.x, reward_position.y], "coins": 18 if tier == "high" else 30, "items": ["region_damage_purple", "region_health_purple"] if tier == "high" else ["region_damage_gold", "region_health_gold"], "risk": {"depth": 3, "platforming": 3, "timing": 3, "pressure": 0, "resource": 2, "return": 2}, "variant":variant,"rolled_variant":variant,"selected_reason":selected_reason,"challenge_modules":trial_modules,"action_signature":str(recipe_ids[0]).trim_prefix("plains_")+">"+str(recipe_ids[1]).trim_prefix("plains_")})

func _fill_edge(m: Dictionary, e: Dictionary, rng: RunRandomStream) -> void:
	var a := _point(_area(m, e.a).position)
	var b := _point(_area(m, e.b).position)
	if e.kind=="drop":
		e.path=[[a.x,a.y],[b.x,b.y]];e.actions="inspect_return>drop_through>land";e.return_hint="climb_neighbouring_well"
		return
	if e.kind == "diagonal":
		_add_existing(m, e.id + "_ferry", "plains_ferry_two", a + Vector2(200,0))
		var d := _floor_definition("region_diagonal_join",Rect2(0,18,180,24),true)
		d.world_bounds = Rect2(-20,-210,300,270)
		d.platforms.append(Rect2(80,-56,100,18))
		d.one_way_platform_indices.append(1)
		_add_inline(m,e.id+"_join",a+Vector2(1180,-552),d)
		e.path = [[a.x,a.y],[b.x,b.y]]
		return
	if e.kind == "stairs":
		var choices: Array=["lift","lift","switchback","recoil_shaft"] if m.family=="crossroads" else ["switchback","recoil_shaft","switchback","lift"] if m.family=="woven_layers" else ["recoil_shaft","lift","recoil_shaft","switchback"]
		var recipe: String=choices[rng.next_int(choices.size())] if not m.sample else "switchback"
		e.shaft_recipe=recipe
		var d := _floor_definition("region_stairs", Rect2(-200,18,80,24), true)
		var rise:=a.y-b.y
		d.world_bounds = Rect2(-220,-rise-50,440,rise+140)
		e.path = [[a.x,a.y]]
		if recipe=="lift":
			d.platforms[0]=Rect2(-200,18,100,24)
			var carrier:=ModuleMovingPlatformDefinition.new();carrier.platform_id=&"well_lift";carrier.start=Vector2(110,-70);carrier.finish=Vector2(110,-rise+130);carrier.size=Vector2(120,24);carrier.travel_duration=3.8;carrier.dwell_duration=1.5
			d.ferries.append(carrier)
			e.actions="wait_lift>jump_board>ride>jump_upper_bank"
		elif recipe=="recoil_shaft":
			for i: int in maxi(1,floori((rise-100.0)/190.0)):
				var x: float=90.0 if i%2==0 else -90.0
				var height:=minf(190.0*(i+1),rise-100.0)
				d.platforms.append(Rect2(x-70,18-height,140,18));d.one_way_platform_indices.append(d.platforms.size()-1)
				e.path.append([a.x+x,a.y-height])
			e.actions="jump>aim_down>recoil_rise>land_recover>repeat"
		else:
			for i: int in maxi(1,floori((rise-100.0)/100.0)):
				var height:=minf(100.0*(i+1),rise-80.0)
				d.platforms.append(Rect2(-160 if i % 2 == 0 else 20,18-height,140,18));d.one_way_platform_indices.append(d.platforms.size()-1)
				e.path.append([a.x + (-90 if i % 2 == 0 else 90), a.y-height])
			e.actions="hold_jump>alternate_landing>look_up"
		if e.condition=="backside":
			d.world_bounds=Rect2(-250,-rise-50,500,rise+140)
			d.platforms.append(Rect2(-229,b.y-a.y+45,24,a.y-b.y-81))
			d.platforms.append(Rect2(205,b.y-a.y+45,24,a.y-b.y-81))
		_add_inline(m, e.id, a, d)
		e.path.append([b.x,b.y])
		if e.condition == "backside":
			e.gate = [a.x - 205, b.y + 45, 410, 24]
			e.control = [b.x, b.y]
		return
	# Horizontal edges combine phrases in a bounded lane with both-way landings.
	if not m.has("recipe_history"): m.recipe_history=[]
	var recipe: Dictionary=e.get("design_recipe",{})
	if recipe.is_empty(): recipe=PlainsRouteRecipes.choose(rng,m.recipe_history,m.difficulty=="intro","legacy_sample" if m.sample else "")
	var ids: Array=recipe.modules
	e.recipe=recipe.id;e.action_signature=recipe.actions;e.pressure=recipe.pressure;e.decision=recipe.decision
	if m.sample and e.a == "area_0_1": ids = []
	var x := a.x + HALF
	e.modules = []
	for id: String in ids:
		var d := RandomStageGenerator.new().definition_for(id, false, false)
		_add_existing(m, e.id + "_%s" % e.modules.size(), id, Vector2(x, a.y))
		e.modules.append(m.nodes.size()-1)
		x += d.world_bounds.size.x
	if x < b.x - HALF:
		var remaining := b.x - HALF - x
		var overlap := 0.0
		# This overlap only repairs the certified bridge/arch join into the solid arch floor only; preserve the receiving one-way floor.
		if remaining == 20.0 and recipe.id == "thorn_gap" and ids == ["plains_thorn_bridge", "plains_low_arch"] and a.y == b.y:
			var arch := definition(m.nodes[int(e.modules[-1])])
			var receiving_nodes: Array = m.nodes.filter(func(n: Dictionary): return n.id == e.b)
			if receiving_nodes.size() == 1:
				var receiving := definition(receiving_nodes[0])
				var arch_floor := arch.platforms[0]
				var receiving_floor := receiving.platforms[0]
				if not arch.one_way_platform_indices.has(0) and arch_floor == Rect2(0,300,640,32) and receiving_floor == Rect2(-HALF,18,HALF*2,32):
					overlap = 20.0
		var join := _floor_definition("region_connection", Rect2(-overlap,18,remaining + overlap,32))
		if overlap > 0.0:
			join.anchors.assign([Vector2(-4,0), Vector2(4,0)])
			join.entry_port = _port("entry", join.anchors[0])
			join.exit_port = _port("exit", join.anchors[1])
		_add_inline(m, e.id + "_join", Vector2(x, a.y), join)
		if overlap > 0.0: m.nodes[-1].geometry.standing_margin = 16.0
	e.path = [[a.x,a.y],[b.x,b.y]]

func _connection_actions(m: Dictionary,e: Dictionary) -> Dictionary:
	var actions: Dictionary={"jumps":0 if e.kind=="drop" else 1,"air_shots":1 if e.kind=="challenge" or (e.kind=="tutorial" and e.a=="tutorial_jump") else 0,"shoot_mechanism":e.kind=="tutorial" and e.a=="tutorial_bell","requires_burst":e.kind=="challenge" or (e.kind=="tutorial" and e.a=="tutorial_jump")}
	if e.get("shaft_recipe","")=="recoil_shaft": actions.air_shots=1;actions.requires_burst=true
	for index: int in e.get("modules",[]):
		var d:=definition(m.nodes[index])
		actions.air_shots=maxi(int(actions.air_shots),d.min_air_shots)
		actions.requires_burst=bool(actions.requires_burst) or d.requires_burst
		actions.shoot_mechanism=bool(actions.shoot_mechanism) or "windchime" in str(d.module_id) or d.module_id in [&"plains_bell_ferry_control",&"plains_remote_sequence"]
		if d.module_id==&"plains_remote_bell":actions.optional_remote_shot=true
	return actions

func _floor_definition(id: String, slab: Rect2, one_way := false) -> PlatformingModuleDefinition:
	var d := PlatformingModuleDefinition.new()
	d.module_id = StringName(id)
	d.world_bounds = Rect2(slab.position.x - 20,-160,slab.size.x + 40,slab.end.y+180)
	d.platforms.append(slab)
	if one_way: d.one_way_platform_indices.append(0)
	d.anchors.assign([Vector2(slab.position.x+20,slab.position.y-18), Vector2(slab.end.x-20,slab.position.y-18)])
	d.entry_port = _port("entry", d.anchors[0])
	d.exit_port = _port("exit", d.anchors[1])
	return d

func _port(id: String, p: Vector2) -> PlatformingModulePort:
	var port := PlatformingModulePort.new()
	port.port_id = StringName(id)
	port.position = p
	return port

func _add_existing(m: Dictionary, id: String, module_id: String, entry: Vector2) -> void:
	var d := RandomStageGenerator.new().definition_for(module_id, false, false)
	var phase_stream := RunRandomStream.new(str(m.seed), "region_phases", id, RNG_VERSION)
	var phases: Array = []
	for saw: ModuleSawDefinition in d.saws: phases.append({"id":str(saw.source_id),"phase":float(phase_stream.next_int(4))/4.0})
	for ferry: ModuleMovingPlatformDefinition in d.ferries: phases.append({"id":str(ferry.platform_id),"phase":float(phase_stream.next_int(4))/4.0})
	var offset := entry - Vector2(0, d.entry_port.position.y)
	m.nodes.append({"id": id, "module_id": module_id, "offset": [offset.x,offset.y], "mirrored": false, "reverse_traversal": false, "initial_phases": phases, "definition_version":d.definition_version,"definition_hash":JSON.stringify(_definition_data(d),"",true).sha256_text()})

func _add_inline(m: Dictionary, id: String, p: Vector2, d: PlatformingModuleDefinition) -> void:
	var slabs: Array = []
	for rect: Rect2 in d.platforms: slabs.append([rect.position.x,rect.position.y,rect.size.x,rect.size.y])
	var carriers: Array=[]
	for f: ModuleMovingPlatformDefinition in d.ferries: carriers.append({"id":str(f.platform_id),"start":[f.start.x,f.start.y],"finish":[f.finish.x,f.finish.y],"size":[f.size.x,f.size.y],"travel":f.travel_duration,"dwell":f.dwell_duration,"phase":f.initial_phase})
	m.nodes.append({"id": id, "module_id": str(d.module_id), "offset": [p.x,p.y], "mirrored": false, "reverse_traversal": false, "initial_phases": [], "geometry": {"bounds": [d.world_bounds.position.x,d.world_bounds.position.y,d.world_bounds.size.x,d.world_bounds.size.y], "platforms": slabs, "one_way": d.one_way_platform_indices, "ferries":carriers, "junction": str(d.module_id) == "region_junction"}})

static func definition(node: Dictionary) -> PlatformingModuleDefinition:
	if not node.has("geometry"):
		var authored := RandomStageGenerator.new().definition_for(str(node.module_id),false,false).duplicate(true) as PlatformingModuleDefinition
		for phase: Dictionary in node.initial_phases:
			for saw: ModuleSawDefinition in authored.saws:
				if str(saw.source_id)==phase.id: saw.initial_phase=float(phase.phase)
			for ferry: ModuleMovingPlatformDefinition in authored.ferries:
				if str(ferry.platform_id)==phase.id: ferry.initial_phase=float(phase.phase)
		return authored
	var d := PlatformingModuleDefinition.new()
	d.module_id = StringName(node.module_id)
	var g: Dictionary = node.geometry
	d.world_bounds = Rect2(g.bounds[0],g.bounds[1],g.bounds[2],g.bounds[3])
	for r: Array in g.platforms: d.platforms.append(Rect2(r[0],r[1],r[2],r[3]))
	d.one_way_platform_indices.assign(g.one_way)
	for data: Dictionary in g.get("ferries",[]):
		var f:=ModuleMovingPlatformDefinition.new();f.platform_id=StringName(data.id);f.start=Vector2(data.start[0],data.start[1]);f.finish=Vector2(data.finish[0],data.finish[1]);f.size=Vector2(data.size[0],data.size[1]);f.travel_duration=data.travel;f.dwell_duration=data.dwell;f.initial_phase=data.phase;d.ferries.append(f)
	var floor_rect := d.platforms[0]
	var standing_margin := float(g.get("standing_margin", 20.0))
	d.anchors.assign([Vector2(floor_rect.position.x+standing_margin,floor_rect.position.y-18),Vector2(floor_rect.end.x-standing_margin,floor_rect.position.y-18)])
	var gen := PlainsRegionGenerator.new()
	d.entry_port = gen._port("entry",d.anchors[0])
	d.exit_port = gen._port("exit",d.anchors[1])
	if g.get("junction",false):
		d.entry_ports.assign([d.entry_port,gen._port("arrival_up",Vector2(-70,0)),gen._port("arrival_down",Vector2(70,0))])
		d.exit_ports.assign([d.exit_port,gen._port("depart_up",Vector2(-40,0)),gen._port("depart_down",Vector2(40,0))])
		d.entry_ports[1].direction = Vector2.DOWN
		d.entry_ports[2].direction = Vector2.UP
		d.exit_ports[1].direction = Vector2.UP
		d.exit_ports[2].direction = Vector2.DOWN
	return d

func _edge(m: Dictionary, a: String, b: String, kind: String, condition := "open", bidirectional := true) -> void:
	m.connections.append({"id": "plains/passage/%s/%s" % [a,b], "a": a, "b": b, "kind": kind, "condition": condition, "bidirectional": bidirectional})

func _area(m: Dictionary, id: String) -> Dictionary:
	for a: Dictionary in m.areas:
		if a.id == id: return a
	return {}

func _has_edge(m: Dictionary, a: String, b: String) -> bool:
	return m.connections.any(func(e: Dictionary) -> bool: return (e.a == a and e.b == b) or (e.a == b and e.b == a))

func _degree(m: Dictionary, id: String) -> int:
	return m.connections.filter(func(e: Dictionary) -> bool: return e.condition == "open" and (e.a==id or (e.bidirectional and e.b==id))).size()

func _connected(m: Dictionary) -> bool:
	if m.areas.is_empty(): return false
	# Both forward and reverse flood: every reachable chamber also has an exit.
	for reverse: bool in [false,true]:
		var seen := {str(m.areas[0].id): true}
		for unused: int in m.areas.size():
			for e: Dictionary in m.connections:
				if e.condition != "open": continue
				var source: String=e.b if reverse else e.a
				var target: String=e.a if reverse else e.b
				if seen.has(source): seen[target]=true
				if e.bidirectional and seen.has(target): seen[source]=true
		if seen.size()!=m.areas.size(): return false
	return true

func _cycles(m: Dictionary) -> int:
	return m.connections.filter(func(e: Dictionary) -> bool: return e.condition == "open").size() - m.areas.size() + 1

func _point(p: Array) -> Vector2: return Vector2(p[0],p[1])

func _hash(m: Dictionary) -> String:
	return RandomStageGenerator.new()._manifest_hash(m)

func _semantic_edge(m: Dictionary,a: String,b: String) -> bool:
	if m.get("sample",false): return false
	for spec: Dictionary in m.topology.semantic_routes.values():
		var path: Array=spec.areas
		for i: int in range(path.size()-1):
			if (path[i]==a and path[i+1]==b) or (path[i]==b and path[i+1]==a): return true
	return false

func semantic_route_errors(m: Dictionary) -> Array[String]:
	var errors: Array[String]=[]
	if m.get("sample",false): return errors
	var required: Dictionary=PlainsExplorationTopology.route_specs()
	var declared: Variant=m.get("route_intents",{})
	var topology_routes: Variant=m.get("topology",{}).get("semantic_routes",{})
	if not declared is Dictionary or not topology_routes is Dictionary:
		errors.append("missing semantic route contracts");return errors
	for route_id: String in required:
		var path: Array=required[route_id].areas
		if declared.get(route_id,[])!=path or topology_routes.get(route_id,{})!=required[route_id]:
			errors.append(route_id+": declaration differs from authored split/rejoin contract")
		for i: int in range(path.size()-1):
			var source: String=path[i];var target: String=path[i+1]
			if _area(m,source).is_empty() or _area(m,target).is_empty():
				errors.append(route_id+": actual route area missing");continue
			var usable:=false
			for edge: Dictionary in m.get("connections",[]):
				var forward: bool=edge.get("a","")==source and edge.get("b","")==target
				var reverse: bool=edge.get("b","")==source and edge.get("a","")==target and bool(edge.get("bidirectional",false))
				if not forward and not reverse: continue
				# These are first-visit choices, so no speculative upper-side unlock.
				if edge.get("condition","")!="open": continue
				var future:=false
				for ability: String in edge.get("required_capabilities",[]):
					if ability not in ["base_jump","base_recoil","shoot_mechanism"]: future=true
				if future: continue
				usable=true;break
			if not usable: errors.append(route_id+": unavailable directed initial step "+source+" -> "+target)
	if declared.get("convergence","")!="area_2_1" or m.get("merchant_id","")!="area_2_1": errors.append("known camp convergence mismatch")
	return errors

func validate(m: Dictionary, tuning: PlayerTuning) -> bool:
	if m.get("version") != VERSION or m.get("manifest_hash") != _hash(m) or not _connected(m) or _cycles(m) < 3 or not semantic_route_errors(m).is_empty(): return false
	if m.areas.size() < 12 or m.areas.size() > 24 or _degree(m, m.prep_id) < 2: return false
	if m.connections.filter(func(e: Dictionary) -> bool: return e.condition == "backside").size() < 2: return false
	if m.areas.filter(func(a: Dictionary) -> bool: return _degree(m,a.id) >= 3).size() < 3: return false
	var ids := {}
	for n: Dictionary in m.nodes:
		if ids.has(n.id): return false
		ids[n.id] = true
		var d := definition(n)
		if not d.supports(tuning): return false
	if not PlainsShotLatchPlanner.validate(m): return false
	# Rehashed removals, fake connections/rewards and changed geometry cannot
	# pass replay validation. Generation is bounded and each namespace is separate.
	var expected := _candidate("region-woven_layers" if m.fallback_id != "" else str(m.seed),bool(m.get("sample",false)),str(m.family),int(m.attempt),str(m.get("difficulty","advanced")))
	if m.fallback_id != "":
		expected.seed = m.seed
		expected.fallback_id = m.fallback_id
	return _hash(expected) == _hash(m)

func _result(m: Dictionary) -> Dictionary:
	var arena: Array = m.boss_arena
	var points: Array[Vector2] = []
	for a: Dictionary in m.areas: points.append(_point(a.position))
	return {"ok": true, "manifest": m, "placement_points": points, "boss_arena": Rect2(arena[0],arena[1],arena[2],arena[3]), "stage_generator_version": VERSION, "encounter_plan": {"version": VERSION, "enemies": m.enemies}, "shot_latch_plan": m.shot_latch_plan}

# Hash loaded physics data, not raw .tres bytes: exports remap .tres to binary
# resources, while a fixed seed must remain portable between native and Web.
func _definition_data(value: Variant) -> Variant:
	if value is Resource:
		var fields: Dictionary={}
		for property: Dictionary in value.get_property_list():
			if int(property.usage)&PROPERTY_USAGE_SCRIPT_VARIABLE and int(property.usage)&PROPERTY_USAGE_STORAGE:
				fields[property.name]=_definition_data(value.get(property.name))
		return fields
	if value is Vector2: return [float(value.x),float(value.y)]
	if value is Rect2: return [float(value.position.x),float(value.position.y),float(value.size.x),float(value.size.y)]
	if value is Array or value is PackedInt32Array or value is PackedFloat32Array or value is PackedFloat64Array:
		var result: Array=[]
		for child: Variant in value: result.append(_definition_data(child))
		return result
	if value is int or value is float: return float(value)
	if value is StringName: return str(value)
	return value
