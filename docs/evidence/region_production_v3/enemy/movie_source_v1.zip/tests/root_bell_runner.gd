extends SceneTree
var assertions := 0
var failures := 0
func _initialize() -> void: run.call_deferred()
func check(ok: bool, label: String) -> void:
	assertions += 1
	if not ok:
		failures += 1
		print("ROOT BELL FAILURE: ", label)
func run() -> void:
	var suite := preload("res://tests/root_bell_tests.gd").new()
	if "--showcase" in OS.get_cmdline_user_args(): await suite.showcase(self, check)
	else: await suite.run(self, check)
	print("ROOT BELL: %s assertions, %s failures" % [assertions, failures])
	quit(0 if failures == 0 else 1)
