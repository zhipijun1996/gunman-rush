"""Run actual root-bell actors and optional continuous GPU+audio fixture.

The package admission stays closed. A movie is an animation review carrier,
not proof of a formal route, visual quality, device performance, or acceptance.
"""
import argparse
import copy
import hashlib
import json
import os
from pathlib import Path
import re
import selectors
import subprocess
import time
from run_tests import run_engine

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / 'build/root_bell'
LOCK = '/workspace/gunman-rush/build/region_production_v3/engine.lock'
SOURCES = [
    'scripts/enemies/enemy_actor.gd', 'scripts/enemies/enemy_definition.gd',
    'scripts/enemies/root_bell_behavior.gd', 'scripts/enemies/root_bell_presentation.gd',
    'scripts/generation/plains_encounter_planner.gd',
    'scripts/generation/plains_region_generator.gd',
    'scripts/generation/plains_root_bell_placement.gd',
    'scripts/demo/generated_demo_stage.gd',
    'resources/enemies/plains_root_bell.tres',
    'assets/region_production_v3/enemies/root_bell/source/master.png',
    'assets/region_production_v3/enemies/root_bell/manifest.json',
    'tests/root_bell_tests.gd', 'tests/root_bell_runner.gd', 'tools/run_root_bell_tests.py',
]

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def sources():
    return {p: sha(ROOT / p) for p in SOURCES}

def require(ok, reason):
    if not ok:
        raise ValueError(reason)

def validate_capture(data):
    cases = {c['id']: c for c in data['cases']}
    def events(name, kind):
        return [e for e in cases[name]['events'] if e['kind'] == kind]
    standing = events('stand_in_pulse_positive_damage', 'damage')
    require(len(standing) == 1 and standing[0]['target'] == 'player' and ':root_pulse:' in standing[0]['id'], 'standing pulse lacks one actual damage event')
    for name in ('walk_out_alive_nonkill', 'base_jump_nonkill'):
        row = cases[name]
        require(len(events(name, 'pulse')) == 1 and not events(name, 'damage'), 'nonkill bypass lacks a real living pulse')
        require(row['frames'][-1]['enemy_hp'] == 3, 'nonkill bypass silently killed target')
    jumping = cases['base_jump_nonkill']
    require(len(events('base_jump_nonkill', 'accepted_jump')) == 1, 'missing actual accepted jump')
    require(any(not f['grounded'] and f['position'][1] < 245 for f in jumping['frames']) and jumping['frames'][-1]['grounded'], 'jump lacks physical ascent and landing')
    interrupted = cases['real_projectile_interrupt']
    shots = events('real_projectile_interrupt', 'shot')
    damage = [e for e in events('real_projectile_interrupt', 'damage') if e['target'] == 'root_fixture']
    cancelled = events('real_projectile_interrupt', 'interrupted')
    require(len(shots) == len(damage) == len(cancelled) == 1, 'real projectile interruption requires accepted shot/damage/interrupt')
    require(shots[0]['tick'] <= damage[0]['tick'] == cancelled[0]['tick'], 'interruption precedes HP commitment')
    require(interrupted['frames'][-1]['enemy_hp'] == 2 and not events('real_projectile_interrupt', 'pulse'), 'interruption did not lower HP/cancel pulse')
    for name in ('solid_occlusion_negative', 'miss_does_not_interrupt'):
        require(cases[name]['frames'][-1]['enemy_hp'] == 3 and not events(name, 'interrupted'), 'blocked/missed attack faked HP interrupt')
    dead = cases['early_real_death_and_walk_through']
    require(dead['frames'][-1]['enemy_hp'] == 0 and dead['frames'][-1]['position'][0] > 370, 'dead actor path was not walked')
    require(len([e for e in events(dead['id'], 'damage') if e['target'] == 'root_fixture']) == 3, 'death lacks three actual committed shots')
    require(not events('restored_pending_pulse_is_cancelled', 'damage') and not events('restored_pending_pulse_is_cancelled', 'pulse'), 'restored old attack damaged new target')
    calibrated = [c for c in data['cases'] if 'calibration' in c]
    require(len(calibrated) == 6, 'missing two-direction 400/440/560 physical calibration')
    for row in calibrated:
        observed = row['calibration']
        require(observed['actual_support_rect_xywh'][2] == observed['width'], 'calibration floor differs from live support')
        require(not observed['formal_width_policy_changed'], 'calibration silently changed production policy')
        require(not [e for e in row['events'] if e['kind'] in ('shot', 'damage')], 'calibration used shooting or accepted damage')
        require(len([e for e in row['events'] if e['kind'] == 'accepted_jump']) == 1, 'calibration lacks one real base jump')
        require(any(e['kind'] == 'pulse' for e in row['events']) and row['frames'][-1]['grounded'] and row['frames'][-1]['enemy_hp'] == 3, 'calibration missing live pulse or final supported landing')
        center = observed['actual_enemy_center']
        half = observed['actual_enemy_collision_size']
        over_body = [f for f in row['frames'] if abs(f['position'][0] - center[0]) < half[0]/2 + 13]
        require(over_body and all(f['position'][1] < center[1] - half[1]/2 - 19 for f in over_body), 'calibration did not physically clear live enemy contact envelope')
    rows = cases['actual_formal_manifest_gated_candidates']['frames'][0]['manifest_rows']
    require(len(rows) == 20 and all(r['candidate']['replaced'] <= 1 for r in rows), 'missing formal manifest budget matrix')

def tamper_checks(data):
    def remove(case, kind):
        def mutation(row):
            target = next(c for c in row['cases'] if c['id'] == case)
            target['events'] = [e for e in target['events'] if e['kind'] != kind]
        return mutation
    mutations = {
        'erase_actual_pulse_damage': remove('stand_in_pulse_positive_damage', 'damage'),
        'erase_actual_projectile_damage': remove('real_projectile_interrupt', 'damage'),
        'erase_accepted_shot': remove('real_projectile_interrupt', 'shot'),
        'erase_accepted_jump': remove('base_jump_nonkill', 'accepted_jump'),
        'erase_death_hits': remove('early_real_death_and_walk_through', 'damage'),
    }
    rejected = []
    for name, mutate in mutations.items():
        altered = copy.deepcopy(data)
        mutate(altered)
        try:
            validate_capture(altered)
        except ValueError:
            rejected.append(name)
        else:
            raise RuntimeError('Evidence validator accepted deliberate erasure: ' + name)
    return rejected

def movie():
    folder = OUT / 'movie'
    folder.mkdir(parents=True, exist_ok=False)
    xvfb = '/workspace/toolchains/xvfb/usr/bin/Xvfb'
    display_log = (folder / 'display.log').open('wb')
    display = subprocess.Popen([xvfb, '-displayfd', '1', '-screen', '0', '1280x720x24', '-nolisten', 'tcp', '-ac'], stdout=subprocess.PIPE, stderr=display_log)
    env = os.environ.copy()
    try:
        with selectors.DefaultSelector() as selector:
            selector.register(display.stdout, selectors.EVENT_READ)
            if not selector.select(20):
                raise RuntimeError('Xvfb readiness timeout')
            number = display.stdout.readline().decode().strip()
            require(number.isdigit(), 'Invalid display number')
        env.update(DISPLAY=':' + number, LIBGL_ALWAYS_SOFTWARE='1', LP_NUM_THREADS='1')
        avi = folder / 'showcase.avi'
        command = ['bash', str(ROOT / 'tools/godot.sh'), '--path', str(ROOT), '--rendering-method', 'gl_compatibility', '--audio-driver', 'Dummy', '--fixed-fps', '60', '--write-movie', str(avi), '--script', 'tests/root_bell_runner.gd', '--', '--showcase']
        request = {'command': command, 'environment': {k: env.get(k) for k in ('DISPLAY', 'LIBGL_ALWAYS_SOFTWARE', 'LP_NUM_THREADS', 'GODOT_BIN')}, 'source_before': sources(), 'scope': 'one continuous actual-input fixture, not formal-route/visual/device admission', 'started_epoch': time.time()}
        (folder / 'request.json').write_text(json.dumps(request, indent=2) + '\n')
        with (folder / 'capture.log').open('w') as log:
            result = subprocess.run(command, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=180)
        output = (folder / 'capture.log').read_text()
        require(result.returncode == 0 and 'ERROR:' not in output and re.search(r'^ROOT BELL: [1-9]\d* assertions, 0 failures$', output, re.M), 'actual GPU movie runner failed; preserve original log')
        mp4 = folder / 'showcase.mp4'
        with (folder / 'encode.log').open('w') as log:
            subprocess.run(['flock', LOCK, 'ffmpeg', '-y', '-i', str(avi), '-c:v', 'libx264', '-crf', '20', '-pix_fmt', 'yuv420p', '-c:a', 'aac', str(mp4)], check=True, stdout=log, stderr=subprocess.STDOUT, timeout=120)
        media = json.loads(subprocess.check_output(['flock', LOCK, 'ffprobe', '-v', 'error', '-show_streams', '-show_format', '-of', 'json', str(mp4)], timeout=30))
        video = next(s for s in media['streams'] if s['codec_type'] == 'video')
        audio = next(s for s in media['streams'] if s['codec_type'] == 'audio')
        require(video['avg_frame_rate'] == '60/1' and (video['width'], video['height']) == (1280, 720), 'wrong video format')
        require(int(audio['sample_rate']) == 48000 and audio['channels'] == 2, 'wrong audio format')
        require(sources() == request['source_before'], 'source drift during movie')
        request.update(status='captured', source_after=sources(), finished_epoch=time.time(), exit_code=0, media=media, movie_sha256=sha(mp4), trace_sha256=sha(OUT/'showcase.json'))
        (folder / 'receipt.json').write_text(json.dumps(request, indent=2) + '\n')
        # Keep the original AVI as local evidence; parent decides archival size.
        print('ROOT BELL MOVIE: actual 1280x720 60FPS stereo48k fixture; art/audio judgment unverified')
    finally:
        display.terminate()
        try:
            display.wait(timeout=5)
        except subprocess.TimeoutExpired:
            display.kill()
            display.wait(timeout=5)
        display_log.close()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--movie', action='store_true', help='Record separate single-fight animation fixture after tests')
    parser.add_argument('--movie-only', action='store_true', help='Record fixture on already-imported source; no technical rerun')
    args = parser.parse_args()
    OUT.mkdir(parents=True, exist_ok=True)
    if args.movie_only:
        movie()
        return
    report = {'status': 'failed', 'source_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(), 'source_before': sources(), 'scope': 'G0/G1 actual Motor/collision/projectile/phase/snapshot/placement tests; promotion gated; no independent/device/player approval', 'started_epoch': time.time()}
    try:
        output = run_engine(['--headless', '--path', '.', '--editor', '--quit'], 120)
        (OUT / 'import.log').write_text(output)
        output = run_engine(['--headless', '--path', '.', '--fixed-fps', '60', '--script', 'tests/root_bell_runner.gd'], 120)
        (OUT / 'runtime.log').write_text(output)
        match = re.search(r'^ROOT BELL: ([1-9]\d*) assertions, 0 failures$', output, re.M)
        require(match is not None and 'ERROR:' not in output, 'Missing root-bell completion or engine ERROR')
        capture = json.loads((OUT / 'capture.json').read_text())
        validate_capture(capture)
        report['validator_erasure_rejections'] = tamper_checks(capture)
        require(sources() == report['source_before'], 'source drift during tests')
        report.update(status='passed', assertions=int(match[1]), source_after=sources(), capture_sha256=sha(OUT/'capture.json'), runtime_log_sha256=sha(OUT/'runtime.log'))
        print('PASS: root bell actual fixtures and five evidence erasure rejections; promotion remains gated')
    finally:
        report['finished_epoch'] = time.time()
        (OUT / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
    if args.movie:
        movie()

if __name__ == '__main__':
    main()
