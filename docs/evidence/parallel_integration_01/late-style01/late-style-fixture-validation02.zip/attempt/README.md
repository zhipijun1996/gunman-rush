# Typed02 full-wrapper verification: two passes, one real failure

All runs used frozen helper SHA `5177b16758e1fb9134f1147cc04639c39ca1517e30c0ea8ee6853cbfbdcf4063`, the registered original wrapper arguments/caps and all original assertion/mutation paths. This is a separate source/attempt from failed validation01; neither it nor the earlier CI failures are overwritten.

| Registered check | Actual outer result | Actual native scope |
| --- | --- | --- |
| terrain-family-tests | PASS, exit 0, 97.415s / 720s | Complete original 10 seeds × 2 maps positive, 508 assertions / 0 failures; original negative 55 assertions / exactly 1 expected failure. Both accepted by original wrapper. |
| directed-space-tests | PASS, exit 0, 141.539s / 300s | Both original historical algorithm environments: legacy positive 1133/0, default-branch positive 680/0; original negatives 190/1 and 81/1. Both positives retain 10 seeds × 2 maps. All four original paths accepted. The branch named default is explicitly fenced as historical presentation compatibility, not current pixel-art approval. |
| visual-director-space | FAIL, exit 1, 166.464s / 240s | First eleven original cases accepted (baseline positive, translated-parent positive and nine actual negatives). Twelfth `ferry_graded` encountered a real missing-child/null-material error and reached the unchanged original 90-second child timeout. No GPU probe or final complete source guard was reached. |
| connected-family-tests | NOT RUN | Sequence stopped at the real visual failure. No success is claimed. |

Terrain and directed original reports contain actual stable complete before/after source guards. Visual failed before its own after-guard; `terminal-summary.json` explicitly records that fact. Its separately performed immediate post-failure full source comparison equals the original before-map, but does not retrospectively mark the skipped original guard as executed or passed.

The real failure occurs because the explicit historical terrain fixture still leaves moving-platform `painted_art` as current `PixelMovingPaint`, which has no child zero. The unchanged original `ferry_graded` mutation reads child zero's ShaderMaterial at runner line 216. This is a missing historical test consumer, not evidence that player physics or the pixel production default is faulty. A bounded repair should install the actual original moving-platform shader only in the explicit waterworks fixture, preserving exact body geometry and original negative assertions.

The generic original visual wrapper did not preserve the partial subprocess pipe output on TimeoutExpired. To retain the actual native error honestly, a read-only snapshot of the engine's standard user log was captured while the original failing child was active, plus its persisted terminal bytes after the original timeout. These files are labelled `actual-native-userlog`, with provenance; they are not reconstructed wrapper stdout or a fabricated missing `ferry_graded.json`. The original eleven case JSON/log files, wrapper report and failure process receipt remain byte-exact.

The engine and source-freeze leases were released after the natural terminal failure. No source/assertion/budget modification, forced kill or blind retry was performed by this verifier. Root authorized the eventual next local run to cover only visual+connected after the bounded repair; the two passing typed02 prefixes retain their exact earlier source identity, while final frozen-source complete CI remains required. No player, physical-device or aesthetic acceptance is implied.
