# Late style-consumer audit: four actual failures

Read-only diagnosis before the next complete CI. No production/test/assertion/budget file was changed. Four original Harness wrappers ran sequentially once each, with their exact registered arguments and limits. Each stopped at its own first invalid positive prefix; their later negative cases were not executed and are not claimed passed. The earlier CI failures remain separate failed runs.

| Check | Actual outer result | Native evidence | Cause |
| --- | --- | --- | --- |
| terrain-family-tests | exit 1, 53.093s | 162 assertions, 60 failures, missing-meta/script errors | Actual `PlainsTerrainStudy.art` is now `PixelFormalTerrain`; original test expects `family_entries`, sampled old panel sources and `one_way_baseline_count`. |
| directed-space-tests | exit 1, 32.232s | legacy positive: 70 assertions, 20 failures | Environment chooses a legacy assertion branch, but does not construct the absent `PlainsSemanticLandscape` consumer. The original wrapper correctly stops before negatives/default branch. |
| visual-director-space | exit 1, 5.826s | positive: 7 assertions, 1 failure | `--legacy-waterworks-contract` selects a contract but cannot create the old `PlainsRegionComposition` tree; actual `PlainsVisualSpace` count is zero. |
| connected-family-tests | exit 1, 6.776s | 6 assertions, 1 failure | Actual current stage has no `ConnectedLandscape` node. The old family test never reaches its real plant fault injections. |

Source guards: directed's original before/after guard is stable; connected's original before/after hashes are equal. Terrain and visual fail before their original after-guard code. A separately recorded immediate read-only post-failure comparison against each original before-map is exactly equal; this does not retrospectively claim those skipped original guards ran. See `source-guard-observations.json`.

## False positives excluded

`plains-autonomy-golden` is **already passed in the exact CI5 serial report**, as check five. Its actual registered Python tool sees the current `plains-region-v10` generator compatibility marker and restores the retained exact v9 source/assets, then overlays only post-observation teardown. Running the current repository's slice runner directly would not execute that registered check and would produce a misleading diagnosis. No duplicate autonomy run or frozen cache copy was made.

Painterly background tests construct the actual `PlainsBackground` component in isolation with explicit historical switches. Pressure/Boss tests separately retain historical renderer fixtures and inspect the actual current `PixelPlainsParallax` default. Joint-recoil shader tests instantiate their named candidate composer explicitly, rather than asserting that the default current stage uses it. Terrain production/tile and shared-player component tests have actual direct consumers and already passed CI5 where applicable. These were not reclassified as missing-default failures merely because they mention ShaderMaterial or old assets.

Another actual tooling limitation, not asserted as an already reproduced imminent CI failure: `tools/level_formal_capture.gd::scenery_inventory` still recognizes only old `PlainsRegionScenery`. Current-pixel captures can therefore lack `initial_scenery_inventory`, which `visual_director.load_capture` requires. Previously passed formal-runtime tests do not establish that visual-capture inventory contract. This needs a real current-pixel inventory consumer, not fabricated manifest rows. `plains_connected_landscape_runner.gd` also expects the absent old composition, but it is not directly selected by the audited registered CI check list.

## Minimal repair proposal — not implemented here

Use one explicit test-only historical presentation fixture shared by these four existing suites, installed only by their historical branches on real formal gameplay geometry. Construct the retained old production scenery/composition/family-sampler classes there, with original bounds, source, support, fault injections and assertion bodies intact. For the family suite, preserve the original sampler implementation from its actual historical production bytes rather than substituting pixel output under an old name. Keep historical environment/flags and report scope explicit; a flag alone is insufficient without an actual consumer.

Keep the ordinary game entry and production defaults pixel-only. Verify their actual pixel terrain/nodes/material/physical bounds independently through the existing pixel-formal/current-scene contracts, including the already exercised original eight-route scene positive, ten actual mutations and twelve forged-output negatives. Where a suite also labels a branch current/default, that branch must inspect actual pixel nodes or be explicitly versioned as historical, with current-pixel acceptance added in the same existing workflow. Do not call an old fixture a successful current-default check, remove old assertions, broaden allowed types to accept absent consumers, restore rejected old artwork to the game, or add another production pipeline.

Implementation requires root authorization and independent review. No engine is left running under this diagnostic lease; source freeze was released after the separate source comparison finished.
