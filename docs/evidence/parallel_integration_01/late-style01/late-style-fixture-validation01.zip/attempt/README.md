# First actual historical-fixture validation — failed

The standard cold editor invocation passed in 7.156s with exit 0 and no strict native diagnostics. That result did not establish that every preloaded dependency compiles when a real runner is executed.

The first unchanged registered `terrain-family-tests` wrapper then failed in 40.403s, exit 1. Its actual positive child reports `legacy_plains_presentation_fixture.gd:109`: `Cannot infer the type of "refused_cleanly" variable because the value doesn't have a set type`. The helper preload failed and `prepare` was consequently unavailable. The original unchanged assertions then rejected the still-current pixel terrain. No failure was masked and no budget or check was relaxed.

The sequence stopped on this first real failure. Directed-space, visual-space and connected-family were **not executed in this attempt**. No blind retry occurred. The engine and source-freeze leases were released after the child and wrapper naturally terminated.

The original wrapper fails before its normal source-after guard. A separate immediate selected-file comparison records unchanged helper/runner/wrapper/profile hashes against the original before-snapshot; this is not a claim that the skipped complete after-guard ran. The exact raw import/positive/outer logs, original native JSON/report and actual process receipts are retained. No production or test source was edited by the verifier.

A bounded author repair should explicitly type the Variant-derived Boolean expression and inspect similar inferred expressions. A standard Godot `--check-only --script` preflight on the actual runner can exercise the preload before the next full original wrapper, without replacing the complete acceptance run. This failure remains a failed historical attempt even if a later source passes.
