from pathlib import Path
import sys,json,time,hashlib
from PIL import Image,ImageDraw
sys.path.insert(0,'tools');from studio_gui_pointer import _studio_actions_from_pixels,_studio_button_boxes
out=Path(__file__).parent;rows=[]
for name,src in [('desktop',Path('build/integration01/ci-artifact-browser06/browser-cwd/build/studio-navigation/1792414572955230108/development-0.png')),('mobile',Path('build/studio-navigation/1792415377115368766/development-0.png'))]:
 obs={};start=time.monotonic()
 try:obs.update(point=_studio_actions_from_pixels(src.read_bytes(),out,name,obs),status='passed')
 except Exception as e:obs.update(status='failed',error=str(e))
 obs.update(case=name,source=str(src),source_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),seconds=time.monotonic()-start);rows.append(obs);print(name,obs['status'],obs.get('point'),obs.get('error'),flush=True)
im=Image.new('RGB',(1600,1200),(239,225,198));d=ImageDraw.Draw(im)
for y in range(6):
 for x in range(6):d.rectangle((20+x*250,20+y*150,220+x*250,65+y*150),outline=(43,112,103),width=1)
im.save(out/'overflow.png')
try:_studio_button_boxes(im);raise RuntimeError('Accepted overflow')
except AssertionError as e:rows.append({'case':'candidate-overflow','rejected':True,'error':str(e)});print('overflow refused',flush=True)
(out/'actual-controls.json').write_text(json.dumps({'helper_sha256':hashlib.sha256(Path('tools/studio_gui_pointer.py').read_bytes()).hexdigest(),'cases':rows},indent=2)+'\n');assert all(r.get('status')=='passed'or r.get('rejected')for r in rows)
