from pathlib import Path
import csv,hashlib,io,json,os,subprocess,sys,time
from PIL import Image
root=Path('/workspace/gunman-rush-design');sys.path.insert(0,str(root/'tools'))
from studio_gui_pointer import _studio_label_box
out=Path(__file__).parent;src=root/'build/integration01/ci-artifact-browser06/browser-cwd/build/studio-navigation/1792414572955230108/development-0.png';im=Image.open(src).convert('L');records=[]
for name,scale,psm in [('bilingual3-11',3,11),('bilingual6-11',6,11),('bilingual3-6',3,6)]:
 p=out/(name+'.png');im.resize((im.width*scale,im.height*scale)).save(p);start=time.monotonic();r=subprocess.run(['tesseract',str(p),'stdout','--tessdata-dir',str(out/'tessdata'),'-l','eng+chi_sim','--psm',str(psm),'tsv'],capture_output=True,text=True,timeout=15,env={**os.environ,'OMP_THREAD_LIMIT':'1'});(out/(name+'.tsv')).write_text(r.stdout);(out/(name+'.stderr')).write_text(r.stderr)
 row={'name':name,'scale':scale,'psm':psm,'duration_seconds':time.monotonic()-start,'exit_code':r.returncode,'image_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'tsv_sha256':hashlib.sha256(r.stdout.encode()).hexdigest()}
 try:row.update(strict_parser='accepted',point=_studio_label_box(r.stdout,'ACTIONS',scale))
 except AssertionError as e:row.update(strict_parser='rejected',error=str(e))
 row['ACTIONS_ocr_rows']=[w for w in csv.DictReader(io.StringIO(r.stdout),delimiter='\t')if 'ACTION'in w.get('text','').upper()];records.append(row);print(name,row,flush=True)
(out/'language-report.json').write_text(json.dumps({'scope':'Offline exact same screenshot plus pinned chi_sim dependency; unchanged strict parser','source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'helper_sha256':hashlib.sha256((root/'tools/studio_gui_pointer.py').read_bytes()).hexdigest(),'cases':records},indent=2)+'\n')
