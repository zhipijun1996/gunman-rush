from pathlib import Path
from PIL import Image
from collections import Counter,deque
import csv,hashlib,io,json,os,subprocess,sys,time
root=Path('/workspace/gunman-rush-design');sys.path.insert(0,str(root/'tools'))
from studio_gui_pointer import _studio_label_box
out=Path(__file__).parent
src=root/'build/integration01/ci-artifact-browser06/browser-cwd/build/studio-navigation/1792414572955230108/development-0.png'
im=Image.open(src).convert('RGB');w,h=im.size
colors=[rgb for rgb,n in Counter(im.getdata()).most_common(16)]
candidates=set()
for color in colors:
 pixels={(i%w,i//w) for i,c in enumerate(im.getdata())if c==color}
 while pixels:
  seed=pixels.pop();todo=[seed];left=right=seed[0];top=bottom=seed[1];n=0
  while todo:
   x,y=todo.pop();n+=1;left=min(left,x);right=max(right,x);top=min(top,y);bottom=max(bottom,y)
   for pt in ((x-1,y),(x+1,y),(x,y-1),(x,y+1)):
    if pt in pixels:pixels.remove(pt);todo.append(pt)
  bw=right-left+1;bh=bottom-top+1
  if 80<=bw<=w*.9 and 20<=bh<=h*.15 and 2<=bw/bh<=24 and n/(bw*bh)<.6:candidates.add((left,top,right+1,bottom+1))
records=[]
for idx,box in enumerate(sorted(candidates)):
 name=f'roi-{idx}';p=out/(name+'.png');roi=im.crop(box).convert('L');roi.resize((roi.width*6,roi.height*6),Image.Resampling.NEAREST).save(p)
 start=time.monotonic();r=subprocess.run(['tesseract',str(p),'stdout','--psm','7','tsv'],capture_output=True,text=True,timeout=10,env={**os.environ,'OMP_THREAD_LIMIT':'1'});(out/(name+'.tsv')).write_text(r.stdout)
 row={'name':name,'box':box,'duration_seconds':time.monotonic()-start,'exit_code':r.returncode,'image_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'tsv_sha256':hashlib.sha256(r.stdout.encode()).hexdigest(),'text':' '.join(z['text'] for z in csv.DictReader(io.StringIO(r.stdout),delimiter='\t')if z.get('text','').strip())}
 try:
  x,y=_studio_label_box(r.stdout,'ACTIONS',6);row.update(strict_parser='accepted',local_point=[x,y],actual_point=[x+box[0],y+box[1]])
 except AssertionError as e:row.update(strict_parser='rejected',error=str(e))
 records.append(row);print(name,box,row['strict_parser'],row['text'],flush=True)
(out/'roi-report.json').write_text(json.dumps({'scope':'Offline bounded screenshot-derived frequent-color connected outline crops; unchanged exact parser; no fixed button coordinates/no live input','source':str(src),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'limits':{'colors':16,'width':[80,w*.9],'height':[20,h*.15],'aspect':[2,24],'max_fill':.6,'scale':6,'resampling':'NEAREST','psm':7},'candidates':records},indent=2)+'\n')
