from pathlib import Path
import csv,hashlib,io,json,os,subprocess,sys,time
from PIL import Image
ROOT=Path('/workspace/gunman-rush-design');sys.path.insert(0,str(ROOT/'tools'))
from studio_gui_pointer import _studio_label_box
out=Path(__file__).resolve().parent
source=ROOT/'build/integration01/ci-artifact-browser06/browser-cwd/build/studio-navigation/1792414572955230108/development-0.png'
im=Image.open(source).convert('L');records=[]
for name,method,psm in [('nearest11',Image.Resampling.NEAREST,'11'),('lanczos11',Image.Resampling.LANCZOS,'11'),('nearest6',Image.Resampling.NEAREST,'6'),('lanczos6',Image.Resampling.LANCZOS,'6')]:
 start=time.monotonic();p=out/(name+'.png');im.resize((im.width*6,im.height*6),method).save(p)
 r=subprocess.run(['tesseract',str(p),'stdout','--psm',psm,'tsv'],capture_output=True,text=True,timeout=10,env={**os.environ,'OMP_THREAD_LIMIT':'1'});(out/(name+'.tsv')).write_text(r.stdout);(out/(name+'.stderr')).write_text(r.stderr)
 row={'name':name,'scale':6,'filter':name.split(str(psm))[0],'psm':psm,'exit_code':r.returncode,'duration_seconds':time.monotonic()-start,'image_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'tsv_sha256':hashlib.sha256(r.stdout.encode()).hexdigest()}
 try:row.update(strict_parser='accepted',point=_studio_label_box(r.stdout,'ACTIONS',6))
 except AssertionError as e:row.update(strict_parser='rejected',error=str(e))
 row['ACTIONS_ocr_rows']=[w for w in csv.DictReader(io.StringIO(r.stdout),delimiter='\t')if 'ACTION'in w.get('text','').upper()]
 records.append(row);print(name,row['strict_parser'],row.get('point'),row['duration_seconds'],flush=True)
(out/'report.json').write_text(json.dumps({'scope':'Bounded four same-source screenshot preprocess diagnostics; no live game/input, no tracked edits','source':str(source),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'helper_sha256':hashlib.sha256((ROOT/'tools/studio_gui_pointer.py').read_bytes()).hexdigest(),'cases':records},indent=2)+'\n')
