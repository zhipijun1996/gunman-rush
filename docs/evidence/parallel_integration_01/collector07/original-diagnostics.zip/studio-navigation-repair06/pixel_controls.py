from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import io,sys,json,time,hashlib
root=Path('/workspace/gunman-rush-design');sys.path.insert(0,str(root/'tools'))
from studio_gui_pointer import _studio_actions_from_pixels
out=Path(__file__).parent;source=root/'build/integration01/ci-artifact-browser06/browser-cwd/build/studio-navigation/1792414572955230108/development-0.png';original=Image.open(source).convert('RGB');button=original.crop((254,272,452,318));bg=(239,225,198);green=(43,112,103);cases={}
im=original.copy();im.paste(button,(254,350));cases['duplicate_actual_button']=im
im=Image.new('RGB',original.size,bg);im.paste(button.crop((5,5,193,41)),(259,277));cases['actual_text_without_frame']=im
cases['blank']=Image.new('RGB',original.size,bg)
im=Image.new('RGB',original.size,bg);draw=ImageDraw.Draw(im);draw.rectangle((254,272,610,317),outline=green,width=1);im.paste(button.crop((4,4,194,42)),(258,276));font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',18);draw.text((455,285),'EXTRA',font=font,fill=green);cases['actual_actions_with_visible_suffix']=im
rows=[]
for name,im in cases.items():
 path=out/(name+'.png');im.save(path);obs={};start=time.monotonic()
 try:
  point=_studio_actions_from_pixels(path.read_bytes(),out,name,obs);obs.update(rejected=False,unexpected_point=point)
 except AssertionError as e:obs.update(rejected=True,error=str(e))
 obs.update(case=name,input_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),seconds=time.monotonic()-start);rows.append(obs);print(name,obs['rejected'],obs.get('error'),flush=True)
(out/'pixel-controls.json').write_text(json.dumps({'helper_sha256':hashlib.sha256((root/'tools/studio_gui_pointer.py').read_bytes()).hexdigest(),'scope':'Offline rendered-pixel counterexamples using actual CI6 ACTIONS glyphs; not gameplay evidence','cases':rows},indent=2)+'\n');assert all(r['rejected']for r in rows)
