from pathlib import Path
import os,subprocess,hashlib,json,sys,time,re,traceback
sys.path.insert(0,'tools')
from run_tests import run_engine
r=Path('build/integration01/menu-loading-graph-counterfactual03');p=Path('scripts/ui/demo_menu.gd');original=p.read_bytes();assert original.startswith(b'@static_unload\n');old=original.removeprefix(b'@static_unload\n');stat=p.stat();sha=lambda x:hashlib.sha256(x).hexdigest()
(r/'current_menu.gd.source').write_bytes(original);(r/'counterfactual_menu_no_annotation.gd.source').write_bytes(old);(r/'head64_menu.gd.source').write_bytes(subprocess.check_output(['git','show','64e6c7a4:scripts/ui/demo_menu.gd']))
test=Path('tests/menu_scroll_touch_tests.gd').read_bytes();(r/'original43.gd.source').write_bytes(test)
receipt={'current_menu_sha256':sha(original),'counterfactual_menu_sha256':sha(old),'original43_sha256':sha(test),'original_mtime_ns':stat.st_mtime_ns,'scope':'one exact original43 counterfactual only: only first @static_unload annotation removed from current DemoMenu; finally restore bytes and atime/mtime; strict run_engine120 verbose; does not certify current source','tracked_status_before':subprocess.check_output(['git','status','--porcelain'],text=True)}
(r/'before.json').write_text(json.dumps(receipt,indent=2)+'\n');result={'timeout':120,'strict_guard':True};start=time.monotonic()
try:
 p.write_bytes(old)
 assert p.read_bytes()==old
 out=run_engine(['--headless','--fixed-fps','60','--verbose','--path','.','--script','tests/menu_scroll_touch_tests.gd'],120)
 if not re.search(r'^MENU SCROLL TOUCH: 43 checks / 0 failures; native GUI lifecycle only, Web scrolling separate$',out,re.M):raise RuntimeError('Missing original43 clean completion')
 result.update(exit_code=0,completed43=True)
except Exception as e:
 result.update(exit_code=1,error=repr(e));traceback.print_exc()
finally:
 p.write_bytes(original);os.utime(p,ns=(stat.st_atime_ns,stat.st_mtime_ns))
 result.update(seconds=time.monotonic()-start,restored_menu_sha256=sha(p.read_bytes()),restored_mtime_ns=p.stat().st_mtime_ns,source43_unchanged=Path('tests/menu_scroll_touch_tests.gd').read_bytes()==test,tracked_status_after=subprocess.check_output(['git','status','--porcelain'],text=True))
 result['exact_rollback']=result['restored_menu_sha256']==receipt['current_menu_sha256'] and result['restored_mtime_ns']==receipt['original_mtime_ns'] and result['tracked_status_after']==receipt['tracked_status_before']
 (r/'result.json').write_text(json.dumps(result,indent=2)+'\n')
 assert result['exact_rollback'] and result['source43_unchanged']
sys.exit(result['exit_code'])
