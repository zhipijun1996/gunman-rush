Selected original evidence09, not a release approval

CI8 source64 fullCI FAILED and deployment was skipped. Its local73/23/20 are prior-source evidence only. Current dirty PR94 has core and limited scenery/pipeline passes, but shared03 strict menu teardown still FAILS49ObjectDB/37resources. All4 counterfactuals fail; actual SCC retention root remainsUNKNOWN. Two-worker has11fixture tests and bounded review only, not a true80 pass.

Original bytes are SHA-bound in selection-manifest.json. The huge dirty targeted report is deliberately omitted; its clearly marked metadata projection and original SHA are included. WebZIPs, raw captures, videos and other full archives remain outside this small bundle in custody/Vault. No private publisher checkpoint or signed download URL is included. No source64 result is approval for the new main/PR94 preview.
