# Original positive-child diagnosis

This is one actual local diagnostic invocation of the original positive Godot child, with its original 180-second limit and success marker. It is not the missing CI child receipt and not a successful complete wrapper/profile.

Result: 179.535 seconds, exit 0, 91 assertions / 0 failures. All eight routes actually reached their targets, each with zero observed issues. Evaluating the original wrapper's `cleanup_valid` expression directly from its AST returned true for eight cleanup rows. The original malformed/error/leak expression found nothing. Calling the unchanged `errors(data)` function returned exactly eight errors: `missing actual four-identity composition consumer`.

Root cause: `PlainsRegionStage` now creates `PixelRegionScenery`; `scene_inventory` still collects only `PlainsRegionScenery`. Consequently every actual route records `scenery: []`. The new pixel implementation currently contains generic supported atlas props and no distinct four-area composition identities. The original assertion therefore correctly refuses the missing evidence. Merely labeling generic props with four identity strings would not establish four compositions. The old `floating_landmark` fault injection also searches only the old class and needs a genuine new pixel consumer before its corresponding negative can remain meaningful.

Minimal honest repair direction: keep the eight-route, identity, physical support, viewport, actual-body, mutation and cleanup checks. Implement distinct, readable landmarks for the four existing gameplay-space roles in the current pixel presentation (new assets/geometry consistent with the latest art foundation; no resurrection of rejected old artwork), with actual instantiated support/placement/bounds receipts. Extend the actual scene observer and floating-landmark mutation to that real new consumer, while retaining old-class coverage for compatibility. Do not synthesize scenery rows from the generation manifest alone or waive empty scenery.

Separately add the existing `build/plains_redesign/scene` output tree to the original Harness check's `artifact_paths`, so future CI failures retain their real positive/receipt files. This does not repair the content or retroactively recover the unavailable CI JSON. It only closes the observability gap.

The local runtime is close to the original child budget; the CI outer failure at approximately 115 seconds was a contract rejection, not its 900-second wrapper timeout. No budget increase or assertion relaxation is justified. Local timings do not prove CI performance, and this diagnostic does not sign art, human experience or device acceptance.

No production, test or Harness file was changed by this task. `diagnosis.json` binds the actual JSON/log/process bytes; no further engine is running under this diagnostic's lease.
