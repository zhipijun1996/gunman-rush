"""Freeze an exact committed host/native/PCK triplet. Starts no server/browser/engine."""
import argparse,hashlib,json,os,re,shlex,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
BASE=Path(__file__).resolve().parent
SCENES={'default':'res://experiments/generation/runtime_map_generated_slice.tscn','gears':'res://experiments/generation/runtime_map_m35_slice.tscn','windchime':'res://experiments/generation/runtime_map_windchime_slice.tscn'}
MARKERS={'default':'RUNTIME_MAP_GENERATED_SLICE','gears':'RUNTIME_MAP_M35_RUNTIME','windchime':'RUNTIME_MAP_WINDCHIME_GENERATED'}
def sha(path):
    with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def extract_expected(log,source,mode):
    text=Path(log).read_text();markers=re.findall(r'^'+MARKERS[mode]+r' checks=(\d+) failures=(\d+)\s*$',text,re.M)
    assert len(markers)==1 and int(markers[0][0])>0 and markers[0][1]=='0','Native completion failed/missing/ambiguous'
    assert not re.search(r'^(?:SCRIPT ERROR|ERROR:|WARNING: ObjectDB instances leaked|ERROR: Resources still in use)',text,re.M),'Native errors/leaks cannot supply expectations'
    events={k:[] for k in ['MAPGEN_RUNTIME ','MAPGEN_HOST_V2 ','MAPGEN_WINDCHIME ']}
    for line in text.splitlines():
        for prefix,rows in events.items():
            if line.startswith(prefix):rows.append(json.loads(line[len(prefix):]))
    seed=930007 if mode=='gears' else 930001
    committed=[v for v in events['MAPGEN_RUNTIME '] if v.get('event')=='committed' and v.get('output',{}).get('seed')==seed]
    assert committed,'No matching actual committed output'
    receipt=committed[0];identity=receipt['identity'];host=identity['host_load_identity']
    assert all(v['identity']==identity and v['output']==receipt['output'] for v in committed),'Ambiguous actual native outputs'
    assert identity['source_kind']==receipt['source_kind']=='generated_memory'
    assert identity['map_content']['implementation']=='mapgen/gdscript-candidate-0.4.1'
    assert identity['source_receipt']['algorithm_package']['version']=='0.4.1'
    loaded=[v for v in events['MAPGEN_HOST_V2 '] if v.get('event')=='loaded' and v.get('host_load_identity')==host]
    assert loaded,'No actual matching loaded observation'
    sample=loaded[0];assert sample['player']==identity['host_load']['spawn']
    assert receipt['output']['status']=='PASS'
    expected=dict(schema='gunman-rush/mapgen04-browser-expected/v1',source=source,scene=SCENES[mode],sdk_implementation='mapgen/gdscript-candidate-0.4.1',input_profile='gears_conformance' if mode=='gears' else 'conformance',runtime_profile=receipt['profile'],actual_generated_output=receipt['output'],spawn=sample['player'],selected_instances=identity['host_load']['selected_instances'],host_load_identity=host,map_content_identity=identity['map_content_identity'],native_proof_file=str(Path(log).resolve()),native_proof_sha256=sha(log))
    if mode=='gears':
        assert len(sample['mechanisms'])==len(sample['static_contacts'])==1
        module=sample['mechanisms'][0];contact=sample['static_contacts'][0]
        assert expected['selected_instances']==[module['instance_id']]
        assert len(module['ferries'])==2 and len(module['saws'])==1 and all(contact[k] is True for k in ['enabled','shared_policy','fall_plane'])
        expected['mechanisms']=dict(ferry_ids=[v['id'] for v in module['ferries']],saw_ids=[v['id'] for v in module['saws']],static_contact_rect=contact['rect'])
    elif mode=='windchime':
        assert receipt['profile']=='controller' and len(sample['mechanisms'])==len(expected['selected_instances'])==1
        rows=[v for v in events['MAPGEN_WINDCHIME '] if v.get('event')=='committed']
        assert len(rows)==1 and rows[0].get('neighbor_loaded') is False and rows[0].get('scope')=='complete_owned_start_module_only'
        start=rows[0];assert start['exit_port']=='exit' and len(start['latches'])==1
        latch=start['latches'][0];assert latch['instance_id']==expected['selected_instances'][0] and latch['latch_id']=='windchime_plains_windchime_lesson'
        assert not latch['is_open'] and latch['open_count']==0 and not latch['gate_disabled']
        expected.update(exit_bank_world=start['exit_bank_world'],latch_id=latch['latch_id'],bell_world=latch['bell_world'],gate_world=latch['gate_world'],scope='complete_owned_start_module_only; neighbor not loaded')
    else:
        assert len(sample['mechanisms'])==len(expected['selected_instances'])==3
        assert sample.get('carrier') is not None
    return expected

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--mode',choices=SCENES,required=True)
    for n in ['source-root','bundle','native-log','output']:p.add_argument('--'+n,type=Path,required=True)
    for n in ['source','pack-sha256']:p.add_argument('--'+n,required=True)
    p.add_argument('--pack-bytes',type=int,required=True);p.add_argument('--port',type=int,required=True);a=p.parse_args()
    root=a.source_root.resolve();bundle=a.bundle.resolve();scene=SCENES[a.mode]
    assert re.fullmatch('[0-9a-f]{40}',a.source) and re.fullmatch('[0-9a-f]{64}',a.pack_sha256) and a.pack_bytes>0
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==a.source
    assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip(),'Freeze/commit source before staging'
    expected=extract_expected(a.native_log.resolve(),a.source,a.mode)
    sys.path.insert(0,str(root/'tools'))
    from cloud_delivery import validate_bundle,inject_entry
    info,validation=validate_bundle(bundle,root,scene)
    assert info['source_commit']==a.source and validation['pack_sha256']==a.pack_sha256 and validation['pack_bytes']==a.pack_bytes
    out=a.output.resolve();out.mkdir(parents=True,exist_ok=False);site=out/'site';site.mkdir()
    assert site.stat().st_dev==bundle.stat().st_dev,'Stage on bundle filesystem for original no-copy hardlink contract'
    original=(bundle/'index.html').read_text();injected=inject_entry(original,'MAPGEN-HOST-WINDCHIME-041',str(expected['actual_generated_output']['seed']),'scene',scene)
    links=[]
    for src in sorted(bundle.rglob('*')):
        assert not src.is_symlink();target=site/src.relative_to(bundle)
        if src.is_dir():target.mkdir(exist_ok=True)
        elif src==bundle/'index.html':target.write_text(injected)
        else:
            os.link(src,target);assert (src.stat().st_dev,src.stat().st_ino)==(target.stat().st_dev,target.stat().st_ino)
            links.append(dict(path=src.relative_to(bundle).as_posix(),bytes=src.stat().st_size,dev=src.stat().st_dev,inode=src.stat().st_ino))
    expected_path=out/'expected-native.json';expected_path.write_text(json.dumps(expected,indent=2)+'\n')
    receipt=dict(source=a.source,mode=a.mode,pack_sha256=a.pack_sha256,pack_bytes=a.pack_bytes,native_proof_file=expected['native_proof_file'],native_proof_sha256=expected['native_proof_sha256'],validation=validation,url=f'http://127.0.0.1:{a.port}/',site=str(site),original_index_sha256=sha(bundle/'index.html'),injected_index_sha256=sha(site/'index.html'),hardlinks=links,large_site_copy=False,published=False)
    receipt_path=out/'stage-receipt.json';receipt_path.write_text(json.dumps(receipt,indent=2)+'\n')
    driver=BASE/(a.mode+'_driver.py');argv=['python3','-B',str(driver),'--source-root',str(root),'--bundle',str(bundle),'--output',str(out/'actual'),'--commands',str(out/'commands'),'--ocr-prefix','/workspace/refactor-evidence/mapgen-host-04-acceptance-rescue/browser-tools/ocr-data','--source',a.source,'--url',receipt['url'],'--pack-sha256',a.pack_sha256,'--pack-bytes',str(a.pack_bytes),'--expected-host-load-identity',expected['host_load_identity'],'--expected-observation',str(expected_path)]
    producers=[*sorted(BASE.glob('*.py')),*sorted(BASE.glob('*.json')),receipt_path,site/'index.html',root/'tools/build.py',root/'tools/cloud_delivery.py',root/'tools/mobile_web_perf/serve_coi.py',root/'experiments/generation/runtime_map_verified_library_cache.gd',root/'game/world/levels/content/runtime_map_port_admission.gd',root/'game/world/levels/content/runtime_map_shot_latch_adapter.gd',root/'game/world/components/runtime_map_shot_latch_encounter.gd']
    for path in producers:assert path.is_file();argv.extend(['--producer-file',str(path)])
    (out/'run-argv.json').write_text(json.dumps(argv,indent=2)+'\n');(out/'run.sh').write_text('#!/bin/sh\nset -eu\nexec '+shlex.join(argv)+'\n')
    serve=['python3','-B',str(root/'tools/mobile_web_perf/serve_coi.py'),'--directory',str(site),'--port',str(a.port)]
    (out/'serve.sh').write_text('#!/bin/sh\nset -eu\nexec '+shlex.join(serve)+'\n')
    (out/'recovery-producers.json').write_text(json.dumps({str(x):sha(x) for x in [driver,*producers]},indent=2)+'\n')
    print(json.dumps(dict(status='STAGED_ONLY_NOT_RUN',output=str(out),expected=expected),indent=2))
if __name__=='__main__':main()
