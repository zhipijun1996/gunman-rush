"""Execute actual two-session driver against explicit fake browser, never real Web."""
import asyncio,importlib.util,json,sys,time,unittest
from pathlib import Path
from types import SimpleNamespace as NS
import test_gears as base
import default_offline_review as review
BASE=Path(__file__).resolve().parent
class Fixture(base.Fixture):
    def __init__(self,fault=None):
        super().__init__(fault)
        old=self.m;spec=importlib.util.spec_from_file_location('actual_default_driver',BASE/'default_driver.py');self.m=importlib.util.module_from_spec(spec);spec.loader.exec_module(self.m)
        for name in ['helpers','time','asyncio']:setattr(self.m,name,getattr(old,name))
        self.output['seed']=930001;self.identity['source_receipt']['request']['seed']=930001
        self.expected.update(scene=self.m.SCENE,input_profile='conformance');self.expected['actual_generated_output']=self.output
        self.expected_path.write_text(json.dumps(self.expected))
        self.config['conformance']=self.config['gears_conformance'];self.put('config/mapgen_candidate.json',json.dumps(self.config).encode());self.put('resources/request.json',json.dumps(dict(seed=930001)).encode())
        self.put(self.m.SCENE.removeprefix('res://'),b'pure fake default scene')
        self.html='/* cloud-preview-entry */ args: '+json.dumps(['--cloud-preview','--entry=scene','--scene='+self.m.SCENE])+',';(self.bundle/'index.html').write_text(self.html)
        self.player_x=474.;self.axis=0.;self.sessions=0;self.playwright_module.async_playwright=lambda:FakePlaywright(self)
    def host_value(self,event):
        value=super().host_value(event)
        if not(self.fault=='spawn' and event=='loaded'):value['player']=[self.player_x,974.]
        value['carrier']=[self.module_clock*4.,0.];return value
    async def sleep(self,delay):
        self.player_x+=self.axis*15
        await super().sleep(delay)
class FakePlaywright(base.FakePlaywright):
    async def launch(self,**kwargs):return FakeBrowser(self.o)
class FakeBrowser(base.FakeBrowser):
    async def new_context(self,**kwargs):self.o.sessions+=1;return FakeContext(self.o)
class FakeContext(base.FakeContext):
    async def new_page(self):self.o.page=FakePage(self.o);return self.o.page
class FakePage(base.FakePage):
    def __init__(self,o):
        super().__init__(o);self.keyboard=NS(press=self.press,down=self.down,up=self.up)
    async def goto(self,*a,**kwargs):
        self.o.closed=False
        if self.o.sessions==1:await super().goto(*a,**kwargs)
        else:
            for event in ['started','preload','generate']:self.o.emit(self.o.m.RUNTIME_PREFIX,self.o.runtime(event))
    async def down(self,key):self.o.axis=1 if key=='d' else -1
    async def up(self,key):self.o.axis=0.
    async def press(self,key):
        await super().press(key)
        if self.o.sessions==2:self.o.emit(self.o.m.RUNTIME_PREFIX,dict(event='source_closed',closed=True,phase='cancelled'))
        # Replace first source_closed observation before synchronous wait tests it.
        if self.o.sessions==2:
            row=self.o.report['sessions'][-1]
            for item in row['runtime_observations']:
                if item['value'].get('event')=='source_closed':item['value']['phase']='cancelled'
class ExecutionTests(unittest.TestCase):
    def run_case(self,fault=None):
        f=Fixture(fault);self.addCleanup(f.temp.cleanup);return f,asyncio.run(f.execute())
    def test_two_fresh_complete_pending_and_six_images(self):
        f,r=self.run_case();self.assertEqual(r['status'],review.PENDING);self.assertEqual(f.sessions,2);self.assertEqual(sum(len(v['screenshots']) for v in r['sessions']),6);review.validate_report(f.args.output/'report.json')
    def test_original_guards_and_failure_semantics(self):
        for fault in ['timeout','source','afterguard-error','page','spawn','missing-title','cleanup','latecommit','missing-marker','missing-image']:
            with self.subTest(fault=fault):
                f,r=self.run_case(fault);self.assertNotEqual(r['status'],review.PENDING)
                with self.assertRaises(ValueError):review.validate_report(f.args.output/'report.json')
class JoinTests(unittest.TestCase):
    def setUp(self):
        self.f=Fixture();self.addCleanup(self.f.temp.cleanup);asyncio.run(self.f.execute());self.report=self.f.args.output/'report.json';self.review=self.f.base/'review.json';self.output=self.f.base/'acceptance.json'
        review.begin(self.report,self.review,'PURE_TEST_INDEPENDENT_REVIEWER')
    def complete_synthetic_review(self):
        value=review.read(self.review);now=time.time()*1000
        value['records']=[dict(file=item['file'],capture_sha256=item['sha256'],decision='pass',method=review.ACTUAL_VIEW_METHOD,notes='PURE_SYNTHETIC_REVIEW_FIXTURE only; no actual view or real acceptance',started_epoch_ms=now,finished_epoch_ms=now) for item in value['captures']]
        self.review.write_text(json.dumps(value))
    def test_strict_join_positive_fixture_and_no_overwrite(self):
        self.complete_synthetic_review();value=review.finish(self.report,self.review,self.output);self.assertTrue(value['status'].startswith('PASSED'))
        for path in [self.report,self.review,self.output,self.f.args.output/review.FILES[0]]:
            before=path.read_bytes()
            with self.assertRaises(ValueError):review.finish(self.report,self.review,path)
            self.assertEqual(path.read_bytes(),before)
    def test_missing_review_empty_pass_wrong_sha_nan_and_late_ack_rejected(self):
        initial=self.review.read_bytes()
        for fault in ['missing','empty-notes','empty-method','automatic-method','wrong-sha','nan-time','late-ack','failed-auto','nan-budget','capture-change','missing-capture']:
            with self.subTest(fault=fault):
                self.review.write_bytes(initial);self.complete_synthetic_review();v=review.read(self.review);raw_report=self.report.read_bytes();pic=self.f.args.output/review.FILES[0];raw_pic=pic.read_bytes()
                if fault=='missing':v['records'].pop()
                if fault=='empty-notes':v['records'][0]['notes']=''
                if fault=='empty-method':v['records'][0]['method']=''
                if fault=='automatic-method':v['records'][0]['method']='automatic-unseen-approval'
                if fault=='wrong-sha':v['records'][0]['capture_sha256']='0'*64
                if fault=='nan-time':v['records'][0]['finished_epoch_ms']=float('nan')
                if fault=='late-ack':v=dict(seq=3,action='confirm-title',passed=True)
                if fault in ['failed-auto','nan-budget']:
                    r=json.loads(raw_report)
                    if fault=='failed-auto':r['status']='FAILED'
                    else:r['elapsed_seconds']=float('nan')
                    self.report.write_text(json.dumps(r))
                if fault=='capture-change':pic.write_bytes(b'wrong bytes')
                if fault=='missing-capture':pic.unlink()
                self.review.write_text(json.dumps(v))
                with self.assertRaises(ValueError):review.finish(self.report,self.review,self.output)
                self.report.write_bytes(raw_report);pic.write_bytes(raw_pic)
    def test_begin_refuses_report_or_capture_alias(self):
        for path in [self.report,self.f.args.output/review.FILES[0]]:
            before=path.read_bytes()
            with self.assertRaises(ValueError):review.begin(self.report,path,'PURE_TEST_INDEPENDENT_REVIEWER')
            self.assertEqual(path.read_bytes(),before)
    def test_empty_or_author_reviewer_rejected(self):
        for identity in ['', '/root/browser_verify', '/root/web_041_driver_upgrade']:
            with self.assertRaises(ValueError):review.begin(self.report,self.f.base/'other-review.json',identity)
    def test_missing_or_changed_normal_source_vector_rejected(self):
        vector=self.f.args.output/'source-after.json.gz';original=vector.read_bytes()
        vector.unlink()
        with self.assertRaises(ValueError):review.validate_report(self.report)
        vector.write_bytes(original)
        import gzip
        vector.write_bytes(gzip.compress(b'{"wrong_source":true}'))
        with self.assertRaises(ValueError):review.validate_report(self.report)

if __name__=='__main__':unittest.main()
