"""Finite, invertible SDK and checkpoint migration. Never executes a browser."""
import ast, hashlib, json
from pathlib import Path
BASE=Path(__file__).resolve().parent
OLD_START='        async def checkpoint(label,pic,row,action):\n'
OLD_END='        async with async_playwright() as p:\n'
AUTO='''        async def checkpoint(label,pic,row,action):
            nonlocal sequence
            sequence+=1
            plan=[('generated-escape','view-real-generated-slice','move-d',1),('generated-escape','view-after-real-d','move-a',2),('generated-escape','view-after-real-a','escape',3),('generated-escape','view-real-returned-title','confirm-title',4),('cancel-generate','view-real-returned-title','confirm-title',2)]
            assert 1<=sequence<=len(plan) and (row['label'],label,action,len(row['screenshots']))==plan[sequence-1]
            files=[item['file'] for item in row['screenshots']]
            assert pic.name==files[-1]
            row.setdefault('deferred_visual_checkpoints',[]).append(dict(seq=sequence,label=label,expected_action=action,screenshot=pic.name,capture_files=files,disposition='DEFERRED_ACTUAL_VISUAL_REVIEW_REQUIRED'))
            report['visual_review_state']='PENDING_INDEPENDENT_OFFLINE_REVIEW'
            report['checkpoint_policy']='Automatic declared actions; all original captures require actual independent offline review. No ACK read or generated.'
            save();print('CAPTURE_DEFERRED',sequence,label,pic.name,flush=True)
'''
def sha(raw):return hashlib.sha256(raw).hexdigest()
def asts(raw):return ast.dump(ast.parse(raw),include_attributes=False)
def main():
    rows={}
    for mode in ['default','gears']:
        raw=(BASE/f'original_{mode}.py').read_text()
        out=raw.replace('0.4.0','0.4.1')
        sdk_count=raw.count('0.4.0');assert sdk_count==2
        if mode=='default':
            start=out.index(OLD_START);end=out.index(OLD_END,start);old_checkpoint=out[start:end]
            out=out[:start]+AUTO+out[end:]
            replacements={"'PASSED_ACTUAL_GENERATED_ESCAPE'":"'AUTOMATED_GENERATED_ESCAPE_VISUAL_PENDING'","'PASSED_ACTUAL_GENERATE_CANCELLATION'":"'AUTOMATED_GENERATE_CANCELLATION_VISUAL_PENDING'","'PASSED_GENERATED_INPUT_ESCAPE_AND_GENERATE_CANCELLATION'":"'AUTOMATED_COMPLETE_VISUAL_PENDING'","if report['status'].startswith('PASSED'):":"if report['status']=='AUTOMATED_COMPLETE_VISUAL_PENDING':"}
            for old,new in replacements.items():assert out.count(old)==1;out=out.replace(old,new)
            reverse=out
            for old,new in reversed(list(replacements.items())):reverse=reverse.replace(new,old)
            assert reverse.count(AUTO)==1;reverse=reverse.replace(AUTO,old_checkpoint).replace('0.4.1','0.4.0')
            removed=[n for n in ast.walk(ast.parse(old_checkpoint.lstrip())) if isinstance(n,ast.Assert)]
            assert len(removed)==1
        else:
            reverse=out.replace('0.4.1','0.4.0')
        assert reverse==raw and asts(reverse)==asts(raw)
        original_asserts=sum(isinstance(n,ast.Assert) for n in ast.walk(ast.parse(raw)))
        current_asserts=sum(isinstance(n,ast.Assert) for n in ast.walk(ast.parse(out)))
        (BASE/f'{mode}_driver.py').write_text(out)
        rows[mode]={'original_sha256':sha(raw.encode()),'current_sha256':sha(out.encode()),'sdk_literals_updated':sdk_count,'original_asserts':original_asserts,'current_asserts':current_asserts,'inverse_bytes_and_ast_equal':True,'original_total_budget_seconds':300,'fresh_contexts':2 if mode=='default' else 1,'removed_assertions':'only manual ACK validation replaced by explicit automatic route and saved-capture assertions' if mode=='default' else 'none','scope':'pure source migration, no browser execution or image review'}
    (BASE/'migration-audit.json').write_text(json.dumps(rows,indent=2)+'\n')
    print(json.dumps(rows,indent=2))
if __name__=='__main__':main()
