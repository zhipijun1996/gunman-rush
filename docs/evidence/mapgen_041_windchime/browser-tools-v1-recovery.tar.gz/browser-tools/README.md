# 0.4.1 host Web consumers — frozen tools, not actual acceptance

These external development tools start no game, browser or server during preparation or pure tests. No production source or SDK solver is modified. Actual Web runs are **NOT RUN** by the tool author. The root owns the engine/browser lease and must supply its new real PCK and exact committed source.

`original_default.py` is the exact original 0.4 default two-fresh consumer from `mapgen-host-v2-04/web-browser/default-actual-03/run.py` (5b8330a8bf5781cf7110a714ee5942588016e4237d7b7a1f43b0fec91937278e). `original_gears.py` is the already independently reviewed automated 0.4 gears consumer (eeab037bb93b67caa453206aeadbcd1da69876a2c2acda8f04499cfa5b65f82e). They are preserved, not overwritten or relabelled as 0.4.1 evidence.

`build_drivers.py` explicitly changes two SDK literals per driver to 0.4.1. Gears retains all79 assertions. Default retains all70 non-ACK assertions, replacing only manual ACK assertion/wait with two declared-route/real-file assertions (72 total), and changes success labels to pending independent review. Its five checkpoint action routes are fixed; it neither emits nor consumes human ACKs. Both migrations have a complete inverse: original bytes and AST must be recovered exactly. `migration-audit.json` records hashes/counts. Original two fresh contexts, d180ms/a180ms movement, cancellation timing, all6 screenshots, all guards and total300 seconds stay. Gears retains its original one fresh context, ten source-clock AND wall seconds,7 images and300 total seconds. Final guards still run on pending completion; pending is never full PASS.

`windchime_driver.py` is a new consumer derived using `build_windchime.py` from the same guard shell. It retains real SourceRoot before/after vectors, exact actual PCK/config/19 SDK+module dependencies, byte readback, native expectation hash, producer freeze and before/after HTTP identity. It uses passive console only and real Playwright keyboard/mouse (no evaluate/init script/state/resource writes/teleport). First fresh opens actual controller-profile start, observes stable birth and closed gate, physically walks toward gate, sends a real upward miss, targets actual bell through existing mouse adapter/Router/projectile, repeats, physically walks to actual owned Port bank, ESC returns actual menu. Second fresh cancels at observed generate and proves no commit/Stage and cleanup before menu. It saves7 route images +2 cancel images, total300 seconds. Actual neighbor is not loaded; shore is single complete module only. Native tests separately own restore and post-exit token checks; this browser tool does not invent a reload hotkey.

## Preparation after root freezes source and exports real new bundle

Use fresh same-filesystem output directory: staging hardlinks non-HTML files and refuses an implicit PCK copy. `native-log` must be the root's actual successful matching0.4.1 wrapper stdout; expected output/spawn/instances/load identity are extracted from that real result, never hardcoded from old maps/M numbers. The windchime log additionally supplies actual Port-bank and bell/gate observations. Keep the raw native log, not just the extracted expected JSON.

```sh
TOOLS=/workspace/refactor-evidence/mapgen-041-integration/browser-tools
python3 -B "$TOOLS/prepare_run.py" \
 --mode default \
 --source-root /tmp/gunman-rush-mapgen-041 \
 --bundle /tmp/gunman-rush-mapgen-041/build/web \
 --native-log /ABS/ACTUAL-CURRENT-generated-slice.log \
 --source ACTUAL_COMMITTED_HEAD --pack-sha256 ACTUAL_SHA --pack-bytes ACTUAL_BYTES \
 --output /tmp/mapgen041-browser-default-01 --port 8841
```

Replace mode/native log/output/port for `gears` or `windchime` (`8842` / `8843`). Prepare checks git HEAD and clean status, then original `cloud_delivery.validate_bundle` / `inject_entry`, original export-report/scene admission and exact PCK SHA/size. No frozen map generation fallback. It creates `serve.sh`, `run.sh`, original/native/SHA receipts and explicit producers. Run `serve.sh` and `run.sh` as separate processes and preserve actual exit codes/logs; preparation never runs them. Serve locally only; no deployment.

All automatic logs/PNG/source vectors must be preserved outside ephemeral `/tmp` after capture. PCK uses an artifact, not source Git. The original frozen v2 JSON readback remains an export regression guard, not an input to actual SDK generation.

## Actual independent offline image review

Successful automation is `AUTOMATED_COMPLETE_VISUAL_PENDING`. Use `<mode>_offline_review.py` (`default`, `gears`, `windchime`). An independent reviewer must actually view every exact new PNG; the tool author and original browser author are refused. A JSON record alone cannot prove seeing an image.

```sh
python3 -B "$TOOLS/default_offline_review.py" begin \
 --report /ABS/ACTUAL/report.json --review /ABS/NEW-review.json --reviewer /root/ACTUAL_DIFFERENT_REVIEWER
python3 -B "$TOOLS/default_offline_review.py" record \
 --report /ABS/ACTUAL/report.json --review /ABS/NEW-review.json \
 --capture EXACT_ORIGINAL_CAPTURE.png --decision pass \
 --method functions.exec/tools.view_image --notes ACTUAL_VISIBLE_OBSERVATIONS \
 --started-epoch-ms ACTUAL_START --finished-epoch-ms ACTUAL_END
python3 -B "$TOOLS/default_offline_review.py" finish \
 --report /ABS/ACTUAL/report.json --review /ABS/NEW-review.json --output /ABS/NEW-acceptance.json
```

The strict join checks normal vectors/producer/HTTP guards, original context count, actual output/spawn/actions/cleanup, all original captures in order and each saved SHA, independent review times/method/notes/decision, missing/changed images, aliases and no overwrites. Automatic execution and offline actual viewing times are separately recorded. Six/default, seven/gears, nine/windchime images must all pass. No phone/user/FPS/full-map claim follows.

## Pure development tests

`test_default.py`, `test_gears.py`, `test_windchime.py` execute the actual driver `run()` with explicitly synthetic fake browser/Pack/source/HTTP/clock; fixture captures are text, **not real screenshots or actual acceptance**. They test pending-only success, original source/final guards, timeout, page/spawn/title/cleanup/duplicate-commit/phase/image failures, real-route/cancel sequencing, new bell-miss/idempotence failures, and strict-join negative cases. `test_prepare.py` additionally validates finite inverse migration and the actual root's existing gears73 stdout parser with altered/failing/old-SDK/ambiguous inputs. Its current native log path may be overridden by changing test setup only when original log is deliberately relocated with SHA preservation.

```sh
cd "$TOOLS"
python3 -B -m unittest test_default test_gears test_windchime test_prepare
```

Pure tests do not sign native/Web/image review. Historical failures and old versions keep original identities.
