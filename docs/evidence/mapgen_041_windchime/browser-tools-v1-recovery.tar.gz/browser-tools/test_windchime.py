"""Explicit synthetic browser mechanics for guard/automation fault tests; not real Web."""
import asyncio,importlib.util,json,time,unittest
from types import SimpleNamespace as NS
from pathlib import Path
import test_gears as common
import test_default as default
import windchime_offline_review as review
BASE=Path(__file__).resolve().parent
class Fixture(default.Fixture):
    def __init__(self,fault=None):
        super().__init__(fault);old=self.m
        spec=importlib.util.spec_from_file_location('actual_windchime_driver',BASE/'windchime_driver.py');self.m=importlib.util.module_from_spec(spec);spec.loader.exec_module(self.m)
        for name in ['helpers','time','asyncio']:setattr(self.m,name,getattr(old,name))
        self.expected.update(scene=self.m.SCENE,runtime_profile='controller',exit_bank_world=[750.,974.],latch_id='real-source-latch-fixture',bell_world=[520.,927.],gate_world=[590.,800.,24.,220.]);self.expected_path.write_text(json.dumps(self.expected));self.identity['host_load']['capabilities']={'profile':'controller'}
        for path in [self.m.SCENE.removeprefix('res://'),'experiments/generation/runtime_map_windchime_slice.gd','resources/levels/mapgen_host_041_windchime/bindings.json']:self.put(path,b'pure synthetic source')
        self.html='/* cloud-preview-entry */ args: '+json.dumps(['--cloud-preview','--entry=scene','--scene='+self.m.SCENE])+',';(self.bundle/'index.html').write_text(self.html)
        self.opened=False;self.shots=0;self.playwright_module.async_playwright=lambda:FakePlaywright(self)
    def runtime(self,event):
        result=super().runtime(event);result.update(profile='controller',request_abilities=['jump','shot_recoil']);return result
    def host_value(self,event):
        result=super().host_value(event)
        result['latches']=[dict(instance_id='fixture-module',latch_id=self.expected['latch_id'],bell_world=self.expected['bell_world'],gate_world=self.expected['gate_world'],is_open=self.opened,gate_disabled=self.opened,open_count=1 if self.opened else 0)]
        if self.fault=='duplicate-open' and self.shots>=3:result['latches'][0]['open_count']=2
        return result
    async def sleep(self,delay):
        self.player_x+=self.axis*delay*240
        if not self.opened:self.player_x=min(self.player_x,578.)
        await common.Fixture.sleep(self,delay)
class FakePlaywright(default.FakePlaywright):
    async def launch(self,**kwargs):return FakeBrowser(self.o)
class FakeBrowser(default.FakeBrowser):
    async def new_context(self,**kwargs):self.o.sessions+=1;return FakeContext(self.o)
class FakeContext(default.FakeContext):
    async def new_page(self):self.o.page=FakePage(self.o);return self.o.page
class FakePage(default.FakePage):
    def __init__(self,o):
        super().__init__(o);self.mouse=NS(move=self.mouse_move,click=self.mouse_click)
    async def mouse_move(self,*point):pass
    async def mouse_click(self,*point,**kwargs):
        self.o.shots+=1
        if self.o.shots>=2 and self.o.fault!='bell-miss':self.o.opened=True
class ExecutionTests(unittest.TestCase):
    def run_case(self,fault=None):
        f=Fixture(fault);self.addCleanup(f.temp.cleanup);return f,asyncio.run(f.execute())
    def test_complete_real_actions_route_synthetic_fixture_pending_only(self):
        f,r=self.run_case();self.assertEqual(r['status'],review.PENDING);self.assertEqual(f.sessions,2);self.assertEqual(sum(len(v['screenshots']) for v in r['sessions']),9);review.validate_report(f.args.output/'report.json')
    def test_failed_original_guards_and_mechanism_assertions_reject(self):
        for fault in ['timeout','source','afterguard-error','page','spawn','missing-title','cleanup','latecommit','missing-marker','missing-image','bell-miss','duplicate-open']:
            with self.subTest(fault=fault):
                f,r=self.run_case(fault);self.assertNotEqual(r['status'],review.PENDING)
                with self.assertRaises(ValueError):review.validate_report(f.args.output/'report.json')
class JoinTests(unittest.TestCase):
    def setUp(self):
        self.f=Fixture();self.addCleanup(self.f.temp.cleanup);asyncio.run(self.f.execute());self.report=self.f.args.output/'report.json';self.review=self.f.base/'review.json';self.output=self.f.base/'acceptance.json'
        review.begin(self.report,self.review,'PURE_TEST_INDEPENDENT_REVIEWER')
    def complete_synthetic_review(self):
        value=review.read(self.review);now=time.time()*1000
        value['records']=[dict(file=item['file'],capture_sha256=item['sha256'],decision='pass',method=review.ACTUAL_VIEW_METHOD,notes='PURE_SYNTHETIC_REVIEW_FIXTURE only; no actual view or real acceptance',started_epoch_ms=now,finished_epoch_ms=now) for item in value['captures']]
        self.review.write_text(json.dumps(value))
    def test_strict_join_positive_fixture_and_no_overwrite(self):
        self.complete_synthetic_review();value=review.finish(self.report,self.review,self.output);self.assertTrue(value['status'].startswith('PASSED'))
        for path in [self.report,self.review,self.output,self.f.args.output/review.FILES[0]]:
            before=path.read_bytes()
            with self.assertRaises(ValueError):review.finish(self.report,self.review,path)
            self.assertEqual(path.read_bytes(),before)
    def test_missing_review_empty_pass_wrong_sha_nan_and_late_ack_rejected(self):
        initial=self.review.read_bytes()
        for fault in ['missing','empty-notes','empty-method','automatic-method','wrong-sha','nan-time','late-ack','failed-auto','nan-budget','capture-change','missing-capture']:
            with self.subTest(fault=fault):
                self.review.write_bytes(initial);self.complete_synthetic_review();v=review.read(self.review);raw_report=self.report.read_bytes();pic=self.f.args.output/review.FILES[0];raw_pic=pic.read_bytes()
                if fault=='missing':v['records'].pop()
                if fault=='empty-notes':v['records'][0]['notes']=''
                if fault=='empty-method':v['records'][0]['method']=''
                if fault=='automatic-method':v['records'][0]['method']='automatic-unseen-approval'
                if fault=='wrong-sha':v['records'][0]['capture_sha256']='0'*64
                if fault=='nan-time':v['records'][0]['finished_epoch_ms']=float('nan')
                if fault=='late-ack':v=dict(seq=3,action='confirm-title',passed=True)
                if fault in ['failed-auto','nan-budget']:
                    r=json.loads(raw_report)
                    if fault=='failed-auto':r['status']='FAILED'
                    else:r['elapsed_seconds']=float('nan')
                    self.report.write_text(json.dumps(r))
                if fault=='capture-change':pic.write_bytes(b'wrong bytes')
                if fault=='missing-capture':pic.unlink()
                self.review.write_text(json.dumps(v))
                with self.assertRaises(ValueError):review.finish(self.report,self.review,self.output)
                self.report.write_bytes(raw_report);pic.write_bytes(raw_pic)
    def test_begin_refuses_report_or_capture_alias(self):
        for path in [self.report,self.f.args.output/review.FILES[0]]:
            before=path.read_bytes()
            with self.assertRaises(ValueError):review.begin(self.report,path,'PURE_TEST_INDEPENDENT_REVIEWER')
            self.assertEqual(path.read_bytes(),before)
    def test_empty_or_author_reviewer_rejected(self):
        for identity in ['', '/root/browser_verify', '/root/web_041_driver_upgrade']:
            with self.assertRaises(ValueError):review.begin(self.report,self.f.base/'other-review.json',identity)
    def test_missing_or_changed_normal_source_vector_rejected(self):
        vector=self.f.args.output/'source-after.json.gz';original=vector.read_bytes()
        vector.unlink()
        with self.assertRaises(ValueError):review.validate_report(self.report)
        vector.write_bytes(original)
        import gzip
        vector.write_bytes(gzip.compress(b'{"wrong_source":true}'))
        with self.assertRaises(ValueError):review.validate_report(self.report)

if __name__=='__main__':unittest.main()
