"""Native expectation parser and finite migration tests. Does not run a browser."""
import ast,hashlib,json,tempfile,unittest
from pathlib import Path
import build_drivers as build
import prepare_run as prepare
B=Path(__file__).resolve().parent
class MigrationTests(unittest.TestCase):
    def test_exact_inverse_and_original_action_budgets(self):
        build.main();audit=json.loads((B/'migration-audit.json').read_text())
        self.assertTrue(all(v['inverse_bytes_and_ast_equal'] for v in audit.values()))
        for mode,count in [('default',2),('gears',1)]:
            text=(B/(mode+'_driver.py')).read_text();self.assertIn('BUDGET = 300',text);self.assertEqual(audit[mode]['fresh_contexts'],count)
            tree=ast.parse(text)
            self.assertFalse(any(isinstance(n,ast.Attribute) and n.attr in ['evaluate','add_init_script'] for n in ast.walk(tree)))
    def test_actual_new_gears_native_readback_and_negative_inputs(self):
        source=Path('/tmp/gunman-rush-mapgen-041/build/mapgen041/gears-runtime-02.log')
        self.assertTrue(source.is_file(),'Root actual source native log required for parser test')
        expected=prepare.extract_expected(source,'d'*40,'gears')
        self.assertEqual(expected['sdk_implementation'],'mapgen/gdscript-candidate-0.4.1');self.assertEqual(expected['native_proof_sha256'],hashlib.sha256(source.read_bytes()).hexdigest())
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'log';raw=source.read_text()
            for bad in [raw.replace('RUNTIME_MAP_M35_RUNTIME checks=73 failures=0','RUNTIME_MAP_M35_RUNTIME checks=73 failures=1'),raw.replace('mapgen/gdscript-candidate-0.4.1','mapgen/gdscript-candidate-0.4.0'),raw+'\nERROR: synthetic retained failure\n',raw+'\nRUNTIME_MAP_M35_RUNTIME checks=73 failures=0\n']:
                p.write_text(bad)
                with self.assertRaises(AssertionError):prepare.extract_expected(p,'d'*40,'gears')
if __name__=='__main__':unittest.main()
