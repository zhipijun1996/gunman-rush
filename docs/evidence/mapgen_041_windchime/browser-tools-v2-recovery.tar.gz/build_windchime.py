"""Derive new complete start-module GUI consumer from the frozen common guard shell."""
from pathlib import Path
import ast,hashlib,json
B=Path(__file__).resolve().parent
s=(B/'default_driver.py').read_text()
s=s.replace("SCENE = 'res://experiments/generation/runtime_map_generated_slice.tscn'","SCENE = 'res://experiments/generation/runtime_map_windchime_slice.tscn'")
s=s.replace("assert expected['input_profile']=='conformance'","assert expected['input_profile']=='conformance' and expected['runtime_profile']=='controller'")
start=s.index('        async def checkpoint(');end=s.index('        async with async_playwright()',start)
s=s[:start]+'''        async def checkpoint(label,pic,row,action):
            nonlocal sequence
            sequence+=1
            assert action=='confirm-title' and label=='view-real-returned-title'
            row.setdefault('deferred_visual_checkpoints',[]).append(dict(seq=sequence,label=label,expected_action=action,screenshot=pic.name,capture_files=[v['file'] for v in row['screenshots']],disposition='DEFERRED_ACTUAL_VISUAL_REVIEW_REQUIRED'))
            report['visual_review_state']='PENDING_INDEPENDENT_OFFLINE_REVIEW';save()
'''+s[end:]
s=s.replace("for label in ['generated-escape','cancel-generate']:","for label in ['windchime-escape','cancel-generate']:").replace("if label=='generated-escape':","if label=='windchime-escape':").replace("if label=='generated-escape' else", "if label=='windchime-escape' else")
s=s.replace("for field in ['player','carrier']","for field in ['player']")
start=s.index("                            pic=await screen('01-committed');")
end=s.index('\n                        else:',start)
route='''                            assert committed['profile']=='controller' and 'grapple' not in committed['request_abilities'] and not committed['actual_hook_enabled']
                            assert identity['host_load']['capabilities']['profile']=='controller'
                            assert len(expected['selected_instances'])==1 and len(loaded[0]['value']['mechanisms'])==1
                            def latch_sample(value):
                                values=value['latches'];assert len(values)==1
                                result=values[0]
                                assert result['instance_id']==expected['selected_instances'][0] and result['latch_id']==expected['latch_id']
                                assert result['bell_world']==expected['bell_world'] and result['gate_world']==expected['gate_world']
                                assert isinstance(result['is_open'],bool) and isinstance(result['gate_disabled'],bool)
                                return result
                            def newest(): return physics()[-1]
                            def current_latch(): return latch_sample(newest())
                            assert all(latch_sample(value)['open_count']==0 and not latch_sample(value)['is_open'] for value in [loaded[0]['value'],*physics()])
                            await wait_for(lambda:newest()['grounded'])
                            assert math.dist(newest()['player'],expected['spawn'])<.3,'Actual start birth did not remain stable on its original support'
                            await screen('01-committed')
                            target=expected['exit_bank_world'];forward=1 if target[0]>expected['spawn'][0] else -1
                            key='d' if forward>0 else 'a'
                            baseline=newest()['player'];await real_key(key,1400);count=len(physics())
                            await wait_for(lambda:len(physics())>=count+2)
                            closed=newest();gate=expected['gate_world'];gate_center=gate[0]+gate[2]/2
                            assert (closed['player'][0]-gate_center)*forward<0 and (closed['player'][0]-baseline[0])*forward>1
                            assert not current_latch()['is_open'] and not current_latch()['gate_disabled'] and closed['grounded']
                            await screen('02-closed-gate')
                            async def mouse_shot(world_target,label):
                                player=newest()['player'];point=[640+world_target[0]-player[0],360+world_target[1]-player[1]]
                                assert 0<point[0]<1280 and 0<point[1]<720
                                begin=time.time()*1000
                                async def dispatch_mouse():
                                    await page.mouse.move(*point)
                                    await page.mouse.click(*point,delay=100)
                                await asyncio.wait_for(dispatch_mouse(),timeout=remaining(15000)/1000.0)
                                row['inputs'].append(dict(action='actual-mouse-shot-'+label,world_target=world_target,screen_point=point,begin_epoch_ms=begin,end_epoch_ms=time.time()*1000));save()
                                count=len(physics());await wait_for(lambda:len(physics())>=count+2)
                            player=newest()['player'];await mouse_shot([player[0],player[1]-200],'miss')
                            assert not current_latch()['is_open'] and current_latch()['open_count']==0
                            await screen('03-miss')
                            await mouse_shot(expected['bell_world'],'bell')
                            await wait_for(lambda:current_latch()['is_open'] and current_latch()['gate_disabled'])
                            assert current_latch()['open_count']==1
                            await screen('04-opened')
                            await mouse_shot(expected['bell_world'],'repeat')
                            assert current_latch()['is_open'] and current_latch()['gate_disabled'] and current_latch()['open_count']==1
                            await screen('05-repeat-idempotent')
                            row['shore_movement']=[];route_start=time.monotonic()
                            while abs(newest()['player'][0]-target[0])>3 or not newest()['grounded']:
                                assert time.monotonic()-route_start<30,'Actual walking failed to reach owned exit bank within bounded movement observation'
                                before_point=newest()['player'];delta=target[0]-before_point[0]
                                await real_key('d' if delta>0 else 'a',min(120,max(16,abs(delta)/240*1000*.6)))
                                count=len(physics());await wait_for(lambda:len(physics())>=count+1)
                                row['shore_movement'].append(dict(before=before_point,after=newest()['player'],target=target));save()
                            assert newest()['grounded'] and abs(newest()['player'][0]-target[0])<=3
                            assert current_latch()['is_open'] and current_latch()['open_count']==1 and current_latch()['gate_disabled']
                            row['exit_bank_reached']=dict(target=target,observed=newest(),scope='complete owned start module only; actual neighbor is not loaded')
                            await screen('06-exit-bank')
                            begin=time.time()*1000;await page.keyboard.press('Escape')
                            row['inputs'].append(dict(action='actual-Escape-after-windchime-exit-bank',begin_epoch_ms=begin,end_epoch_ms=time.time()*1000))'''
s=s[:start]+route+s[end:]
s=s.replace("'AUTOMATED_GENERATED_ESCAPE_VISUAL_PENDING'","'AUTOMATED_WINDCHIME_ESCAPE_VISUAL_PENDING'")
s=s.replace("scope='Real generated source and cancellation through real keyboard/mouse", "scope='Real complete owned start windchime source/shooting/exit-bank and cancellation through real keyboard/mouse")
# Explicitly freeze the new exact consumer and binding too; common SDK/PCK and
# original normal before/after guards remain byte-for-byte in the shared shell.
s=s.replace("frozen += [path.resolve() for path in a.producer_file]", "frozen += [root/'experiments/generation/runtime_map_windchime_slice.gd',root/'resources/levels/mapgen_host_041_windchime/bindings.json']\n        frozen += [path.resolve() for path in a.producer_file]")
(B/'windchime_driver.py').write_text(s)
ast.parse(s)
(B/'windchime-derivation.json').write_text(json.dumps(dict(base_sha256=hashlib.sha256((B/'default_driver.py').read_bytes()).hexdigest(),current_sha256=hashlib.sha256(s.encode()).hexdigest(),scope='New mechanic consumer derived from common guard shell; not inverse-equivalent to default actions',fresh_contexts=2,budget_seconds=300,evaluate_or_init_scripts=False,expected_first_session_images=7,expected_cancel_images=2,status='NOT_RUN'),indent=2)+'\n')
