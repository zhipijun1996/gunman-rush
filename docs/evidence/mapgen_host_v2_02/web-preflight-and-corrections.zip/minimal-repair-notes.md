# 给root的最小有限修复

只作建议，以下未应用主树。

- `tools/cloud_delivery.py:103`：保原scenes前缀，仅增加精确 `scene == "res://experiments/generation/entries/runtime_map_v2_slice.tscn"` 例外；原所有安全检查继续。不是允许所有experiments/game。相应帮助文本437行与原Python正反例更新。
- 同文件`clean_runtime:83` prefixes加 `resources/`；原diff和untracked拒绝保持。用实际资源JSON dirty/untracked测试，不能只改期望文本。
- 新scene根静态写 `metadata/owns_audio_service = true`。原`cloud_preview.gd:74`附近消费：

```gdscript
var audio_owner: Variant = custom_scene.get_meta(&"owns_audio_service", false)
if not custom_scene is DemoApp and not (audio_owner is bool and audio_owner):
    custom_audio = GameAudio.new()
    add_child(custom_audio)
```

原DemoApp persistence/cloud_preview_host判定不改。metadata在instantiate后、add_child/_ready前已存在，源scene仍由RuntimeMapSlice._ready创建其唯一PlayerWeaponFeelAudioV2。保未声明flag旧scene的宿主服务，拒把字符串/非boolean当真。这里不新建音频注册表/树搜索/平行服务。本轮live代码只发现cloud_preview.gd一个通用独立scene音频创建点；preview_affordance只是banner代理。原App queue_free造成的瞬时旧服务与稳定extra custom_audio要分开，不能从metadata推断严格退出已通过。

原cloud-preview-runtime三case必须保留；追加actual new scene/自身audio服务解析与仅一服务、返回FULL GAME/MENU及原严格audio teardown验证。Playwright后续只读实际UI与console，不注入metadata/资源/状态。

当前selected style-v34、两区creative-v37里，上述tools/scene/bootstrap/slice没有直接SHA leaf，所查五个相关quality record也无这些目标的单独SHA leaf。因此不建议刷新Bible/creative版本。MAPGEN质量record有affected_paths与聚合production_snapshot，须在最终F/真实证据下按原production_loop更新该任务绑定；旧quality审查/失败不追签。若root最终另改实际已绑定的DemoApp或正式audio/material叶子，需单独重新核绑定，不能沿此结论豁免。

raw JSON：原preset有限include补7个确切路径；原check_runtime_closure读实际PCK逐bytes+SHA；列表及现有Foundry/source守门见README与audit.json。不要以当前native150或B局部通过签Web。后续只接受root给定最终F与新bundle身份，不用旧URL代签。
