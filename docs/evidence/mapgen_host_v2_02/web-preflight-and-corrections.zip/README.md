# PR127 E Web 前置：只读审计

本轮仅读取源文件、Git状态、已安装工具版本和依赖；未改主树、未启动Godot或Chrome、未导出、未访问生产站。任务给定HEAD前缀9e97b553；审计中root已继续工作，实际读到HEAD95cd283d324be45a6c7084cff38e8a6180864d6f，Provider与runner处于root WIP。因此这是一份位置与边界审计，不是冻结源/干净树/构建通过证明。后续必须重新绑定root给定的最终F和实际PCK，不复用旧预览签新源。

## 最小有限修改建议

1. `tools/cloud_delivery.py:103–113`：保留旧 `res://scenes/` 一般准入，仅为 `res://experiments/generation/entries/runtime_map_v2_slice.tscn` 增加一个精确字符串例外；继续原控制字符、遍历、反斜线、路径组件和bootstrap递归拒绝。不要把整个 `experiments/` 或 `game/` 开给Python工具。`validate_bundle:143–148`仍须读实际PCK中bootstrap和目标scene。CLI `--scene`帮助文本437行也需准确说明该例外。
2. `tools/cloud_delivery.py:80–86`：`clean_runtime` prefixes补 `resources/`，否则新raw JSON脏文件/新增文件可漏过。原HEAD核验、构建报告artifact SHA和不可覆盖路由均保留。`tools/underworld_delivery.py:113–127`现有runtime_paths已包括resources，可作对照；不是放宽SourceRoot。
3. `experiments/generation/entries/runtime_map_v2_slice.tscn`根节点加静态 `metadata/owns_audio_service = true`。`experiments/platform/cloud_preview.gd:70–80`在已有 `DemoApp`判定旁把该明确boolean作为拥有音频服务的声明：只有非DemoApp且未声明owns_audio_service的旧独立场景仍创建bootstrap GameAudio；现有DemoApp持久化禁用和meta标记原样保留。RuntimeMapSlice `_ready:18–21`本来就创建 `PlayerWeaponFeelAudioV2`，无需再造服务或在宿主跨树搜索。源码当前唯一通用独立scene音频创建点是cloud_preview.gd:75；preview_affordance.gd只是横幅显示代理，不另建audio。普通App在切换时还会被queue_free，须区分瞬时旧App与稳定额外custom_audio；原生/真实Web退出需验证，不凭metadata宣称无泄漏。
4. `export_presets.cfg`三个现有preset的include_filter追加下列7个精确JSON成员，不开目录glob。`tools/check_web_bundle.py:143`现有有限runtime_contract增加这个实际消费者的闭包，原`check_runtime_closure:398–401`逐份raw字节与本地冻结源一致；同时按input-lock中的6条SHA核验。当前raw exporter只另处理PNG/音频/recorded TRES，JSON现行机制是preset明确include+有限PCK读回，不应先凭假设新增一套平行JSON注册表。若真实Godot导出仍不保留原字节，再在原raw exporter加有限适配并用实际PCK证明。

```text
resources/levels/mapgen_host_v2_01/input-lock.json
resources/levels/mapgen_host_v2_01/map.json
resources/levels/mapgen_host_v2_01/bindings.json
resources/levels/mapgen_host_v2_01/selection.json
resources/levels/mapgen_host_v2_01/content/M16.json
resources/levels/mapgen_host_v2_01/content/M18.json
resources/levels/mapgen_host_v2_01/content/M21.json
```

消费者是 `experiments/generation/runtime_map_frozen_source.gd:4–25`：固定ROOT、3个IDS，input-lock锁6个成员并拒绝缺件/SHA错/额外成员。input-lock自身由冻结Git字节/PCK完整SHA绑定。`runtime_map_slice.gd:42`调用它。普通游戏不会选择此Provider；`game/application/demo_app.gd:132–140`只在显式`--cloud-preview`时redirect。

## 精确回归位置

- `tests/test_cloud_delivery.py` / Harness `cloud-delivery-tests`：原60s。保原合法scene用例，新增唯一新scene准入及其他experiments路径/遍历/自递归拒绝；补resources已跟踪dirty与untracked均拒绝。
- `tests/cloud_preview_runner.gd` / `cloud-preview-runtime`：外120s、内90s，原音频严格退出wrapper。保actions/scene/demo三原case，追加声明自有audio的scene，确认不建custom_audio、实际origin解析到scene自己的服务，FULL GAME/MENU重建与音频排空仍正确。不能只断言metadata存在。
- `runtime-raw-export-tests`原60s；`underworld-raw-export`原120s；`tests/test_web_bundle.py`补有限JSON真实PCK字节拒绝/丢成员/锁错等有意义反例。
- `runtime-map-v2-host`原180s覆盖真正固定源入口与已有拒绝/物理断言；本审计未执行。新增脚本/scene/source集合需保原required inputs/artifacts，不从顶层参数推断实际闭包。

## 原构建/PCK/源守门路径

`python3 tools/build.py web`，不是build.sh。`tools/build.py:139–154`依次check_environment、锁定Godot身份、editor import90s、Foundry stamp30s、原debug export180s；165行前后不代表设备执行。`prepare_web_playtest:18–129`完整PCK SHA前12位作build_id，并写engine/loader/chunks与source_commit。原报告205–210记录实际artifact SHA。

`python3 tools/check_web_bundle.py <bundle>`：431–460核chunk gzip长度、每块SHA、完整PCK一致、build_id及实际runtime_closure；`Pack:90–140`解析真实PCK目录并核每entry MD5，不能以strings/metadata冒读回。`tools/style_exploration_delivery.py:85 reconstruct_pack`是原重建入口；`python3 tools/style_exploration_delivery.py reconstruct-pack --bundle <bundle>`保完整SHA收据。

`tools/cloud_delivery.py validate_bundle:116`要求真正source-root子路径下原build_report、完整artifact字节、不可symlink、准确HEAD、runtime clean；`stage_preview:350`创建不可覆写的 `previews/<TASK>/<F>/<BUILD>/`，只在HTML原startGame加入原bootstrap参数，不是状态注入。参数为 `--cloud-preview --entry=scene --scene=res://experiments/generation/entries/runtime_map_v2_slice.tscn --task=... --seed=...`。普通Web不支持任意positional scene覆盖，不能改用裸scene参数绕过。

`tools/verify_ci_artifact_browser.py:179 SourceRoot.snapshot`核root inode/Git目录/精确HEAD/clean/index集合/每个物理文件对应Git blob；不能为WIP跳过或伪称通过。该整工具主流程另外固定了历史CI consumers及reviewed工具对，不能把新宿主直接冒称原三consumer已测；可在新独立GUI验证中复用原严格SourceRoot，最终F重新绑定。现有`underworld_delivery.py closure`也是具体runtime+PCK源对齐守门。

## Foundry前置

`tools/build.py:146–147`在有resources/foundry/batch.json时总会先跑原`tools/foundry_export_stamp.gd`。其4–14行拒绝stale batch，写已验证basis及配置SHA到**已跟踪**resources/foundry/export_basis.json。`FoundryCatalog.basis:38–81`含锁定engine和广泛源码，其中game/world/levels递归`.gd/.tres`，因此本轮Provider改动可能令旧开发池basis失配。不能手抄basis/改stamp/删除guard。

沿仓库project-integration技能的原要求：只有真实stale时用 `python3 tools/foundry.py build --count 24 --promote` 重建开发池与原输入回放；默认base/double_jump/air_chain，engine import120s、每profile原300s，保旧池/失败。随后原export stamp；最终把这些tracked生成结果纳入真实冻结源再导出，不给旧池的通过换新标签。本审计没有计算或宣称当前basis有效，也不要求盲跑整套CI。

## Bible与quality边界

当前选定style是registry指向的v34 death-runtime，两区creative-v37。扫描它们的实际嵌套references/authority_sources：cloud_delivery.py、cloud_preview.gd、runtime_map_slice.gd及runtime_map_v2_slice.tscn均没有直接SHA leaf；无须为这几处工程修复刷新Bible/style/creative版本。历史archives中的工具名字不是当前绑定。

当前MAPGEN-HOST-V2-01质量记录已把scene/slice列affected_paths，GAME-ARCH-AUDIO-01列cloud_preview，CLOUD-PRODUCTION-01列cloud_delivery，但这些记录没有上述文件的单独SHA leaf。MAPGEN的production_snapshot是聚合摘要：`tools/production_loop.py:1126`要求当前task/content_hash；应按最终修改重建真实任务证据/snapshot并保旧失败，不拿改版本当行为验证。如果后续改到已绑定的DemoApp、灰盒或其他真正runtime_reference，须另按其实际叶子执行原技术重绑规则，不能沿本结论豁免。

## 浏览器当前可用性

已安装Chromium154.0.8037.57、Python Playwright1.62.0、Pillow12.3.0、numpy2.3.5、scipy1.17.0、Tesseract5.5.0。只执行版本/包查找和Playwright IPC driver启动/关闭，**未launch Chrome**；因此“安装可用”不冒称新环境已浏览通过。将来显式system executable `/usr/bin/chromium`即可沿原Playwright入口，不依赖可能不存在的Playwright下载缓存。

原helper：`tools/verify_four_line_browser.py locate_any/locate_primary/locate_cjk`、`tools/studio_gui_pointer.py`、`tools/verify_forest_browser.py validate_identity/environment_proxy`。COI本地server为`tools/mobile_web_perf/serve_coi.py`；threaded Web必须保COOP/COEP。新/tmp已空，先前/tmp外部driver/OCR bundle均不可假定仍在。训练数据仍在`/workspace/toolchains/tessdata-4.1.0-fast/{eng,chi_sim}.traineddata`，但该目录缺configs/tsv；系统 `/usr/share/tesseract-ocr/5/tessdata/configs/tsv`存在。后续可在/tmp组symlink训练数据+原tsv配置，或原CJK helper显式`-c tessedit_create_tsv=1`；不能只改TESSDATA_PREFIX后让原Latin `tsv`静默空输出。

未来实际Web验证另等root给最终F/build/PCK64SHA/长度、实际bundle/Preview URL和独占lease。核metadata+真实PCK读回，然后真实图像/鼠标键盘进入新切片、移动/机制、FULL GAME/MENU返回，保原page/console错误和helper/driver前后SHA；无FPS04/teleport/状态写，不签手机性能或完整地图。旧Preview最多作历史参考，不签新源。
