from pathlib import Path
import urllib.request,json,hashlib,base64
out=Path('/workspace/refactor-evidence/mapgen-host-v2-01/upstream');ref='02b5cb53b06d7009225b2ecff9351f315e46b12e';rows=[]
for mid in ['idea-spec02-s11-001','game-route-junction']:
 rel='modules/'+mid+'/record.json';url=f'https://api.github.com/repos/zhipijun1996/map-edit/contents/{rel}?ref={ref}'
 try:
  with urllib.request.urlopen(urllib.request.Request(url,headers={'Accept':'application/vnd.github+json','User-Agent':'mapgen-host-v2-01-readonly'}),timeout=40) as r:metadata=r.read();status=r.status
  md=json.loads(metadata);data=base64.b64decode(md['content']);p=out/'selection-r2'/'original-source-records'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);p.with_name(p.name+'.api-metadata.json').write_bytes(metadata)
  rows.append({'url':url,'ref':ref,'status':status,'git_blob_sha':md['sha'],'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'path':str(p)});print(mid,len(data),flush=True)
 except Exception as exc:rows.append({'url':url,'error':repr(exc)});print(repr(exc),flush=True)
 (out/'selection-r2'/'source-record-fetch-receipt.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
