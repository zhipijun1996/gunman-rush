from pathlib import Path
import urllib.request,json,hashlib,base64
out=Path('/workspace/refactor-evidence/mapgen-host-v2-01/upstream');receipts=[]
leaves=[('47aefebe07f4f0e7471f3d1546214502a6b2aade','docs/module-package-consumers.md'),('47aefebe07f4f0e7471f3d1546214502a6b2aade','MAP_FOUNDATION.md')]
for mid in ['game-plains-windchime-lesson','idea-interface-s12-001','game-plains-ferry-gears']:
 leaves.append(('02b5cb53b06d7009225b2ecff9351f315e46b12e','modules/'+mid+'/record.json'))
for ref,rel in leaves:
 url=f'https://api.github.com/repos/zhipijun1996/map-edit/contents/{rel}?ref={ref}'
 try:
  with urllib.request.urlopen(urllib.request.Request(url,headers={'Accept':'application/vnd.github+json','User-Agent':'mapgen-host-v2-01-readonly'}),timeout=40) as r:meta=r.read();status=r.status
  md=json.loads(meta);data=base64.b64decode(md['content']);dest=out/'map-edit-api'/ref/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
  dest.with_name(dest.name+'.api-metadata.json').write_bytes(meta)
  receipts.append({'url':url,'ref':ref,'status':status,'git_blob_sha':md['sha'],'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'path':str(dest)})
  print(rel,len(data),flush=True)
 except Exception as exc:
  receipts.append({'url':url,'error':repr(exc)});print(rel,repr(exc),flush=True)
 (out/'selected-leaf-fetch-receipt.json').write_text(json.dumps(receipts,ensure_ascii=False,indent=2)+'\n')
