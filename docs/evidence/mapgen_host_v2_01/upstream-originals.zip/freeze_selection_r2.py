from pathlib import Path
import json,zipfile,shutil,hashlib,re,math
out=Path('/workspace/refactor-evidence/mapgen-host-v2-01/upstream');attempt=out/'attempt-01-official-930001';m=json.loads((attempt/'map.json').read_text());cat=json.loads((out/'catalog.json').read_text());by_module={e['id']:e for e in cat['modules']}
root=out/'selection-r2';root.mkdir(exist_ok=True);ids=['M16','M18','M21'];instances=[i for i in m['instances'] if i['id'] in ids];assert [i['id'] for i in instances]==ids
internal=[c for c in m['connections'] if c['a']['instance_id'] in ids and c['b']['instance_id'] in ids];assert [c['id'] for c in internal]==['C027','C030','C031']
cut=[c for c in m['connections'] if (c['a']['instance_id'] in ids)!=(c['b']['instance_id'] in ids)]
seals={i['id']:i['seals'] for i in instances};allhashes={};ellipse_leaves=[]
with zipfile.ZipFile(out/'module-pack-1.1.0.zip') as z:
 package_manifest=json.loads(z.read('manifest.json'))
 for i in instances:
  target=root/i['content_ref'];target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(attempt/i['content_ref'],target)
  assert json.loads(target.read_text())==json.loads((attempt/i['content_ref']).read_text())
  allhashes[i['content_ref']]=hashlib.sha256(target.read_bytes()).hexdigest()
  target=root/'instances'/(i['id']+'.json');target.parent.mkdir(parents=True,exist_ok=True);target.write_text(json.dumps(i,ensure_ascii=False,indent=2)+'\n')
  e=by_module[i['module_id']];target=root/'catalog-records'/(i['module_id']+'.json');target.parent.mkdir(parents=True,exist_ok=True);target.write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n')
  for name in z.namelist():
   if name.startswith('modules/'+i['module_id']+'/') and not name.endswith('/'):
    target=root/'original-package-leaves'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(z.read(name));assert hashlib.sha256(target.read_bytes()).hexdigest()==package_manifest['files'][name]
 leaves=['runtime/module_runtime/revision061_ellipse_definition_v1-fff23a5cee8f.gd','runtime/module_runtime/revision061_ellipse_install_v1-7416999b951a.gd','runtime/module_runtime/module_loader_revision061_v2-daa7e5eceb9f.gd']
 for name in leaves:
  b=z.read(name);sha=hashlib.sha256(b).hexdigest();assert sha==package_manifest['files'][name]
  target=root/'ellipse-source'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b)
  ellipse_leaves.append({'package_path':name,'local_path':str(target),'bytes':len(b),'sha256':sha,'manifest_checksum_verified':True})
# Static identity checks only: both real endpoints retain their exact world Port.
for c in internal:
 positions=[]
 for end in [c['a'],c['b']]:
  i=next(i for i in instances if i['id']==end['instance_id']);p=next(p for p in i['ports'] if p['id']==end['port_id']);world=[i['origin_blocks'][a]*128+p['local_position_pixels'][a] for a in range(2)];assert world==c['position_pixels'];positions.append(world)
 assert positions[0]==positions[1]
sel={'schema':'mapgen-host-v2/selection/v1','revision':'r2-real-moving-platform-interaction','source_map_id':m['map_id'],'request_fingerprint':m['generator']['request_fingerprint'],'seed':m['seed'],'source_full_map':'attempt-01-official-930001/map.json','selection_rule':'Root explicitly selected original M16/M18/M21 from the unchanged official map for real ellipse-platform riding and actual C027/C030/C031 seams; complete records only, no enemy/reward/Boss/shot-latch scope. This supersedes r1 required-danger rule only; r1 zero-eligible scan and C001 rejection remain immutable evidence.','instance_ids':ids,'source_instance_records':['selection-r2/instances/'+i+'.json' for i in ids],'content_refs':['selection-r2/'+i['content_ref'] for i in instances],'content_sha256':allhashes,'internal_connections':internal,'cut_edges':cut,'original_seals':seals,'source_records_include_all_ports_routes_connected_port_ids':True,'seals_unchanged':True,'synthetic_cut_edge_seals_added':False,'cut_edges_policy':'Retain original full-map connection records; outside endpoint is absent in this slice, not reclassified as original unused Port and not silently sealed. Host test must bound/record its slice endpoint scope.','coordinates':m['coordinates'],'content_rebased_or_remirrored':False,'ellipse_source_leaves':ellipse_leaves,'static_selected_port_alignment':'PASS exact original world coordinates','runtime_physics_and_player_riding':'NOT_RUN','excludes':['enemy','reward','Boss','projectile-to-latch opening'],'r1_history':['connection-selection-audit.json','pair-candidate-scan.json','c001-not-adopted/selection.json']}
(out/'selection-r2.json').write_text(json.dumps(sel,ensure_ascii=False,indent=2)+'\n')
(root/'connections.json').write_text(json.dumps({'internal':internal,'cut_edges':cut},ensure_ascii=False,indent=2)+'\n');(root/'original-seals.json').write_text(json.dumps(seals,ensure_ascii=False,indent=2)+'\n')
(root/'ellipse-source-receipt.json').write_text(json.dumps({'archive_sha256':'5ad5a7871941b2c1ffa759b18f7b1e80f2fe7e571b72f95d1e0ef26031f08723','package_source_commit':'02b5cb53b06d7009225b2ecff9351f315e46b12e','leaves':ellipse_leaves,'source_runtime_formula':'a=PI+TAU*fposmod(clock/period()+initial_phase,1.0); center+Vector2(cos(a)*radii.x,sin(a)*radii.y)','period':'travel_duration, installed from raw.ellipse_period','envelope':'Rect2(center-radii-size*.5,radii*2+size)','original_runtime_ignores_mapgen_ellipse_x_sign':True,'materialized_M16_requires_x_sign':-1,'not_a_runtime_certification':True},ensure_ascii=False,indent=2)+'\n')
summary={'ids':ids,'content_sha256':allhashes,'internal_connections':[c['id'] for c in internal],'cut_edges':[c['id'] for c in cut],'seals_counts':{k:len(v) for k,v in seals.items()},'ports_counts':{i['id']:len(i['ports']) for i in instances},'routes_counts':{i['id']:len(i['routes']) for i in instances},'ellipse_leaves':ellipse_leaves}
(root/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');print(json.dumps(summary,ensure_ascii=False,indent=2))
