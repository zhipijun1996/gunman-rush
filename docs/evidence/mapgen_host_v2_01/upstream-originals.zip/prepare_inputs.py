from pathlib import Path
import urllib.request,json,base64,hashlib,shutil,time
out=Path('/workspace/refactor-evidence/mapgen-host-v2-01/upstream');src=Path('/tmp/map-gen-host-source')
lock=json.loads((src/'examples/library-lock.json').read_text()); ref='47aefebe07f4f0e7471f3d1546214502a6b2aade'
receipts=[]
for rel in ['AGENTS.md','README.md','releases/map-edit-modules-1.1.0.zip']:
 url=f'https://api.github.com/repos/zhipijun1996/map-edit/contents/{rel}?ref={ref}'
 req=urllib.request.Request(url,headers={'Accept':'application/vnd.github+json','User-Agent':'mapgen-host-v2-01-readonly'})
 try:
  with urllib.request.urlopen(req,timeout=40) as r: data=r.read();status=r.status
  metadata=json.loads(data); destination=out/'map-edit-api'/rel;destination.parent.mkdir(parents=True,exist_ok=True)
  (destination.parent/(destination.name+'.api-metadata.json')).write_bytes(data)
  if rel.endswith('.zip'):
   assert metadata['size']<100_000_000,(metadata['size'],'unexpected leaf size')
   with urllib.request.urlopen(urllib.request.Request(metadata['download_url'],headers={'User-Agent':'mapgen-host-v2-01-readonly'}),timeout=60) as r: content=r.read();download_status=r.status
   assert hashlib.sha256(content).hexdigest()==lock['sha256']
   destination=out/'module-pack-1.1.0.zip';destination.write_bytes(content)
  else:
   content=base64.b64decode(metadata['content']);destination.write_bytes(content);download_status=None
  receipts.append({'api_url':url,'api_status':status,'resolved_git_blob_sha':metadata['sha'],'ref':ref,'path':str(destination),'bytes':len(content),'sha256':hashlib.sha256(content).hexdigest(),'download_status':download_status})
  print(rel,receipts[-1]['bytes'],receipts[-1]['sha256'],flush=True)
 except Exception as e:
  receipts.append({'api_url':url,'error':repr(e)});(out/'input-fetch-receipt.json').write_text(json.dumps(receipts,indent=2)+'\n');raise
for rel,name in [('examples/request-930001.json','request.json'),('profiles/stable-v2.json','config.json'),('examples/library-lock.json','library-lock.json'),('schemas/runtime-map.schema.json','runtime-map-v2.schema.json')]:shutil.copyfile(src/rel,out/name)
(out/'input-fetch-receipt.json').write_text(json.dumps(receipts,indent=2)+'\n')
