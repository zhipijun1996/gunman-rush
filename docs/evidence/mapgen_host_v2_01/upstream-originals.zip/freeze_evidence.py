from pathlib import Path
import json,zipfile,shutil,hashlib,subprocess
out=Path('/workspace/refactor-evidence/mapgen-host-v2-01/upstream');a=out/'attempt-01-official-930001';m=json.loads((a/'map.json').read_text());catalog=json.loads((out/'catalog.json').read_text());entries={e['id']:e for e in catalog['modules']}
# Preserve the initial honest candidate as NOT_ADOPTED, never remove its content.
f=out/'c001-not-adopted';f.mkdir(exist_ok=True);ids=['M01','M02'];instances=[i for i in m['instances'] if i['id'] in ids]
with zipfile.ZipFile(out/'module-pack-1.1.0.zip') as z:
 for i in instances:
  q=f/'content'/Path(i['content_ref']).name;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(a/i['content_ref'],q)
  q=f/'instances'/(i['id']+'.json');q.parent.mkdir(parents=True,exist_ok=True);q.write_text(json.dumps(i,ensure_ascii=False,indent=2)+'\n')
  e=entries[i['module_id']];q=f/'catalog-records'/(i['module_id']+'.json');q.parent.mkdir(parents=True,exist_ok=True);q.write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n')
  for name in z.namelist():
   if name.startswith('modules/'+i['module_id']+'/') and not name.endswith('/'):
    q=f/'original-package-leaves'/name;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(z.read(name))
 # Also preserve the sole simple dangerous module, without claiming a valid pair.
 i=next(i for i in m['instances'] if i['id']=='M35');q=out/'danger-module-unpaired';q.mkdir(exist_ok=True)
 (q/'M35-instance.json').write_text(json.dumps(i,ensure_ascii=False,indent=2)+'\n');shutil.copyfile(a/i['content_ref'],q/'M35-content.json')
 e=entries[i['module_id']];(q/'catalog-record.json').write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n')
 for name in z.namelist():
  if name.startswith('modules/'+i['module_id']+'/') and not name.endswith('/'):
   target=q/'original-package-leaves'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(z.read(name))
selection={'schema':'mapgen-host-v2/evidence-selection/v1','source_map_id':m['map_id'],'status':'NOT_ADOPTED','instance_ids':ids,'connection':m['connections'][0],'reason':'Complete C001 pair includes unsupported latch, enemy and approved_hq_cells. Retained unchanged for audit, not selected for r1 host fixture.','external_connections':[c for c in m['connections'] if (c['a']['instance_id'] in ids)!=(c['b']['instance_id'] in ids)],'seals_ports_routes_preserved':True,'full_map_preserved':str(a/'map.json'),'current_selected_supported_danger_pair':None}
(f/'selection.json').write_text(json.dumps(selection,ensure_ascii=False,indent=2)+'\n')
receipt={'task':'MAPGEN-HOST-V2-01','mapgen_commit':'178c40164c2f7371ce1c8a56cde658e84a4f42c2','mapedit_release_file_commit':'47aefebe07f4f0e7471f3d1546214502a6b2aade','mapedit_package_source_commit':'02b5cb53b06d7009225b2ecff9351f315e46b12e','package_sha256':'5ad5a7871941b2c1ffa759b18f7b1e80f2fe7e571b72f95d1e0ef26031f08723','catalog_sha256':hashlib.sha256((out/'catalog.json').read_bytes()).hexdigest(),'official_generation_status':'PASS','runtime_schema':m['schema'],'map_instances':len(m['instances']),'map_connections':len(m['connections']),'initial_pair_status':'C001 retained NOT_ADOPTED','supported_complete_danger_pair_count':0,'upstream_git_status':subprocess.check_output(['git','status','--porcelain'],cwd='/tmp/map-gen-host-source',text=True),'godot_run':False,'host_production_writes':0,'no_algorithm_copied_to_game':True}
try:
 import jsonschema
 jsonschema.Draft202012Validator(json.loads((out/'runtime-map-v2.schema.json').read_text())).validate(m);receipt['independent_runtime_schema_check']='PASS'
except ImportError:receipt['independent_runtime_schema_check']='NOT_RUN jsonschema unavailable'
(out/'freeze-receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
files={str(p.relative_to(out)):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in sorted(out.rglob('*')) if p.is_file() and p.name!='SHA256-manifest.json'}
(out/'SHA256-manifest.json').write_text(json.dumps({'schema':'evidence-file-manifest/v1','files':files},ensure_ascii=False,indent=2)+'\n')
print(json.dumps(receipt,ensure_ascii=False,indent=2))
