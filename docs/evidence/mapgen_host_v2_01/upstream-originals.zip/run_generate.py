from pathlib import Path
from mapgen import generate,GenerationRequest,GeneratorConfig,ModuleLibrary,GenerationHooks
import json,time,sys,hashlib,subprocess,platform
out=Path('/workspace/refactor-evidence/mapgen-host-v2-01/upstream');src=Path('/tmp/map-gen-host-source')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=src,text=True).strip()=='178c40164c2f7371ce1c8a56cde658e84a4f42c2'
attempt=out/'attempt-01-official-930001';attempt.mkdir(exist_ok=False)
request=json.loads((out/'request.json').read_text());config=json.loads((out/'config.json').read_text());lock=json.loads((out/'library-lock.json').read_text())
commands={'command':'PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/tmp/map-gen-host-source python3 /workspace/refactor-evidence/mapgen-host-v2-01/upstream/run_generate.py','api':'mapgen.generate(GenerationRequest.from_dict(request), ModuleLibrary.from_zip(archive,expected_sha256=lock.sha256), GeneratorConfig.from_dict(config), hooks=GenerationHooks(...))','source_commit':'178c40164c2f7371ce1c8a56cde658e84a4f42c2','python':platform.python_version(),'request':request,'config':config,'library_lock':lock,'source_sha256':{str(p.relative_to(src)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((src/'mapgen').glob('*.py'))}}
(attempt/'invocation.json').write_text(json.dumps(commands,ensure_ascii=False,indent=2)+'\n')
events=[]
def checkpoint(event):
 events.append(event);print(json.dumps({'checkpoint':event},ensure_ascii=False),flush=True)
def failure(event):
 events.append({'failure':event});print(json.dumps({'failure':event},ensure_ascii=False),flush=True)
library=ModuleLibrary.from_zip(out/'module-pack-1.1.0.zip',expected_sha256=lock['sha256'])
start=time.perf_counter();result=generate(GenerationRequest.from_dict(request),library,GeneratorConfig.from_dict(config),hooks=GenerationHooks(on_checkpoint=checkpoint,on_failure=failure))
(attempt/'result.json').write_text(json.dumps(result.to_dict(),ensure_ascii=False,indent=2)+'\n')
(attempt/'events.json').write_text(json.dumps(events,ensure_ascii=False,indent=2)+'\n')
if result.status=='PASS':
 (attempt/'map.json').write_text(json.dumps(result.map,ensure_ascii=False,indent=2)+'\n')
 for ref,content in result.content_store.items():
  target=attempt/ref;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(json.dumps(content,ensure_ascii=False,indent=2)+'\n')
receipt={'status':result.status,'request_fingerprint':result.fingerprint,'wall_seconds':time.perf_counter()-start,'metrics':result.metrics,'map_instances':len(result.map['instances']) if result.map else None,'map_bytes':(attempt/'map.json').stat().st_size if result.map else None,'content_records':len(result.content_store),'seed':request['seed'],'no_seed_substitution':True,'no_goal_relaxation':True,'upstream_git_status_after':subprocess.check_output(['git','status','--porcelain'],cwd=src,text=True)}
(attempt/'run-receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n');print(json.dumps(receipt,ensure_ascii=False,indent=2),flush=True)
sys.exit(0 if result.status=='PASS' else 2)
