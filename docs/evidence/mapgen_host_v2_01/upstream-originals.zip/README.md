# MAPGEN-HOST-V2-01 upstream frozen evidence

Actual API generation of official request930001 + unchanged stable-v2 config passed on the first attempt. Map-gen source is locked to main178c40164c2f7371ce1c8a56cde658e84a4f42c2. The generator source was imported from that read-only checkout; no algorithm was copied into the host, no upstream file changed, no Godot ran.

The real map-edit module1.1.0 ZIP was obtained as one locked GitHub API leaf, 1,750,444 bytes, SHA2565ad5a7871941b2c1ffa759b18f7b1e80f2fe7e571b72f95d1e0ef26031f08723. Catalog SHA307b3c02c08d6f9abd58ef10bfe0716709bc8260db49a2a2c21d36980330be7a. Release-file commit47aefebe07f4f0e7471f3d1546214502a6b2aade differs from manifest's actual package-source commit02b5cb53b06d7009225b2ecff9351f315e46b12e; both are retained. Selected raw source record leaves were fetched at the package-source commit. No large map-edit repository was cloned; package/leaf receipts include URLs, HTTP statuses, Git blob IDs and SHA256.

## Actual files

- `request.json`, `config.json`, `library-lock.json`: byte copies of official inputs.
- `run_generate.py` + `attempt-01.log` + `attempt-01-official-930001/invocation.json`: exact actual API entrypoint, command, Python/source hashes and complete events/result/metrics. Re-running intentionally refuses to overwrite attempt-01.
- `attempt-01-official-930001/map.json`: complete runtime-map/v2,46 instances/55 connections/three reference main paths;547741 bytes. `content/` contains all46 complete materialized records. Full result and diagnostics also remain.
- `full-content-inventory.json`: every instance, every field/type/count/value, all nonempty entity counts and aggregates. Map totals:236 platforms,78 one-way indices,30 moving platforms,18 enemies,20 approvedHQ cells,11 reward sites,3 hazards,12 thorns,7 saws,9 latches,1 hook,1 original region chest and1 carried-enemy list. Some content also declares scalar warmup/profile flags; all fields are inventoried.
- `connection-selection-audit.json`: all55 actual connections scanned in ascending ID with exact unsupported-content reasons and danger presence. `pair-candidate-scan.json` records the allowed field rule and empty eligible set.
- `c001-not-adopted/`: initial M01/M02 candidate preserved completely (instance Ports/seals/routes/service requirements, unchanged content, full catalog records and original package leaves). Its locked source `record.json` files are under map-edit-api/02b5.../modules/. It is **not adopted**: M01 has a latch; M02 has enemy+approvedHQ cells.
- `danger-module-unpaired/`: M35 original instance, full content, full catalog and original package leaves retained for inspection; not misrepresented as a valid supported pair.
- `package-leaves/`: exact package runtime builder reference, both host locks, player profiles and installer; no installer was run. Locked map-edit AGENTS/README/Foundation/consumer docs and raw source records are under `map-edit-api/`.
- `freeze-receipt.json`, `SHA256-manifest.json`: generation/source/schema/selection status and exact frozen file hashes. Independent runtime-map JSON Schema validation passed; this is separate from Godot physics/playability.

## Selection result under the narrowed r1 contract

After official success, root narrowed r1 to complete pairs without enemy/reward/HQ/latch/hooks/unknown nonempty content, allowing true platforms/oneway/walls/hazard/thorn/saw and standard linear ferries. At least one real hazard/thorn/saw is required. Applying this unchanged rule to ascending actual connection IDs yields **zero eligible pairs**. No content, target or seed was removed/replaced to make this appear successful.

The only simple dangerous instance is M35(game-plains-ferry-gears):hazard1+saw1+linear ferries2. Its actual neighbors are C008→M04(enemy+HQ), C051→M34(enemy+carried-enemy/warmup), C052→M41(reward). All complete native-only pairs(C017,C030,C031,C036,C037,C048) have no danger. The initial C001 is preserved but is outside r1. This batch therefore supplies a complete genuine frozen map and an honest selection gap, **not an accepted two-room playable fixture**.

## v2 host facts

`world_pixel = origin_blocks*128 + local_pixel`; positive x right/y down. Instance content is already owned-rectangle and fully materialized, including horizontal mirror. Do not apply source_affine, source origin offset or negative parent scale again. Real arbitrary Ports are instance.ports with original IDs; connected_port_ids, full seals and effective directed routes must remain. Never replace these with an old entry/exit pair. Player spawn and Boss completion anchors remain UNRESOLVED; static graph PASS does not provide a playable spawn.

Package builder reference `runtime/module_runtime/module_loader_v3-1d72f57d63dd.gd` maps raw platform/hazard/ferry/saw/thorn fields to existing PlatformingModuleDefinition/native definitions. Its old loader also fabricates entry/exit Ports, so only the content-mapping portion is suitable reference for a new v2 adapter. Keep the current host Player/physics/services and actual v2 Port records. Package default host12f6... and current-game compatibility profile5f557... are historical locks, not authorization to overwrite the current host. Mirroring/seams/seals retain UNKNOWN/NOT_RUN physical scope.


## r2 selection update

Root revised the local slice requirement to real moving-platform riding. The original M16/M18/M21 slice with C027/C030/C031 is now frozen in `selection-r2.json` and `selection-r2/README.md`; all three complete contents/instances/seals/routes, explicit cut edges and the exact source ellipse implementation are retained. The r1 zero-danger-pair outcome above remains historical evidence, not a claim that r2 failed. Physics and host riding are still NOT_RUN by this upstream author.
