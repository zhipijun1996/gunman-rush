# r2 real moving-platform interaction slice

Root explicitly revised r1's danger requirement to a real moving-platform interaction. This slice uses the original official930001 map, with unchanged request/config/library/seed/goals. `../selection-r2.json` records the exact selection and source fingerprint. R1's zero-danger-pair scan, C001 rejection, complete46-module map and all46 contents remain intact.

Selected original instance IDs are M16/M18/M21. All instance fields, full materialized content, exact catalog records, original package leaves and locked package-source `record.json` leaves are retained. Content SHA256: M16 `9cfa577517940be7e715942d32b0afebe39226faf6a0d8c51aa40885eb87d496`; M18/M21 each `e1e0a2f82917adad1c69a723d2276a44e112feab6719d8ea4c3b96b86e5e7512`.

- M16 idea-spec02-s11-001:origin[-3,6],size[5,4],mirrored;4 platforms/one one-way index/one true ellipse platform.3 Ports/2 effective Routes/one original BOTTOM seal.
- M18 game-route-junction:origin[-9,5],size[6,2],mirrored;all7 platforms.4 Ports/6 effective Routes/one original RIGHT seal.
- M21 same module content:origin[-15,5],size[6,2],mirrored.4 Ports/12 effective Routes/no seals.

Internal original connections: C027 M16.R↔M18.entry_left at[-384,832]; C030 M18.entry_right↔M21.entry_left at[-1152,832]; C031 M18.exit_upper_right↔M21.exit_upper_left at[-1152,704]. Every selected endpoint was statically recomputed from original origin*128+local Port and exactly matches its exported connection position. This is coordinate evidence, not a newly certified physical seam or whole route.

Cut edges C022/C036/C037 retain their exact full-map records with absent external endpoints. No connected Port was relabeled as unused, no route was dropped, no synthetic seal was added. The host must explicitly scope its slice boundary/test endpoints; it cannot claim this slice is the complete46-module map or silently substitute new closures. Enemy/reward/Boss/projectile-to-latch flows are outside this r2 scope and none of those content entities exists in these three selected records.

## Original ellipse implementation

Exact minimal leaves under `ellipse-source/runtime/module_runtime/`, verified against the locked ZIP manifest:

- revision061_ellipse_definition_v1-fff23a5cee8f.gd SHA256 `ca112f114470b372b5322e10e6da8d3f59dd5752e0fda0e129fbe282b26e46fd` (689B).
- revision061_ellipse_install_v1-7416999b951a.gd SHA256 `bf6618e3f3fa563334c39903baf348396482e6225894e2cd7eb1c13feb10be8f` (849B).
- module_loader_revision061_v2-daa7e5eceb9f.gd SHA256 `b7bf21f75141f2ae0d2a3be33526a1fb3a740c19179b93a62da2036d2c752791` (4930B), retaining the real replacement/install call site.

The original definition extends existing ModuleMovingPlatformDefinition. `period()` returns travel_duration. `at_time(clock)` computes `a=PI+TAU*fposmod(clock/period()+initial_phase,1.0)` then `center+Vector2(cos(a)*radii.x,sin(a)*radii.y)`. Envelope is `Rect2(center-radii-size*.5,radii*2+size)`. Original validity requires nonempty ID, finite positive radii/size/travel_duration, zero dwell and finite phase in[0,1). The installer copies ellipse_center/radii/period/phase/size/start/finish and replaces the existing ferry definition when trajectory_kind is clockwise_ellipse/v1. Start/finish are not a command to replace the curve with linear ping-pong.

M16's fully materialized content has ellipse_x_sign=-1, center[320,256],radii[160,144],period8,phase0,start[480,256],finish[160,256],size[112,16]. The original package definition predates map-gen's materialized mirror x-sign and does not read it. The host adapter must honor that sign on the original x offset while retaining the original phase, sine and Vector2 rounding boundaries; do not remirror the entire module or use the unmirrored original leaf unchanged. The local envelope remains[104,104,432,304]. The mathematically expected mirrored quarter-turn landmarks are t0[480,256],t2[320,112],t4[160,256],t6[320,400],t8[480,256]; these are analytic checks, not observed engine samples.

The implementation agent `/root/items_refactor` and root received the exact leaves, SHA and x-sign distinction. No Godot was run by this upstream freezer; riding/seams/physics remain NOT_RUN here. No upstream or host production source was edited.
