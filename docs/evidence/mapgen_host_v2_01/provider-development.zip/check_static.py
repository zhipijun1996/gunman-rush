from pathlib import Path
import json,hashlib,struct,math,subprocess
root=Path('/workspace/gunman-rush-refactor');src=Path('/workspace/refactor-evidence/mapgen-host-v2-01/upstream/attempt-01-official-930001');out=Path(__file__).parent
m=json.loads((src/'map.json').read_text());ids=['M16','M18','M21'];instances={x['id']:x for x in m['instances']};content={i:json.loads((src/'content'/f'{i}.json').read_text()) for i in ids};rows=[]
def encloses(a,b):return a[0]<=b[0] and a[1]<=b[1] and a[0]+a[2]>=b[0]+b[2] and a[1]+a[3]>=b[1]+b[3]
def intersects(a,b):return a[0]<b[0]+b[2] and a[0]+a[2]>b[0] and a[1]<b[1]+b[3] and a[1]+a[3]>b[1]
for i in ids:
 c=content[i];ins=instances[i];bounds=c['world_bounds'];platforms=c['platforms']+[s['rect_pixels'] for s in ins['seals']];assert all(encloses(bounds,p) for p in platforms)
 envelope=[]
 for e in c['moving_platforms']:
  cx,cy=e['ellipse_center'];rx,ry=e['ellipse_radii'];w,h=e['size'];box=[cx-rx-w/2,cy-ry-h/2,2*rx+w,2*ry+h];envelope.append(box);assert encloses(bounds,box);assert e['start']==[cx-e['ellipse_x_sign']*rx,cy];assert e['finish']==[cx+e['ellipse_x_sign']*rx,cy]
 for port in ['entry_port','exit_port']:
  x,y=c[port];body=[x-12,y-18,24,36];assert any(abs(y+18-p[1])<=.1 and x-12>=p[0] and x+12<=p[0]+p[2] for p in platforms);assert not any(intersects(p,body) for p in platforms);assert not any(intersects(p,[body[0]-8,body[1]-8,40,52]) for p in envelope)
 rows.append({'instance':i,'original_platforms':len(c['platforms']),'original_seals':len(ins['seals']),'total_platforms':len(platforms),'one_way_indices':c['one_way_platform_indices'],'ferries':len(c['moving_platforms']),'body_ports_support_and_original_envelope_checks':'passed_python_geometry_subset_not_Godot_is_valid','origin_pixels':[v*128 for v in ins['origin_blocks']]})
edges=[]
for e in m['connections']:
 if all(e[k]['instance_id'] in ids for k in ['a','b']):
  for k in ['a','b']:
   x=e[k];ins=instances[x['instance_id']];port=next(p for p in ins['ports'] if p['id']==x['port_id']);at=[ins['origin_blocks'][n]*128+port['local_position_pixels'][n] for n in [0,1]];assert at==e['position_pixels'];assert port['surface']==e['surface']
  edges.append(e['id'])
assert edges==['C027','C030','C031']
paths=['game/world/levels/providers/runtime_map_v2_provider.gd','game/world/levels/providers/runtime_map_v2_provider.gd.uid','game/world/levels/content/runtime_map_ellipse_definition.gd','game/world/levels/content/runtime_map_ellipse_definition.gd.uid'];sha=lambda b:hashlib.sha256(b).hexdigest();leaves=[]
for p in paths:
 raw=(root/p).read_bytes();dest=out/'candidate'/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw);leaves.append({'path':p,'sha256':sha(raw),'bytes':len(raw)})
report={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'source_map_sha256':sha((src/'map.json').read_bytes()),'selected_ids':ids,'geometry_checks':rows,'internal_connection_ids':edges,'files':leaves,'consumer_contract':{'signature':'load_level(request,map,content_store,selected_ids,spawn,source_sha256)','content_store_keys':['content/M16.json','content/M18.json','content/M21.json'],'request_root_seed':'must equal str(map.seed); here930001','legacy_generated':'empty','source_preservation':'each Definition metadata runtime_map_v2_instance and runtime_map_v2_content; raw internal edge duplicate pluscondition=open','map_hash':'JSON.stringify([source_sha256,lexically sorted selected_ids]).sha256_text(); no RNG','native_trajectory':'upstream PI+TAU*fposmod(clock/period+initial_phase,1), Vector2 components then explicit materialized x_sign only; @export fields survive duplicate(true)'},'checks_not_run':['Godot parse','Definition.is_valid/supports native','Module duplicate Resource preservation','actual rider carrying/seam traversal','strict native teardown'],'no_files_or_nodes_created_by_provider':True,'unsupported_content':'Unknown content fields/trajectory fields or any nonempty unsupported arrays reject with instances.ID.content.FIELD; missing/invalid structures reject before Plan is published.'}
(out/'static-review.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps(report,ensure_ascii=False,indent=2))
