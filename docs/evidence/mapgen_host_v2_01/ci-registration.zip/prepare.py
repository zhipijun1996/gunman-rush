from pathlib import Path
import json,hashlib,copy,difflib,subprocess
R=Path('/workspace/gunman-rush-refactor');D=Path('/workspace/refactor-evidence/mapgen-host-v2-01/ci-registration');C=D/'candidate';B=D/'originals'
files=['tools/harness/profiles.json','config/production_impact.json','tools/production_plan.py','tests/test_production_plan.py']
for f in files:
 for root in (C,B):(root/f).parent.mkdir(parents=True,exist_ok=True)
 (B/f).write_bytes((R/f).read_bytes());(C/f).write_bytes((R/f).read_bytes())
name='runtime-map-v2-host';runner='tests/runtime_map_v2_runner.gd';m=json.loads((B/files[0]).read_text());old=copy.deepcopy(m)
check=copy.deepcopy(m['checks']['level-plan']);check['argv'][-1]=runner;check['success_pattern']='^RUNTIME MAP V2 HOST: [1-9][0-9]* assertions, 0 failures$';check['artifact_paths']=['build/mapgen_host_v2_01/native.json'];check['inputs']=[runner if p=='tests/level_plan_runner.gd' else p for p in check['inputs']];check['inputs'] += ['tools/godot_identity.py','tools/engine/patches']
m['checks'][name]=check
for profile in ('gameplay','full'):m['profiles'][profile].append(name)
(C/files[0]).write_text(json.dumps(m,indent=2)+'\n')
fixture=sorted(p.relative_to(R).as_posix() for p in (R/'resources/levels/mapgen_host_v2_01').rglob('*.json'))
sources=['game/world/levels/providers/runtime_map_v2_provider.gd','game/world/levels/content/runtime_map_ellipse_definition.gd','experiments/generation/runtime_map_frozen_source.gd','experiments/generation/runtime_map_slice.gd','experiments/generation/runtime_map_slice_stage.gd',runner]
paths=[p+s for p in sources for s in ('','.uid')]+['experiments/generation/entries/runtime_map_v2_slice.tscn']+fixture
text=(B/files[1]).read_text();p=json.loads(text)
for stage in ('development','integration'):
 prior=p['domains']['world'][stage];needle=json.dumps(prior);replacement=json.dumps(prior+[name]);assert text.count(needle)==1;text=text.replace(needle,replacement,1)
rule={'id':'runtime-map-v2-host','paths':paths,'domain':'world','reason':'Exact v2 loading-slice Provider, content fixture and real native consumer; shared world contracts remain selected and unknown experiment/resource neighbours stay full.'}
anchor='  "rules": [\n';assert text.count(anchor)==1;text=text.replace(anchor,anchor+'    '+json.dumps(rule,indent=2).replace('\n','\n    ')+',\n',1);(C/files[1]).write_text(text)
text=(B/files[2]).read_text();anchor='EXACT_EXPERIMENT_CONFIG = {\n';assert text.count(anchor)==1;text=text.replace(anchor,anchor+''.join('    '+repr(p)+': ("runtime-map-v2-host", "world"),\n' for p in fixture),1);(C/files[2]).write_text(text)
text=(B/files[3]).read_text();anchor='        current_manifest = self.manifest\n        retired_positions = {';assert text.count(anchor)==1
text=text.replace(anchor,'        appended_manifest = self.manifest\n        self.manifest = copy.deepcopy(appended_manifest)\n        for profile in ("gameplay", "full"):\n            self.assertEqual(self.manifest["profiles"][profile][-1], "runtime-map-v2-host")\n            self.manifest["profiles"][profile].pop()\n'+anchor,1)
anchor='        self.manifest = current_manifest\n\n    def test_real_refactor_runners';assert text.count(anchor)==1;text=text.replace(anchor,'        self.manifest = appended_manifest\n\n    def test_real_refactor_runners',1)
sha=lambda v:hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':')).encode()).hexdigest()
method='''    def test_runtime_map_v2_host_appends_real_consumer_and_exact_resource_routing(self):
        name = "runtime-map-v2-host"
        check = self.manifest["checks"][name]
        self.assertEqual(check["argv"], ["bash", "tools/godot.sh", "--headless", "--fixed-fps", "60", "--path", ".", "--script", "tests/runtime_map_v2_runner.gd"])
        self.assertEqual(check["timeout_seconds"], 180)
        self.assertIs(check["serial"], True)
        self.assertEqual(check["success_pattern"], "^RUNTIME MAP V2 HOST: [1-9][0-9]* assertions, 0 failures$")
        self.assertEqual(check["artifact_paths"], ["build/mapgen_host_v2_01/native.json"])
        self.assertEqual({p for p, checks in self.manifest["profiles"].items() if name in checks}, {"gameplay", "full"})
        canonical = lambda value: hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
        for profile, original_sha in PREFIXES.items():
            self.assertEqual(self.manifest["profiles"][profile][-1], name)
            self.assertEqual(canonical(self.manifest["profiles"][profile][:-1]), original_sha)
        full = self.plan(["project.godot"], "integration")
        self.assertEqual((len(full["checks"]), len(full["ci_lane_checks"]["parallel"]), len(full["ci_lane_checks"]["serial"])), (172, 92, 80))
        rule = next(r for r in self.policy["rules"] if r["id"] == name)
        self.assertEqual(rule["paths"], EXPECTED_PATHS)
        for path in rule["paths"]:
            with self.subTest(path=path):
                plan = self.plan([path], "integration")
                self.assertEqual(plan["selection"], "scoped")
                self.assertIn(name, plan["checks"])
                self.assertIn("level-plan", plan["checks"])
                self.assertNotIn("web-build", plan["checks"])
        for path in ("resources/levels/mapgen_host_v2_01/unknown.json", "experiments/generation/runtime_map_unknown.gd", "tests/runtime_map_unknown_runner.gd", "game/world/state/demo_lifetime.gd", "config/production_impact.json", "tools/harness/profiles.json"):
            with self.subTest(unknown_or_shared=path):
                self.assertEqual(self.plan([path], "integration")["selection"], "full")
        altered = copy.deepcopy(self.policy)
        next(r for r in altered["rules"] if r["id"] == name)["paths"].append("resources/levels/mapgen_host_v2_01/unknown.json")
        self.assertEqual(self.plan(["resources/levels/mapgen_host_v2_01/unknown.json"], "integration", altered)["selection"], "full")
        self.assertEqual(self.plan(["docs/handoff.md"], "integration")["checks"], self.policy["baseline_checks"])

'''.replace('PREFIXES',repr({p:sha(old['profiles'][p]) for p in ('gameplay','full')})).replace('EXPECTED_PATHS',repr(paths))
anchor='    def test_real_refactor_runners_keep_direct_strict_native_contracts(self):';text=text.replace(anchor,method+anchor,1);(C/files[3]).write_text(text)
patch=''.join(''.join(difflib.unified_diff((B/f).read_text().splitlines(True),(C/f).read_text().splitlines(True),fromfile='a/'+f,tofile='b/'+f)) for f in files);(D/'candidate.patch').write_text(patch)
(D/'paths.json').write_text(json.dumps({'write_set':files,'new_actual_paths':paths},indent=2)+'\n')
print('created',len(patch),'patch bytes',len(fixture),'fixtures; profiles',len(m['profiles']['full']))
