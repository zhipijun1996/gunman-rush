from pathlib import Path
import shutil,subprocess,json,time,hashlib
D=Path(__file__).resolve().parent;R=Path('/workspace/gunman-rush-refactor');O=D/'overlay';files=json.loads((D/'paths.json').read_text())['write_set'];prefixes={str(Path(f).parent) for f in files};prefixes|={str(p) for f in files for p in Path(f).parents if str(p)!='.'}
def build(source,target,relative=''):
 target.mkdir(exist_ok=True)
 for child in source.iterdir():
  if child.name in ('.git','.godot','build'):continue
  rel=(Path(relative)/child.name).as_posix();dest=target/child.name
  if dest.exists() or dest.is_symlink():continue
  if rel in files:shutil.copyfile(D/'candidate'/rel,dest)
  elif rel in prefixes:build(child,dest,rel)
  else:dest.symlink_to(child,target_is_directory=child.is_dir())
build(R,O)
before={f:hashlib.sha256((R/f).read_bytes()).hexdigest() for f in files};t=time.monotonic()
with (D/'planner-tests-03.log').open('w') as log:run=subprocess.run(['python3','tests/test_production_plan.py'],cwd=O,stdout=log,stderr=subprocess.STDOUT,timeout=30)
result={'command':['python3','tests/test_production_plan.py'],'cwd':str(O),'exit_code':run.returncode,'elapsed_seconds':time.monotonic()-t,'cap_seconds':30,'overlay':'4 candidate regular files; all other dependencies read-only symlinked current source; test methods only write TemporaryDirectory','main_before':before,'main_after':{f:hashlib.sha256((R/f).read_bytes()).hexdigest() for f in files}}
(D/'planner-tests-03.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if not k.startswith('main')}));print((D/'planner-tests-03.log').read_text()[-6500:])
