import hashlib
import json
from pathlib import Path
import subprocess
import sys

root = Path('/workspace/gunman-rush-refactor')
sys.path.insert(0, str(root / 'tools'))
import harness

out = Path('/workspace/refactor-evidence/mobile-combat-presentation-01')
label, *names = sys.argv[1:]
manifest = harness.load_manifest()
results = {}
for name in names:
    if name == 'pipeline-bench':
        check = {'argv':['bash','tools/godot.sh','--headless','--audio-driver','Dummy','--path','.', '--script',str(out / 'pipeline_bench.gd')], 'timeout_seconds':90, 'success_pattern':'^PRESENTATION_PIPELINE_BENCH '}
    else:
        check = manifest['checks'][name]
    result = harness.run_check(check, out / f'{label}-{name}.log', root=root)
    results[name] = result
    print(label, name, result['status'], result['duration_seconds'], flush=True)
    receipt = {'git_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'scope':'Local exact registered command via original run_check; not full Harness/CI or phone performance acceptance','results':results,'source_hashes':{str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [root/'game/enemies/presentation/enemy_presentation.gd',root/'game/presentation/actors/underworld_plains/underworld_enemy.gd',root/'game/enemies/presentation/plains_revision_visual.gd',root/'tests/plains_motion_loot_02_motion.gd',root/'tests/plains_motion_loot_02_presentation.gd']}}
    (out / f'{label}-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    if result['status'] != 'passed':
        sys.exit(1)
