extends SceneTree
## Controlled native host CPU only: no draw, browser, AI or device FPS.
var rows: Array = []
var traces: Array = []
func _initialize() -> void:
	run.call_deferred()
func run() -> void:
	for profile: StringName in [&"scene", &"underworld"]:
		for kind: StringName in [&"patrol", &"charger", &"hopper", &"sentry", &"fan_sentry", &"root_bell"]:
			var world := Node2D.new()
			world.process_mode = Node.PROCESS_MODE_DISABLED
			root.add_child(world)
			var floor_body := StaticBody2D.new()
			floor_body.position = Vector2(0, 420)
			var collision := CollisionShape2D.new()
			var shape := RectangleShape2D.new()
			shape.size = Vector2(10000, 40)
			collision.shape = shape
			floor_body.add_child(collision)
			world.add_child(floor_body)
			var motor := EnemyFactory.create_for_behavior(kind)
			world.add_child(motor)
			var actor := motor.get_node("Actor") as EnemyActor
			motor.position = Vector2(0, 400-actor.definition.collision_size.y*.5)
			actor.brain.enabled = false
			if profile == &"underworld": EnemyPresentationBinding.replace(actor, profile)
			var host := motor.get_node("Presentation") as Node2D
			var visual := host.get("revision_visual") as PlainsRevisionVisual
			var motion := host.get("body_motion") as PlainsMotion02
			await physics_frame
			var samples: Array[float] = []
			for batch: int in 27:
				var elapsed := 0
				for tick: int in 150:
					actor.brain.direction = 1 if (tick/9)%2 == 0 else -1
					motor.position.x += float(actor.brain.direction)*.7
					motor.velocity = Vector2(42*actor.brain.direction, sin(tick*.1)*30)
					var started := Time.get_ticks_usec()
					host.call("_process", 1.0/60.0)
					elapsed += Time.get_ticks_usec()-started
					if batch == 2 and tick in [0, 1, 8, 9, 10, 14, 15, 20, 149]:
						traces.append({"profile":profile,"kind":kind,"tick":tick,"pose":visual.pose.duplicate(true),"scale":visual.scale,"motion":[motion.clock,motion.stride,motion.drive,motion.body_follow,motion.appendage_follow]})
				if batch >= 2: samples.append(float(elapsed)/150.0)
			var average := 0.0
			for sample: float in samples: average += sample/samples.size()
			samples.sort()
			rows.append({"profile":profile,"kind":kind,"mean_tick_us":average,"p50_batch_us":samples[12],"p95_batch_us":samples[23],"samples":samples.size(),"ticks_per_sample":150})
			world.queue_free()
			await process_frame
			await process_frame
	print("PRESENTATION_PIPELINE_BENCH "+JSON.stringify({"rows":rows,"traces":traces,"scope":"Controlled current native host ticks only; excludes draw/upload/AI/browser/device. Timed loops use explicit motor/facing inputs; pose traces compare the same script before and after."}))
	quit()
