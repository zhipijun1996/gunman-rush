from pathlib import Path
import subprocess,json,time,re,hashlib
out=Path('build/forest_playable/ecology/grammar_trace_scope');rows=[]
for finish,verbose in [('direct',False),('direct',True),('deferred',False),('deferred',True)]:
 label=finish+('_verbose'if verbose else'_normal')
 argv=['bash','tools/godot.sh','--headless',*(['--verbose']if verbose else[]),'--fixed-fps','60','--path','.','--script',str(out/'probe.gd'),'--','--finish='+finish,'--output=res://'+str(out/(label+'.json'))]
 t=time.monotonic()
 with(out/(label+'.log')).open('w')as f:
  try:r=subprocess.run(argv,stdout=f,stderr=subprocess.STDOUT,timeout=12);code=r.returncode
  except subprocess.TimeoutExpired:code=None
 s=(out/(label+'.log')).read_text();rows.append({'case':label,'argv':argv,'exit_code':code,'seconds':time.monotonic()-t,'strict_errors':re.findall(r'^(?:WARNING:|ERROR:|SCRIPT ERROR:|Resource still in use:|Leaked instance:).*',s,re.M)})
 print(label,code,rows[-1]['seconds'],len(rows[-1]['strict_errors']),flush=True)
(out/'results.json').write_text(json.dumps({'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'scope':'Actual one coin branch, identical helper and probe bytes, direct vs deferred finish/normal vs verbose; no drain/retry','runs':rows},indent=2))
