extends SceneTree
const AUDIO_TEARDOWN := preload("res://tests/audio_teardown.gd")
## One actual coin-room branch using the unchanged formal trace helper.
## The deferred case inspects after _run returns; it never polls/drains/retries.
var failures := 0
var assertions := 0
var refs: Dictionary = {}
var finish_mode := "direct"
var output := ""
var audio_receipt: Dictionary = {}
func _initialize() -> void:
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--finish="): finish_mode=arg.trim_prefix("--finish=")
		if arg.begins_with("--output="): output=arg.trim_prefix("--output=")
	_run.call_deferred()
func check(ok: bool,label: String) -> void:
	assertions+=1
	if not ok:
		failures+=1
		print("GRAMMAR SCOPE FAILURE: ",label)
func _run() -> void:
	var tuning := PlayerTuning.load_default()
	var g := RandomStageGenerator.new()
	var layout := PlainsBranchLayout.new()
	var actual := PlainsStageGenerator.new().generate("grammar-coin-0",5,&"coin_reward",tuning)
	check(actual.ok,"actual coin fixture generates")
	if not actual.ok:
		_finish.call_deferred()
		return
	check(g.validate_manifest(actual.manifest,tuning).ok,"actual coin fixture validates")
	var trace = load("res://tests/plains_run_trace.gd").new()
	refs={"generator":weakref(g),"layout":weakref(layout),"trace":weakref(trace)}
	trace.tree=self
	trace.check=check
	await trace.branch_route(actual.manifest,tuning,"scope coin actual branch",0)
	if is_instance_valid(trace.world):
		if "--observed-audio-release" in OS.get_cmdline_user_args():
			var receipt: Dictionary=AUDIO_TEARDOWN.stop_fallback_voices(trace.world)
			check(receipt.pending.size()>0,"cleanup must observe at least one real active backend weakref")
			audio_receipt={"owners":receipt.owners,"pending_playback_weakrefs":receipt.pending.size(),"timeout_msec":1000}
			trace.world.free()
			var released: bool=await AUDIO_TEARDOWN.wait_fallback_release(receipt,1000)
			audio_receipt.released=released
			check(released,"actual stopped fallback playback must release within1000ms")
		else: trace.world.free()
	print("GRAMMAR SCOPE: actual branch done; finish=",finish_mode)
	if finish_mode=="deferred": _finish.call_deferred()
	else: _finish()
func _finish() -> void:
	var alive: Dictionary = {}
	for key: String in refs:
		alive[key]=is_instance_valid((refs[key] as WeakRef).get_ref())
		if finish_mode=="deferred": check(not alive[key],"owner "+key+" must be released after _run returned")
	var result: Dictionary={"finish_mode":finish_mode,"observed_audio_release":audio_receipt,"assertions":assertions,"failures":failures,"weak_owners_alive":alive,"scope":"one actual unchanged coin-branch trace; no extra idle-frame drain or polling"}
	if not output.is_empty():FileAccess.open(output,FileAccess.WRITE).store_string(JSON.stringify(result,"  "))
	print("GRAMMAR SCOPE RESULT: ",JSON.stringify(result))
	quit(1 if failures else 0)
