from pathlib import Path
import subprocess,json,time,re,hashlib
out=Path('build/forest_playable/ecology/grammar_trace_scope');rows=[]
paths=['tests/plains_run_trace.gd','tests/random_stage_tests.gd','tests/audio_teardown.gd','scripts/world/shot_latch.gd',str(out/'probe.gd')]
before={p:hashlib.sha256(Path(p).read_bytes()).hexdigest()for p in paths}
for cleanup,verbose in [(False,False),(False,True),(True,False),(True,True)]:
 label=('audio_preloaded_receipt'if cleanup else'audio_preloaded_baseline')+('_verbose'if verbose else'_normal')
 argv=['bash','tools/godot.sh','--headless',*(['--verbose']if verbose else[]),'--fixed-fps','60','--path','.','--script',str(out/'probe.gd'),'--','--finish=direct','--output=res://'+str(out/(label+'.json')),*(['--observed-audio-release']if cleanup else[])]
 t=time.monotonic()
 with(out/(label+'.log')).open('w')as f:
  try:r=subprocess.run(argv,stdout=f,stderr=subprocess.STDOUT,timeout=7);code=r.returncode
  except subprocess.TimeoutExpired:code=None
 s=(out/(label+'.log')).read_text();rows.append({'case':label,'argv':argv,'exit_code':code,'seconds':time.monotonic()-t,'strict_errors':re.findall(r'^(?:WARNING:|ERROR:|SCRIPT ERROR:|Resource still in use:|Leaked instance:).*',s,re.M)})
 print(label,code,rows[-1]['seconds'],len(rows[-1]['strict_errors']),flush=True)
after={p:hashlib.sha256(Path(p).read_bytes()).hexdigest()for p in paths}
(out/'audio_preloaded_results.json').write_text(json.dumps({'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'sources_before':before,'sources_after':after,'sources_unchanged':before==after,'scope':'Same probe bytes, actual one coin branch; immediate exit vs existing observed stopped-playback release, hard1000ms conditional check; no gameplay/audio defaults altered','runs':rows},indent=2))
