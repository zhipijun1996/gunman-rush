extends SceneTree
func _initialize() -> void: call_deferred("run")
func run() -> void:
 var trace_path: String = OS.get_cmdline_user_args()[0]
 var started := Time.get_ticks_msec()
 var script = load(trace_path)
 var loaded := Time.get_ticks_msec()
 var g := PlainsRegionGenerator.new()
 var tuning := PlayerTuning.load_default()
 var failed := 0
 var checks := 0
 var trace_usec := 0
 for i: int in 20:
  var r := g.generate("corpus/woven_layers/"+str(i),tuning,false,"woven_layers")
  checks+=1
  if not r.ok: failed+=1; continue
  var m: Dictionary=r.manifest
  checks+=1
  if not g.validate(JSON.parse_string(JSON.stringify(m)),tuning): failed+=1
  var n := g.generate("corpus/woven_layers/"+str(i),tuning,false,"woven_layers")
  checks+=1
  if m.manifest_hash != n.manifest.manifest_hash: failed+=1
  var ts := Time.get_ticks_usec()
  var trace=script.new()
  var assembler := PlainsRegionAssembler.new()
  assembler.manifest=m
  trace.stage=assembler
  var path: Array=trace.path_to("area_0_1",str(m.prep_id))
  checks+=1
  if path.is_empty(): failed+=1
  assembler.free()
  trace=null
  trace_usec+=Time.get_ticks_usec()-ts
 print("PERF20 ",JSON.stringify({"trace":trace_path,"load_ms":loaded-started,"corpus_ms":Time.get_ticks_msec()-loaded,"trace_creation_path_usec":trace_usec,"resources":Performance.get_monitor(Performance.OBJECT_RESOURCE_COUNT),"objects":Performance.get_monitor(Performance.OBJECT_COUNT),"checks":checks,"failed":failed}))
 quit(1 if failed else 0)
