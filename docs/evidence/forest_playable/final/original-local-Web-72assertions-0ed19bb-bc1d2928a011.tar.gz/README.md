# Original local Web browser evidence

This archive preserves actual 72-assertion original-consumer passes against local HTTP Web package source 0ed19bb2f9b50b5fcc191ded67b077b81b1fadea, build bc1d2928a011. It is not CI ZIP artifact acceptance.

- Action budget: serial_03, 24 assertions, exit 0, 101.421 seconds.
- Studio click: serial_02, 40 assertions, exit 0, 201.323 seconds.
- All weapons: serial_02, 8 assertions, exit 0, 90.649 seconds.

The original scripts, 30-second navigation timeout and harness 300-second process timeout were unchanged. Earlier navigation failures and the competing-load 300-second timeout remain in their original directories; these are not erased or counted as successes. Read evidence/browser_original_0ed19bb_serial_03/combined-original-three-passes.json to locate exact selected passing receipts.

All available reports, logs, screenshots, accepted-event traces, runner scripts and original failure receipts from all three evidence directories are included. Original consumer/helper/harness source bytes and hashes are included. The 90 MB PCK, Web engine assets and reconstructed project trees are excluded; package identity and its full observed local/HTTP hashes remain in the receipts. No remote CI artifact acceptance is claimed.

MEMBERS.json lists SHA-256 and byte length for every other archive member. The external archive receipt hashes the tar.gz, MEMBERS.json and every archive member including MEMBERS.json itself.
