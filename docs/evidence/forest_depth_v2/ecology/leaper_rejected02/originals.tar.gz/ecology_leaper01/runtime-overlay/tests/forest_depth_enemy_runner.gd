extends SceneTree
## Independent local goldens, not complete formal forest route admission.
const AUDIO := preload("res://tests/audio_teardown.gd")
const ECOLOGY_GEOMETRY := preload("res://scripts/generation/forest_ecology_geometry.gd")
var assertions := 0
var failures := 0
var tick := 0
var world: Node2D
var player: PlayerMotor
var controller: PlayerController
var policy: FrameDamagePolicy
var life: DemoLifetime
var enemies: Array[EnemyActor] = []
var contacts: Array[DemoContactEmitter] = []
var events: Array[Dictionary] = []
var cases: Array[Dictionary] = []
var comparisons: Array[Dictionary] = []
var stress_controls: Array[Dictionary] = []
class ThreadAblationPolicy extends FrameDamagePolicy:
	var disable_thread := false
	var suppressed: Array[Dictionary] = []
	func submit(request: DamageRequest) -> bool:
		if disable_thread and request.source_id==&"woven_thread_spider" and String(request.event_id).contains(":thread:"):
			suppressed.append({"physics_frame":Engine.get_physics_frames(),"event_id":String(request.event_id),"source":String(request.source_id),"target":String(request.target_id),"amount":request.amount,"actor_epoch":request.actor_epoch})
			return false
		return super.submit(request)
var comparison_frames: Array[Dictionary] = []
var comparison_id := ""
func _initialize() -> void: run.call_deferred()
func check(ok: bool, label: String) -> void:
	assertions += 1
	print("FOREST DEPTH CHECK: ","PASS " if ok else "FAIL ",label)
	if not ok: failures += 1
func frames(count: int) -> void:
	for i: int in count:
		await physics_frame
		await process_frame
		tick+=1
		for index: int in enemies.size():
			contacts[index].enabled = not enemies[index].health.terminal
		if not comparison_id.is_empty():
			comparison_frames.append(_comparison_frame())
func slab(rect: Rect2, one_way := false, support_id: String = "") -> void:
	var body := StaticBody2D.new()
	body.position=rect.get_center()
	body.set_meta("ecology_support_id",support_id)
	var shape := CollisionShape2D.new()
	var rectangle := RectangleShape2D.new()
	rectangle.size=rect.size
	shape.shape=rectangle
	shape.one_way_collision=one_way
	if one_way: body.add_to_group(&"one_way_platform")
	body.add_child(shape)
	world.add_child(body)
func cleanup() -> void:
	if not is_instance_valid(world): return
	controller.router.clear("forest_depth_fixture_cleanup")
	controller.active=false
	life.end()
	for actor: EnemyActor in enemies: actor.attack_behavior.cancel()
	var receipt: Dictionary = AUDIO.stop_fallback_voices(world)
	world.free()
	world=null
	enemies.clear()
	contacts.clear()
	check(await AUDIO.wait_fallback_release(receipt),"owned world audio backend actually released")
func fixture(at: Vector2 = Vector2(-30,282), geometry: Dictionary = {}) -> void:
	await cleanup()
	world=Node2D.new()
	root.add_child(world)
	if geometry.is_empty(): slab(Rect2(-1200,300,2600,50))
	else:
		for row: Dictionary in geometry.platforms:
			var rect: Array=row.rect
			slab(Rect2(rect[0],rect[1],rect[2],rect[3]),bool(row.one_way),str(row.role))
	player=load("res://scenes/player/player.tscn").instantiate()
	player.position=at
	world.add_child(player)
	controller=player.get_node("Controller")
	controller.enable_shot_energy()
	controller.traversal.grant(&"grapple")
	controller.shoot_ability.shot_fired.connect(_shot)
	life=DemoLifetime.new()
	policy=ThreadAblationPolicy.new()
	policy.lifetime=life
	world.add_child(policy)
	policy.register_target(&"player",controller.actor_resources.health,true)
	policy.batch_resolved.connect(_damage)
	await frames(5)
func _shot(aim: Vector2, serial: int) -> void:
	events.append({"kind":"accepted_shot","tick":tick,"serial":serial,"aim":[aim.x,aim.y],"projectiles":controller.shoot_ability._projectiles.size()})
func _damage(results: Array[DamageResult]) -> void:
	for result: DamageResult in results:
		events.append({"kind":"policy_result","tick":tick,"event_id":String(result.request.event_id),"source":String(result.request.source_id),"target":String(result.request.target_id),"hp":result.health.current})
func enemy(id: String, at: Vector2, instance_id: String = "") -> EnemyActor:
	var scene: PackedScene=load("res://scenes/enemies/patrol_drone.tscn" if id=="plains_charger" else "res://scenes/enemies/"+id+".tscn")
	var body := scene.instantiate() as EnemyMotor
	if id=="plains_charger":
		(body.get_node("Actor") as EnemyActor).definition=load("res://resources/enemies/plains_charger.tres")
	body.position=at
	world.add_child(body)
	var actor := body.get_node("Actor") as EnemyActor
	var source := StringName(instance_id if not instance_id.is_empty() else id)
	policy.bind_damageable(source,actor.damageable,actor.health)
	actor.bind_encounter(controller,policy,life,source,[])
	var contact := DemoContactEmitter.new()
	contact.policy=policy
	contact.controller=controller
	contact.source_id=StringName(str(source)+"_body")
	contact.half_size=actor.definition.collision_size*0.5
	body.add_child(contact)
	enemies.append(actor)
	contacts.append(contact)
	return actor
func ring(at: Vector2) -> void:
	var anchor := GrappleAnchor.new()
	anchor.position=at
	world.add_child(anchor)
func wait_state(behavior: EnemyAttackBehavior, wanted: StringName, limit := 240) -> bool:
	for i: int in limit:
		if behavior.state==wanted: return true
		await frames(1)
	return false
func shoot_to_death(actor: EnemyActor) -> void:
	for i: int in 6:
		if actor.health.terminal: return
		controller.router.request_action(&"shoot_release",(actor.motor.global_position-player.global_position).normalized())
		await frames(30)
func cross_with_fixed_ring(actor: EnemyActor) -> bool:
	ring(Vector2(175,190))
	await frames(2)
	controller.router.request_action(&"grapple",(Vector2(175,190)-player.global_position).normalized())
	controller.router.set_move_axis(1)
	var caught_fixed := false
	for i: int in 85:
		await frames(1)
		if controller.traversal.hook_target is GrappleAnchor: caught_fixed=true
	controller.router.set_move_axis(0)
	await frames(25)
	return caught_fixed and player.global_position.x>200 and actor.health.current==actor.health.capacity and controller.actor_resources.health.current==controller.actor_resources.health.capacity
func _comparison_frame() -> Dictionary:
	var actors: Array = []
	for actor: EnemyActor in enemies:
		actors.append({"id":String(actor.definition.stable_id),"instance_id":String(actor.attack_behavior.source_id),"position":[actor.motor.global_position.x,actor.motor.global_position.y],"hp":actor.health.current,"state":String(actor.attack_behavior.state),"state_time":actor.attack_behavior.state_time})
	for index: int in enemies.size():
		if enemies[index].attack_behavior is ForestBranchLeaperBehavior:
			actors[index]["depth"]=enemies[index].attack_behavior.depth_snapshot()
	var support_id := ""
	if player.is_on_floor():
		var ray:=PhysicsRayQueryParameters2D.create(player.global_position,player.global_position+Vector2(0,24),1,[player.get_rid()])
		var support:=player.get_world_2d().direct_space_state.intersect_ray(ray)
		if not support.is_empty(): support_id=str((support.collider as Node).get_meta("ecology_support_id","root_floor"))
	return {"support_id":support_id,"normal_velocity":[player.normal_velocity.x,player.normal_velocity.y],"recoil_velocity":[player.recoil_velocity.x,player.recoil_velocity.y],"burst_remaining":player.recoil_burst_remaining,"shot_cost":controller.shot_energy.shot_energy_cost,"contact_remaining":controller.traversal._contact_remaining,"comparison":comparison_id,"tick":tick,"position":[player.global_position.x,player.global_position.y],"grounded":player.is_on_floor(),"hp":controller.actor_resources.health.current,"stamina":controller.actor_resources.stamina.current,"shot_charges":controller.action_resources.shot_charges,"H_state":String(controller.traversal.state),"H_target":str(controller.traversal.hook_target.name) if is_instance_valid(controller.traversal.hook_target) else "","actors":actors}

func _walk_to_entry(entry: Vector2) -> bool:
	for i: int in 180:
		var dx:=entry.x-player.global_position.x
		if absf(dx)<=player.tuning.ground_speed/float(Engine.physics_ticks_per_second) and player.is_on_floor():
			controller.router.set_move_axis(0)
			await frames(1)
			return true
		controller.router.set_move_axis(signf(dx))
		await frames(1)
	controller.router.set_move_axis(0)
	return false

func _consume_misses_and_return(entry: Vector2) -> bool:
	var cost:=controller.shot_energy.shot_energy_cost
	for shot: int in 7:
		if controller.actor_resources.stamina.current>=cost and controller.actor_resources.stamina.current<=cost*2: return true
		controller.router.request_action(&"shoot_release",Vector2.LEFT)
		await frames(int(ceil(player.tuning.shot_burst_duration*float(Engine.physics_ticks_per_second)))+1)
		if not await _walk_to_entry(entry): return false
	return false

func _phase_ready(spider: EnemyActor, lantern: EnemyActor, phase: String) -> bool:
	if phase=="fresh": return true
	if phase=="line_hold": return spider.attack_behavior.state==&"hold"
	var motion:=lantern.attack_behavior
	if motion.state!=&"travel": return false
	var relative:=lantern.motor.global_position.x-motion.home.x
	var limit:=lantern.definition.patrol_half_width*.75
	return (phase=="travel_left" and lantern.brain.direction<0 and relative<=-limit) or (phase=="travel_right" and lantern.brain.direction>0 and relative>=limit)

func run_combination(layout: String, strategy: String, legacy := false, variant: Dictionary = {}) -> void:
	comparison_id=""
	var geometry: Dictionary=ECOLOGY_GEOMETRY.woven_crown() if layout=="woven_crown" else {}
	var entry: Vector2=Vector2(geometry.spawn[0],geometry.spawn[1]) if not geometry.is_empty() else Vector2(10,282)
	await fixture(entry,geometry)
	var primary: EnemyActor
	var secondary: EnemyActor
	if layout=="root_split":
		slab(Rect2(140,190,220,16),true,"main_branch")
		ring(Vector2(175,150))
		primary=enemy("plains_charger",Vector2(160,284))
		secondary=enemy("forest_thread_spider",Vector2(270,150))
		(secondary.attack_behavior as ForestThreadSpiderBehavior).configure_line(Vector2(120,172),Vector2(260,172))
	else:
		for row: Dictionary in geometry.hook_anchors: ring(Vector2(row.position[0],row.position[1]))
		var spider_row: Dictionary=geometry.enemies[0]
		var lantern_row: Dictionary=geometry.enemies[1]
		primary=enemy(str(spider_row.behavior_id),Vector2(spider_row.position[0],spider_row.position[1]),str(spider_row.id))
		(primary.attack_behavior as ForestThreadSpiderBehavior).configure_line(Vector2(spider_row.line_start[0],spider_row.line_start[1]),Vector2(spider_row.line_end[0],spider_row.line_end[1]))
		secondary=enemy(str(lantern_row.behavior_id),Vector2(lantern_row.position[0],lantern_row.position[1]),str(lantern_row.id))
	# All controls use identical layout/real actor definitions/resources per layout.
	# Legacy naturally retains its own HP/body/range/timing, reported as limitations.
	var setup_event_start:=events.size()
	var setup_started:=tick
	var phase_name:=str(variant.get("phase","fresh"))
	comparison_id="setup/"+str(variant.get("id",layout+"/"+strategy))
	(policy as ThreadAblationPolicy).disable_thread=bool(variant.get("line_disabled",false))
	var setup_ok:=true
	if not variant.is_empty():
		for phase_tick: int in 600:
			if _phase_ready(primary,secondary,phase_name): break
			await frames(1)
		setup_ok=_phase_ready(primary,secondary,phase_name)
		if bool(variant.get("dead_lantern",false)):
			await shoot_to_death(secondary)
			setup_ok=setup_ok and secondary.health.terminal and await _walk_to_entry(entry)
		if bool(variant.get("low_resource",false)):
			setup_ok=setup_ok and await _consume_misses_and_return(entry)
	var setup_state:=_comparison_frame()
	comparison_id=str(variant.id) if not variant.is_empty() else layout+"/"+("legacy/" if legacy else "depth/")+strategy
	var exit_x: float=float(geometry.exit.position[0]) if not geometry.is_empty() else 450.0
	var began:=tick
	var event_start:=events.size()
	var first:=_comparison_frame()
	var observed_preview:=false
	var requested_H:=false
	var caught_expected:=false
	var upper_seen:=false
	var dangerous_observed:=false
	var preview_cancelled:=false
	if strategy=="bank_shoot":
		await shoot_to_death(primary)
	elif strategy=="direct_walk":
		pass
	else:
		if bool(variant.get("react_now",false)):
			for frame: Dictionary in comparison_frames:
				if frame.tick>=setup_started and str(frame.comparison).begins_with("setup/"):
					for actor_row: Dictionary in frame.actors:
						if actor_row.id=="forest_thread_spider" and actor_row.state=="telegraph": observed_preview=true
			observed_preview=observed_preview or primary.attack_behavior.state==&"telegraph"
		else: observed_preview=await wait_state(primary.attack_behavior,&"telegraph")
		if strategy=="lower_wait" or strategy=="wait_line":
			if strategy=="lower_wait":
				controller.router.set_move_axis(-1)
				for retreat_tick: int in 40:
					if player.global_position.x < -60: break
					await frames(1)
				controller.router.set_move_axis(0)
			var dangerous_seen:=false
			for i: int in 240:
				var phase: StringName=primary.attack_behavior.state
				dangerous_seen=dangerous_seen or phase in [&"rush",&"attack",&"hold"]
				if not dangerous_seen and phase==&"recovery":
					preview_cancelled=true
					break
				if dangerous_seen and phase in [&"retract",&"recovery",&"brake"]: break
				await frames(1)
			dangerous_observed=dangerous_seen
		else:
			var target: Vector2=secondary.motor.global_position if strategy=="live_H" else (Vector2(175,150) if layout=="root_split" else Vector2(geometry.hook_anchors[0].position[0],geometry.hook_anchors[0].position[1]))
			controller.router.request_action(&"grapple",(target-player.global_position).normalized())
			requested_H=true
	controller.router.set_move_axis(1)
	var jumped:=false
	var jump_release_at: int=-1
	var live_kick_seen:=false
	var recoil_request_tick: int=-1
	var recoil_before: Dictionary={}
	var recoil_after: Dictionary={}
	for i: int in 260:
		if strategy=="live_H":
			live_kick_seen=live_kick_seen or controller.traversal.state==&"hook_kick"
			if live_kick_seen and caught_expected and recoil_request_tick<0 and controller.traversal.state==&"free" and not player.is_on_floor():
				recoil_request_tick=tick
				recoil_before=_comparison_frame()
				controller.router.request_action(&"shoot_release",Vector2.LEFT)
			elif recoil_request_tick>=0 and recoil_after.is_empty() and tick>recoil_request_tick:
				recoil_after=_comparison_frame()
		if not jumped and player.is_on_floor():
			for candidate: EnemyActor in enemies:
				if candidate.health.terminal: continue
				var offset:=candidate.motor.global_position-player.global_position
				var half_player: Vector2=(player.get_node("CollisionShape2D") as CollisionShape2D).shape.get_rect().size*0.5
				var half_enemy:=candidate.definition.collision_size*0.5
				var takeoff_distance:=half_player.x+half_enemy.x+player.tuning.ground_speed*player.tuning.jump_hold_duration
				if offset.x>0 and offset.x<takeoff_distance and absf(offset.y)<half_player.y+half_enemy.y:
					controller.router.request_action(&"jump")
					jumped=true
					jump_release_at=i+int(ceil(player.tuning.jump_hold_duration*float(Engine.physics_ticks_per_second)))
					break
		if i==jump_release_at: controller.router.request_action(&"jump_release")
		var hook_target:=controller.traversal.hook_target
		if is_instance_valid(hook_target):
			caught_expected=caught_expected or (hook_target==secondary.motor if strategy=="live_H" else hook_target is GrappleAnchor)
		upper_seen=upper_seen or str(_comparison_frame().support_id)=="main_branch"
		if player.global_position.x>exit_x and player.is_on_floor(): break
		if controller.actor_resources.health.terminal: break
		await frames(1)
	controller.router.set_move_axis(0)
	await frames(3)
	var last:=_comparison_frame()
	var result: Dictionary={"id":comparison_id,"layout":layout,"geometry_version":str(geometry.get("version","root_split_local")),"strategy":strategy,"legacy":legacy,"start":first,"end":last,"ticks":tick-began,"completed":player.global_position.x>exit_x and not controller.actor_resources.health.terminal,"observed_preview":observed_preview,"requested_H":requested_H,"caught_expected_H_target":caught_expected,"upper_support_seen":upper_seen,"committed_attack_seen":dangerous_observed,"preview_cancelled_on_retreat":preview_cancelled,"recoil_request_tick":recoil_request_tick,"recoil_before":recoil_before,"recoil_after":recoil_after,"primary_definition":{"id":String(primary.definition.stable_id),"hp":primary.health.capacity,"body":[primary.definition.collision_size.x,primary.definition.collision_size.y],"range":primary.definition.activation_range,"telegraph":primary.definition.telegraph_duration,"line_damage":(primary.definition as ForestEnemyDefinition).line_damage if primary.definition is ForestEnemyDefinition else 0.0},"event_start":event_start,"event_end":events.size(),"scope":"Local combined fixture. Success alone does not prove mechanic value; controls preserve their original Definitions."}
	if variant.is_empty(): comparisons.append(result)
	else:
		result["variant"]=variant.duplicate(true)
		result["setup_ok"]=setup_ok
		result["setup_start_tick"]=setup_started
		result["setup_event_start"]=setup_event_start
		result["setup_state"]=setup_state
		result["thread_suppressed"]=(policy as ThreadAblationPolicy).suppressed.duplicate(true)
		result["geometry_hash"]=JSON.stringify(geometry).sha256_text()
		stress_controls.append(result)
	comparison_id=""

func run() -> void:
	if "--leaper" in OS.get_cmdline_user_args():
		await run_leaper_goldens()
		return
	await fixture(Vector2(80,282))
	var spider := enemy("forest_thread_spider",Vector2(260,190))
	var thread := spider.attack_behavior as ForestThreadSpiderBehavior
	check(spider.definition.is_valid() and thread!=null,"spider real Definition and dispatcher")
	await frames(90)
	check(thread.state==&"idle" and controller.actor_resources.health.current==controller.actor_resources.health.capacity,"unconfigured line fail-closed without attacks")
	check(not thread.configure_line(Vector2.ZERO,Vector2(500,0)),"overlong line rejected")
	check(thread.configure_line(Vector2(20,282),Vector2(140,282)),"authored bounded line accepted")
	check(await wait_state(thread,&"hold"),"spider whole preview/extend precedes hold")
	var hp := controller.actor_resources.health.current
	await frames(30)
	check(controller.actor_resources.health.current==hp-1,"standing in occupied line takes one real policy damage")
	await frames(8)
	check(controller.actor_resources.health.current==hp-1,"same line cycle never repeats damage")
	cases.append({"id":"spider_stand_line","tick":tick,"hp_before":hp,"hp_after":controller.actor_resources.health.current})
	await fixture(Vector2(0,282))
	spider=enemy("forest_thread_spider",Vector2(260,190))
	thread=spider.attack_behavior as ForestThreadSpiderBehavior
	thread.configure_line(Vector2(20,282),Vector2(140,282))
	check(await wait_state(thread,&"telegraph"),"spider safe observation before line locks")
	check(await cross_with_fixed_ring(spider),"spider actual fixed-H upper bypass never requires killing")
	cases.append({"id":"spider_live_bypass","tick":tick,"enemy_hp":spider.health.current,"player_hp":controller.actor_resources.health.current})
	await fixture()
	spider=enemy("forest_thread_spider",Vector2(260,190))
	thread=spider.attack_behavior as ForestThreadSpiderBehavior
	thread.configure_line(Vector2(20,282),Vector2(140,282))
	await shoot_to_death(spider)
	check(spider.health.terminal and not thread.line_active,"spider actual bullet death removes owned dangerous line")
	cases.append({"id":"spider_bullets","tick":tick,"terminal":spider.health.terminal})
	await fixture(Vector2(80,282))
	spider=enemy("forest_thread_spider",Vector2(260,190))
	thread=spider.attack_behavior as ForestThreadSpiderBehavior
	thread.configure_line(Vector2(20,282),Vector2(140,282))
	check(await wait_state(thread,&"telegraph"),"cancel fixture reaches real preview")
	var phase := thread.state_time
	paused=true
	for i: int in 8: await process_frame
	check(thread.state_time==phase,"pause freezes line preview")
	paused=false
	life.invalidate_actor()
	await frames(1)
	check(not thread.line_active and thread.state==&"recovery","actor epoch cancels old line before activation")
	controller.active=false
	hp=controller.actor_resources.health.current
	await frames(100)
	check(not thread.line_active and controller.actor_resources.health.current==hp,"inactive target leaves no damaging old line")
	cases.append({"id":"spider_cancel_pause_epoch_inactive","tick":tick})
	for strategy: String in ["bank_shoot","lower_wait","fixed_H"]:
		await run_combination("root_split",strategy,true)
	for strategy: String in ["bank_shoot","wait_line","fixed_H","live_H"]:
		await run_combination("woven_crown",strategy)
	for phase_name: String in ["fresh","line_hold"]:
		for strategy: String in ["direct_walk","wait_line","fixed_H","live_H"]:
			for disabled: bool in [false,true]:
				await run_combination("woven_crown",strategy,false,{"id":"ablation/"+phase_name+"/"+strategy+("/off" if disabled else "/on"),"phase":phase_name,"line_disabled":disabled,"react_now":phase_name!="fresh"})
	for phase_name: String in ["travel_left","travel_right"]:
		await run_combination("woven_crown","live_H",false,{"id":"phase/"+phase_name,"phase":phase_name,"react_now":true})
	await run_combination("woven_crown","fixed_H",false,{"id":"dead_lantern/fixed_H","dead_lantern":true})
	await run_combination("woven_crown","live_H",false,{"id":"low_resource/live_H","low_resource":true,"react_now":true})
	await cleanup()
	var output := "res://build/forest_depth/ecology/native"
	for argument: String in OS.get_cmdline_user_args():
		if argument.begins_with("--output-dir="): output=argument.trim_prefix("--output-dir=")
	DirAccess.make_dir_recursive_absolute(output)
	var file := FileAccess.open(output+"/capture.json",FileAccess.WRITE)
	file.store_string(JSON.stringify({"scope":"independent local real actors/Router/projectiles/policy; no formal full route claimed","assertions":assertions,"failures":failures,"cases":cases,"events":events,"comparisons":comparisons,"stress_controls":stress_controls,"comparison_frames":comparison_frames},"  "))
	file.close()
	print("FOREST DEPTH ENEMIES: %s assertions, %s failures" % [assertions,failures])
	quit(0 if failures==0 else 1)

func leaper_fixture() -> ForestBranchLeaperBehavior:
	# Exact relevant actual root/reward shores; no room claiming formal traversal.
	await fixture(Vector2(560,802),{"platforms":[{"rect":[290,820,500,50],"one_way":false,"role":"root_floor"},{"rect":[400,738,240,20],"one_way":true,"role":"reward_branch"}]})
	var actor:=enemy("forest_branch_leaper",Vector2(680,804))
	var leap:=actor.attack_behavior as ForestBranchLeaperBehavior
	var points: Array[Vector2]=[Vector2(680,804),Vector2(622,722)]
	var ids: Array[String]=["root_floor","reward_branch"]
	check(leap.configure_shores(points,ids),"leaper both complete body shores are actual supported surfaces")
	return leap

func _leaper_upper_stand() -> bool:
	var frame:=_comparison_frame()
	return frame.support_id=="reward_branch" and player.global_position.x>=412 and player.global_position.x<=628

func _leaper_route(strategy: String) -> void:
	comparison_id=""
	var leap: ForestBranchLeaperBehavior=await leaper_fixture()
	var actor:=leap.actor
	comparison_id="leaper/"+strategy
	var start:=_comparison_frame()
	var begin:=tick
	var event_start:=events.size()
	var h_requested:=false
	var arrived_h:=false
	var contact_seen:=false
	var free_tick:=-1
	var recoil_before: Dictionary={}
	var recoil_after: Dictionary={}
	var jump_at:=-1
	var r_requests:=0
	var upper_count:=0
	var upper_tick:=-1
	var upper: Dictionary={}
	var departure_observed:=false
	var fired_shots:=0
	var last_shot:=-100
	for i: int in 600:
		if strategy=="shoot_then_jump" and not actor.health.terminal:
			if tick-last_shot>=30 and controller.traversal.state==&"free":
				controller.router.request_action(&"shoot_release",(actor.motor.global_position-player.global_position).normalized())
				last_shot=tick;fired_shots+=1
		elif strategy=="live_H":
			departure_observed=departure_observed or leap.state==&"jump"
			if departure_observed and not h_requested:
				if player.global_position.x<733: controller.router.set_move_axis(1)
				else:
					controller.router.set_move_axis(0)
					h_requested=true
					controller.router.request_action(&"grapple",(actor.motor.global_position-player.global_position).normalized())
			if controller.traversal.hook_target==actor.motor:
				arrived_h=true
			if arrived_h and controller.traversal.state in [&"hook_contact_kick",&"hook_kick"]: contact_seen=true
			if contact_seen and free_tick<0 and controller.traversal.state==&"free" and not player.is_on_floor():
				free_tick=tick
				recoil_before=_comparison_frame()
				controller.router.request_action(&"shoot_release",Vector2.RIGHT)
				r_requests+=1
			elif free_tick>=0 and recoil_after.is_empty() and tick>free_tick: recoil_after=_comparison_frame()
			if free_tick>=0 and player.recoil_burst_remaining<=0:
				controller.router.set_move_axis(-1 if player.global_position.x>575 else 0)
		else:
			if strategy=="shoot_then_jump" and jump_at<0 and absf(player.global_position.x-560)>7:
				controller.router.set_move_axis(signf(560-player.global_position.x))
				await frames(1)
				continue
			controller.router.set_move_axis(0)
			if strategy=="wait_commit":
				departure_observed=departure_observed or (leap.state==&"jump" and actor.motor.global_position.y<758)
			if jump_at<0 and (strategy!="wait_commit" or departure_observed):
				controller.router.request_action(&"jump")
				jump_at=tick
			if tick==jump_at+int(ceil(player.tuning.jump_hold_duration*float(Engine.physics_ticks_per_second))): controller.router.request_action(&"jump_release")
			# The strongest cheap control may legitimately need zero R for 82px.
			if strategy=="ordinary_full_jump" and jump_at>=0 and not player.is_on_floor() and player.normal_velocity.y>=0 and player.global_position.y>720 and r_requests<2 and tick-last_shot>=10:
				controller.router.request_action(&"shoot_release",Vector2.DOWN)
				r_requests+=1;last_shot=tick
		upper_count=upper_count+1 if _leaper_upper_stand() else 0
		if upper_count>=12:
			upper_tick=tick;upper=_comparison_frame();break
		if controller.actor_resources.health.terminal or fired_shots>6: break
		await frames(1)
	controller.router.set_move_axis(0)
	check(upper_tick>begin,"leaper "+strategy+" reaches reward shore with twelve actual full-body supports")
	if strategy=="shoot_then_jump":
		check(actor.health.terminal,"leaper ordinary real projectiles kill before normal ascent")
	elif strategy=="wait_commit": check(departure_observed,"leaper wait route reads real committed departure")
	elif strategy=="live_H":
		check(h_requested and arrived_h and contact_seen,"leaper H reaches actual living moving actor rather than a line/marker")
		check(free_tick>=0 and not recoil_after.is_empty(),"leaper contact returns actual free state and accepts subsequent R")
	else: check(r_requests<=2 and not h_requested,"strong normal full jump allows at most two R without H")
	var returned:=false
	if upper_tick>begin:
		controller.router.request_action(&"drop_through")
		for i: int in 160:
			if player.is_on_floor() and str(_comparison_frame().support_id)=="root_floor": break
			await frames(1)
		returned=await _walk_to_entry(Vector2(560,802))
	check(returned and str(_comparison_frame().support_id)=="root_floor","leaper "+strategy+" completes real normal return, no relocation")
	cases.append({"id":comparison_id,"strategy":strategy,"start":start,"upper":upper,"end":_comparison_frame(),"entry_tick":begin,"upper_tick":upper_tick,"ticks":tick-begin,"returned":returned,"H_requested":h_requested,"H_arrived":arrived_h,"contact_seen":contact_seen,"free_tick":free_tick,"recoil_before":recoil_before,"recoil_after":recoil_after,"R_requests":r_requests,"event_start":event_start,"event_end":events.size(),"enemy_hp":actor.health.current,"landings":leap.landing_count,"motions":leap.motion_receipts.duplicate(true),"scope":"Actual local two shores and normal resources; comparison not automatic mechanism admission"})
	comparison_id=""

func run_leaper_goldens() -> void:
	var leap: ForestBranchLeaperBehavior=await leaper_fixture()
	comparison_id="leaper/physical_cycle"
	var began:=tick
	for i: int in 420:
		if leap.landing_count>=2 or leap.state==&"blocked": break
		await frames(1)
	check(leap.landing_count>=2,"leaper actual upper and lower landings, not same-height hopper return")
	check(leap.state!=&"blocked" and leap.current_shore==0,"physical complete-body one-way cycle returns to lower shore")
	check(not leap.motion_receipts.is_empty(),"leaper every movement has actual EnemyMotor collision receipt")
	cases.append({"id":comparison_id,"entry_tick":began,"depth":leap.depth_snapshot(),"motions":leap.motion_receipts.duplicate(true)})
	comparison_id=""
	for strategy: String in ["ordinary_full_jump","shoot_then_jump","wait_commit","live_H"]:
		await _leaper_route(strategy)
		if failures>0: break
	if failures==0:
		leap=await leaper_fixture()
		check(await wait_state(leap,&"telegraph"),"blocked counterexample first reaches genuine preview")
		slab(Rect2(646,650,22,140),false,"blocked_arc_wall")
		await frames(50)
		check(leap.state==&"blocked" and leap.landing_count==0,"actual blocking terrain rejects committed body arc without teleport")
		cases.append({"id":"leaper/blocked_arc","depth":leap.depth_snapshot(),"position":[leap.actor.motor.position.x,leap.actor.motor.position.y]})
		leap=await leaper_fixture()
		check(await wait_state(leap,&"telegraph"),"pause/cancel fixture reaches genuine preview")
		var phase:=leap.state_time
		paused=true
		for i: int in 8: await process_frame
		check(leap.state_time==phase,"leaper real tree pause freezes preview")
		paused=false
		var saved:=leap.depth_snapshot()
		check(leap.restore_depth_state(saved) and leap.depth_snapshot()==saved,"same live shores save/restore preserves actual branch phase data")
		var rejected:=saved.duplicate(true);rejected.target_shore=rejected.current_shore
		check(not leap.restore_depth_state(rejected),"malformed save shore identity rejected")
		life.invalidate_actor()
		await frames(1)
		check(leap.state==&"rest" and leap.landing_count==0,"actor epoch cancels old preview without a jump")
		controller.active=false
		var position:=leap.actor.motor.global_position
		await frames(120)
		check(leap.actor.motor.global_position==position and leap.landing_count==0,"inactive target cannot launch or leave old movement")
		controller.active=true
		check(await wait_state(leap,&"jump"),"renewed live target reaches a genuine physical jump")
		await frames(8)
		var flight_saved:=leap.depth_snapshot()
		check(leap.restore_depth_state(flight_saved) and leap.depth_snapshot()==flight_saved,"in-flight save data restores velocity and branch identity without moving body")
		life.invalidate_actor()
		await frames(1)
		check(leap.state==&"falling" and leap.flight_velocity.x==0,"new actor epoch cancels committed horizontal motion, no snap home")
		for i: int in 180:
			if leap.state in [&"blocked",&"settle"]: break
			await frames(1)
		check(leap.state in [&"blocked",&"settle"],"cancelled flight reaches a bounded physical collision/landing")
		await shoot_to_death(leap.actor)
		check(leap.actor.health.terminal and leap.actor.motor.collision_layer==0,"ordinary projectile death cancels actor and preserves empty normal route")
		cases.append({"id":"leaper/pause_save_cancel_death","depth":leap.depth_snapshot(),"enemy_hp":leap.actor.health.current})
	await cleanup()
	var output:="res://build/forest_depth/ecology/leaper"
	for argument: String in OS.get_cmdline_user_args():
		if argument.begins_with("--output-dir="): output=argument.trim_prefix("--output-dir=")
	DirAccess.make_dir_recursive_absolute(output)
	var file:=FileAccess.open(output+"/capture.json",FileAccess.WRITE)
	file.store_string(JSON.stringify({"scope":"Local cross-shore physical golden only; not random pool or full forest admission","assertions":assertions,"failures":failures,"cases":cases,"events":events,"comparison_frames":comparison_frames},"  "))
	file.close()
	print("FOREST DEPTH ENEMIES: %s assertions, %s failures" % [assertions,failures])
	quit(0 if failures==0 else 1)
