class_name ForestBranchLeaperPresentation
extends Node2D
@export var actor: EnemyActor
func _process(_delta: float) -> void: queue_redraw()
func _draw() -> void:
	if not is_instance_valid(actor): return
	var alive:=not actor.health.terminal
	var color:=Color("9eb35d") if alive else Color("444a39")
	draw_rect(Rect2(-14,-16,28,32),color)
	draw_line(Vector2(-9,11),Vector2(-18,17),Color("e4bd74"),4)
	draw_line(Vector2(9,11),Vector2(18,17),Color("e4bd74"),4)
	draw_circle(Vector2(-5,-6),2,Color("fff0c2"))
	draw_circle(Vector2(5,-6),2,Color("fff0c2"))
	var leap:=actor.attack_behavior as ForestBranchLeaperBehavior
	if not alive or leap==null or not leap.configured: return
	if leap.state in [&"telegraph",&"jump"]:
		var target:=to_local(leap.shores[leap.target_shore])
		draw_rect(Rect2(target-Vector2(17,18),Vector2(34,36)),Color("ffc66f"),false,2)
		draw_line(Vector2.ZERO,target,Color("ffc66f",.35),2)
	if leap.state==&"blocked": draw_line(Vector2(-10,-10),Vector2(10,10),Color("ee7174"),3)
