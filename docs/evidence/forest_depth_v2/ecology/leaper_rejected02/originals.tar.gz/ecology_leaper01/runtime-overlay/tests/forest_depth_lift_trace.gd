extends "res://tests/forest_depth_ecology_trace.gd"
## One real R->E candidate in the generated DemoApp, never a copied room.
var lift_strategy := "alive_lift"
var lift_started := -1
var lift_finished := -1
var lift_state := "entry"
var lift_actor: EnemyActor
var lift_entry: Dictionary = {}
var lift_exit: Dictionary = {}
var lift_prefix: Array = []
var lift_original_itinerary: Array = []
var lift_contact := false
var lift_shots := 0
var lift_setup_shots := 0
var lift_contact_tick := -1
var lift_first_free_tick := -1
var lift_goal := Vector2.ZERO
var lift_bank_x := 0.0
var lift_h_snapshot: Dictionary = {}
var lift_motion_started := -1
var lift_empty_tick := -1
var lift_floor_recovery_tick := -1

func _ready() -> void:
	ecology_enabled=false
	super._ready()

func begin() -> void:
	await super.begin()
	if not initialized or not is_instance_valid(controller): return
	controller.energy_recovered.connect(func(amount: float, airborne: bool) -> void:
		event("actual_shot_energy_recovered",{"amount":amount,"airborne":airborne,"snapshot":snapshot()}))

func _hook_event(state: StringName) -> void:
	super._hook_event(state)
	if lift_started<0: return
	if state==&"hook_contact_kick" and is_instance_valid(lift_actor) and controller.traversal.hook_target==lift_actor.motor:
		lift_contact=true;lift_contact_tick=tick
		event("lift_actual_contact",{"enemy_id":"hollow_route__outer_lift_lantern","snapshot":snapshot(),"enemy_health":lift_actor.health.current})

func observe() -> void:
	super.observe()
	if lift_started<0 or frames.is_empty() or int(frames[-1].tick)!=tick: return
	frames[-1].combat_energy=controller.combat_energy.current
	frames[-1].combat_hit_packets=controller.combat_energy._packets.duplicate(true)
	frames[-1].pending_shot_grants=controller.received_resource_grants.size()
	frames[-1].shot_energy_hit_receipts=controller.shot_energy._hits.duplicate(true)
	frames[-1].lift_health=lift_actor.health.current if is_instance_valid(lift_actor) else -1.0
	frames[-1].lift_position=pair(lift_actor.motor.global_position) if is_instance_valid(lift_actor) else []
	if lift_contact and lift_first_free_tick<0 and controller.traversal.state==&"free" and not player.is_on_floor():
		lift_first_free_tick=tick
		event("lift_first_actual_free_frame",{"snapshot":snapshot()})

func _connection(id: String) -> Dictionary:
	for row: Dictionary in manifest.connections:
		if row.id==id:
			var result: Dictionary=row.duplicate(true)
			result.edge_id=id;result.landing=result.get("landing",result.path[-1]).duplicate()
			return result
	return {}

func _fixed_return() -> void:
	# These are the actual existing edges, including both fixed rings and
	# normal recovery jumps. No invented staircase or added topology.
	var revised: Array[Dictionary]=[]
	for index: int in leg_index: revised.append(itinerary[index].duplicate(true))
	for id: String in ["outer_to_inner","inner_recovery","upper_out"]:
		var row := _connection(id)
		if row.is_empty(): fail("lift_missing_actual_fixed_return/"+id);return
		revised.append(row)
		if row.has("post_landing_steps"):
			for step: Dictionary in row.post_landing_steps:
				var copy: Dictionary=step.duplicate(true);copy.edge_id=id;copy.post_landing=true;revised.append(copy)
	itinerary=revised
	lift_state="fixed_return";set_phase("align")
	event("lift_existing_fixed_return_selected",{"edges":["outer_to_inner","inner_recovery","upper_out"]})

func _seal_lift() -> void:
	if lift_finished>=0: return
	lift_finished=tick;lift_exit=snapshot()
	lift_exit.supports=supports();lift_exit.combat_energy=controller.combat_energy.current
	event("lift_actual_E_arrival",{"snapshot":lift_exit.duplicate(true),"strategy":lift_strategy})

func complete_leg() -> void:
	if lift_started>=0 and lift_state=="fixed_return" and leg_index==itinerary.size()-1:
		_seal_lift()
	super.complete_leg()

func _start_live_lift() -> void:
	lift_motion_started=tick
	controller.router.set_move_axis(0);jump(false)
	event("lift_motion_started",{"snapshot":snapshot(),"enemy_state":String(lift_actor.attack_behavior.state),"enemy_position":pair(lift_actor.motor.global_position),"travel_side":(lift_actor.attack_behavior as ForestLanternBehavior).travel_side,"shot_energy_hit_receipts":controller.shot_energy._hits.duplicate(true)})
	request(&"grapple",(lift_actor.motor.global_position-player.global_position-Vector2(0,-6)).normalized())
	lift_h_snapshot=snapshot();lift_state="hook";set_phase("lift_live_hook")

func _start_strong_jump() -> void:
	lift_motion_started=tick
	controller.router.set_move_axis(clampf((lift_goal.x-player.global_position.x)/12,-1,1))
	jump(true);lift_state="normal_jump";set_phase("lift_full_jump")
	event("lift_motion_started",{"snapshot":snapshot()})

func drive_hollow(leg: Dictionary) -> void:
	if lift_started<0 and str(leg.get("edge_id",""))!="outer_to_inner":
		super.drive_hollow(leg);return
	if lift_started<0:
		var R := Vector2.ZERO
		for area: Dictionary in manifest.areas:
			if area.id=="R": R=point(area.position)
			if area.id=="E": lift_goal=point(area.position)
		if not at_destination(R,"hollow__outer_root"): fail("lift_not_actual_R_entry");return
		for index: int in stage.enemy_manifest.size():
			if stage.enemy_manifest[index].id=="hollow_route__outer_lift_lantern": lift_actor=stage.enemies[index].get_node("Actor")
		if not is_instance_valid(lift_actor) or lift_actor.health.current!=lift_actor.definition.health_definition.initial_current:
			fail("lift_actual_live_HP2_entry_missing");return
		lift_started=tick;lift_entry=snapshot();lift_entry.supports=supports()
		lift_entry.combat_energy=controller.combat_energy.current
		lift_entry.shot_energy_hit_receipts=controller.shot_energy._hits.duplicate(true)
		lift_prefix=completed.duplicate(true);lift_original_itinerary=itinerary.duplicate(true)
		var support: Dictionary=platform("hollow__outer_root")
		lift_bank_x=maxf(player.global_position.x,float(support.rect[0])+12.0+player.weapon_motion.base_distance(player.tuning,true)+7.0)
		event("lift_R_choice_started",{"strategy":lift_strategy,"entry":lift_entry.duplicate(true),"enemy_health":lift_actor.health.current,"enemy_position":pair(lift_actor.motor.global_position),"travel_side":(lift_actor.attack_behavior as ForestLanternBehavior).travel_side,"enemy_state":String(lift_actor.attack_behavior.state),"manifest_row":stage.enemy_manifest[stage.enemies.find(lift_actor.motor)].duplicate(true)})
		if lift_strategy=="fixed_return": _fixed_return();return
		if lift_strategy in ["dead_fixed_return","dead_jump_two_R","lethal_contact_lift"]: lift_state="shoot_dead";return
		if lift_strategy=="jump_two_R": _start_strong_jump();return
		if lift_strategy=="left_phase_lift": lift_state="left_phase_wait";return
		if lift_strategy=="low_air_recover_lift":
			controller.router.set_move_axis(0);jump(true);lift_state="low_full_jump";set_phase("lift_low_full_jump");return
		_start_live_lift();return
	if lift_state=="fixed_return":
		super.drive_hollow(leg);return
	if lift_state=="shoot_dead":
		if lift_strategy=="lethal_contact_lift" and lift_actor.health.current==1:
			event("lift_actual_projectile_prime_HP1",{"setup_shots":lift_setup_shots,"snapshot":snapshot(),"enemy_health":lift_actor.health.current})
			lift_state="dead_realign";set_phase("lift_primed_R_realign");return
		if lift_actor.health.terminal:
			event("lift_actual_projectile_death_before_return",{"setup_shots":lift_setup_shots,"snapshot":snapshot()})
			if lift_strategy=="dead_fixed_return": _fixed_return()
			else: lift_state="dead_realign";set_phase("lift_dead_R_realign")
			return
		controller.router.set_move_axis(clampf((lift_bank_x-player.global_position.x)/12,-1,1))
		if full_support("hollow__outer_root") and absf(player.global_position.x-lift_bank_x)<7 and controller.shoot_ability.cooldown_remaining<=0:
			request(&"shoot_release",(lift_actor.motor.global_position-player.global_position).normalized());lift_setup_shots+=1
		return
	if lift_state=="dead_realign":
		var R: Vector2=point(lift_entry.position)
		controller.router.set_move_axis(clampf((R.x-player.global_position.x)/12,-1,1))
		stable=stable+1 if at_destination(R,"hollow__outer_root") else 0
		if stable>=12:
			if lift_strategy=="lethal_contact_lift": _start_live_lift()
			else: _start_strong_jump()
		return
	if lift_state=="left_phase_wait":
		controller.router.set_move_axis(0)
		var lantern := lift_actor.attack_behavior as ForestLanternBehavior
		if lantern.state==&"travel" and lantern.travel_side<0: _start_live_lift()
		return
	if lift_state=="low_full_jump":
		controller.router.set_move_axis(0)
		if not player.is_on_floor() and player.velocity.y>=0 and age>1:
			jump(false);request(&"shoot_release",Vector2.LEFT);lift_setup_shots=1;lift_state="low_second_miss"
		return
	if lift_state=="low_second_miss":
		controller.router.set_move_axis(0)
		if not player.is_on_floor() and player.recoil_burst_remaining<=0 and controller.shoot_ability.cooldown_remaining<=0:
			request(&"shoot_release",Vector2.RIGHT);lift_setup_shots=2;lift_state="low_empty_fall";set_phase("lift_low_empty_fall")
		return
	if lift_state=="low_empty_fall":
		if not player.is_on_floor() and controller.action_resources.shot_charges==0 and lift_empty_tick<0:
			lift_empty_tick=tick
			event("lift_actual_empty_air_rounds",{"snapshot":snapshot()})
		var R: Vector2=point(lift_entry.position)
		controller.router.set_move_axis(clampf((R.x-player.global_position.x)/12,-1,1))
		stable=stable+1 if at_destination(R,"hollow__outer_root") else 0
		if stable>=12:
			if lift_empty_tick<0 or controller.action_resources.shot_charges!=player.tuning.max_air_shots:
				fail("lift_low_air_natural_recovery_missing");return
			lift_floor_recovery_tick=tick
			event("lift_actual_ground_round_recovery",{"snapshot":snapshot()})
			_start_live_lift()
		return
	if lift_state=="hook":
		controller.router.set_move_axis(0)
		if lift_contact and controller.traversal.state==&"free" and not player.is_on_floor():
			jump(false)
			event("lift_first_free_down_R_request",{"snapshot":snapshot(),"shot_cost":controller.shot_energy.shot_energy_cost,"enemy_health":lift_actor.health.current})
			request(&"shoot_release",Vector2.DOWN);lift_shots=1;lift_state="land";set_phase("lift_live_upward_recoil")
		elif age>240: fail("lift_actual_H_arrival_or_free_failed")
		return
	if lift_state=="normal_jump":
		controller.router.set_move_axis(clampf((lift_goal.x-player.global_position.x)/12,-1,1))
		# Keep the legitimate full jump until its actual apex; early release
		# would artificially weaken the strongest ordinary two-shot control.
		if not player.is_on_floor() and player.velocity.y>=0 and age>1:
			event("lift_normal_full_jump_apex",{"snapshot":snapshot()})
			jump(false);request(&"shoot_release",Vector2.DOWN);lift_shots=1
			lift_state="second_R";set_phase("lift_normal_first_R")
		return
	if lift_state=="second_R":
		controller.router.set_move_axis(clampf((lift_goal.x-player.global_position.x)/12,-1,1))
		# If the first shot already gains full crown clearance, don't force
		# a second cost. Otherwise spend at most the real second air round.
		var crown: Dictionary=platform("hollow__outer_crown")
		if player.global_position.y+18<float(crown.rect[1]): lift_state="land"
		elif not player.is_on_floor() and player.recoil_burst_remaining<=0 and controller.shoot_ability.cooldown_remaining<=0:
			request(&"shoot_release",Vector2.DOWN);lift_shots+=1;lift_state="land";set_phase("lift_normal_second_R")
		return
	if lift_state=="land":
		controller.router.set_move_axis(clampf((lift_goal.x-player.global_position.x)/12,-1,1))
		stable=stable+1 if at_destination(lift_goal,"hollow__outer_crown") else 0
		if stable>=12:
			_seal_lift();controller.router.set_move_axis(0);jump(false);finish_pending=true
