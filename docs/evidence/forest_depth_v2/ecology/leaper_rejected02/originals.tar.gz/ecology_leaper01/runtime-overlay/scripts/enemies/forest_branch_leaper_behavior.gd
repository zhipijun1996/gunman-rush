class_name ForestBranchLeaperBehavior
extends EnemyAttackBehavior
## Two actual shores. Every displacement is an EnemyMotor collision move.
var shores: Array[Vector2] = []
var shore_ids: Array[String] = []
var current_shore := 0
var target_shore := 1
var configured := false
var flight_velocity := Vector2.ZERO
var flight_seconds := 0.0
var landing_count := 0
var blocked_reason := ""
var motion_receipts: Array[Dictionary] = []

func configure_shores(points: Array[Vector2], ids: Array[String]) -> bool:
	configured=false
	if not is_instance_valid(actor) or points.size()!=2 or ids.size()!=2: return false
	for index: int in 2:
		if not points[index].is_finite() or ids[index].is_empty(): return false
	if points[0].distance_to(points[1])<actor.definition.collision_size.length(): return false
	shores=points.duplicate()
	shore_ids=ids.duplicate()
	current_shore=0 if actor.motor.global_position.distance_to(shores[0])<=actor.motor.global_position.distance_to(shores[1]) else 1
	target_shore=1-current_shore
	if actor.motor.global_position.distance_to(shores[current_shore])>1 or not _supported(shores[current_shore],shore_ids[current_shore]): return false
	if not _supported(shores[target_shore],shore_ids[target_shore]): return false
	configured=true
	cooldown=(actor.definition as ForestEnemyDefinition).leap_rest_seconds
	_set_state(&"rest")
	return true

func advance(delta: float) -> bool:
	if not _active():
		cancel()
		return true
	if _actor_epoch!=lifetime.actor_epoch:
		_actor_epoch=lifetime.actor_epoch
		cancel()
		return true
	if not configured or state==&"blocked": return true
	var d:=actor.definition as ForestEnemyDefinition
	state_time+=delta
	match state:
		&"rest":
			if state_time>=d.leap_rest_seconds and _can_engage():
				if _supported(actor.motor.global_position,shore_ids[current_shore]) and _supported(shores[target_shore],shore_ids[target_shore]) and _clear_arc():
					_set_state(&"telegraph")
				else: _block("departure_target_or_arc_not_clear")
		&"telegraph":
			if not _can_engage():
				_set_state(&"rest")
			elif state_time>=d.telegraph_duration:
				if not _clear_arc() or not _supported(shores[target_shore],shore_ids[target_shore]): _block("committed_arc_changed")
				else:
					flight_seconds=_duration(actor.motor.global_position,shores[target_shore])
					flight_velocity=Vector2((shores[target_shore].x-actor.motor.global_position.x)/flight_seconds,-d.leap_launch_speed)
					_serial+=1
					_set_state(&"jump")
		&"jump",&"falling": _fly(delta)
		&"settle":
			if state_time>=d.leap_settle_seconds: _set_state(&"rest")
	return true

func _can_engage() -> bool:
	# Local proximity activates a deterministic two-shore cycle, not a shot or
	# a player-locked leap. Its own support may separate the player vertically;
	# the actual full-body arc is still checked before every commitment.
	if not _active() or controller.motor.global_position.distance_to(actor.motor.global_position)>actor.definition.activation_range: return false
	for point: Vector2 in protected_points:
		if controller.motor.global_position.distance_to(point)<actor.definition.protected_radius: return false
	if state==&"rest":
		var concurrent:=0
		for sibling: Node in actor.motor.get_parent().get_children():
			if sibling is EnemyMotor and sibling!=actor.motor:
				var peer:=sibling.get_node_or_null("Actor") as EnemyActor
				if peer!=null and peer.attack_behavior!=null and peer.attack_behavior.state in [&"telegraph",&"attack",&"jump"] and peer.attack_behavior._active(): concurrent+=1
		if concurrent>=max_concurrent_attacks: return false
	return true

func _duration(start: Vector2, finish: Vector2) -> float:
	var d:=actor.definition as ForestEnemyDefinition
	var discriminant:=d.leap_launch_speed*d.leap_launch_speed+2*d.leap_gravity*(finish.y-start.y)
	return (d.leap_launch_speed+sqrt(discriminant))/d.leap_gravity if discriminant>0 else 0.0

func _supported(at: Vector2, expected_id: String) -> bool:
	var half:=actor.definition.collision_size*.5
	var found: Object
	for dx: float in [-half.x+1,0.0,half.x-1]:
		var foot:=at+Vector2(dx,half.y)
		var query:=PhysicsRayQueryParameters2D.create(foot+Vector2(0,-1),foot+Vector2(0,2),1,[actor.motor.get_rid()])
		var hit:=actor.motor.get_world_2d().direct_space_state.intersect_ray(query)
		if hit.is_empty() or str((hit.collider as Node).get_meta("ecology_support_id",""))!=expected_id: return false
		if found!=null and found!=hit.collider: return false
		found=hit.collider
	return true

func _clear_arc() -> bool:
	var d:=actor.definition as ForestEnemyDefinition
	var start:=actor.motor.global_position
	var finish:=shores[target_shore]
	var seconds:=_duration(start,finish)
	if seconds<=0 or seconds>d.leap_max_seconds: return false
	var initial:=Vector2((finish.x-start.x)/seconds,-d.leap_launch_speed)
	var at:=start
	var steps:=int(ceil(seconds*float(Engine.physics_ticks_per_second)*2.0))
	for index: int in range(1,steps+1):
		var t:=seconds*float(index)/float(steps)
		var next:=start+initial*t+Vector2(0,.5*d.leap_gravity*t*t)
		# Prediction tests the actual body's collision, including one-way direction.
		var transform:=actor.motor.global_transform
		transform.origin=at
		if actor.motor.test_move(transform,next-at):
			if index<steps-1: return false
		for point: Vector2 in protected_points:
			var expanded:=actor.definition.collision_size*.5+Vector2(12,18)
			var close:=Vector2(clampf(point.x,next.x-expanded.x,next.x+expanded.x),clampf(point.y,next.y-expanded.y,next.y+expanded.y))
			if close.distance_to(point)<d.protected_radius: return false
		at=next
	return true

func _fly(delta: float) -> void:
	var d:=actor.definition as ForestEnemyDefinition
	var start:=actor.motor.global_position
	var motion:=flight_velocity*delta+Vector2(0,.5*d.leap_gravity*delta*delta)
	flight_velocity.y+=d.leap_gravity*delta
	var clear:=actor.motor.move_attack(motion,false,delta)
	var finish:=actor.motor.global_position
	motion_receipts.append({"physics_frame":Engine.get_physics_frames(),"from":[start.x,start.y],"to":[finish.x,finish.y],"requested":[motion.x,motion.y],"clear":clear,"state":String(state)})
	if not clear:
		if flight_velocity.y>0 and finish.distance_to(shores[target_shore])<=d.leap_landing_tolerance and _supported(finish,shore_ids[target_shore]):
			current_shore=target_shore
			target_shore=1-current_shore
			home=finish
			flight_velocity=Vector2.ZERO
			landing_count+=1
			_set_state(&"settle")
		else: _block("actual_body_collision_outside_target")
	elif state_time>d.leap_max_seconds:
		_block("landing_deadline")

func _block(reason: String) -> void:
	blocked_reason=reason
	flight_velocity=Vector2.ZERO
	actor.motor.stop()
	_set_state(&"blocked")

func cancel() -> void:
	# No queued damage/projectile exists. A dead body loses collision in Actor.
	# An inactive target freezes this actor. A renewed active scope only resumes
	# bounded physical falling, never snaps to an authored shore/home.
	if is_instance_valid(actor): actor.motor.stop()
	if state in [&"jump",&"falling"]:
		flight_velocity.x=0
		_set_state(&"falling")
	elif state!=&"blocked": _set_state(&"rest")

func depth_snapshot() -> Dictionary:
	var points: Array=[]
	for point: Vector2 in shores: points.append([point.x,point.y])
	return {"version":1,"configured":configured,"shores":points,"shore_ids":shore_ids.duplicate(),"current_shore":current_shore,"target_shore":target_shore,"velocity":[flight_velocity.x,flight_velocity.y],"flight_seconds":flight_seconds,"landing_count":landing_count,"blocked_reason":blocked_reason}

func restore_depth_state(saved: Dictionary) -> bool:
	if saved.get("version")!=1 or not bool(saved.get("configured",false)): return false
	var points: Array=saved.get("shores",[])
	var ids: Array=saved.get("shore_ids",[])
	var vector: Array=saved.get("velocity",[])
	if points.size()!=2 or ids.size()!=2 or vector.size()!=2: return false
	var restored: Array[Vector2]=[]
	for point: Array in points:
		if point.size()!=2: return false
		var at:=Vector2(point[0],point[1])
		if not at.is_finite(): return false
		restored.append(at)
	var current:=int(saved.get("current_shore",-1))
	var target:=int(saved.get("target_shore",-1))
	var velocity:=Vector2(vector[0],vector[1])
	if current not in [0,1] or target!=1-current or not velocity.is_finite(): return false
	if not _supported(restored[0],str(ids[0])) or not _supported(restored[1],str(ids[1])): return false
	shores=restored;shore_ids.assign(ids)
	current_shore=current;target_shore=target;flight_velocity=velocity
	flight_seconds=float(saved.get("flight_seconds",0))
	landing_count=int(saved.get("landing_count",0));blocked_reason=str(saved.get("blocked_reason",""))
	configured=true
	return true
