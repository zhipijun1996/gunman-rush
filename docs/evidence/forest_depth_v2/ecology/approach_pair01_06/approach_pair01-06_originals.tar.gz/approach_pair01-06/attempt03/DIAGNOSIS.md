# 03原始首败，后五法未运行

导入/普通native实际均完成；普通6assert1fail、strict无额外ERROR或泄漏、sourceguard true。有grapple请求484，真实contact489落在Seed而非ring，Seed3→2；gate未开，终点HP4。不可称通过。

本driver的set_aim(current_device,...,true)激活AirFocus：PlayerController67→AirFocus52→Engine.time_scale=.2；x每帧约.866而非4.333，固定8tick松跳也不再等于正常.13s，因此不是公平正常满跳生态反例。04彻底删除aim/guide/privateprobe，正常跳保持至apex，普通可越过真实Lamp/Seed完整身体+12钩头后尽早直request同环；右岸1430另作宽容对照。

04尚在独立新snapshot执行，不能回签03。378是选定局部预热，不等同重放全prefix的真实怪物相位。
