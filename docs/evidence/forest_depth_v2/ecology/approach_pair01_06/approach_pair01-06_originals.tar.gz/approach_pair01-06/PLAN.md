# Seed＋live Lantern：局部上层比较

仅用现有EnemyActor、Motor、DamagePolicy、InputRouter、H、普通弹体。真实map2 generator/assembler全部平台、semantic protected_points和closed vine不改；两新放置是局部假设，不进入Manifest敌池。所有生成选择/原完整Manifest都随capture保存。

Seed(1230,C.y)、Lantern(1250,C.y−90)，全部Definition默认；C→prep→gate有明确目标。候选种子00和02分别报告真实cache_route/cavity_direction，不能手造label。

普通快解先跑：走1150、正常满跳、首个实际guide可达固定环。清敌：1120逐弹重新站岸3弹，真实命中返能，随后同满跳/固定环。保活：正常走1080并靠近到210，H实际萤→kick→首free正常向左枪的向右反冲→同真实固定环；不能强指定hook_target。三法均实际钩gate key/由Assembler接受hook_kick开vine/1400同岸12帧终态，未完成必须拒绝。

共同378物理tick仅是局部预热。它参照root00/map2/growth已知C完成时间，但并未重放全prefix/暂停/怪物起始相位；不等同实际到C状态。比较目标是局部是否有潜在不同决策，不能借此宣称正式全路成立。真实C前缀/自然buff应在有价值后才融合正式consumer。

首失败即止，不提高180s单case/90s import，不改玩家/保护/HP/频率，不为过关特调phase；必须保留最强普通快解，HP与能量/次数/终端均报告。若普通快解支配且没有锁定后换角收益，DROP，不再靠等待/加怪堆意义。

01、02为驾驶观测错误的严格失败：无H请求、非生态可行结论。03仅将set_aim source改为InputRouter实际current_device；action请求方向/参数复用正式trace模式，仍须真正原生验证。原31静态剥离证明在default-preservation.json，未拿本批签原31重新native。
