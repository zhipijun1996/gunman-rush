extends SceneTree
## Independent local goldens, not complete formal forest route admission.
const AUDIO := preload("res://tests/audio_teardown.gd")
const ECOLOGY_GEOMETRY := preload("res://scripts/generation/forest_ecology_geometry.gd")
var assertions := 0
var failures := 0
var tick := 0
var world: Node2D
var player: PlayerMotor
var controller: PlayerController
var policy: FrameDamagePolicy
var life: DemoLifetime
var enemies: Array[EnemyActor] = []
var contacts: Array[DemoContactEmitter] = []
var events: Array[Dictionary] = []
var cases: Array[Dictionary] = []
var comparisons: Array[Dictionary] = []
var stress_controls: Array[Dictionary] = []
class ThreadAblationPolicy extends FrameDamagePolicy:
	var disable_thread := false
	var suppressed: Array[Dictionary] = []
	func submit(request: DamageRequest) -> bool:
		if disable_thread and request.source_id==&"woven_thread_spider" and String(request.event_id).contains(":thread:"):
			suppressed.append({"physics_frame":Engine.get_physics_frames(),"event_id":String(request.event_id),"source":String(request.source_id),"target":String(request.target_id),"amount":request.amount,"actor_epoch":request.actor_epoch})
			return false
		return super.submit(request)
var comparison_frames: Array[Dictionary] = []
var comparison_id := ""
func _initialize() -> void: run.call_deferred()
func check(ok: bool, label: String) -> void:
	assertions += 1
	print("FOREST DEPTH CHECK: ","PASS " if ok else "FAIL ",label)
	if not ok: failures += 1
func frames(count: int) -> void:
	for i: int in count:
		await physics_frame
		await process_frame
		tick+=1
		for index: int in enemies.size():
			contacts[index].enabled = not enemies[index].health.terminal
		if not comparison_id.is_empty():
			comparison_frames.append(_comparison_frame())
func slab(rect: Rect2, one_way := false, support_id: String = "") -> void:
	var body := StaticBody2D.new()
	body.position=rect.get_center()
	body.set_meta("ecology_support_id",support_id)
	var shape := CollisionShape2D.new()
	var rectangle := RectangleShape2D.new()
	rectangle.size=rect.size
	shape.shape=rectangle
	shape.one_way_collision=one_way
	if one_way: body.add_to_group(&"one_way_platform")
	body.add_child(shape)
	world.add_child(body)
func cleanup() -> void:
	if not is_instance_valid(world): return
	controller.router.clear("forest_depth_fixture_cleanup")
	controller.active=false
	life.end()
	for actor: EnemyActor in enemies: actor.attack_behavior.cancel()
	var receipt: Dictionary = AUDIO.stop_fallback_voices(world)
	world.free()
	world=null
	enemies.clear()
	contacts.clear()
	check(await AUDIO.wait_fallback_release(receipt),"owned world audio backend actually released")
func fixture(at: Vector2 = Vector2(-30,282), geometry: Dictionary = {}) -> void:
	await cleanup()
	world=Node2D.new()
	root.add_child(world)
	if geometry.is_empty(): slab(Rect2(-1200,300,2600,50))
	else:
		for row: Dictionary in geometry.platforms:
			var rect: Array=row.rect
			slab(Rect2(rect[0],rect[1],rect[2],rect[3]),bool(row.one_way),str(row.role))
	player=load("res://scenes/player/player.tscn").instantiate()
	player.position=at
	world.add_child(player)
	controller=player.get_node("Controller")
	controller.enable_shot_energy()
	controller.traversal.grant(&"grapple")
	controller.shoot_ability.shot_fired.connect(_shot)
	life=DemoLifetime.new()
	policy=ThreadAblationPolicy.new()
	policy.lifetime=life
	world.add_child(policy)
	policy.register_target(&"player",controller.actor_resources.health,true)
	policy.batch_resolved.connect(_damage)
	await frames(5)
func _shot(aim: Vector2, serial: int) -> void:
	events.append({"kind":"accepted_shot","tick":tick,"serial":serial,"aim":[aim.x,aim.y],"projectiles":controller.shoot_ability._projectiles.size()})
func _damage(results: Array[DamageResult]) -> void:
	for result: DamageResult in results:
		events.append({"kind":"policy_result","tick":tick,"event_id":String(result.request.event_id),"source":String(result.request.source_id),"target":String(result.request.target_id),"hp":result.health.current})
func enemy(id: String, at: Vector2, instance_id: String = "") -> EnemyActor:
	var scene: PackedScene=load("res://scenes/enemies/patrol_drone.tscn" if id=="plains_charger" else "res://scenes/enemies/"+id+".tscn")
	var body := scene.instantiate() as EnemyMotor
	if id=="plains_charger":
		(body.get_node("Actor") as EnemyActor).definition=load("res://resources/enemies/plains_charger.tres")
	body.position=at
	world.add_child(body)
	var actor := body.get_node("Actor") as EnemyActor
	var source := StringName(instance_id if not instance_id.is_empty() else id)
	policy.bind_damageable(source,actor.damageable,actor.health)
	actor.bind_encounter(controller,policy,life,source,[])
	var contact := DemoContactEmitter.new()
	contact.policy=policy
	contact.controller=controller
	contact.source_id=StringName(str(source)+"_body")
	contact.half_size=actor.definition.collision_size*0.5
	body.add_child(contact)
	enemies.append(actor)
	contacts.append(contact)
	return actor
func ring(at: Vector2) -> void:
	var anchor := GrappleAnchor.new()
	anchor.position=at
	world.add_child(anchor)
func wait_state(behavior: EnemyAttackBehavior, wanted: StringName, limit := 240) -> bool:
	for i: int in limit:
		if behavior.state==wanted: return true
		await frames(1)
	return false
func shoot_to_death(actor: EnemyActor) -> void:
	for i: int in 6:
		if actor.health.terminal: return
		controller.router.request_action(&"shoot_release",(actor.motor.global_position-player.global_position).normalized())
		await frames(30)
func cross_with_fixed_ring(actor: EnemyActor) -> bool:
	ring(Vector2(175,190))
	await frames(2)
	controller.router.request_action(&"grapple",(Vector2(175,190)-player.global_position).normalized())
	controller.router.set_move_axis(1)
	var caught_fixed := false
	for i: int in 85:
		await frames(1)
		if controller.traversal.hook_target is GrappleAnchor: caught_fixed=true
	controller.router.set_move_axis(0)
	await frames(25)
	return caught_fixed and player.global_position.x>200 and actor.health.current==actor.health.capacity and controller.actor_resources.health.current==controller.actor_resources.health.capacity
func _comparison_frame() -> Dictionary:
	var actors: Array = []
	for actor: EnemyActor in enemies:
		actors.append({"id":String(actor.definition.stable_id),"instance_id":String(actor.attack_behavior.source_id),"position":[actor.motor.global_position.x,actor.motor.global_position.y],"hp":actor.health.current,"state":String(actor.attack_behavior.state),"state_time":actor.attack_behavior.state_time})
	var support_id := ""
	if player.is_on_floor():
		var ray:=PhysicsRayQueryParameters2D.create(player.global_position,player.global_position+Vector2(0,24),1,[player.get_rid()])
		var support:=player.get_world_2d().direct_space_state.intersect_ray(ray)
		if not support.is_empty(): support_id=str((support.collider as Node).get_meta("ecology_support_id","root_floor"))
	return {"support_id":support_id,"normal_velocity":[player.normal_velocity.x,player.normal_velocity.y],"recoil_velocity":[player.recoil_velocity.x,player.recoil_velocity.y],"burst_remaining":player.recoil_burst_remaining,"shot_cost":controller.shot_energy.shot_energy_cost,"contact_remaining":controller.traversal._contact_remaining,"comparison":comparison_id,"tick":tick,"position":[player.global_position.x,player.global_position.y],"grounded":player.is_on_floor(),"hp":controller.actor_resources.health.current,"stamina":controller.actor_resources.stamina.current,"shot_charges":controller.action_resources.shot_charges,"H_state":String(controller.traversal.state),"H_target":str(controller.traversal.hook_target.name) if is_instance_valid(controller.traversal.hook_target) else "","actors":actors}

func _walk_to_entry(entry: Vector2) -> bool:
	for i: int in 180:
		var dx:=entry.x-player.global_position.x
		if absf(dx)<=player.tuning.ground_speed/float(Engine.physics_ticks_per_second) and player.is_on_floor():
			controller.router.set_move_axis(0)
			await frames(1)
			return true
		controller.router.set_move_axis(signf(dx))
		await frames(1)
	controller.router.set_move_axis(0)
	return false

func _consume_misses_and_return(entry: Vector2) -> bool:
	var cost:=controller.shot_energy.shot_energy_cost
	for shot: int in 7:
		if controller.actor_resources.stamina.current>=cost and controller.actor_resources.stamina.current<=cost*2: return true
		controller.router.request_action(&"shoot_release",Vector2.LEFT)
		await frames(int(ceil(player.tuning.shot_burst_duration*float(Engine.physics_ticks_per_second)))+1)
		if not await _walk_to_entry(entry): return false
	return false

func _phase_ready(spider: EnemyActor, lantern: EnemyActor, phase: String) -> bool:
	if phase=="fresh": return true
	if phase=="line_hold": return spider.attack_behavior.state==&"hold"
	var motion:=lantern.attack_behavior
	if motion.state!=&"travel": return false
	var relative:=lantern.motor.global_position.x-motion.home.x
	var limit:=lantern.definition.patrol_half_width*.75
	return (phase=="travel_left" and lantern.brain.direction<0 and relative<=-limit) or (phase=="travel_right" and lantern.brain.direction>0 and relative>=limit)

func run_combination(layout: String, strategy: String, legacy := false, variant: Dictionary = {}) -> void:
	comparison_id=""
	var geometry: Dictionary=ECOLOGY_GEOMETRY.woven_crown() if layout=="woven_crown" else {}
	var entry: Vector2=Vector2(geometry.spawn[0],geometry.spawn[1]) if not geometry.is_empty() else Vector2(10,282)
	await fixture(entry,geometry)
	var primary: EnemyActor
	var secondary: EnemyActor
	if layout=="root_split":
		slab(Rect2(140,190,220,16),true,"main_branch")
		ring(Vector2(175,150))
		primary=enemy("plains_charger",Vector2(160,284))
		secondary=enemy("forest_thread_spider",Vector2(270,150))
		(secondary.attack_behavior as ForestThreadSpiderBehavior).configure_line(Vector2(120,172),Vector2(260,172))
	else:
		for row: Dictionary in geometry.hook_anchors: ring(Vector2(row.position[0],row.position[1]))
		var spider_row: Dictionary=geometry.enemies[0]
		var lantern_row: Dictionary=geometry.enemies[1]
		primary=enemy(str(spider_row.behavior_id),Vector2(spider_row.position[0],spider_row.position[1]),str(spider_row.id))
		(primary.attack_behavior as ForestThreadSpiderBehavior).configure_line(Vector2(spider_row.line_start[0],spider_row.line_start[1]),Vector2(spider_row.line_end[0],spider_row.line_end[1]))
		secondary=enemy(str(lantern_row.behavior_id),Vector2(lantern_row.position[0],lantern_row.position[1]),str(lantern_row.id))
	# All controls use identical layout/real actor definitions/resources per layout.
	# Legacy naturally retains its own HP/body/range/timing, reported as limitations.
	var setup_event_start:=events.size()
	var setup_started:=tick
	var phase_name:=str(variant.get("phase","fresh"))
	comparison_id="setup/"+str(variant.get("id",layout+"/"+strategy))
	(policy as ThreadAblationPolicy).disable_thread=bool(variant.get("line_disabled",false))
	var setup_ok:=true
	if not variant.is_empty():
		for phase_tick: int in 600:
			if _phase_ready(primary,secondary,phase_name): break
			await frames(1)
		setup_ok=_phase_ready(primary,secondary,phase_name)
		if bool(variant.get("dead_lantern",false)):
			await shoot_to_death(secondary)
			setup_ok=setup_ok and secondary.health.terminal and await _walk_to_entry(entry)
		if bool(variant.get("low_resource",false)):
			setup_ok=setup_ok and await _consume_misses_and_return(entry)
	var setup_state:=_comparison_frame()
	comparison_id=str(variant.id) if not variant.is_empty() else layout+"/"+("legacy/" if legacy else "depth/")+strategy
	var exit_x: float=float(geometry.exit.position[0]) if not geometry.is_empty() else 450.0
	var began:=tick
	var event_start:=events.size()
	var first:=_comparison_frame()
	var observed_preview:=false
	var requested_H:=false
	var caught_expected:=false
	var upper_seen:=false
	var dangerous_observed:=false
	var preview_cancelled:=false
	if strategy=="bank_shoot":
		await shoot_to_death(primary)
	elif strategy=="direct_walk":
		pass
	else:
		if bool(variant.get("react_now",false)):
			for frame: Dictionary in comparison_frames:
				if frame.tick>=setup_started and str(frame.comparison).begins_with("setup/"):
					for actor_row: Dictionary in frame.actors:
						if actor_row.id=="forest_thread_spider" and actor_row.state=="telegraph": observed_preview=true
			observed_preview=observed_preview or primary.attack_behavior.state==&"telegraph"
		else: observed_preview=await wait_state(primary.attack_behavior,&"telegraph")
		if strategy=="lower_wait" or strategy=="wait_line":
			if strategy=="lower_wait":
				controller.router.set_move_axis(-1)
				for retreat_tick: int in 40:
					if player.global_position.x < -60: break
					await frames(1)
				controller.router.set_move_axis(0)
			var dangerous_seen:=false
			for i: int in 240:
				var phase: StringName=primary.attack_behavior.state
				dangerous_seen=dangerous_seen or phase in [&"rush",&"attack",&"hold"]
				if not dangerous_seen and phase==&"recovery":
					preview_cancelled=true
					break
				if dangerous_seen and phase in [&"retract",&"recovery",&"brake"]: break
				await frames(1)
			dangerous_observed=dangerous_seen
		else:
			var target: Vector2=secondary.motor.global_position if strategy=="live_H" else (Vector2(175,150) if layout=="root_split" else Vector2(geometry.hook_anchors[0].position[0],geometry.hook_anchors[0].position[1]))
			controller.router.request_action(&"grapple",(target-player.global_position).normalized())
			requested_H=true
	controller.router.set_move_axis(1)
	var jumped:=false
	var jump_release_at: int=-1
	var live_kick_seen:=false
	var recoil_request_tick: int=-1
	var recoil_before: Dictionary={}
	var recoil_after: Dictionary={}
	for i: int in 260:
		if strategy=="live_H":
			live_kick_seen=live_kick_seen or controller.traversal.state==&"hook_kick"
			if live_kick_seen and caught_expected and recoil_request_tick<0 and controller.traversal.state==&"free" and not player.is_on_floor():
				recoil_request_tick=tick
				recoil_before=_comparison_frame()
				controller.router.request_action(&"shoot_release",Vector2.LEFT)
			elif recoil_request_tick>=0 and recoil_after.is_empty() and tick>recoil_request_tick:
				recoil_after=_comparison_frame()
		if not jumped and player.is_on_floor():
			for candidate: EnemyActor in enemies:
				if candidate.health.terminal: continue
				var offset:=candidate.motor.global_position-player.global_position
				var half_player: Vector2=(player.get_node("CollisionShape2D") as CollisionShape2D).shape.get_rect().size*0.5
				var half_enemy:=candidate.definition.collision_size*0.5
				var takeoff_distance:=half_player.x+half_enemy.x+player.tuning.ground_speed*player.tuning.jump_hold_duration
				if offset.x>0 and offset.x<takeoff_distance and absf(offset.y)<half_player.y+half_enemy.y:
					controller.router.request_action(&"jump")
					jumped=true
					jump_release_at=i+int(ceil(player.tuning.jump_hold_duration*float(Engine.physics_ticks_per_second)))
					break
		if i==jump_release_at: controller.router.request_action(&"jump_release")
		var hook_target:=controller.traversal.hook_target
		if is_instance_valid(hook_target):
			caught_expected=caught_expected or (hook_target==secondary.motor if strategy=="live_H" else hook_target is GrappleAnchor)
		upper_seen=upper_seen or str(_comparison_frame().support_id)=="main_branch"
		if player.global_position.x>exit_x and player.is_on_floor(): break
		if controller.actor_resources.health.terminal: break
		await frames(1)
	controller.router.set_move_axis(0)
	await frames(3)
	var last:=_comparison_frame()
	var result: Dictionary={"id":comparison_id,"layout":layout,"geometry_version":str(geometry.get("version","root_split_local")),"strategy":strategy,"legacy":legacy,"start":first,"end":last,"ticks":tick-began,"completed":player.global_position.x>exit_x and not controller.actor_resources.health.terminal,"observed_preview":observed_preview,"requested_H":requested_H,"caught_expected_H_target":caught_expected,"upper_support_seen":upper_seen,"committed_attack_seen":dangerous_observed,"preview_cancelled_on_retreat":preview_cancelled,"recoil_request_tick":recoil_request_tick,"recoil_before":recoil_before,"recoil_after":recoil_after,"primary_definition":{"id":String(primary.definition.stable_id),"hp":primary.health.capacity,"body":[primary.definition.collision_size.x,primary.definition.collision_size.y],"range":primary.definition.activation_range,"telegraph":primary.definition.telegraph_duration,"line_damage":(primary.definition as ForestEnemyDefinition).line_damage if primary.definition is ForestEnemyDefinition else 0.0},"event_start":event_start,"event_end":events.size(),"scope":"Local combined fixture. Success alone does not prove mechanic value; controls preserve their original Definitions."}
	if variant.is_empty(): comparisons.append(result)
	else:
		result["variant"]=variant.duplicate(true)
		result["setup_ok"]=setup_ok
		result["setup_start_tick"]=setup_started
		result["setup_event_start"]=setup_event_start
		result["setup_state"]=setup_state
		result["thread_suppressed"]=(policy as ThreadAblationPolicy).suppressed.duplicate(true)
		result["geometry_hash"]=JSON.stringify(geometry).sha256_text()
		stress_controls.append(result)
	comparison_id=""

func run() -> void:
	if "--approach" in OS.get_cmdline_user_args():
		await run_approach()
		return
	await fixture(Vector2(80,282))
	var spider := enemy("forest_thread_spider",Vector2(260,190))
	var thread := spider.attack_behavior as ForestThreadSpiderBehavior
	check(spider.definition.is_valid() and thread!=null,"spider real Definition and dispatcher")
	await frames(90)
	check(thread.state==&"idle" and controller.actor_resources.health.current==controller.actor_resources.health.capacity,"unconfigured line fail-closed without attacks")
	check(not thread.configure_line(Vector2.ZERO,Vector2(500,0)),"overlong line rejected")
	check(thread.configure_line(Vector2(20,282),Vector2(140,282)),"authored bounded line accepted")
	check(await wait_state(thread,&"hold"),"spider whole preview/extend precedes hold")
	var hp := controller.actor_resources.health.current
	await frames(30)
	check(controller.actor_resources.health.current==hp-1,"standing in occupied line takes one real policy damage")
	await frames(8)
	check(controller.actor_resources.health.current==hp-1,"same line cycle never repeats damage")
	cases.append({"id":"spider_stand_line","tick":tick,"hp_before":hp,"hp_after":controller.actor_resources.health.current})
	await fixture(Vector2(0,282))
	spider=enemy("forest_thread_spider",Vector2(260,190))
	thread=spider.attack_behavior as ForestThreadSpiderBehavior
	thread.configure_line(Vector2(20,282),Vector2(140,282))
	check(await wait_state(thread,&"telegraph"),"spider safe observation before line locks")
	check(await cross_with_fixed_ring(spider),"spider actual fixed-H upper bypass never requires killing")
	cases.append({"id":"spider_live_bypass","tick":tick,"enemy_hp":spider.health.current,"player_hp":controller.actor_resources.health.current})
	await fixture()
	spider=enemy("forest_thread_spider",Vector2(260,190))
	thread=spider.attack_behavior as ForestThreadSpiderBehavior
	thread.configure_line(Vector2(20,282),Vector2(140,282))
	await shoot_to_death(spider)
	check(spider.health.terminal and not thread.line_active,"spider actual bullet death removes owned dangerous line")
	cases.append({"id":"spider_bullets","tick":tick,"terminal":spider.health.terminal})
	await fixture(Vector2(80,282))
	spider=enemy("forest_thread_spider",Vector2(260,190))
	thread=spider.attack_behavior as ForestThreadSpiderBehavior
	thread.configure_line(Vector2(20,282),Vector2(140,282))
	check(await wait_state(thread,&"telegraph"),"cancel fixture reaches real preview")
	var phase := thread.state_time
	paused=true
	for i: int in 8: await process_frame
	check(thread.state_time==phase,"pause freezes line preview")
	paused=false
	life.invalidate_actor()
	await frames(1)
	check(not thread.line_active and thread.state==&"recovery","actor epoch cancels old line before activation")
	controller.active=false
	hp=controller.actor_resources.health.current
	await frames(100)
	check(not thread.line_active and controller.actor_resources.health.current==hp,"inactive target leaves no damaging old line")
	cases.append({"id":"spider_cancel_pause_epoch_inactive","tick":tick})
	for strategy: String in ["bank_shoot","lower_wait","fixed_H"]:
		await run_combination("root_split",strategy,true)
	for strategy: String in ["bank_shoot","wait_line","fixed_H","live_H"]:
		await run_combination("woven_crown",strategy)
	for phase_name: String in ["fresh","line_hold"]:
		for strategy: String in ["direct_walk","wait_line","fixed_H","live_H"]:
			for disabled: bool in [false,true]:
				await run_combination("woven_crown",strategy,false,{"id":"ablation/"+phase_name+"/"+strategy+("/off" if disabled else "/on"),"phase":phase_name,"line_disabled":disabled,"react_now":phase_name!="fresh"})
	for phase_name: String in ["travel_left","travel_right"]:
		await run_combination("woven_crown","live_H",false,{"id":"phase/"+phase_name,"phase":phase_name,"react_now":true})
	await run_combination("woven_crown","fixed_H",false,{"id":"dead_lantern/fixed_H","dead_lantern":true})
	await run_combination("woven_crown","live_H",false,{"id":"low_resource/live_H","low_resource":true,"react_now":true})
	await cleanup()
	var output := "res://build/forest_depth/ecology/native"
	for argument: String in OS.get_cmdline_user_args():
		if argument.begins_with("--output-dir="): output=argument.trim_prefix("--output-dir=")
	DirAccess.make_dir_recursive_absolute(output)
	var file := FileAccess.open(output+"/capture.json",FileAccess.WRITE)
	file.store_string(JSON.stringify({"scope":"independent local real actors/Router/projectiles/policy; no formal full route claimed","assertions":assertions,"failures":failures,"cases":cases,"events":events,"comparisons":comparisons,"stress_controls":stress_controls,"comparison_frames":comparison_frames},"  "))
	file.close()
	print("FOREST DEPTH ENEMIES: %s assertions, %s failures" % [assertions,failures])
	quit(0 if failures==0 else 1)

# Scoped placement hypothesis only: actual map geometry/protection, local new pair.
# No manifest enemy rows, route, HP, state clock or player physics are rewritten.
var approach_assembler = null
var approach_lamp: EnemyActor
var approach_ring: Node2D
var approach_contacts: Array[Dictionary] = []
func approach_hook_contact(point: Vector2) -> void:
	var target: Node2D=controller.traversal.hook_target
	approach_contacts.append({"tick":tick,"target":str(target.name) if is_instance_valid(target) else "invalid","lamp":target==approach_lamp.motor,"ring":target==approach_ring,"point":[point.x,point.y]})
func approach_request(kind: StringName, aim: Vector2=Vector2.ZERO) -> bool:
	var accepted:=controller.router.request_action(kind,aim)
	events.append({"kind":"router_request","action":String(kind),"tick":tick,"aim":[aim.x,aim.y],"queued":accepted,"before":_comparison_frame()})
	return accepted
func approach_walk(x: float, limit:=180) -> bool:
	for i: int in limit:
		if absf(player.global_position.x-x)<=4 and player.is_on_floor():
			controller.router.set_move_axis(0)
			return true
		controller.router.set_move_axis(signf(x-player.global_position.x))
		await frames(1)
	controller.router.set_move_axis(0)
	return false
func approach_terrain_head_clear(manifest: Dictionary) -> bool:
	var origin:=player.global_position+Vector2(0,-6)
	var radius:=controller.traversal.definition.hook_capture_radius
	for row: Dictionary in manifest.platforms:
		var r: Array=row.rect
		var expanded:=Rect2(r[0],r[1],r[2],r[3]).grow(radius)
		# Conservative rectangle Minkowski sweep. Both one-way faces block H.
		if DemoContactEmitter.segment_intersects_bounds(origin,approach_ring.global_position,expanded):return false
	return true
func run_approach() -> void:
	var strategy:="ordinary"
	var root_seed:="forest-depth-hollow-00"
	var warmup:=378
	var output:="res://build/forest_depth/ecology/approach"
	for argument: String in OS.get_cmdline_user_args():
		if argument.begins_with("--strategy="):strategy=argument.trim_prefix("--strategy=")
		if argument.begins_with("--root-seed="):root_seed=argument.trim_prefix("--root-seed=")
		if argument.begins_with("--warmup="):warmup=int(argument.trim_prefix("--warmup="))
		if argument.begins_with("--output-dir="):output=argument.trim_prefix("--output-dir=")
	var tuning:=PlayerTuning.load_default()
	var generator: RefCounted=load("res://scripts/generation/thorn_forest_region_v2.gd").new()
	var generated: Dictionary=generator.generate_spatial_candidate(root_seed+"/thorn_forest/map_2",tuning,2,{"grapple":true,"abilities":["grapple"]})
	check(generated.get("ok",false),"approach actual map2 generator accepted")
	if not generated.get("ok",false):quit(1);return
	var manifest: Dictionary=generated.manifest
	var C:=Vector2.ZERO
	for area: Dictionary in manifest.areas:
		if area.id=="C":C=Vector2(area.position[0],area.position[1])
	world=Node2D.new();root.add_child(world)
	approach_assembler=load("res://scripts/generation/thorn_forest_region_assembler.gd").new()
	world.add_child(approach_assembler)
	approach_assembler.region_state=load("res://scripts/run/plains_region_state.gd").new()
	var built: Dictionary=approach_assembler.build(manifest,tuning)
	check(built.get("ok",false),"actual assembler platforms, ring and closed vine")
	player=load("res://scenes/player/player.tscn").instantiate();player.position=C;world.add_child(player)
	controller=player.get_node("Controller");controller.enable_shot_energy();controller.traversal.grant(&"grapple")
	controller.shoot_ability.shot_fired.connect(_shot)
	life=DemoLifetime.new();policy=ThreadAblationPolicy.new();policy.lifetime=life;world.add_child(policy)
	policy.register_target(&"player",controller.actor_resources.health,true);policy.batch_resolved.connect(_damage)
	var protected: Array[Vector2]=approach_assembler.world_anchors()
	protected.append(approach_assembler.world_entry())
	var seed:=enemy("forest_seed_sentry",Vector2(1230,C.y),"approach_seed")
	approach_lamp=enemy("forest_lantern",Vector2(1250,C.y-90),"approach_lamp")
	for actor: EnemyActor in [seed,approach_lamp]:actor.attack_behavior.configure(actor,controller,policy,life,actor.attack_behavior.source_id,protected)
	approach_ring=approach_assembler.hook_targets[manifest.vine_gate.key_anchor]
	controller.traversal.hook_contact.connect(approach_hook_contact)
	comparison_id="setup/"+strategy
	await frames(warmup) # Selected local phase. Not a reproduced full-route arrival clock.
	var setup:=_comparison_frame()
	check(player.is_on_floor() and player.global_position.distance_to(C)<1,"identical supported protected C warmup")
	check(seed.health.current==3 and approach_lamp.health.current==2 and controller.actor_resources.health.current==5,"fresh real HP retained through warmup")
	var start_tick:=tick
	comparison_id=strategy
	var initial:=_comparison_frame()
	var action_ok:=true
	if strategy=="clear":
		for shot_index: int in 3:
			if not await approach_walk(1120):action_ok=false;break
			approach_request(&"shoot_release",(seed.motor.global_position-player.global_position).normalized())
			await frames(30)
		check(seed.health.terminal,"three real ordinary projectiles kill seed from repeated safe bank")
		action_ok=action_ok and seed.health.terminal
	# Ordinary full jump keeps its ascent until the actual apex, not a tick guess.
	if strategy in ["ordinary","ordinary_wide","clear"]:
		action_ok=action_ok and await approach_walk(1186)
		controller.router.set_jump_held(&"approach",true)
		events.append({"kind":"jump_hold","tick":tick,"held":true})
		controller.router.set_move_axis(1)
	elif strategy=="live":
		action_ok=await approach_walk(1080)
		controller.router.set_move_axis(1)
	var lamp_requested:=false
	var lamp_caught:=false
	var kick_seen:=false
	var recoil_requested:=false
	var gate_requested:=false
	var R_burst_seen:=false
	var stable:=0
	for i: int in 900:
		var state: StringName=controller.traversal.state
		lamp_caught=lamp_caught or controller.traversal.hook_target==approach_lamp.motor
		if lamp_caught and state==&"hook_kick":kick_seen=true
		if strategy=="live" and not lamp_requested and player.global_position.distance_to(approach_lamp.motor.global_position)<210:
			lamp_requested=approach_request(&"grapple",(approach_lamp.motor.global_position-(player.global_position+Vector2(0,-6))).normalized())
		if strategy=="live" and kick_seen and state==&"free" and not recoil_requested:
			recoil_requested=approach_request(&"shoot_release",Vector2.LEFT)
		# Contact/kick is real; no target assignment or forced gate opening.
		approach_assembler.resolve_hook_action(controller.traversal)
		R_burst_seen=R_burst_seen or (recoil_requested and player.recoil_burst_remaining>0)
		var live_ready:=R_burst_seen and player.recoil_burst_remaining<=0 and player.global_position.x>approach_lamp.motor.global_position.x+26
		var clear_x:=maxf(approach_lamp.motor.global_position.x+approach_lamp.definition.collision_size.x*.5+controller.traversal.definition.hook_capture_radius,seed.motor.global_position.x+seed.definition.collision_size.x*.5+controller.traversal.definition.hook_capture_radius)+1
		var ordinary_ready:=strategy!="live" and player.global_position.x>=(1426.0 if strategy=="ordinary_wide" else clear_x)
		if not gate_requested and state==&"free" and (live_ready if strategy=="live" else ordinary_ready) and approach_terrain_head_clear(manifest):
			controller.router.set_jump_held(&"approach",false)
			gate_requested=approach_request(&"grapple",(approach_ring.global_position-(player.global_position+Vector2(0,-6))).normalized())
		if not player.is_on_floor() and player.normal_velocity.y>=0:controller.router.set_jump_held(&"approach",false)
		var motion_goal:=1430.0 if strategy!="live" and not gate_requested else 1400.0
		var dx:=motion_goal-player.global_position.x
		controller.router.set_move_axis(signf(dx) if absf(dx)>3 else 0)
		if absf(1400-player.global_position.x)<=5 and player.is_on_floor() and absf(player.global_position.y-C.y)<1:stable+=1
		else:stable=0
		if stable>=12 or controller.actor_resources.health.terminal:break
		await frames(1)
	var final:=_comparison_frame()
	var opened: bool=approach_assembler.region_state.opened.has("crown_vine")
	check(action_ok and stable>=12 and opened,"actual gate key H and same full supported gate-ready terminal")
	if strategy=="live":
		check(lamp_requested and lamp_caught and kick_seen and recoil_requested,"actual moving live contact, kick and first-free R")
		check(approach_lamp.health.current==1,"actual H contact consumes one lamp HP")
	var points: Array=[]
	for point: Vector2 in protected:points.append([point.x,point.y])
	var data:={"scope":"Local placement hypothesis on actual generated map2 supports and protected semantic points; no formal prefix or encounter admission","strategy":strategy,"root_seed":root_seed,"choices":manifest.choices,"manifest":manifest,"protected_points":points,"setup":setup,"initial":initial,"final":final,"warmup_ticks":warmup,"phase_scope":"Selected local warmup, not full route arrival reproduced","start_tick":start_tick,"decision_ticks":tick-start_tick,"completed":stable>=12 and opened,"lamp_caught":lamp_caught,"kick_seen":kick_seen,"recoil_requested":recoil_requested,"gate_opened":opened,"contacts":approach_contacts.duplicate(true),"events":events.duplicate(true),"frames":comparison_frames.duplicate(true)}
	comparison_id=""
	await cleanup()
	approach_assembler=null;approach_lamp=null;approach_ring=null;seed=null;generator=null
	data.assertions=assertions;data.failures=failures
	DirAccess.make_dir_recursive_absolute(output)
	var file:=FileAccess.open(output+"/capture.json",FileAccess.WRITE);file.store_string(JSON.stringify(data));file.close()
	print("FOREST DEPTH APPROACH: %s assertions, %s failures"%[assertions,failures])
	quit(0 if failures==0 else 1)
