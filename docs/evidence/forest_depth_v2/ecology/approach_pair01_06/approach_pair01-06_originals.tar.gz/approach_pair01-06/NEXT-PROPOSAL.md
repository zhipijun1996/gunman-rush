# 后继只读因果与两对照提案（未运行）

先同05实际失败的live输入加passive observer：仅在hook_fly→hook_miss后读取现有ShapeCast缓存get_collider/get_collision_point及hook_tip，记录support_ids，不force更新、不调用私有probe、不改aim或input。生产/输入/phase与05原失败逐字一致。真实旧capture没有collider字段，静态交叉不能冒写实际命中对象。

若确证relay拦截，live仅改为1080真实满跳、在实际头到Lamp中心保守平台扫线净空后发H。从上侧先接触Lamp再到台，用真实目标接触保护；kick→首freeR→真实burst出现和结束→同ring。目标/敌/平台/phase不动，不救range/HP。

必须同时补普通更强时机：1125附近开始真实满跳，过Seed时高、到Lamp时已落下，可能无伤直走到原固定环；不再用1186恰好下降碰Lamp的HP4当不可避免伤。普通/清敌无需同一步起跳；各自最便宜合法时机才公平。127/149两原PASS与270清敌原PASS仍保原producer、不重签新source。

当前Lamp原轨迹y282，setup1267.635→final1309.038。relay x1100..1260/top290，Lamp底294确实与其顶4px重叠；不能称全相位悬空H可用。05地面origin1090.666,365.925→Lamp1278.369,282，12px头扫掠必交relay，实际H392→401miss，无contact/R；后4另seed未跑。
