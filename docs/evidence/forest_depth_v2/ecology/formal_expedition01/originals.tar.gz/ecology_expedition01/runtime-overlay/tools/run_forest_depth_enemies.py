"""Current spider/real-charger local ecology: real input, bullets, policy, strict native exit."""
import argparse
import contextlib
import hashlib
import json
from pathlib import Path
import re
import time

from run_tests import run_engine
import level_formal

ROOT = Path(__file__).resolve().parent.parent


def validate(data):
    if data.get('failures') != 0 or data.get('assertions', 0) < 35:
        raise ValueError('Complete native assertions are required')
    expected = {'spider_stand_line', 'spider_live_bypass', 'spider_bullets',
                'spider_cancel_pause_epoch_inactive'}
    rows = data.get('cases', [])
    if len(rows) != len(expected) or {r.get('id') for r in rows} != expected:
        raise ValueError('Every independent golden/counterfactual is required')
    events = data.get('events', [])
    for target in ('forest_thread_spider',):
        hits = [e for e in events if e.get('kind') == 'policy_result'
                and e.get('target') == target and e.get('hp') == 0
                and str(e.get('source', '')).startswith('player_projectile:')]
        if not hits:
            raise ValueError(f'{target}: actual projectile lethal policy result missing')
    if not any(e.get('kind') == 'accepted_shot' and e.get('projectiles', 0) > 0 for e in events):
        raise ValueError('Actual accepted shot with a spawned projectile required')
    row = next(r for r in rows if r['id'] == 'spider_stand_line')
    if row['hp_before'] - row['hp_after'] != 1:
        raise ValueError('Occupied-line policy damage must occur once')
    if not any(e.get('kind') == 'policy_result' and e.get('target') == 'player'
               and ':thread:' in str(e.get('event_id', '')) for e in events):
        raise ValueError('Actual thread hazard policy event missing')
    controls = data.get('comparisons', [])
    expected_controls = {f'root_split/{version}/{strategy}'
                         for version in ('legacy',)
                         for strategy in ('bank_shoot', 'lower_wait', 'fixed_H')}
    expected_controls |= {f'woven_crown/depth/{strategy}' for strategy in
                          ('bank_shoot', 'wait_line', 'fixed_H', 'live_H')}
    if len(controls) != 7 or {row.get('id') for row in controls} != expected_controls:
        raise ValueError('All seven current spatial strategy controls required')
    frames = data.get('comparison_frames', [])
    for row in controls:
        observed = [frame for frame in frames if frame.get('comparison') == row['id']]
        if not observed or row.get('ticks', 0) <= 0:
            raise ValueError(f"{row['id']}: real frame observations missing")
        if not row.get('completed'):
            raise ValueError(f"{row['id']}: strategy did not complete; retain failed control")
        if row.get('requested_H') and not row.get('caught_expected_H_target'):
            raise ValueError(f"{row['id']}: expected real H target was not caught")
        if row.get('strategy') != 'bank_shoot' and not row.get('observed_preview'):
            raise ValueError(f"{row['id']}: strategy bypassed actual observation")
        if row.get('strategy') == 'live_H':
            validate_live_recoil(row, events)
    validate_stress(data)


def validate_live_recoil(row, events):
    before, after = row.get('recoil_before', {}), row.get('recoil_after', {})
    request_tick = row.get('recoil_request_tick', -1)
    shot = [e for e in events[row['event_start']:row['event_end']]
            if e.get('kind') == 'accepted_shot' and e.get('aim') == [-1, 0]
            and request_tick <= e.get('tick', -1) <= request_tick + 1
            and e.get('projectiles', 0) > 0]
    if not shot or before.get('H_state') != 'free' or before.get('grounded'):
        raise ValueError('Live H must actually fire a left projectile at first free airborne recovery')
    if after.get('shot_charges') != before.get('shot_charges', 0) - 1:
        raise ValueError('Actual H->R must consume one real air shot')
    if abs(before.get('stamina', 0) - after.get('stamina', 0) - before.get('shot_cost', -1)) > 1e-6:
        raise ValueError('Actual H->R must consume the real configured shot cost')
    if not row.get('upper_support_seen'):
        raise ValueError('Live H->R must actually reach the named main support')


def _initial_signature(row):
    frame = row['start']
    return {key: frame[key] for key in ('position', 'hp', 'stamina', 'shot_charges', 'actors')}


def validate_stress(data):
    rows = data.get('stress_controls', [])
    expected = {f'ablation/{phase}/{strategy}/{switch}'
                for phase in ('fresh', 'line_hold')
                for strategy in ('direct_walk', 'wait_line', 'fixed_H', 'live_H')
                for switch in ('on', 'off')}
    expected |= {'phase/travel_left', 'phase/travel_right', 'dead_lantern/fixed_H', 'low_resource/live_H'}
    if len(rows) != len(expected) or {row.get('id') for row in rows} != expected:
        raise ValueError('All twenty causal/phase/dead/low-resource controls required')
    events = data['events']
    frames = data['comparison_frames']
    by_id = {row['id']: row for row in rows}
    for row in rows:
        if not row.get('setup_ok') or not row.get('completed'):
            raise ValueError(f"{row['id']}: actual setup or legal completion failed")
        observed = [frame for frame in frames if frame.get('comparison') == row['id']]
        if not observed:
            raise ValueError(f"{row['id']}: no actual frame observations")
        if row.get('requested_H') and not row.get('caught_expected_H_target'):
            raise ValueError(f"{row['id']}: requested H missed its actual target")
        if row.get('strategy') == 'live_H':
            validate_live_recoil(row, events)
        if row.get('strategy') not in ('bank_shoot', 'direct_walk') and not row.get('observed_preview'):
            raise ValueError(f"{row['id']}: missing actual observed preview")
        suppressed = row.get('thread_suppressed', [])
        if not row['variant'].get('line_disabled') and suppressed:
            raise ValueError('Normal controls must never suppress damage')
        if any(e.get('source') != 'woven_thread_spider' or ':thread:' not in e.get('event_id', '')
               or e.get('target') != 'player' or e.get('amount') != row['primary_definition']['line_damage']
               for e in suppressed):
            raise ValueError('Ablation may suppress only this spider line, never body/other damage')
    for phase in ('fresh', 'line_hold'):
        for strategy in ('direct_walk', 'wait_line', 'fixed_H', 'live_H'):
            left, right = [by_id[f'ablation/{phase}/{strategy}/{switch}'] for switch in ('on', 'off')]
            if left['geometry_hash'] != right['geometry_hash'] or _initial_signature(left) != _initial_signature(right):
                raise ValueError('Causal line pairs need exactly matched geometry, entry, resources and actor states')
    for phase in ('travel_left', 'travel_right'):
        row = by_id[f'phase/{phase}']
        actor = next(a for a in row['setup_state']['actors'] if a['id'] == 'forest_lantern')
        if actor['state'] != 'travel':
            raise ValueError('Moving-anchor phase must be reached through actual travel')
    row = by_id['dead_lantern/fixed_H']
    actor = next(a for a in row['start']['actors'] if a['id'] == 'forest_lantern')
    prefix = events[row['setup_event_start']:row['event_start']]
    if actor['hp'] != 0 or not any(e.get('kind') == 'policy_result' and e.get('target') == 'woven_lantern'
                                  and e.get('hp') == 0 and str(e.get('source', '')).startswith('player_projectile:')
                                  for e in prefix):
        raise ValueError('Dead-anchor fallback needs real projectile death before the route')
    row = by_id['low_resource/live_H']
    cost = row['start']['shot_cost']
    if not cost <= row['start']['stamina'] <= 2 * cost:
        raise ValueError('Low-energy route must start with one or two configured shot costs')
    prefix = events[row['setup_event_start']:row['event_start']]
    if not any(e.get('kind') == 'accepted_shot' and e.get('aim') == [-1, 0] and e.get('projectiles', 0) > 0 for e in prefix):
        raise ValueError('Low-energy setup needs actual costly missed projectiles')
    if any(e.get('kind') == 'policy_result' for e in prefix):
        raise ValueError('Low-energy miss setup must not secretly hit/refund or damage the player')


def summarize_stress(data):
    rows = {row['id']: row for row in data['stress_controls']}
    effects = []
    for phase in ('fresh', 'line_hold'):
        for strategy in ('direct_walk', 'wait_line', 'fixed_H', 'live_H'):
            on, off = [rows[f'ablation/{phase}/{strategy}/{switch}'] for switch in ('on', 'off')]
            effects.append({'phase': phase, 'strategy': strategy,
                            'line_on': {'ticks': on['ticks'], 'hp': on['end']['hp'], 'stamina': on['end']['stamina']},
                            'line_off': {'ticks': off['ticks'], 'hp': off['end']['hp'], 'stamina': off['end']['stamina']},
                            'off_suppressed_requests': len(off['thread_suppressed'])})
    return {'scope': 'Actual local matched causal observations, not fun/formal pool acceptance',
            'pairs': effects, 'no_automatic_mechanic_acceptance': True}




FORMAL_STRATEGIES = ('live_H', 'shoot_clear', 'wait_phase', 'fixed_route_continue', 'stand_danger', 'entry_clear', 'entry_wait', 'entry_hold', 'west_clear', 'west_wait', 'west_jump')
LIFT_BASE_STRATEGIES = ('alive_lift', 'jump_two_R', 'fixed_return', 'dead_fixed_return')
LIFT_STRATEGIES = LIFT_BASE_STRATEGIES + ('dead_jump_two_R', 'left_phase_lift', 'low_air_recover_lift', 'lethal_contact_lift')

def validate_router_observation(data):
    queued_requests = [r for r in data.get('requests', []) if r.get('queued') is True]
    sequences = [r.get('router_sequence') for r in queued_requests]
    if not sequences or any(type(n) is not int for n in sequences) or any(a >= b for a, b in zip(sequences, sequences[1:])):
        raise ValueError('Actual Router submission identities must be present and strictly increasing')
    for request in queued_requests:
        if request.get('observation') != 'actual_router_queued_direction' or type(request.get('router_epoch')) is not int:
            raise ValueError('Real queued direction/type/epoch observation required')
        raw, canonical = request.get('raw_aim', []), request.get('aim', [])
        if len(raw) != 2 or len(canonical) != 2:
            raise ValueError('Raw and actual canonical directions must both remain available')
        length = (raw[0] ** 2 + raw[1] ** 2) ** .5
        expected = [v / length for v in raw] if length else [0, 0]
        if any(abs(a - b) > 1e-6 for a, b in zip(expected, canonical)):
            raise ValueError('Observed canonical aim must preserve the original requested direction')


def validate_formal_choice(data):
    from run_forest_depth_region import validate as validate_actual_route
    errors = validate_actual_route(data)
    if errors:
        raise ValueError('Actual DemoApp route rejected: ' + ', '.join(errors))
    validate_router_observation(data)
    strategy = data.get('ecology_strategy')
    if strategy not in FORMAL_STRATEGIES or not (0 < data.get('ecology_started', -1) < data.get('ecology_finished', -1)):
        raise ValueError('Actual crown encounter entry/exit required')
    manifest = data['manifest']
    contract = manifest.get('encounter_plan_contract', {})
    if contract.get('version') != 'compact-authored-ecology-v3' or contract.get('mix_consumed') is not True or contract.get('selected_mix') != manifest['choices']['enemy_mix']:
        raise ValueError('Actual recorded seed ecology recipe must be consumed')
    events = data['events']
    begin, end = data['ecology_started'], data['ecology_finished']
    observed = [e for e in events if begin <= e['tick'] <= end]
    primary = next(e['primary'] for e in observed if e.get('kind') == 'ecology_choice_started')
    if strategy in ('west_clear', 'west_wait', 'west_jump'):
        if data.get('map_index') != 2 or primary != 'hollow_route__west_seed_watch':
            raise ValueError('West comparison requires actual map2 west side-branch sentry')
        if data['ecology_entry']['health'] != data['ecology_exit']['health']:
            raise ValueError('West legal response must preserve real local HP without refill')
        arrivals = [e for e in observed if e.get('kind') == 'west_seed_actual_M_arrival']
        if len(arrivals) != 1 or not any(str(s).startswith('hollow__belly') for s in arrivals[0].get('supports', [])):
            raise ValueError('Actual original west gap and full supported M successor required')
        kills = [e for e in observed if e.get('kind') == 'committed_damage' and e.get('target') == primary and e.get('lethal') is True and not str(e.get('event_id','')).startswith('hook/')]
        if strategy == 'west_clear' and (len(kills) != 1 or not str(kills[0].get('source','')).startswith('player_projectile:')):
            raise ValueError('West clear requires actual ordinary projectile lethal, not ray assumption')
        if strategy == 'west_clear':
            bank = next((e for e in observed if e.get('kind') == 'west_seed_actual_outside_spawn_gun_bank'), None)
            started = next(e for e in observed if e.get('kind') == 'ecology_choice_started')
            spawn = manifest['spawn']
            shots = [e for e in observed if e.get('kind') == 'shot_fired']
            if bank is None or 'west_court' not in bank.get('supports', []) or started.get('actual_spawn') != spawn or not shots:
                raise ValueError('West clear must actually leave spawn and reach a physically supported gun bank')
            protected = started.get('protected_radius', -1)
            if protected <= 0 or any(((e['position'][0]-spawn[0])**2+(e['position'][1]-spawn[1])**2)**.5 <= protected for e in shots):
                raise ValueError('West clear must fire actual ordinary shots outside unchanged spawn protection')
        if strategy != 'west_clear' and kills:
            raise ValueError('West live route must preserve the actual sentry')
        if strategy == 'west_wait' and not any(e.get('kind') == 'ecology_actual_seed_zone' and e.get('source') == primary for e in observed):
            raise ValueError('West wait needs an actual unsuppressed landed seed zone outside spawn protection')
        if strategy == 'west_jump' and any(e.get('kind') in ('shot_fired','hook_cast') for e in observed):
            raise ValueError('Cheap west control must retain ordinary gap input without H/gun cost')
        return
    if strategy in ('entry_clear', 'entry_wait', 'entry_hold'):
        if data.get('route') != 'borer' or data.get('map_index') != 1 or primary != 'hollow_route__borer_entry_thread':
            raise ValueError('Entry line comparison must use the actual map1 M-to-S region prefix')
        arrivals = [e for e in observed if e.get('kind') == 'entry_thread_actual_S_arrival']
        if len(arrivals) != 1 or 'hollow__cavity_observe' not in arrivals[0].get('supports', []):
            raise ValueError('Actual shared S arrival and original full successor route are required')
        damage = [e for e in observed if e.get('kind') == 'committed_damage' and str(e.get('event_id', '')).startswith(primary + ':thread:')]
        before, after = data['ecology_entry']['health'], data['ecology_exit']['health']
        if strategy == 'entry_hold':
            if len(damage) != 1 or before - after != 1 or not any(e.get('kind') == 'entry_thread_actual_hold_observed' for e in observed):
                raise ValueError('Hold counterfactual needs actual physical thread damage once and a completed real recovery')
        elif damage or before != after:
            raise ValueError('Clear/wait line response must preserve actual HP without refill')
        if strategy == 'entry_wait':
            if not any(e.get('kind') == 'entry_thread_actual_hold_observed' for e in observed) or not any(e.get('kind') == 'entry_thread_actual_retraction_observed' for e in observed):
                raise ValueError('Wait must actually observe hold then retraction, not inject a phase')
        if strategy == 'entry_clear':
            kills = [e for e in observed if e.get('kind') == 'committed_damage' and e.get('target') == primary and e.get('lethal') is True and str(e.get('source','')).startswith('player_projectile:') and not str(e.get('event_id','')).startswith('hook/')]
            if len(kills) != 1:
                raise ValueError('Actual ordinary projectile kill is required before the supported access')
        elif any(e.get('kind') == 'committed_damage' and e.get('target') == primary for e in observed):
            raise ValueError('Live wait/hold line comparisons must leave the actual spider intact')
        return
    if strategy == 'fixed_route_continue':
        prefix = [e for e in events if e['tick'] < begin]
        if not any(e.get('kind') == 'hook_contact_kick' and e.get('target') == 'hollow__upper_window_ring' for e in prefix):
            raise ValueError('Fixed-route control must actually reach E through the existing fixed ring')
        if any(r.get('kind') == 'grapple' and begin <= r['tick'] <= end for r in data['requests']):
            raise ValueError('Fixed-route control must not add an artificial reverse hook or use the live anchor')
        for target in (primary, 'hollow_route__canopy_lantern'):
            if any(e.get('kind') == 'committed_damage' and e.get('target') == target and e.get('lethal') is True for e in observed):
                raise ValueError('Fixed-route control must preserve the actual pair alive')
    if strategy == 'live_H':
        kind = 'ecology_actual_live_arrival'
        arrivals = [e for e in observed if e.get('kind') == kind]
        if len(arrivals) != 1 or arrivals[0].get('enemy_id') != 'hollow_route__canopy_lantern':
            raise ValueError('Requested hook must actually arrive at its intended real target')
        r = [e for e in observed if e.get('kind') == 'ecology_first_free_R']
        if len(r) != 1 or r[0]['snapshot']['shots'] <= 0 or r[0].get('hook_state') != 'free' or r[0].get('grounded') is not False:
            raise ValueError('Actual airborne first-free R observation missing')
        free_frames = [f for f in data['frames'] if arrivals[0]['tick'] <= f['tick'] < r[0]['tick'] and f.get('hook_state') == 'free' and f.get('grounded') is False]
        if not free_frames or r[0]['tick'] != free_frames[0]['tick'] + 1:
            raise ValueError('R must be requested at the first input step after the actual free airborne Motor frame')
        shot = [e for e in observed if e.get('kind') == 'shot_fired' and e.get('aim') == [-1, 0] and r[0]['tick'] <= e['tick'] <= r[0]['tick'] + 1]
        if len(shot) != 1:
            raise ValueError('Real accepted left projectile after H required')
        by_tick = {f['tick']: f for f in data['frames']}
        after = by_tick[shot[0]['tick']]
        before = r[0]['snapshot']
        cost = float(r[0]['shot_cost'])
        if after['shots'] != before['shots'] - 1 or abs(before['energy'] - after['energy'] - cost) > .001:
            raise ValueError('Actual H-to-R shot/energy deduction does not match the real Definition')
    if strategy == 'shoot_clear':
        for target in (primary, 'hollow_route__canopy_lantern'):
            lethal = [e for e in observed if e.get('kind') == 'committed_damage' and e.get('target') == target and e.get('lethal') is True and str(e.get('source', '')).startswith('player_projectile:')]
            if len(lethal) != 1:
                raise ValueError('Both actual enemies must die to normal projectiles')
            event_id = str(lethal[0].get('event_id', '')).split(':')
            if len(event_id) != 3 or lethal[0]['source'] != 'player_projectile:' + event_id[0] or not any(e.get('kind') == 'shot_fired' and str(e.get('serial')) == event_id[-1] and e['tick'] < lethal[0]['tick'] for e in observed):
                raise ValueError('Lethal must bind an actual normal shot serial, not grapple damage mislabeled by the shared Policy source')
        if any(r.get('kind') == 'grapple' and begin <= r['tick'] <= end for r in data['requests']):
            raise ValueError('Shoot-clear must use normal shots without grapple damage')
    if strategy in ('wait_phase', 'stand_danger'):
        if not any(e.get('kind') == 'ecology_actual_preview' for e in observed) or not any(e.get('kind') == 'ecology_actual_danger_finished' for e in observed):
            raise ValueError('Wait must observe a real warning and real hazard completion')
    if strategy in ('wait_phase', 'stand_danger') and primary == 'hollow_route__outer_watch':
        if not any(e.get('kind') == 'ecology_actual_seed_zone' and e.get('source') == primary for e in observed):
            raise ValueError('A supported seed warning alone is not a danger: require an actual unsuppressed landed zone')
    if strategy == 'stand_danger' and not any(e.get('kind') == 'committed_damage' and e.get('target') == 'player' and e.get('source') == primary and e.get('amount', 0) > 0 for e in observed):
        raise ValueError('Counterexample requires actual configured line/seed Policy damage, not body contact')


def validate_lift_choice(data):
    from run_forest_depth_region import VERSION, expected_itinerary
    if data.get('failures') or data.get('scope') != 'actual_DemoApp_R_E_lift_candidate_not_admitted_route':
        raise ValueError('Actual bounded R-to-E candidate must finish without native route failures')
    manifest = data['manifest']
    if data.get('actual_stage_version') != VERSION or manifest.get('version') != VERSION or data.get('actual_stage_map') != data.get('map_index') or manifest.get('map_index') != data.get('map_index'):
        raise ValueError('Actual stage/Manifest version and map identity required')
    if manifest.get('seed') != f"{data.get('seed')}/thorn_forest/map_{data.get('map_index')}":
        raise ValueError('Actual seed identity required')
    if data.get('manual_motor_step') is not False or data.get('position_or_resource_injection') is not False or data.get('audio_released') is not True:
        raise ValueError('Normal actual Motor/resources and strict owner teardown required')
    frames, events = data['frames'], data['events']
    if not frames or any(f['tick'] != i + 1 or f['motor_steps'] != 1 for i, f in enumerate(frames)):
        raise ValueError('Every real continuous single-Motor frame required')
    validate_router_observation(data)
    for event in events:
        if event.get('kind') == 'shot_fired' and not any(r.get('kind') == 'shoot_release' and r.get('queued') is True and r['tick'] == event['tick'] and r['aim'] == event['aim'] for r in data['requests']):
            raise ValueError('Actual shot must bind its exact real Router submission')
    initial, final = data['initial_snapshot'], data['final_snapshot']
    if initial.get('hook_enabled') is not True or initial.get('double_enabled') is not False or initial.get('wall_enabled') is not False or initial.get('weapon') != 'pulse_gun' or initial.get('tier') != 1:
        raise ValueError('Actual H-only basic Pulse setup required')
    if any(final.get(k) != initial.get(k) for k in ('config', 'hook_enabled', 'double_enabled', 'wall_enabled', 'weapon', 'tier')) or final.get('health', 0) <= 0:
        raise ValueError('Runtime, abilities, weapon and living natural route must remain valid')
    actual = expected_itinerary(manifest, 'high_return')
    if data.get('lift_original_itinerary') != actual:
        raise ValueError('Natural common approach must use the actual generated high-return itinerary')
    prefix = data['lift_prefix']
    if not prefix or len(prefix) >= len(actual) or actual[len(prefix)].get('edge_id') != 'outer_to_inner':
        raise ValueError('Actual natural common prefix must end at R before its real return edge')
    if any(row['edge_id'] != actual[index]['edge_id'] or row['leg'] != index for index, row in enumerate(prefix)):
        raise ValueError('Natural R approach prefix cannot be skipped or renamed')
    begin, end = data.get('lift_started', -1), data.get('lift_finished', -1)
    entry, exit = data.get('lift_entry', {}), data.get('lift_exit', {})
    if not 0 < begin < end or entry.get('shots') != 2 or entry.get('health', 0) <= 0:
        raise ValueError('Actual normal same-R entry and bounded E arrival required')
    areas = {a['id']: a['position'] for a in manifest['areas']}
    for snapshot, goal, support in ((entry, areas['R'], 'hollow__outer_root'), (exit, areas['E'], 'hollow__outer_crown')):
        if abs(snapshot['position'][0] - goal[0]) > 7 or abs(snapshot['position'][1] - goal[1]) > 2 or support not in snapshot.get('supports', []):
            raise ValueError('Both actual same-terminal full-body supported ports required')
    arrival = [f for f in frames if end - 11 <= f['tick'] <= end]
    if len(arrival) != 12 or any('hollow__outer_crown' not in f['supports'] or not f['grounded'] or abs(f['position'][0] - areas['E'][0]) > 7 for f in arrival):
        raise ValueError('Twelve actual supported E endpoint frames required')
    row = next((r for r in manifest['enemies'] if r['id'] == 'hollow_route__outer_lift_lantern'), {})
    if row.get('position') != [1050, 680] or row.get('stable_id') != 'forest_lantern':
        raise ValueError('Only the actual new lower-lift placement is in scope')
    observed = [e for e in events if begin <= e['tick'] <= end]
    strategy = data.get('lift_strategy')
    if strategy not in LIFT_STRATEGIES:
        raise ValueError('Unknown actual lift strategy')
    _validate_lift_motion(data, row, entry, initial, frames, observed, begin, end, strategy)
    if strategy in ('fixed_return', 'dead_fixed_return'):
        if [r['edge_id'] for r in data['completed_legs'][len(prefix):]] != ['outer_to_inner', 'inner_recovery', 'upper_out']:
            raise ValueError('Existing full R-D-M-E return must really execute, not an invented staircase')
    if strategy == 'dead_fixed_return':
        lethal = [e for e in observed if e.get('kind') == 'committed_damage' and e.get('target') == row['id'] and e.get('lethal') is True and not str(e.get('event_id', '')).startswith('hook/')]
        selected = [e for e in observed if e.get('kind') == 'lift_existing_fixed_return_selected']
        if len(lethal) != 1 or len(selected) != 1 or lethal[0]['tick'] >= selected[0]['tick']:
            raise ValueError('Normal projectile death must precede the actual unchanged fixed return')


def _validate_lift_motion(data, row, entry, initial, frames, observed, begin, end, strategy):
    motion_begin = max(begin, data.get('lift_motion_started', begin))
    motion = [e for e in observed if e['tick'] >= motion_begin]
    shots = [e for e in motion if e.get('kind') == 'shot_fired']
    if strategy in ('alive_lift', 'left_phase_lift', 'low_air_recover_lift', 'lethal_contact_lift'):
        contacts = [e for e in observed if e.get('kind') == 'lift_actual_contact' and e.get('enemy_id') == row['id']]
        lethal_contact = strategy == 'lethal_contact_lift'
        hits = [e for e in observed if e.get('kind') == 'committed_damage' and e.get('target') == row['id'] and str(e.get('event_id', '')).startswith('hook/') and e.get('health_after') == (0 if lethal_contact else 1) and bool(e.get('lethal')) == lethal_contact]
        if len(contacts) != 1 or len(hits) != 1 or len(shots) != 1 or shots[0]['aim'] != [0, 1]:
            raise ValueError('Real moving contact, HP2-to-1 grapple Policy and one actual downward shot required')
        hit_frame = next(f for f in frames if f['tick'] == hits[0]['tick'])
        hook_parts = hits[0]['event_id'].split('/')
        config = data['lift_resource_config']
        packet = hook_parts[2] + '/hook/' + hook_parts[3]
        combat_gain = min(config['combat_target_gain'], config['combat_packet_limit'])
        if hit_frame.get('combat_hit_packets', {}).get(packet) != combat_gain:
            raise ValueError('Actual accepted grapple hit must bind the independent combat currency packet')
        launch = next((e for e in observed if e.get('kind') == 'lift_motion_started'), {})
        stamina_receipts = launch.get('shot_energy_hit_receipts') if lethal_contact else entry.get('shot_energy_hit_receipts')
        if hit_frame.get('shot_energy_hit_receipts') != stamina_receipts:
            raise ValueError('Grapple combat credit must not be mislabeled as a normal projectile stamina/round refund')
        first_free = next((f for f in frames if f['tick'] >= contacts[0]['tick'] and f['hook_state'] == 'free' and not f['grounded']), None)
        requests = [e for e in observed if e.get('kind') == 'lift_first_free_down_R_request']
        if first_free is None or len(requests) != 1 or requests[0]['tick'] != first_free['tick'] + 1 or shots[0]['tick'] != requests[0]['tick']:
            raise ValueError('Downward R must occur at the first actual free-air input step')
        after = next(f for f in frames if f['tick'] == shots[0]['tick'])
        before = requests[0]['snapshot']
        if after['shots'] != before['shots'] - 1 or abs(before['energy'] - after['energy'] - requests[0]['shot_cost']) > .001:
            raise ValueError('One real air round and configured stamina cost must be spent')
    if strategy == 'lethal_contact_lift':
        prime = [e for e in observed if e.get('kind') == 'committed_damage' and e.get('target') == row['id'] and e.get('health_after') == 1 and not e.get('lethal') and not str(e.get('event_id', '')).startswith('hook/')]
        setup = [e for e in observed if e.get('kind') == 'shot_fired' and e['tick'] < motion_begin]
        marker = [e for e in observed if e.get('kind') == 'lift_actual_projectile_prime_HP1']
        if len(prime) != 1 or len(setup) != 1 or len(marker) != 1 or not setup[0]['tick'] <= prime[0]['tick'] < motion_begin:
            raise ValueError('One real ordinary shot must prime actual HP2-to-1 before lethal H, without a second setup shot')
        parts = str(prime[0].get('event_id', '')).split(':')
        if len(parts) != 3 or int(parts[2]) != int(setup[0]['serial']) or prime[0].get('source') != 'player_projectile:' + parts[0]:
            raise ValueError('HP1 priming must bind the actual accepted ordinary projectile serial')
        prior = next(f for f in frames if f['tick'] == motion_begin-1)
        if not prior['grounded'] or 'hollow__outer_root' not in prior['supports'] or abs(prior['position'][0] - entry['position'][0]) > 7:
            raise ValueError('Primed H must naturally return to the same supported R bank')
    if strategy in ('jump_two_R', 'dead_jump_two_R'):
        if not 1 <= len(shots) <= 2 or any(e['aim'] != [0, 1] for e in shots) or any(e.get('kind') == 'hook_cast' for e in observed):
            raise ValueError('Strong ordinary control allows at most two down shots and no H')
        if not any(e.get('kind') == 'lift_normal_full_jump_apex' for e in observed):
            raise ValueError('Strong control must reach a genuine full-jump apex rather than an early short release')
    if strategy == 'dead_jump_two_R':
        lethal = [e for e in observed if e.get('kind') == 'committed_damage' and e.get('target') == row['id'] and e.get('lethal') is True and not str(e.get('event_id', '')).startswith('hook/')]
        if len(lethal) != 1 or lethal[0]['tick'] >= motion_begin:
            raise ValueError('Actual ordinary projectile death must precede the strong full-jump return')
        motion_event = next((e for e in observed if e.get('kind') == 'lift_motion_started'), None)
        if motion_event is None or 'hollow__outer_root' not in next(f for f in frames if f['tick'] == motion_begin-1)['supports']:
            raise ValueError('Dead strong return must naturally realign at the same R bank, without resource reset')
    if strategy == 'left_phase_lift':
        start = next((e for e in observed if e.get('kind') == 'lift_R_choice_started'), {})
        launch = next((e for e in observed if e.get('kind') == 'lift_motion_started'), {})
        if start.get('travel_side') != 1 or launch.get('travel_side') != -1 or launch.get('enemy_state') != 'travel' or launch.get('tick', begin) <= begin:
            raise ValueError('Alternative phase must be reached by actual waiting for the opposite real movement, not injected time')
    if strategy == 'low_air_recover_lift':
        empty = data.get('lift_empty_tick', -1)
        restored = data.get('lift_floor_recovery_tick', -1)
        if not begin < empty < restored == motion_begin:
            raise ValueError('Low-air route must actually run out and naturally recover before selecting H')
        empty_frame = next(f for f in frames if f['tick'] == empty)
        if empty_frame['grounded'] or empty_frame['shots'] != 0:
            raise ValueError('The actual airborne empty-round state is required')
        before_motion = [e for e in observed if e['tick'] < motion_begin]
        setup_shots = [e for e in before_motion if e.get('kind') == 'shot_fired']
        if [e['aim'] for e in setup_shots] != [[-1, 0], [1, 0]] or any(e.get('kind') in ('committed_damage', 'actual_shot_energy_recovered') for e in before_motion):
            raise ValueError('Low-air setup must spend two actual enemy misses without secret hit/refund or damage')
        restored_event = next((e for e in before_motion + motion if e.get('kind') == 'lift_actual_ground_round_recovery'), {})
        if restored_event.get('snapshot', {}).get('shots') != initial['shots'] or 'hollow__outer_root' not in next(f for f in frames if f['tick'] == restored-1)['supports']:
            raise ValueError('The real R floor must restore the configured rounds before the live route')


def validate_expedition(data):
    from run_forest_depth_region import validate as validate_actual_route, expected_itinerary
    errors = validate_actual_route(data)
    if errors:
        raise ValueError('Complete actual expedition route rejected: ' + ', '.join(errors))
    if data.get('expedition_scope') != 'actual_reward_camp_then_optional_R_E_and_gate' or data.get('route') != 'ecology_expedition':
        raise ValueError('Explicit complete expedition scope and actual manifest route required')
    validate_router_observation(data)
    m, frames, events = data['manifest'], data['frames'], data['events']
    if data.get('map_index') != 1 or m['choices']['skeleton'] != 1:
        raise ValueError('Only the actual shared-root map1 expedition is admitted here')
    full = expected_itinerary(m, 'ecology_expedition')
    prefix = expected_itinerary(m, 'high_return')
    if full[:len(prefix)] != prefix or data.get('expedition_prefix_count') != len(prefix):
        raise ValueError('Every original reward/camp route leg must remain unchanged before the optional extension')
    if len(full) <= len(prefix) + 2 or full[len(prefix)].get('edge_id') != 'camp_outer_back' or full[len(prefix)+1].get('edge_id') != 'outer_lift_return':
        raise ValueError('Real camp-to-R then optional R-to-E then actual gate tail required')
    optional = full[len(prefix)+1]
    if optional.get('kind') != 'hollow_live_return' or optional.get('a') != 'R' or optional.get('b') != 'E' or optional.get('optional') is not True or optional.get('enemy_id') != 'hollow_route__outer_lift_lantern':
        raise ValueError('Optional edge cannot be forged or relabeled from an old R-D return')
    completed = data['completed_legs']
    camp_row = completed[len(prefix)-1]
    if data.get('expedition_camp_tick') != camp_row['tick'] or data.get('expedition_started_leg') != len(prefix)+1:
        raise ValueError('Real supported camp checkpoint must precede the second R visit')
    marker = [e for e in events if e.get('kind') == 'expedition_reward_return_complete']
    if len(marker) != 1 or marker[0]['tick'] != camp_row['tick'] or data.get('cache_claimed') is not True or data.get('duplicate_checked') is not True:
        raise ValueError('Actual claim/modal/return checkpoint required, not the first spawn R shortcut')
    if len(data.get('pointer_events', [])) != 2 or data.get('duplicate_before') != data.get('duplicate_after'):
        raise ValueError('Actual pointer claim and repeated interaction must remain intact')
    if data.get('gate_saved_open') is not True or data.get('gate_shape_disabled') is not True or full[-1].get('kind') != 'gate_hook':
        raise ValueError('Complete actual gate objective after E is required; local E truncation rejected')
    begin, end = data.get('lift_started', -1), data.get('lift_finished', -1)
    entry, exit = data.get('lift_entry', {}), data.get('lift_exit', {})
    if not camp_row['tick'] < begin < end < frames[-1]['tick']:
        raise ValueError('Reward return, new choice, E and final destination must occur in real order')
    if data.get('lift_prefix') != completed[:len(prefix)+1] or completed[len(prefix)+1]['tick'] != end:
        raise ValueError('New choice must follow the complete real prefix and end its real optional leg')
    areas = {a['id']: a['position'] for a in m['areas']}
    for snap, goal, support in ((entry, areas['R'], 'hollow__outer_root'), (exit, areas['E'], 'hollow__outer_crown')):
        if len(snap.get('position', [])) != 2 or abs(snap['position'][0]-goal[0]) > 7 or abs(snap['position'][1]-goal[1]) > 2 or support not in snap.get('supports', []):
            raise ValueError('Actual supported R and E terminals required')
    arrival = [f for f in frames if end-11 <= f['tick'] <= end]
    if len(arrival) != 12 or any('hollow__outer_crown' not in f['supports'] or not f['grounded'] for f in arrival):
        raise ValueError('Actual twelve-frame E support required before continuing')
    if any('wallet_balance' not in f or 'meta_notes' not in f or 'item_ids' not in f or 'combat_hit_packets' not in f for f in frames):
        raise ValueError('Read-only whole-route wallet/build/combat resource observations required')
    row = next((r for r in m['enemies'] if r['id'] == optional['enemy_id']), {})
    if row.get('position') != [1050, 680] or row.get('stable_id') != 'forest_lantern':
        raise ValueError('Actual lower moving actor identity required')
    strategy = data.get('lift_strategy')
    if strategy not in ('alive_lift', 'jump_two_R', 'left_phase_lift', 'low_air_recover_lift'):
        raise ValueError('Unsupported expedition strategy')
    if data.get('expedition_fallback') is not False:
        raise ValueError('Dead-anchor fallback may complete gameplay but cannot establish the requested live strategy')
    observed = [e for e in events if begin <= e['tick'] <= end]
    _validate_lift_motion(data, row, entry, data['initial_snapshot'], frames, observed, begin, end, strategy)
    if not observed or data.get('lift_original_itinerary') != full:
        raise ValueError('The original full manifest itinerary must not be truncated or rewritten')


def run_formal_choices(out, args, receipt):
    rows = []
    is_expedition = args.scenario == 'expedition'
    is_lift = args.scenario in ('lift', 'expedition')
    receipt['lift_runs' if is_lift else 'formal_runs'] = rows
    strategies = args.expedition_strategies if is_expedition else (args.lift_strategies if is_lift else args.formal_strategies)
    common_R = None
    common_entry = None
    for index, strategy in enumerate(strategies):
        folder = out / f'{index:02d}-{strategy}'
        folder.mkdir()
        argv = ['--headless', '--fixed-fps', '60', '--path', '.', '--script',
                'tests/forest_depth_lift_runner.gd' if is_lift else 'tests/forest_depth_ecology_runner.gd', '--', f'--seed={args.seed}',
                f'--map={args.map}', ('--route=ecology_expedition' if is_expedition else '--route=high_return') if is_lift else f'--route={args.formal_route}', f'--strategy={strategy}',
                f'--output=res://{folder.relative_to(ROOT)}/capture.json'] + (['--expedition'] if is_expedition else [])
        row = {'strategy': strategy, 'argv': argv, 'timeout_seconds': 240, 'passed': False}
        rows.append(row)
        start = time.monotonic()
        try:
            with (folder / 'native.log').open('w') as log, contextlib.redirect_stdout(log):
                text = run_engine(argv, 240)
            if not re.search(r'FOREST DEPTH ROUTE: .* / 0 failures', text):
                raise ValueError('Formal actual route terminal result absent')
            data = json.loads((folder / 'capture.json').read_text())
            (validate_expedition if is_expedition else (validate_lift_choice if is_lift else validate_formal_choice))(data)
            if is_lift:
                signature = {'entry': data['lift_entry'], 'frames': [{k: f[k] for k in ('position', 'health', 'energy', 'shots', 'enemies')} for f in data['frames'] if f['tick'] < data['lift_started']]}
                if common_R is None:
                    common_R = signature
                elif signature != common_R:
                    raise ValueError('Lift strategies must share the exact natural approach, same R resources and actual enemy phases')
                row['common_R_prefix_sha256'] = hashlib.sha256(json.dumps(signature, sort_keys=True).encode()).hexdigest()
            if not is_lift and strategy.startswith(('entry_', 'west_')):
                signature = {'entry': data['ecology_entry'], 'frames': [{k: f[k] for k in ('position', 'health', 'energy', 'shots', 'enemies')} for f in data['frames'] if f['tick'] < data['ecology_started']]}
                if common_entry is None:
                    common_entry = signature
                elif signature != common_entry:
                    raise ValueError('Entry strategies must share the exact actual M prefix/resources/enemy phase')
                row['common_entry_prefix_sha256'] = hashlib.sha256(json.dumps(signature, sort_keys=True).encode()).hexdigest()
            row.update(passed=True, frames=len(data['frames']), recipe=data['manifest']['encounter_plan_contract'],
                       entry=data['lift_entry' if is_lift else 'ecology_entry'], exit=data['lift_exit' if is_lift else 'ecology_exit'],
                       ticks=data['lift_finished' if is_lift else 'ecology_finished']-data['lift_started' if is_lift else 'ecology_started'])
        finally:
            row['elapsed_seconds'] = time.monotonic()-start
    receipt['passed'] = True


def validate_leaper(data):
    if data.get('failures') != 0 or data.get('assertions', 0) < 27:
        raise ValueError('Complete real leaper assertions and clean result required')
    rows = data.get('cases', [])
    expected = {'leaper/physical_cycle', 'leaper/ordinary_full_jump',
                'leaper/shoot_then_jump', 'leaper/wait_commit', 'leaper/live_H',
                'leaper/blocked_arc', 'leaper/pause_save_cancel_death'}
    if len(rows) != len(expected) or {row.get('id') for row in rows} != expected:
        raise ValueError('Every leaper physical/strategy/lifecycle counterexample required')
    indexed = {row['id']: row for row in rows}
    cycle = indexed['leaper/physical_cycle']
    if cycle['depth'].get('landing_count', 0) < 2 or cycle['depth'].get('current_shore') != 0:
        raise ValueError('Both real different-height landings required')
    if indexed['leaper/blocked_arc']['depth'].get('blocked_reason') not in ('committed_arc_changed', 'actual_body_collision_outside_target'):
        raise ValueError('Actual terrain rejection must block rather than move/snap')
    signatures = []
    events = data.get('events', [])
    frames = data.get('comparison_frames', [])
    for strategy in ('ordinary_full_jump', 'shoot_then_jump', 'wait_commit', 'live_H'):
        row = indexed['leaper/' + strategy]
        signatures.append(_initial_signature(row))
        if not row.get('returned') or not row.get('upper') or row['upper'].get('support_id') != 'reward_branch' or row['end'].get('support_id') != 'root_floor':
            raise ValueError('Actual reward shore and complete normal return required')
        observed = [frame for frame in frames if frame.get('comparison') == row['id']]
        upper = [frame for frame in observed if frame.get('support_id') == 'reward_branch' and 412 <= frame['position'][0] <= 628]
        if len(upper) < 12:
            raise ValueError('Twelve full-body real upper support frames required')
        if strategy == 'ordinary_full_jump' and (row.get('H_requested') or row.get('R_requests', 3) > 2):
            raise ValueError('Strong ordinary control cannot secretly use H or more than two R')
        if strategy == 'shoot_then_jump':
            lethal = [event for event in events[row['event_start']:row['event_end']]
                      if event.get('kind') == 'policy_result' and event.get('target') == 'forest_branch_leaper'
                      and event.get('hp') == 0 and str(event.get('source', '')).startswith('player_projectile:')]
            if len(lethal) != 1 or row.get('enemy_hp') != 0 or lethal[0]['tick'] >= row['upper_tick']:
                raise ValueError('Ordinary real projectile lethal must precede ascent goal')
        if strategy == 'live_H':
            if not row.get('H_arrived') or not row.get('contact_seen') or row.get('enemy_hp') != 2:
                raise ValueError('Actual living leaper H contact and one hook damage required')
            before, after = row['recoil_before'], row['recoil_after']
            shot = [event for event in events[row['event_start']:row['event_end']]
                    if event.get('kind') == 'accepted_shot' and event.get('aim') == [1, 0]
                    and row['free_tick'] <= event.get('tick', -1) <= row['free_tick'] + 1
                    and event.get('projectiles', 0) > 0]
            if not shot or before.get('H_state') != 'free' or before.get('grounded'):
                raise ValueError('Live contact must resume real airborne R after free')
            if after.get('shot_charges') != before['shot_charges'] - 1 or abs(before['stamina'] - after['stamina'] - before['shot_cost']) > 1e-6:
                raise ValueError('Actual one-air-round and real shot-energy debit required')
    if any(signature != signatures[0] for signature in signatures[1:]):
        raise ValueError('All four strategies require identical real actor and player entry')
    if not any(event.get('kind') == 'accepted_shot' and event.get('projectiles', 0) > 0 for event in events):
        raise ValueError('Real projectiles required, not direct health tests')
    for row in [cycle, indexed['leaper/live_H']]:
        motions = row.get('motions', [])
        if not motions or any(motion.get('physics_frame', -1) < 0 for motion in motions):
            raise ValueError('Real frame-stamped Motor motion receipts required')
        if any(a['to'] != b['from'] or a['physics_frame'] >= b['physics_frame'] for a, b in zip(motions, motions[1:])):
            raise ValueError('Enemy motion must stay continuous and once per physics frame')
        if any(sum((end - begin) ** 2 for end, begin in zip(motion['to'], motion['from'])) > sum(value ** 2 for value in motion['requested']) + 0.1 for motion in motions):
            raise ValueError('Actual body cannot move beyond its requested physical step')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output-dir', default='build/forest_depth/ecology/native')
    parser.add_argument('--scenario', choices=('golden', 'formal', 'lift', 'leaper', 'expedition'), default='golden')
    parser.add_argument('--seed', default=None)
    parser.add_argument('--map', type=int, choices=(1, 2), default=1)
    parser.add_argument('--formal-route', choices=('fast', 'growth', 'borer'), default='fast')
    parser.add_argument('--formal-strategies', nargs='+', choices=FORMAL_STRATEGIES, default=['wait_phase', 'stand_danger'])
    parser.add_argument('--lift-strategies', nargs='+', choices=LIFT_STRATEGIES, default=list(LIFT_BASE_STRATEGIES))
    parser.add_argument('--expedition-strategies', nargs='+', choices=('alive_lift', 'jump_two_R', 'left_phase_lift', 'low_air_recover_lift'), default=['alive_lift'])
    args = parser.parse_args()
    if args.seed is None:
        args.seed = 'forest-depth-hollow-02' if args.scenario == 'expedition' else 'forest-depth-hollow-00'
    out = (ROOT / args.output_dir).resolve()
    if not out.is_relative_to((ROOT / 'build/forest_depth/ecology').resolve()):
        parser.error('output must be under build/forest_depth/ecology')
    if out.exists() and any(out.iterdir()):
        parser.error('fresh output directory required')
    out.mkdir(parents=True, exist_ok=True)
    before = level_formal.source_files()
    verifier = {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
                for p in (Path(__file__).resolve(), ROOT / 'tests/forest_depth_enemy_runner.gd', ROOT / 'tests/forest_depth_ecology_trace.gd', ROOT / 'tests/forest_depth_ecology_runner.gd', ROOT / 'tests/forest_depth_lift_trace.gd', ROOT / 'tests/forest_depth_lift_runner.gd', ROOT / 'tests/forest_depth_region_trace.gd', ROOT / 'tools/run_forest_depth_region.py')}
    receipt = {'scope': 'Local actors, four spider actor cases, seven spatial controls and twenty causal/phase/dead/low-resource controls; rejected badger prototype retired. Mechanics value remains subject to actual comparison; not formal forest admission',
               'source_before': before, 'verifier_before': verifier, 'passed': False}
    if args.scenario in ('formal', 'lift', 'expedition'):
        receipt['scope'] = 'Actual DemoApp seed recipe crown pair, natural route entry and fixed/live/kill/wait/damage controls; not whole forest admission'
    if args.scenario == 'lift':
        receipt['scope'] = 'Actual generated DemoApp R-to-E live lift vs strongest full-jump/two-R and original fixed return, including natural projectile death; not an admitted topology edge'
    if args.scenario == 'expedition':
        receipt['scope'] = 'Complete actual reward/high_return, camp, optional R-to-E lift and real gate objective; no local truncation or altered manifest'
    if args.scenario == 'leaper':
        receipt['scope'] = 'New local real two-shore leaper prototype; physical landings, four fair routes and cancellation counterexamples, not random-pool admission'
    receipt['scenario'] = args.scenario
    started = time.monotonic()
    try:
        # The public check must work from a clean checkout, not an author's
        # separately imported snapshot. Native gameplay keeps its original cap.
        with (out / 'import.log').open('w') as log, contextlib.redirect_stdout(log):
            imported = run_engine(['--headless', '--path', '.', '--editor', '--quit'], 90)
        if re.search(r'(^|\n)(?:SCRIPT )?ERROR:', imported):
            raise RuntimeError('Unexpected native import ERROR')
        if args.scenario in ('formal', 'lift', 'expedition'):
            run_formal_choices(out, args, receipt)
            print('PASS: actual DemoApp ecology choices, strict exit')
            return
        with (out / 'native.log').open('w') as log, contextlib.redirect_stdout(log):
            text = run_engine(['--headless', '--fixed-fps', '60', '--path', '.', '--script',
                               'tests/forest_depth_enemy_runner.gd', '--',
                               f'--output-dir=res://{out.relative_to(ROOT)}'] + (['--leaper'] if args.scenario == 'leaper' else []), 180)
        if not re.search(r'^FOREST DEPTH ENEMIES: [1-9]\d* assertions, 0 failures$', text, re.M):
            raise RuntimeError('Native completion missing')
        if re.search(r'(^|\n)(?:SCRIPT )?ERROR:', text):
            raise RuntimeError('Unexpected engine ERROR')
        data = json.loads((out / 'capture.json').read_text())
        if args.scenario == 'leaper':
            validate_leaper(data)
        else:
            validate(data)
            (out / 'stress-summary.json').write_text(json.dumps(summarize_stress(data), indent=2) + '\n')
        receipt['passed'] = True
    finally:
        receipt['source_after'] = level_formal.source_files()
        receipt['source_guard'] = before == receipt['source_after']
        receipt['verifier_after'] = {path: hashlib.sha256((ROOT / path).read_bytes()).hexdigest()
                                     for path in verifier}
        receipt['elapsed_seconds'] = time.monotonic() - started
        (out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
        if not receipt['source_guard'] or verifier != receipt['verifier_after']:
            raise RuntimeError('Source changed during native capture')
    print('PASS: local forest depth enemies, actual bullets/policy and strict exit')


if __name__ == '__main__':
    main()
