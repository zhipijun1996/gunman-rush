from pathlib import Path
import hashlib,json,os,shutil,stat,subprocess,time
repo=Path('/workspace/gunman-rush-design');origin=repo/'build/forest_depth/snapshots/ecology_expedition01';dest=repo/'build/forest_depth/snapshots/ecology_expedition03';out=repo/'build/forest_depth/ecology/formal-expedition-plan'
assert not dest.exists(); original=json.loads((origin.parent/'ecology_expedition01-receipt.json').read_text());basis=original['source_files'];overlay_paths=['tests/forest_depth_lift_trace.gd','tools/run_forest_depth_enemies.py']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def inventory(root):
 result={}
 for directory in ['scripts','scenes','resources','config','assets','shaders','addons','tests','tools']:
  for p in (root/directory).rglob('*'):
   if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc':result[str(p.relative_to(root))]=sha(p)
 for f in ['project.godot','export_presets.cfg','.gitignore','.gitattributes']:
  if (root/f).is_file():result[f]=sha(root/f)
 return result
before=inventory(origin);assert all(before.get(p)==h for p,h in basis.items());extra={p:h for p,h in before.items() if p not in basis};overlay_before={p:sha(repo/p) for p in overlay_paths};expected={**basis,**overlay_before};dest.mkdir(parents=True)
for p,h in expected.items():
 src=repo/p if p in overlay_paths else origin/p;dst=dest/p;dst.parent.mkdir(parents=True,exist_ok=True)
 if p.startswith('assets/') and src.suffix.lower() in {'.png','.jpg','.jpeg','.webp','.ogg','.wav','.ttf','.woff','.woff2','.otf'}:os.link(src,dst)
 else:shutil.copy2(src,dst)
 assert sha(dst)==h,p
copied=inventory(dest);after=inventory(origin);overlay_after={p:sha(repo/p) for p in overlay_paths};assert copied==expected;assert before==after;assert overlay_before==overlay_after
production=[p for p in copied if p.startswith(('scripts/','scenes/','resources/','config/')) or p=='project.godot'];assert all(copied[p]==basis[p] for p in production)
subprocess.run(['git','init','--quiet',str(dest)],check=True);objects=Path(subprocess.check_output(['git','rev-parse','--path-format=absolute','--git-path','objects'],cwd=origin,text=True).strip());(dest/'.git/objects/info/alternates').write_text(str(objects)+'\n');head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=origin,text=True).strip();assert head==original['base_commit'];subprocess.run(['git','update-ref','--no-deref','HEAD',head],cwd=dest,check=True);subprocess.run(['git','read-tree','HEAD'],cwd=dest,check=True);(dest/'.git/info/exclude').write_text('build/\n.godot/\n');(dest/'build/verification').mkdir(parents=True)
receipt={'scope':'Exact frozen alive01 runtime plus two explicitly new phase/control producer files. NOT main current source. Original alive preserved; no .godot copied. Identical immutable media inodes only, independent code/sidecars/Git/index/data.','base_commit':head,'original_receipt_sha256':sha(origin.parent/'ecology_expedition01-receipt.json'),'original_snapshot':str(origin),'snapshot_root':str(dest),'source_root':str(origin),'source_files':copied,'origin_before':before,'origin_after':after,'origin_extra_import_sidecars_not_forwarded':extra,'overlay_before':overlay_before,'overlay_after':overlay_after,'source_copy_guard':True,'production_exact_alive':True,'created':time.time()};(dest/'build/snapshot-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');(dest.parent/'ecology_expedition03-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');(out/'controls03-copy-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'snapshot':str(dest),'files':len(copied),'production_exact_alive':True,'overlay':overlay_before,'extras_not_forwarded':list(extra)}))
