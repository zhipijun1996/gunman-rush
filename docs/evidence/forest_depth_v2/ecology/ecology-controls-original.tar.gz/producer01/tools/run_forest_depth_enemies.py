"""Fresh local forest-depth actors: real input, bullets, policy, strict native exit."""
import argparse
import contextlib
import hashlib
import json
from pathlib import Path
import re
import time

from run_tests import run_engine
import level_formal

ROOT = Path(__file__).resolve().parent.parent


def validate(data):
    if data.get('failures') != 0 or data.get('assertions', 0) < 25:
        raise ValueError('Complete native assertions are required')
    expected = {'badger_live', 'badger_bullets_dead_path', 'badger_wall',
                'spider_stand_line', 'spider_live_bypass', 'spider_bullets',
                'spider_cancel_pause_epoch_inactive'}
    rows = data.get('cases', [])
    if len(rows) != len(expected) or {r.get('id') for r in rows} != expected:
        raise ValueError('Every independent golden/counterfactual is required')
    events = data.get('events', [])
    for target in ('forest_branch_badger', 'forest_thread_spider'):
        hits = [e for e in events if e.get('kind') == 'policy_result'
                and e.get('target') == target and e.get('hp') == 0
                and str(e.get('source', '')).startswith('player_projectile:')]
        if not hits:
            raise ValueError(f'{target}: actual projectile lethal policy result missing')
    if not any(e.get('kind') == 'accepted_shot' and e.get('projectiles', 0) > 0 for e in events):
        raise ValueError('Actual accepted shot with a spawned projectile required')
    row = next(r for r in rows if r['id'] == 'spider_stand_line')
    if row['hp_before'] - row['hp_after'] != 1:
        raise ValueError('Occupied-line policy damage must occur once')
    if not any(e.get('kind') == 'policy_result' and e.get('target') == 'player'
               and ':thread:' in str(e.get('event_id', '')) for e in events):
        raise ValueError('Actual thread hazard policy event missing')
    controls = data.get('comparisons', [])
    expected_controls = {f'root_split/{version}/{strategy}'
                         for version in ('depth', 'legacy')
                         for strategy in ('bank_shoot', 'lower_wait', 'fixed_H')}
    expected_controls |= {f'woven_crown/depth/{strategy}' for strategy in
                          ('bank_shoot', 'wait_line', 'fixed_H', 'live_H')}
    if len(controls) != 10 or {row.get('id') for row in controls} != expected_controls:
        raise ValueError('All ten matched spatial strategy controls required')
    frames = data.get('comparison_frames', [])
    for row in controls:
        observed = [frame for frame in frames if frame.get('comparison') == row['id']]
        if not observed or row.get('ticks', 0) <= 0:
            raise ValueError(f"{row['id']}: real frame observations missing")
        if not row.get('completed'):
            raise ValueError(f"{row['id']}: strategy did not complete; retain failed control")
        if row.get('requested_H') and not row.get('caught_expected_H_target'):
            raise ValueError(f"{row['id']}: expected real H target was not caught")
        if row.get('strategy') != 'bank_shoot' and not row.get('observed_preview'):
            raise ValueError(f"{row['id']}: strategy bypassed actual observation")



def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output-dir', default='build/forest_depth/ecology/native')
    args = parser.parse_args()
    out = (ROOT / args.output_dir).resolve()
    if not out.is_relative_to((ROOT / 'build/forest_depth/ecology').resolve()):
        parser.error('output must be under build/forest_depth/ecology')
    if out.exists() and any(out.iterdir()):
        parser.error('fresh output directory required')
    out.mkdir(parents=True, exist_ok=True)
    before = level_formal.source_files()
    verifier = {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
                for p in (Path(__file__).resolve(), ROOT / 'tests/forest_depth_enemy_runner.gd')}
    receipt = {'scope': 'Local actors and ten matched spatial controls only. Mechanics value remains subject to actual comparison, not completed=True; not formal forest admission',
               'source_before': before, 'verifier_before': verifier, 'passed': False}
    started = time.monotonic()
    try:
        with (out / 'native.log').open('w') as log, contextlib.redirect_stdout(log):
            text = run_engine(['--headless', '--fixed-fps', '60', '--path', '.', '--script',
                               'tests/forest_depth_enemy_runner.gd', '--',
                               f'--output-dir=res://{out.relative_to(ROOT)}'], 180)
        if not re.search(r'^FOREST DEPTH ENEMIES: [1-9]\d* assertions, 0 failures$', text, re.M):
            raise RuntimeError('Native completion missing')
        if re.search(r'(^|\n)(?:SCRIPT )?ERROR:', text):
            raise RuntimeError('Unexpected engine ERROR')
        validate(json.loads((out / 'capture.json').read_text()))
        receipt['passed'] = True
    finally:
        receipt['source_after'] = level_formal.source_files()
        receipt['source_guard'] = before == receipt['source_after']
        receipt['verifier_after'] = {path: hashlib.sha256((ROOT / path).read_bytes()).hexdigest()
                                     for path in verifier}
        receipt['elapsed_seconds'] = time.monotonic() - started
        (out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
        if not receipt['source_guard'] or verifier != receipt['verifier_after']:
            raise RuntimeError('Source changed during native capture')
    print('PASS: local forest depth enemies, actual bullets/policy and strict exit')


if __name__ == '__main__':
    main()
