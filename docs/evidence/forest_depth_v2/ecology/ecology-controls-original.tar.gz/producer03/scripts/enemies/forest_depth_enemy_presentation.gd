class_name ForestDepthEnemyPresentation
extends Node2D
@export var actor: EnemyActor
var age := 0.0
func _process(delta: float) -> void:
	age += delta
	queue_redraw()
func _draw() -> void:
	if not is_instance_valid(actor): return
	var alive := not actor.health.terminal
	var behavior := actor.attack_behavior
	var state: StringName = behavior.state if behavior else &"idle"
	var body_color := Color("756248") if alive else Color("393f38")
	if actor.definition.behavior_id == &"forest_branch_badger":
		draw_style_box(_body_style(body_color),Rect2(-17,-13,34,26))
		for i: int in 4:
			var x := -12.0 + i*8
			draw_colored_polygon(PackedVector2Array([Vector2(x,-11),Vector2(x+3,-22),Vector2(x+8,-10)]),Color("a6b36a"))
		var direction := float(actor.brain.direction)
		draw_circle(Vector2(direction*12,-4),3,Color("fff3b5"))
		draw_line(Vector2(-10,12),Vector2(-10+sin(age*10)*2,17),body_color,4)
		draw_line(Vector2(10,12),Vector2(10-sin(age*10)*2,17),body_color,4)
		if behavior and state in [&"telegraph",&"rush",&"transfer_preview",&"transfer"]:
			var goal := to_local(behavior.attack_goal)
			var warning := state in [&"telegraph",&"transfer_preview"]
			draw_line(Vector2.ZERO,goal,Color(1,.77,.3,.55) if warning else Color(1,.3,.2,.8),3)
			draw_circle(goal,8,Color(1,.77,.3,.65),false,2)
			if warning: draw_arc(Vector2.ZERO,24,-PI*.8,-PI*.2,20,Color("ffd680"),3)
	else:
		draw_circle(Vector2.ZERO,12,body_color)
		for side: int in [-1,1]:
			for i: int in 3:
				var elbow := Vector2(side*(16+i*3),-9+i*8)
				draw_line(Vector2(side*6,-4+i*3),elbow,Color("9aaa6a"),3)
				draw_line(elbow,elbow+Vector2(side*5,8),Color("9aaa6a"),2)
		draw_circle(Vector2(-4,-4),2,Color("ffdf94"))
		draw_circle(Vector2(4,-4),2,Color("ffdf94"))
		if behavior is ForestThreadSpiderBehavior and alive:
			var spider := behavior as ForestThreadSpiderBehavior
			if state in [&"telegraph",&"extend",&"hold",&"retract"]:
				var a := to_local(spider.line_start)
				var b := to_local(spider.line_end)
				var color := Color("ffbc68") if not spider.line_active else Color("ef6065")
				draw_line(a,b,Color(color,.20),(actor.definition as ForestEnemyDefinition).line_radius*2)
				draw_line(a,b,color,2 if not spider.line_active else 4)
				draw_circle(a,5,color,false,2)
				draw_circle(b,5,color,false,2)
func _body_style(color: Color) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color=color
	style.set_corner_radius_all(8)
	return style
