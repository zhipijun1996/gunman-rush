class_name ForestBranchBadgerBehavior
extends EnemyAttackBehavior
## Lock -> real swept rush -> brake -> recovery. No player displacement writes.
var transfer_points: Array[Vector2] = []
var completed_rushes := 0
var blocked_last_rush := false
var _transfer_origin := Vector2.ZERO
var _transfer_goal := Vector2.ZERO
var _path_elapsed := 0.0

func configure_transfer_points(points: Array[Vector2]) -> void:
	transfer_points.clear()
	for point: Vector2 in points:
		if point.is_finite(): transfer_points.append(point)

func advance(delta: float) -> bool:
	if not _active():
		cancel()
		return true
	if _actor_epoch != lifetime.actor_epoch:
		_actor_epoch = lifetime.actor_epoch
		cancel()
		return true
	var d := actor.definition as ForestEnemyDefinition
	state_time += delta
	cooldown = maxf(0, cooldown - delta)
	match state:
		&"idle":
			if cooldown > 0 or not _can_engage(): return true
			if completed_rushes >= d.transfer_every and _choose_transfer():
				_set_state(&"transfer_preview")
				return true
			var side := signf(controller.motor.global_position.x - actor.motor.global_position.x)
			if side == 0: side = actor.brain.direction
			locked_direction = Vector2(side,0)
			actor.brain.direction = int(side)
			attack_origin = actor.motor.global_position
			attack_goal = attack_origin + locked_direction * d.rush_distance
			blocked_last_rush = false
			_set_state(&"telegraph")
		&"telegraph":
			if state_time >= d.telegraph_duration: _set_state(&"rush")
		&"rush":
			var remaining := (attack_goal - actor.motor.global_position).dot(locked_direction)
			var motion := locked_direction * minf(d.attack_speed * delta, maxf(0,remaining))
			if remaining <= 0.1:
				_finish_rush()
			elif not _supported(actor.motor.global_position + motion) or not actor.motor.move_attack(motion,false,delta):
				blocked_last_rush = true
				_finish_rush()
		&"brake":
			actor.motor.stop()
			if state_time >= d.brake_seconds: _set_state(&"recovery")
		&"recovery":
			if state_time >= d.recovery_duration:
				cooldown = d.rest_cooldown
				_set_state(&"idle")
		&"transfer_preview":
			if state_time >= d.transfer_preview:
				_path_elapsed = 0
				_set_state(&"transfer")
		&"transfer":
			_path_elapsed += delta
			var t := clampf(_path_elapsed / d.transfer_seconds,0,1)
			var target := _transfer_origin.lerp(_transfer_goal,t) + Vector2(0,-sin(PI*t)*d.transfer_arc)
			if not actor.motor.move_attack(target-actor.motor.global_position,false,delta):
				# Do not leave a cancelled leap floating or teleport back through terrain.
				# Admission rejects a blocked full path; dynamic obstruction uses fall.
				_set_state(&"settle")
			elif t >= 1:
				completed_rushes = 0
				home = actor.motor.global_position
				_set_state(&"recovery")
		&"settle":
			if _supported(actor.motor.global_position): _set_state(&"recovery")
			else: actor.motor.move_attack(Vector2(0,d.return_speed*delta),false,delta)
	return true

func _supported(center: Vector2) -> bool:
	var d := actor.definition
	var half := d.collision_size * 0.5
	for offset: float in [-half.x+2,half.x-2]:
		var foot := center + Vector2(offset,half.y)
		var ray := PhysicsRayQueryParameters2D.create(foot-Vector2(0,2),foot+Vector2(0,7),1,[actor.motor.get_rid()])
		var hit := actor.motor.get_world_2d().direct_space_state.intersect_ray(ray)
		if hit.is_empty() or (hit.normal as Vector2).y > -0.5: return false
	return true

func _choose_transfer() -> bool:
	var d := actor.definition as ForestEnemyDefinition
	for point: Vector2 in transfer_points:
		var offset := point-actor.motor.global_position
		if offset.length() < 8 or absf(offset.x)>d.transfer_max_offset.x or absf(offset.y)>d.transfer_max_offset.y or not _supported(point): continue
		var blocked := false
		for safe: Vector2 in protected_points:
			if safe.distance_to(point)<d.protected_radius+d.collision_size.length()*0.5: blocked=true
		if blocked: continue
		# Test the actual body shape along the authored curve before committing.
		var previous := actor.motor.global_position
		for i: int in range(1,17):
			var t := float(i)/16
			var next := actor.motor.global_position.lerp(point,t)+Vector2(0,-sin(PI*t)*d.transfer_arc)
			var query := PhysicsShapeQueryParameters2D.new()
			query.shape = (actor.motor.get_node("CollisionShape2D") as CollisionShape2D).shape
			query.transform = Transform2D(0,previous)
			query.motion = next-previous
			query.collision_mask = 1
			query.exclude = [actor.motor.get_rid()]
			var cast := actor.motor.get_world_2d().direct_space_state.cast_motion(query)
			if cast[0] < 0.999: blocked=true;break
			previous=next
		if not blocked:
			_transfer_origin=actor.motor.global_position
			_transfer_goal=point
			attack_goal=point
			return true
	return false

func _finish_rush() -> void:
	completed_rushes += 1
	actor.motor.stop()
	_set_state(&"brake")

func cancel() -> void:
	if is_instance_valid(actor): actor.motor.stop()
	super.cancel()

func depth_snapshot() -> Dictionary:
	var points: Array = []
	for point: Vector2 in transfer_points: points.append([point.x,point.y])
	return {"version":1,"transfer_points":points,"completed_rushes":completed_rushes,"blocked_last_rush":blocked_last_rush,"transfer_origin":[_transfer_origin.x,_transfer_origin.y],"transfer_goal":[_transfer_goal.x,_transfer_goal.y],"path_elapsed":_path_elapsed}

func restore_depth_state(saved: Dictionary) -> bool:
	if saved.get("version") != 1: return false
	var points: Array[Vector2] = []
	for point: Array in saved.get("transfer_points",[]):
		if point.size()!=2: return false
		points.append(Vector2(point[0],point[1]))
	configure_transfer_points(points)
	completed_rushes=int(saved.get("completed_rushes",0))
	blocked_last_rush=bool(saved.get("blocked_last_rush",false))
	var origin: Array=saved.get("transfer_origin",[])
	var goal: Array=saved.get("transfer_goal",[])
	if origin.size()!=2 or goal.size()!=2: return false
	_transfer_origin=Vector2(origin[0],origin[1])
	_transfer_goal=Vector2(goal[0],goal[1])
	_path_elapsed=float(saved.get("path_elapsed",0))
	return _transfer_origin.is_finite() and _transfer_goal.is_finite() and is_finite(_path_elapsed) and _path_elapsed>=0 and completed_rushes>=0
