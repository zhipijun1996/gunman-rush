# FOREST-DEPTH-02：联合生态黄金与淘汰条件

只读诊断依据：v2gen._install_ecology planned rows；independent/design-review E01/E02；review/design-diagnosis。首轮30/0只证明局部合法行为，未证明新玩家判断。

## 选择：不为保留新ID证明价值

- 獾当前无巡逻，有限换层未入实际场地：先按“森林charger配方”看待。与旧charger同几何、同入口策略对照后，只有实际换层改变路线决策才有资格宣称独立层级生态。不会让玩家为凑两轮空等；若当前黄金只有同一冲线节奏，合并/删除新敌种主张，保留安全扫掠技术改进。
- 蛛保留候选：必须让锁定线改变先过/等/换枝/击杀至少一个取舍，不能只是计时门或永远可忽略。
- 暂不追加蛾。旧萤可参加联合场地，但不通过加第三种移动曲线粉饰其路线价值。

## A：宽根盘分岔（badger+spider）

入口(10,282)，根桥floor y300，獾(160,287)；上层枝x100..360/top190，蛛(270,150)，线x120..260/y172。固定环(175,150)。观察时根桥、上枝/整条线皆可见，出口x430的根桥。无刺、无掉落补能、无强制奖励/HP锁。

下层只有獾身体/冲线，上层只有蛛线，不把两者叠在唯一接收岸。比较：lower_wait（观察真实锁向→后退到冲线外→等一次冲刺与恢复→正常跳过活体走下层）；bank_shoot（正常远岸先实弹杀獾→走下层，蛛仍活）；fixed_H（锁向后固定环上枝→通过，允许最后回根桥）；repeat上述策略用旧plains_charger（原Definition/行为/HP/碰撞，不人为改旧怪配平；记录这些差异限制因果）。

记录真实冲刺/线phase、入口到出口tick、HP、精力、空射次数、accepted弹数/命中/死者、实际H目标、上层真实支持/路径。若只展示H可以通过而lower合法解同成本，不签H价值；只参数收益不签新敌判断。

## B：织冠双解（spider+lantern）

入口(10,282)，根桥y300，蛛(290,282)、line x120..240/y282；旧萤(170,165)与固定环(140,90)都真实存在，上枝x210..400/top220，出口x450根桥。static_H与live_H分别真实命中对应目标（H自身可能伤萤，不能关闭伤害）；wait_line等完整线收回后通过；bank_shoot优先真实弹体击杀蛛后过。

每种解保留全敌/机关/资源，只初始fixture重建，进行四策略独立对照。若活萤无实际路线/成本收益，明确其短路主张未成立而不删固定环；若静态旁路恒优且无发现差异，删这处蛛/萤组合placement，不用额外伤害或强制H救它。

## 证据与边界

扩展新forest_depth_enemy_runner，comparisons另列，原7case/30check不删；每策略保留真实frame轨迹。策略完成失败如实保存，不把capture写完当策略成功。价值判定依据实际记录及正常速度电影/独审，不能用“使用了H”标签验收。初始几何是明确fixture，不冒充正式v2gen Manifest，planned仍planned。

Stage字段协作：身体position按敌半高对真实支持面；spider端点/receiver_ids/alternative_edge_id/observation_area_id写Manifest。尚未验证位置不入enemies。root/spatial作者独占生成器，本作者只写新runner与专属工具。
