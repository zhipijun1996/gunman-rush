# 第三不同假设：原萤高度的 H→水平R，而非再添接收台

01/02均为严格失败，不覆盖。03不改PC/H/保护/敌数值或相位，不加接收台。

## 已观察与物理预算

原01 `woven_crown/live_H`：tick2983为contact停驻，身体中心(137.797,198.722)；2984进入kick；2989中心(113.797,174.722)；2991首次free，中心(122.464,174.722)、HP5、stamina100、air shots2。直到2999才发生萤body伤害。过去driver首次free后只是260px/s走右，2999才到x157.13，与仍活的萤接触；没有发出R。这不能证明H+R无法成功。

真实PlayerMotor.start_shot_burst：空中左射使normal_velocity.y=0、向右1100px/s持续0.14s，横向总154px（不取额外助力）；每tick约18.333px。现在从x122.46要让身体右缘进入主枝x210只需中心≥198，即75.54px，约5tick；到x214约5tick，身体脚底192.72<主枝top220，尚有27.28px竖直余量。水平burst期间不按普通重力积分；即使保守先以g2600自由落体估计0.0833s也仅落9.03px，仍有18px余量。

萤身体24×24、玩家24×36：同高危险水平中心区约146..194。若从122.46发R，第2tick进入该区、第4tick离开，约0.067s。真实H当前incoming-target接触保护从kick开始0.25s，原free已过约7tick，余约8tick；R在首free请求后保守延迟1tick，预计离开还余3tick。Player traversal.on_weapon_fired/free不清_contact_remaining，不借延长保护。该余量只适用于原01的实际相位；需用真实新frame验证，不能外推所有萤移动相位。

R将射向左侧空处，不给萤假伤/退款：应有实际accepted projectile、正常shot_cost扣费、air shots2→1，保留萤H1后HP1。若实际H不能命中/射击被取消/落点无支持/保护过早到期，保失败，不再移敌来保结果。

## 同条件第三候选

A保持02已证明LOS的上枝x140..360；仍同旧charger三控制，不宣称新物种。B恢复萤(170,165)、删除02左接收枝，保上枝x210..400/top220、固定环(140,90)、蛛/地面短线原样；四策略均在这一同几何独立运行。live_H只在真实contact/kick后第一次free且仍空中时request shoot_release LEFT，之后正常向右。static/等待/枪杀都保02共同身体规避逻辑，不能只重测live。

新增可观察量：support_id真实脚下支持、normal_velocity/recoil burst、H状态/保护目标、真实accepted左射及其费用/余枪。原upper_support_seen用y阈值不足，改为真实支持main_branch，仍保旧原始失败数据不改；不放宽Htarget或完成断言。

本轮若成功只称新组合H+R假设有局部证据，不称独立新敌价值、正式生态/全部相位或用户趣味通过；不得把几何与驾驶共同变动单归因某一项。
