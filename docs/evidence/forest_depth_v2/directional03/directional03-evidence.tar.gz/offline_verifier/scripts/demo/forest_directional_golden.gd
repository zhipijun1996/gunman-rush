extends Node2D
## One development golden. Existing Module/Player/Traversal consumers; no replacement physics.
const GEOMETRY = preload("res://scripts/generation/forest_directional_geometry.gd")
var manifest: Dictionary
var module: PlatformingModule
var player: PlayerMotor
var controller: PlayerController
var grant_hook := true
func _ready() -> void:
	manifest=GEOMETRY.build()
	module=PlatformingModule.new()
	module.name="DirectionalRootArch"
	module.definition=GEOMETRY.as_module(manifest)
	module.authoring_debug=false
	add_child(module)
	for row: Dictionary in manifest.hook_anchors:
		var anchor:=GrappleAnchor.new()
		anchor.name=row.id
		anchor.position=GEOMETRY.point(row.position)
		add_child(anchor)
	player=preload("res://scenes/player/player.tscn").instantiate() as PlayerMotor
	player.position=GEOMETRY.point(manifest.spawn)
	add_child(player)
	controller=player.get_node("Controller") as PlayerController
	controller.enable_shot_energy()
	if grant_hook: controller.traversal.grant(&"grapple")
	var camera:=Camera2D.new()
	camera.position=Vector2(250,-100)
	add_child(camera)
	queue_redraw()
func _draw() -> void:
	draw_string(ThemeDB.fallback_font,Vector2(-180,-85),"ROOT ARCH: SIDE HOOK / AWAY KICK / RECOIL OUT",HORIZONTAL_ALIGNMENT_LEFT,-1,14,Color("e4bc6e"))
	draw_string(ThemeDB.fallback_font,Vector2(510,-265),"CROWN / RETURN OUTSIDE ROOT",HORIZONTAL_ALIGNMENT_LEFT,-1,13,Color("e4bc6e"))
