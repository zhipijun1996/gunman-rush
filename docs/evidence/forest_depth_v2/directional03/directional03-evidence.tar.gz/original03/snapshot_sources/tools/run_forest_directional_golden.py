"""Bounded real-Motor directional forest golden, not formal region admission."""
import argparse,fcntl,hashlib,json,os,pathlib,re,subprocess,time
ROOT=pathlib.Path(__file__).resolve().parents[1]
ERRORS=re.compile(r'(?m)SCRIPT ERROR:|Parse Error:|SHADER ERROR:|^ERROR:|ObjectDB.*leaked|resources? still in use at exit')
def inventory():
    paths=[ROOT/'project.godot']
    for directory in ('scripts','scenes','resources','config','shaders','assets','tests','tools'):
        paths += [p for p in (ROOT/directory).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc']
    return {p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)}
def validate(data):
    errors=[]
    if data.get('passed') is not True or data.get('audio_released') is not True:errors.append('native_route_or_audio_failed')
    if not data.get('frames') or any(f.get('motor_steps')!=1 for f in data['frames']):errors.append('missing_normal_single_Motor_frames')
    if data.get('manual_motor_step') is not False or data.get('midroute_injection') is not False:errors.append('privileged_driver_rejected')
    if data['variant']=='intended':
        if not data.get('reached') or not data.get('returned') or data.get('danger_contacts'):errors.append('physical_out_and_return_failed')
    else:
        if data.get('reached') or not data.get('recovered') or not data.get('danger_contacts'):errors.append('physical_comparison_or_recovery_missing')
    return errors

def main():
    p=argparse.ArgumentParser();p.add_argument('--output-dir',type=pathlib.Path,required=True);p.add_argument('--variant',choices=['intended','noH','naivejump','onlyR','all'],default='all');a=p.parse_args()
    out=a.output_dir.resolve();out.mkdir(parents=True,exist_ok=False)
    report={'status':'running','source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'source_before':inventory(),'scope':'scheduled_InputRouter_development_golden_physical_danger_and_support_comparison','runs':[]}
    def save():(out/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
    save()
    with (ROOT/'build/verification/engine.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        for v in ['intended','noH','naivejump','onlyR'] if a.variant=='all' else [a.variant]:
            capture=out/(v+'.json');log=out/(v+'.log');argv=['bash','tools/godot.sh','--headless','--fixed-fps','60','--path','.','--script','tests/forest_directional_golden_runner.gd','--','--variant='+v,'--output='+str(capture)]
            started=time.monotonic()
            try:
                with log.open('w') as stream:r=subprocess.run(argv,cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT,timeout=45,env={**os.environ,'LP_NUM_THREADS':'1'})
                data=json.loads(capture.read_text()) if capture.exists() else {}
                errors=validate(data) if data else ['capture_absent']
                text=log.read_text(errors='replace')
                ok=r.returncode==0 and not ERRORS.search(text) and not errors and bool(re.search(r'^FOREST DIRECTIONAL: .*passed=true',text,re.M))
                row={'variant':v,'argv':argv,'exit_code':r.returncode,'validation_errors':errors,'status':'passed' if ok else 'failed','seconds':time.monotonic()-started,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
            except subprocess.TimeoutExpired:row={'variant':v,'argv':argv,'status':'timeout','seconds':time.monotonic()-started}
            report['runs'].append(row);save();print(json.dumps(row),flush=True)
            if row['status']!='passed':break
    report['source_after']=inventory();report['source_stable']=report['source_before']==report['source_after'];report['status']='passed' if all(r['status']=='passed' for r in report['runs']) and report['source_stable'] else 'failed';save();print('FOREST DIRECTIONAL GOLDEN:',report['status'],str(out),flush=True)
    return 0 if report['status']=='passed' else 1
if __name__=='__main__':raise SystemExit(main())
