import fcntl,hashlib,importlib.util,json,os,pathlib,selectors,subprocess,time
R=pathlib.Path('/workspace/gunman-rush-design');S=R/'build/forest_depth/snapshots/golden03';O=R/'build/forest_depth/traversal/round03-movie';O.mkdir(exist_ok=False)
spec=importlib.util.spec_from_file_location('frozen_golden_wrapper',S/'tools/run_forest_directional_golden.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
engine=pathlib.Path('/workspace/toolchains/godot/4.7.2/Godot_v4.7.2-stable_linux.x86_64')
env={**os.environ,'GUNMAN_TOOLCHAIN_ROOT':'/workspace/toolchains','GUNMAN_DATA_HOME':str(S/'build/userdata'),'XDG_CONFIG_HOME':str(S/'build/userconfig'),'XDG_CACHE_HOME':str(S/'build/usercache'),'LIBGL_ALWAYS_SOFTWARE':'1','LP_NUM_THREADS':'1','OMP_NUM_THREADS':'1'}
r={'status':'running','scope':'snapshot03 dirty-overlay local development golden, NOT cleanbee/currentroot/formalregion or applied-HP proof','snapshot_absolute':str(S),'engine_sha256':sha(engine),'engine_binary':str(engine),'engine_bytes':engine.stat().st_size,'source_before':mod.inventory(),'producer_sha256':sha(pathlib.Path(__file__)),'frozen_wrapper_sha256':sha(S/'tools/run_forest_directional_golden.py'),'frame_note':'Decoded movie frame/time independent of physics tick; final teardown frames retained.'}
def save():(O/'receipt.json').write_text(json.dumps(r,indent=2)+'\n')
save()
with (R/'build/verification/engine.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 r['engine_version']=subprocess.check_output([str(engine),'--version'],text=True).strip();assert r['engine_version'].startswith('4.7.2.stable.official.')
 log=(O/'display.log').open('wb');display=subprocess.Popen(['/workspace/toolchains/xvfb/usr/bin/Xvfb','-displayfd','1','-screen','0','1280x720x24','-nolisten','tcp','-ac'],stdout=subprocess.PIPE,stderr=log)
 try:
  with selectors.DefaultSelector() as selector:
   selector.register(display.stdout,selectors.EVENT_READ);assert selector.select(15);number=display.stdout.readline().decode().strip();assert number.isdigit()
  env['DISPLAY']=':'+number
  argv=['bash','tools/godot.sh','--rendering-method','gl_compatibility','--audio-driver','Dummy','--fixed-fps','60','--write-movie',str(O/'gameplay.avi'),'--path','.','--script','tests/forest_directional_golden_runner.gd','--','--variant=intended','--output='+str(O/'capture.json')]
  r['argv']=argv;r['native_budget_seconds']=45;save();start=time.monotonic()
  with (O/'native.log').open('w') as stream:process=subprocess.run(argv,cwd=S,env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=45)
  r['native_exit_code']=process.returncode;r['wall_seconds']=time.monotonic()-start
 finally:
  display.terminate();display.wait(timeout=5);log.close()
 r['source_after']=mod.inventory();r['source_stable']=r['source_before']==r['source_after'];text=(O/'native.log').read_text();d=json.loads((O/'capture.json').read_text());r['frozen_original_validation']=mod.validate(d)
 assert r['native_exit_code']==0 and r['source_stable'] and not mod.ERRORS.search(text) and 'OpenGL API' in text and d['passed'] and d['reached'] and d['returned'] and not d['danger_contacts']
 r['native_and_capture_hashes']={p.name:sha(p) for p in [O/'native.log',O/'capture.json',O/'gameplay.avi']};save()
probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames','-show_streams','-show_format','-of','json',str(O/'gameplay.avi')]))
v=next(s for s in probe['streams'] if s['codec_type']=='video');num,den=map(int,v['avg_frame_rate'].split('/'));fps=num/den;assert fps==60;total=int(v['nb_read_frames']);r.update(ffprobe=probe,movie_frames=total,movie_fps=fps,movie_seconds=total/fps)
indices=sorted(set([int(total*f) for f in [.10,.25,.40,.55,.70,.82,.90]]));filt='select='+'+'.join('eq(n\\,%d)'%i for i in indices)
argv=['ffmpeg','-hide_banner','-loglevel','error','-i',str(O/'gameplay.avi'),'-vf',filt,'-vsync','vfr',str(O/'frame-%02d.png')];subprocess.run(argv,check=True,timeout=45);r['frame_extract_argv']=argv
r['frames']=[{'movie_frame':i,'movie_seconds':i/fps,'path':str(O/('frame-%02d.png'%(n+1))),'sha256':sha(O/('frame-%02d.png'%(n+1)))} for n,i in enumerate(indices)]
argv=['ffmpeg','-hide_banner','-loglevel','error','-i',str(O/'gameplay.avi'),'-c:v','libx264','-preset','veryfast','-crf','20','-pix_fmt','yuv420p','-c:a','aac','-movflags','+faststart',str(O/'gameplay.mp4')];subprocess.run(argv,check=True,timeout=45);r['encoding_argv']=argv;r['mp4_sha256']=sha(O/'gameplay.mp4');r['status']='passed_original_native_capture_new_validator_separate';save();print('GOLDEN03 GL MOVIE: passed',total,'frames',total/fps,'seconds',flush=True)
