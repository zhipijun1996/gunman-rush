from pathlib import Path
import json,hashlib,re,collections
R=Path.cwd();O=R/'build/forest_depth/independent/guardian-label-delta02';P=R/'build/forest_depth/boss/label_delta02';S=R/'build/forest_depth/snapshots/guardian_label02';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();r=json.loads((P/'receipt.json').read_text());a=json.loads((R/'build/forest_depth/boss/label_delta01/capture.json').read_text());b=json.loads((P/'capture.json').read_text());assert r['source_stable'] and r['source_before']==r['source_after'] and r['runner_before']==r['runner_after'];assert all(sha(S/p)==h for p,h in r['source_before'].items());assert r['native_exit_code']==0 and r['native_budget_seconds']==45 and r['wall_seconds']<45
for p,h in r['hashes'].items():assert sha(P/p)==h
for f in r['frames']:assert sha(Path(f['path']))==f['sha256']
for p in [P/'native.log',R/'build/forest_depth/boss/label_delta02-import.log']:
 t=p.read_text();assert '4.7.2' in t and not re.search(r'SCRIPT ERROR:|Parse Error:|^ERROR:|ObjectDB.*leaked|resources? still in use at exit',t,re.M)
row=b['comparisons'][0];assert row['initial_boss_hp']==32 and row['boss_hp']==0 and row['player_hp']==5 and row['phase2_overlap_frames']==18
old=(R/'build/forest_depth/snapshots/promotion03/scripts/bosses/forest_boss_duel_presentation_v2.gd').read_text();new=(S/'scripts/bosses/forest_boss_duel_presentation_v2.gd').read_text();assert old[:old.index('func _draw_visible_label')]==new[:new.index('func _draw_visible_label')]
diffs=[]
def walk(x,y,path=''):
 assert type(x)==type(y)
 if isinstance(x,dict):
  assert x.keys()==y.keys()
  for k in x:walk(x[k],y[k],path+'.'+k)
 elif isinstance(x,list):
  assert len(x)==len(y)
  for i,(u,v)in enumerate(zip(x,y)):walk(u,v,path+f'[{i}]')
 elif x!=y:diffs.append({'path':path,'old':x,'new':y})
walk(a,b);assert len(diffs)==440
counts=dict(collections.Counter(x['path'].split('.')[-1]for x in diffs));allowed={'bell_id','owner_id','event_id','attack_id','collider','bell','id','source'};assert set(counts)<=allowed
# Exact complete physical sample dictionaries after excluding Bell object identity only.
assert [{k:v for k,v in f.items()if k!='bell_id'}for f in a['samples']]==[{k:v for k,v in f.items()if k!='bell_id'}for f in b['samples']]
(O/'raw-identity-differences.json').write_text(json.dumps(diffs,indent=2)+'\n')
res={'status':'REVISE_PHASE_LABEL_BELL_OVERLAP_ONLY','source_map_verified':906,'native_capture_strict_pass':True,'cold_import_strict_clean':True,'native_wall':r['wall_seconds'],'original_cap':45,'movie_frames':717,'fps':60,'seconds':11.95,'capture_sha256':sha(P/'capture.json'),'presentation_sha256':sha(S/'scripts/bosses/forest_boss_duel_presentation_v2.gd'),'only_presentation_function_changed':True,'raw_byte_exact':False,'raw_difference_count':len(diffs),'raw_difference_field_counts':counts,'all_complete_physical_samples_equal_except_Bell_instance_id':True,'viewed':'All4whole-time-range sheets73samples plus independently decoded original375/501/585/609. No realtime/audio/device approval.','closed':'375/585 left arena seal no longer masks warning lettering.','remaining':'501 Bell warning outer circles cover right part of II BELL + BODY; need phase-label placement above near-body Bell visual extents, without moving combat geometry.','scope':'Presentation delta only, original01REVISE preserved; wholemechanism/driver not independently re-approved'}
(O/'review.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps(res,indent=2))
