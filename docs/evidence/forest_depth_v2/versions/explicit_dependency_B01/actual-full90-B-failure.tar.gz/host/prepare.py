from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
root=Path.cwd();basis=root/'build/forest_depth/snapshots/version_lifecycle01';dest=root/'build/forest_depth/snapshots/version_dependency_B01';out=root/'build/forest_depth/versions/explicit_dependency_B01';assert not dest.exists()
prior=json.loads((basis/'build/snapshot-receipt.json').read_text());inventory=prior['source_files'];assert all(hashlib.sha256((basis/p).read_bytes()).hexdigest()==h for p,h in inventory.items())
dest.mkdir(parents=True);links={}
for name,sha in inventory.items():
 src=basis/name;dst=dest/name;dst.parent.mkdir(parents=True,exist_ok=True)
 if name.startswith('assets/') and src.suffix.lower() in {'.png','.jpg','.jpeg','.webp','.ogg','.wav','.ttf','.otf','.woff','.woff2'}:
  os.link(src,dst);links[name]={'sealed_basis':str(src),'sha256':sha}
 else:shutil.copyfile(src,dst);shutil.copymode(src,dst)
 assert hashlib.sha256(dst.read_bytes()).hexdigest()==sha
p=dest/'tests/forest_depth_version_runner.gd';s=p.read_text();assert s.count('var tuning := PlayerTuning.load_default()')==1
s=s.replace('const LEGACY :=','const TUNING_SCRIPT := preload("res://scripts/player/player_tuning.gd")\nconst LEGACY :=',1).replace('var tuning := PlayerTuning.load_default()','var tuning := TUNING_SCRIPT.load_default()',1);p.write_text(s)
now={name:hashlib.sha256((dest/name).read_bytes()).hexdigest() for name in inventory};delta=[name for name in inventory if inventory[name]!=now[name]];assert delta==['tests/forest_depth_version_runner.gd']
subprocess.run(['git','init','--quiet',str(dest)],check=True);(dest/'.git/objects/info/alternates').write_text(str(basis/'.git/objects')+'\n');head=prior['base_commit']
if (basis/'.git/shallow').exists():shutil.copyfile(basis/'.git/shallow',dest/'.git/shallow')
subprocess.run(['git','update-ref','--no-deref','HEAD',head],cwd=dest,check=True);subprocess.run(['git','read-tree','HEAD'],cwd=dest,check=True);(dest/'.git/info/exclude').write_text('build/\n.godot/\n')
(dest/'build/verification').mkdir(parents=True)
r={'scope':'Controlled B candidate: same2010 actual frozen source as failed full90 A; only actual tuning dependency declaration/callsite changed. Not current source approval. Independent genuine Git HEAD/index/readonly alternates/cache/userdata; only sealed immutable media hardlinks.','base_commit':head,'source_copy_guard':True,'source_files':now,'source_root':str(basis),'snapshot_root':str(dest),'created':time.time(),'controlled_delta':delta,'baseline_source_files':inventory,'shared_media_links':links}
(dest/'build/snapshot-receipt.json').write_text(json.dumps(r,indent=2)+'\n');(out/'snapshot-receipt.json').write_text(json.dumps(r,indent=2)+'\n')
assert all(hashlib.sha256((basis/name).read_bytes()).hexdigest()==sha for name,sha in inventory.items())
print(json.dumps({'files':len(now),'delta':delta,'baseline_unchanged':True,'snapshot':str(dest)}))
