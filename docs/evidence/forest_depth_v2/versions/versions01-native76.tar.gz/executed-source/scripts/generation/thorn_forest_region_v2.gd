class_name ThornForestRegionV2
extends RefCounted
## Isolated candidate. Semantic graph and coordinates are not a Motor admission.
const VERSION := "thorn-forest-region-v2"
const FAMILIES := ["glade_weave", "root_fold", "three_courts"]
const TRAVERSAL := preload("res://resources/player/traversal.tres")
const DIRECTIONAL := preload("res://scripts/generation/forest_directional_geometry.gd")
const ARENA_FACTORY_PATH := "res://scripts/generation/forest_boss_arena_factory.gd"

static func seed_for(root_seed: String, map_index: int) -> String:
	return root_seed + "/thorn_forest/map_%s" % map_index

func generate(seed_value: String, tuning: PlayerTuning, map_index := 1, capability_snapshot: Dictionary = {}) -> Dictionary:
	var result := generate_spatial_candidate(seed_value, tuning, map_index, capability_snapshot)
	if not bool(result.get("ok", false)): return result
	var manifest: Dictionary = result.manifest
	if not bool(manifest.boss_contract.get("ok", false)):
		result.ok = false
		result.error = "Forest v2 spatial candidate only: " + str(manifest.boss_contract.get("reason", manifest.boss_contract.get("error", "Boss geometry not available")))
	return result

func generate_spatial_candidate(seed_value: String, tuning: PlayerTuning, map_index := 1, capability_snapshot: Dictionary = {}) -> Dictionary:
	if seed_value.is_empty() or tuning == null or map_index not in [1, 2] or not bool(capability_snapshot.get("grapple", false)):
		return {"ok":false, "error":"Forest v2 requires H, tuning, seed and map index 1 or 2"}
	var declared: Variant = capability_snapshot.get("abilities", ["grapple"])
	if not declared is Array or declared.size()!=1 or str(declared[0])!="grapple":
		return {"ok":false,"error":"Forest v2 S2 supports H only; W/D/U1/U2 are forbidden"}
	for forbidden: String in ["wall_climb","double_jump","weapon_evolution_1","weapon_evolution_2"]:
		if bool(capability_snapshot.get(forbidden,false)):
			return {"ok":false,"error":"Forest v2 S2 cannot require or grant "+forbidden}
	var manifest := _candidate(seed_value, map_index)
	if not _validate_structure(manifest, tuning): return {"ok":false, "error":"Forest v2 candidate contract failed"}
	var points: Array[Vector2] = []
	for area: Dictionary in manifest.areas: points.append(_point(area.position))
	return {"ok":true, "manifest":manifest, "stage_generator_version":VERSION,
		"boss_arena":_rect(manifest.boss_arena), "placement_points":points,
		"encounter_plan":{"version":VERSION,"enemies":manifest.enemies.duplicate(true)},"exit_points":[],
		"admission":"isolated_candidate_not_motor_verified", "production_pool":false}

func _candidate(seed_value: String, map_index: int) -> Dictionary:
	var topology := RunRandomStream.new(seed_value, "forest_topology", "map_%s" % map_index, VERSION)
	var content := RunRandomStream.new(seed_value, "forest_ecology", "map_%s" % map_index, VERSION)
	var family: String = FAMILIES[topology.next_int(FAMILIES.size())]
	var choices := {"entry_side":topology.next_int(2), "camp_side":topology.next_int(2),
		"cache_side":topology.next_int(2),"cross_link":topology.next_int(2),"far_return":topology.next_int(2)}
	var m := {"version":VERSION,"region":"thorn_forest","map_index":map_index,"seed":seed_value,
		"family":family,"layout_id":"forest_exploration_graph_v2","fallback_id":"","requires":["grapple"],
		"player_tuning_hash":FileAccess.get_sha256("res://config/player_tuning.json"),
		"traversal_hash":FileAccess.get_sha256("res://resources/player/traversal.tres"),
		"platforms":[],"hook_anchors":[],"areas":[],"connections":[],"rewards":[],"pickups":[],
		"enemies":[],"enemy_drops":{},"dangers":[],"planned_encounters":[],
		"nodes":[{"id":"forest_v2","mirrored":false}],"merchant_id":"root_camp",
		"shop":{"item":"health_blue","price":5,"stock":1},"shot_latch_plan":{"version":1,"latches":[]},
		"terminal_exits":[],"choices":choices,"production_pool":false,
		"admission":{"topology":"candidate","motor":"unverified","directional_golden":"unverified","visual":"unverified"},
		"streams":{"topology":"forest_topology","content":"forest_ecology","reward":"forest_rewards","version":VERSION}}
	var positions := _positions(family)
	var camp_id := "west_heart" if int(choices.camp_side) == 0 else "root_garden"
	m.camp_area = camp_id
	var labels := {"arrival":"ROOT THRESHOLD","lesson":"READ THE INCOMING BRANCH","north_gate":"FIRST VIEW",
		"west_heart":"HOLLOW TRUNK","east_crown":"OUTER BOUGH","root_garden":"ROOT GARDEN",
		"heart_court":"INNER GLADE","cache":"CROSS-BOUGH CACHE","prep":"GUARDIAN LOOKOUT","gate_ready":"BRASS GATE RING"}
	for id: String in positions:
		var role := "junction"
		if id == "arrival" or id == "lesson": role = "tutorial" if map_index == 1 else "review"
		elif id == camp_id: role = "merchant"
		elif id == "cache": role = "challenge_reward"
		elif id in ["prep","gate_ready"]: role = "prep"
		_area(m,id,positions[id],str(labels.get(id,id)),role)
		var width := 420.0 if id in ["west_heart","east_crown","root_garden","heart_court"] else 280.0
		_platform(m,id+"_court",Rect2(positions[id].x-width/2.0,positions[id].y+18,width,28),true)
	m.spawn = _pair(positions.arrival)
	m.merchant_position = _pair(positions[camp_id]+Vector2(25,0))
	_add_edge(m,"learn","arrival","lesson",positions)
	var first := "north_gate" if int(choices.entry_side) == 0 else "root_garden"
	_add_edge(m,"entry_reading","lesson",first,positions)
	_add_edge(m,"entry_retreat",first,"lesson",positions)
	_add_pair(m,"north_west","north_gate","west_heart",positions)
	if family == "glade_weave":
		_add_pair(m,"west_inner","west_heart","heart_court",positions)
		_add_pair(m,"inner_east","heart_court","east_crown",positions)
		_add_pair(m,"east_north","east_crown","north_gate",positions)
		_add_pair(m,"north_root","north_gate","root_garden",positions)
		_add_pair(m,"root_east","root_garden","east_crown",positions)
		_add_pair(m,"weave_cross","west_heart" if int(choices.cross_link)==0 else "heart_court","east_crown" if int(choices.cross_link)==0 else "root_garden",positions)
	elif family == "root_fold":
		_add_pair(m,"west_east","west_heart","east_crown",positions)
		_add_pair(m,"north_root","north_gate","root_garden",positions)
		_add_pair(m,"root_inner","root_garden","heart_court",positions)
		_add_pair(m,"inner_east","heart_court","east_crown",positions)
		_add_pair(m,"fold_cross","west_heart" if int(choices.cross_link)==0 else "root_garden","heart_court" if int(choices.cross_link)==0 else "east_crown",positions)
	else:
		_add_pair(m,"north_root","north_gate","root_garden",positions)
		_add_pair(m,"west_inner","west_heart","heart_court",positions)
		_add_pair(m,"inner_east","heart_court","east_crown",positions)
		_add_pair(m,"east_root","east_crown","root_garden",positions)
		_add_pair(m,"root_west","root_garden","west_heart",positions)
		# The third family has an additional inner approach: a genuinely denser discovery graph.
		_add_pair(m,"court_bypass","north_gate","heart_court",positions)
		_add_pair(m,"court_cross","north_gate" if int(choices.cross_link)==0 else "west_heart","east_crown",positions)
	# Cache is a through-loop with independent entry and different exit, never a tail climb.
	var cache_from := "west_heart" if int(choices.cache_side)==0 else "east_crown"
	var cache_to := "heart_court" if int(choices.cache_side)==0 else "root_garden"
	m.cache_loop = {"entry_area":cache_from,"exit_area":cache_to,"reward_area":"cache"}
	_add_edge(m,"cache_climb",cache_from,"cache",positions)
	_add_edge(m,"cache_return","cache",cache_to,positions)
	_add_edge(m,"cache_abort","cache",cache_from,positions)
	_add_pair(m,"outer_approach","east_crown","prep",positions)
	_add_pair(m,"inner_approach","heart_court","prep",positions)
	var return_to := "west_heart" if int(choices.far_return)==0 else "root_garden"
	_add_edge(m,"far_return","prep",return_to,positions)
	m.far_return_contract = {"edge_id":"far_return","from":"prep","to":return_to,"condition":"open",
		"implementation":"static_independent_hook_transit","future_gate":"not_implemented_no_unlock_claim"}
	# Both approach routes meet before the only required gate-key action.
	_add_edge(m,"crown_approach","prep","gate_ready",positions)
	_install_boss_geometry(m,positions.gate_ready,map_index)
	# Generic transit remains explicitly provisional; specialized H/R geometry is NOT inserted into the live surface list.
	m.directional_candidate = {"factory_version":DIRECTIONAL.VERSION,"factory_path":"res://scripts/generation/forest_directional_geometry.gd",
		"candidate_edge":"weave_cross_out" if family=="glade_weave" else ("fold_cross_out" if family=="root_fold" else "court_cross_out"),
		"status":"pending_golden_and_adapter","inserted_into_platforms":false}
	var camp: Vector2 = positions[camp_id]
	var cache: Vector2 = positions.cache
	m.rewards.append({"id":"crown_cache","area":"cache","tier":"high","position":_pair(cache),"claimed":false,
		"reward_mode":"item_resource","items":["region_health_purple","region_damage_purple"],"coins":18,
		"resources":[{"kind":"coin","amount":18},{"kind":"note","amount":2}],
		"risk":{"depth":3,"platforming":3,"return":1},"action_signature":"candidate_cross_loop_not_motor_verified"})
	m.pickups.append({"id":"camp_heart","kind":"heart","amount":1,"position":_pair(camp+Vector2(-65,-5))})
	m.pickups.append({"id":"crown_note","kind":"note","amount":2,"position":_pair(cache+Vector2(-35,-5))})
	_install_ecology(m,positions,content)
	m.routes = _routes(m)
	m.topology_signature = topology_signature(m)
	m.stream_positions = {"topology":topology.position(),"content":content.position()}
	var bounds := Rect2(_point(m.spawn),Vector2(1,1))
	for row: Dictionary in m.platforms: bounds = bounds.merge(_rect(row.rect))
	for row: Dictionary in m.hook_anchors: bounds = bounds.expand(_point(row.position))
	bounds = bounds.grow(260)
	m.world_bounds = [bounds.position.x,bounds.position.y,bounds.size.x,bounds.size.y]
	# Existing assembler's single gate remains an explicit Boss approach contract, not a generic shortcut system.
	var key_anchor := "crown_approach_ring_0"
	var boss_rect := _rect(m.boss_arena)
	m.vine_gate = {"id":"crown_vine","key_anchor":key_anchor,"rect":[boss_rect.position.x-28,boss_rect.position.y,16.0,maxf(1,boss_rect.size.y+100)]}
	m.manifest_hash = _hash(m)
	return m

func _positions(family: String) -> Dictionary:
	var positions := {"arrival":Vector2(100,582),"lesson":Vector2(380,342),"north_gate":Vector2(660,162),
		"west_heart":Vector2(180,-78),"east_crown":Vector2(1240,-138),"root_garden":Vector2(1060,402),
		"heart_court":Vector2(760,-438),"cache":Vector2(400,-678),"prep":Vector2(1600,-558)}
	if family == "root_fold":
		positions.north_gate=Vector2(580,162);positions.west_heart=Vector2(280,-198)
		positions.east_crown=Vector2(1240,-438);positions.root_garden=Vector2(880,402)
		positions.heart_court=Vector2(980,-78);positions.cache=Vector2(620,-558);positions.prep=Vector2(1660,-678)
	elif family == "three_courts":
		positions.north_gate=Vector2(640,102);positions.west_heart=Vector2(160,-258)
		positions.east_crown=Vector2(1360,-318);positions.root_garden=Vector2(1120,342)
		positions.heart_court=Vector2(800,-618);positions.cache=Vector2(440,-798);positions.prep=Vector2(1720,-558)
	positions.gate_ready=positions.prep+Vector2(140,-85)
	return positions

func _add_pair(m: Dictionary,id: String,a: String,b: String,positions: Dictionary) -> void:
	_add_edge(m,id+"_out",a,b,positions)
	_add_edge(m,id+"_back",b,a,positions)

func _add_edge(m: Dictionary,id: String,a: String,b: String,positions: Dictionary) -> void:
	var start: Vector2 = positions[a]
	var finish: Vector2 = positions[b]
	var delta := finish-start
	var count := maxi(1,int(ceil(maxf(absf(delta.x)/130.0,absf(delta.y)/85.0))))
	var steps: Array[Dictionary] = []
	var current := start
	for index: int in count:
		var landing := start.lerp(finish,float(index+1)/float(count))
		var side := signf(landing.x-current.x)
		if is_zero_approx(side): side = 1.0 if index%2==0 else -1.0
		var anchor := landing+Vector2(side*30,-12)
		var support_id := id+"_branch_%s"%index
		var anchor_id := id+"_ring_%s"%index
		_platform(m,support_id,Rect2(landing.x-90,landing.y+18,180,20),true)
		m.hook_anchors.append({"id":anchor_id,"position":_pair(anchor)})
		steps.append({"takeoff":_pair(current),"landing":_pair(landing),"support_id":support_id,
			"anchor_id":anchor_id,"anchor":_pair(anchor),"phrase":"provisional_short_H_transit",
			"entry":"stable_support","exit":"stable_support","motor_admission":"unverified"})
		current=landing
	m.connections.append({"id":id,"a":a,"b":b,"kind":"hook_steps","condition":"open",
		"path":[_pair(start),_pair(finish)],"steps":steps,"admission":"candidate_not_motor_verified"})

func _install_boss_geometry(m: Dictionary,prep: Vector2,map_index: int) -> void:
	var contract := {"ok":false,"error":"Boss arena factory not materialized","version":"unavailable"}
	if ResourceLoader.exists(ARENA_FACTORY_PATH):
		var factory: RefCounted = load(ARENA_FACTORY_PATH).new()
		contract=factory.call("from_prep",prep,map_index)
	m.boss_contract=contract.duplicate(true)
	# Full world-space factory contract is shared with Stage.boss_position and App.bind_duel.
	# root_supports remain Encounter-owned; do not append them as a second collision surface.
	m.boss_geometry=contract.duplicate(true)
	if not bool(contract.get("ok",false)):
		# Zero-sized sentinel is never admitted by generate/validate. Spatial-only diagnostics may inspect it.
		m.boss_arena=[prep.x,prep.y,0.0,0.0]
		_area(m,"boss",prep,"BOSS CONTRACT BLOCKED","boss")
		return
	m.boss_arena=contract.boss_arena.duplicate()
	m.platforms.append_array(contract.platforms.duplicate(true))
	m.hook_anchors.append_array(contract.hook_anchors.duplicate(true))
	m.boss_root_supports=contract.get("root_supports",[]).duplicate(true)
	var at := _point(contract.get("safe_return",contract.boss_position))
	_area(m,"boss",at,"BRAMBLE WARDEN" if map_index==1 else "THORN QUEEN","boss")
	m.connections.append({"id":"arena_entry","a":"gate_ready","b":"boss","kind":"walk","condition":"open",
		"path":[_pair(prep),_pair(at)],"steps":[],"admission":"factory_contract_pending_motor"})

func _install_ecology(m: Dictionary,positions: Dictionary,content: RunRandomStream) -> void:
	var route_id := "east_north_out" if m.family=="glade_weave" else ("inner_east_out" if m.family=="root_fold" else "east_root_out")
	var edge := _edge(m,route_id)
	if not edge.is_empty():
		var step: Dictionary=edge.steps[mini(1,edge.steps.size()-1)]
		m.enemies.append({"id":"lantern","behavior_id":"forest_lantern","position":_pair(_point(step.anchor)+Vector2(35,-12)),"aerial":true,"patrol_radius":24.0})
	var sentry_id := "east_crown" if int(content.next_int(2))==0 else "heart_court"
	if sentry_id==m.camp_area: sentry_id="east_crown"
	m.enemies.append({"id":"seed_sentry","behavior_id":"forest_seed_sentry","position":_pair(positions[sentry_id]+Vector2(-75,0)),"aerial":false,"patrol_radius":0.0})
	var dropper := EnemyDropService.new()
	dropper.configure(str(m.seed),"thorn_forest/map_%s"%m.map_index)
	for row: Dictionary in m.enemies: m.enemy_drops[row.id]=dropper.settle(StringName(row.id))
	var badger_id := "west_heart" if m.camp_area!="west_heart" else "root_garden"
	var badger_at: Vector2=positions[badger_id]
	var badger_definition := load("res://resources/enemies/forest_branch_badger.tres") as EnemyDefinition
	# Area points are player centres. Place the planned enemy from the actual support top and its own Definition.
	if badger_definition!=null:
		for row: Dictionary in m.platforms:
			if row.id==badger_id+"_court": badger_at.y=_rect(row.rect).position.y-badger_definition.collision_size.y*.5
	m.planned_encounters.append({"id":"branch_badger_candidate","behavior_id":"forest_branch_badger","position":_pair(badger_at),
		"support_id":badger_id+"_court","definition_sha256":FileAccess.get_sha256("res://resources/enemies/forest_branch_badger.tres"),
		"transfer_points":[],"physical_class":"wide_root_420_dual_escape","admission":"planned",
		"blocked_on":["protected_landing_sweep","static_hook_bypass","golden_motor_and_active_encounter"]})
	var spider_at: Vector2=positions.east_crown+Vector2(60,-80)
	m.planned_encounters.append({"id":"thread_spider_candidate","behavior_id":"forest_thread_spider","position":_pair(spider_at),
		"line_start":_pair(spider_at),"line_end":_pair(positions.east_crown+Vector2(-35,0)),
		"receiver_ids":["east_crown_court","heart_court_court"],"observation_area_id":"east_crown",
		"alternative_edge_id":"inner_approach_out","line_geometry_status":"proposal_not_validated",
		"physical_class":"two_ring_bough_pending_sweep","admission":"planned",
		"blocked_on":["second_independent_receiver","line_outside_safe_receiver","normal_camera_preview","golden_motor_and_active_encounter"]})

func _routes(m: Dictionary) -> Dictionary:
	var fast := _route(m,"arrival","gate_ready")
	if not _edge(m,"arena_entry").is_empty(): fast.append("arena_entry")
	var growth := _route(m,"arrival","root_garden")
	growth.append_array(_route(m,"root_garden",str(m.camp_area)))
	growth.append_array(_route(m,str(m.camp_area),"gate_ready"))
	if not _edge(m,"arena_entry").is_empty(): growth.append("arena_entry")
	var high := _route(m,"arrival",str(m.cache_loop.entry_area))
	high.append("cache_climb")
	high.append("cache_return")
	high.append_array(_route(m,str(m.cache_loop.exit_area),str(m.camp_area)))
	high.append_array(_route(m,str(m.camp_area),"north_gate"))
	return {"fast":fast,"growth":growth,"high_return":high}

static func _route(m: Dictionary,start: String,goal: String) -> Array[String]:
	if start==goal: return []
	var queue: Array[String]=[start]
	var visited: Dictionary={start:true}
	var parent: Dictionary={}
	var via: Dictionary={}
	while not queue.is_empty():
		var node: String=queue.pop_front()
		for edge: Dictionary in m.connections:
			if edge.a!=node or edge.b=="cache" or edge.id=="cache_abort" or visited.has(edge.b): continue
			visited[edge.b]=true;parent[edge.b]=node;via[edge.b]=str(edge.id)
			if edge.b==goal:
				var result: Array[String]=[]
				var current := goal
				while current!=start:
					result.push_front(via[current]);current=parent[current]
				return result
			queue.append(edge.b)
	return []

static func _edge(m: Dictionary,id: String) -> Dictionary:
	for edge: Dictionary in m.connections:
		if edge.id==id: return edge
	return {}

static func topology_signature(m: Dictionary) -> String:
	var edges: Array[String]=[]
	for edge: Dictionary in m.connections:
		if edge.id=="arena_entry": continue
		edges.append(str(edge.a)+">"+str(edge.b)+":"+str(edge.condition))
	edges.sort()
	return "|".join(edges)+";camp="+str(m.camp_area)

func validate(m: Dictionary,tuning: PlayerTuning) -> bool:
	if not validate_spatial_candidate(m,tuning): return false
	return bool(m.boss_contract.get("ok",false))

func validate_spatial_candidate(m: Dictionary,tuning: PlayerTuning) -> bool:
	if not _validate_structure(m,tuning): return false
	return RandomStageGenerator.new()._same_data(m,_candidate(str(m.seed),int(m.map_index)))

func _validate_structure(m: Dictionary,tuning: PlayerTuning) -> bool:
	if tuning==null or m.get("version")!=VERSION or m.get("region")!="thorn_forest" or not m.get("seed") is String or str(m.seed).is_empty(): return false
	var map_number: Variant=m.get("map_index")
	if not (map_number is int or map_number is float) or not is_finite(float(map_number)) or float(map_number)!=float(int(map_number)) or int(map_number) not in [1,2]: return false
	if m.get("player_tuning_hash")!=FileAccess.get_sha256("res://config/player_tuning.json") or m.get("traversal_hash")!=FileAccess.get_sha256("res://resources/player/traversal.tres"): return false
	if m.get("manifest_hash")!=_hash(m) or m.get("requires")!=["grapple"] or m.get("production_pool")!=false: return false
	# Check complete seed equality before nested access; malicious replay data must fail cleanly.
	if not RandomStageGenerator.new()._same_data(m,_candidate(str(m.seed),int(map_number))): return false
	var platform_ids: Dictionary={}
	for platform: Dictionary in m.platforms:
		if platform_ids.has(platform.id) or platform.rect.size()!=4 or not _rect(platform.rect).has_area(): return false
		platform_ids[platform.id]=true
	var anchors: Dictionary={}
	for anchor: Dictionary in m.hook_anchors:
		if anchors.has(anchor.id): return false
		anchors[anchor.id]=anchor.position
	for edge: Dictionary in m.connections:
		for step: Dictionary in edge.steps:
			if not platform_ids.has(step.support_id) or anchors.get(step.anchor_id,[])!=step.anchor: return false
			if (_point(step.takeoff)+Vector2(0,-6)).distance_to(_point(step.anchor))>TRAVERSAL.hook_range-4: return false
	for name: String in ["fast","growth","high_return"]:
		var current := "arrival"
		for id: String in m.routes[name]:
			var edge := _edge(m,id)
			if edge.is_empty() or edge.a!=current: return false
			current=str(edge.b)
		if current!=("north_gate" if name=="high_return" else ("boss" if bool(m.boss_contract.get("ok",false)) else "gate_ready")): return false
	return true

static func _area(m: Dictionary,id: String,position: Vector2,label: String,role: String) -> void:
	m.areas.append({"id":id,"position":_pair(position),"label":label,"role":role})
static func _platform(m: Dictionary,id: String,rect: Rect2,one_way: bool) -> void:
	m.platforms.append({"id":id,"rect":[rect.position.x,rect.position.y,rect.size.x,rect.size.y],"one_way":one_way})
static func _point(value: Array) -> Vector2: return Vector2(value[0],value[1])
static func _pair(value: Vector2) -> Array: return [value.x,value.y]
static func _rect(value: Array) -> Rect2: return Rect2(value[0],value[1],value[2],value[3])
static func _hash(m: Dictionary) -> String:
	var value := m.duplicate(true)
	value.erase("manifest_hash")
	return JSON.stringify(JSON.parse_string(JSON.stringify(value,"",true)),"",true).sha256_text()
