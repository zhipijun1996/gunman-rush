class_name ForestBossArenaFactory
extends RefCounted
const VERSION := "forest-boss-duel-golden-v2"
func from_prep(prep: Vector2, map_index: int, definition: BossDuelDefinition = null) -> Dictionary:
	if map_index != 1: return {"ok":false,"version":VERSION,"reason":"Queen mechanic not promoted"}
	var config := definition
	if config == null: config = load("res://resources/bosses/rootbell_guardian_v2.tres") as BossDuelDefinition
	if config == null or not config.is_valid() or not prep.is_finite(): return {"ok":false,"version":VERSION,"reason":"Invalid guardian definition/prep"}
	var left := prep.x + config.entrance_gap
	var floor_y := prep.y + config.player_half_height
	var center := Vector2(left + config.arena_size.x*.5,floor_y)
	var arena := Rect2(Vector2(left,floor_y-config.arena_size.y),config.arena_size)
	var entry := {"id":"boss_entry","rect":[prep.x-config.entrance_overlap,floor_y,config.entrance_overlap+config.entrance_gap+config.safe_inset,config.floor_depth],"one_way":false}
	var platforms: Array[Dictionary] = [entry]
	platforms.append(_platform("boss_floor",Rect2(Vector2(left,floor_y),Vector2(config.arena_size.x,config.floor_depth)),false))
	platforms.append(_platform("counter_branch",Rect2(center+config.counter_offset-Vector2(config.counter_size.x*.5,0),config.counter_size),true))
	var roots: Array[Dictionary] = []
	var hooks: Array[Dictionary] = []
	var stands: Array = []
	for side: int in [-1,1]:
		var tag := "left" if side < 0 else "right"
		var root_rect := Rect2(center+Vector2(config.root_offset.x*side,config.root_offset.y)-Vector2(config.root_size.x*.5,0),config.root_size)
		roots.append({"id":"root_"+tag,"rect":_rect(root_rect),"perch_id":"root_"+tag,"side":side})
		for kind: String in ["inner","return"]:
			var offset := config.inner_hook_offset if kind == "inner" else config.return_hook_offset
			hooks.append({"id":kind+"_"+tag,"position":_point(center+Vector2(offset.x*side,offset.y))})
		stands.append(_point(center+Vector2(config.counter_stand_offset.x*side,config.counter_stand_offset.y)))
	return {"ok":true,"version":VERSION,"boss_contract":"guardian-golden-only","boss_arena":_rect(arena),"platforms":platforms,"entrance_connector":entry,"entrance_position":_point(Vector2(left+config.safe_inset,floor_y-config.player_half_height)),"root_supports":roots,"hook_anchors":hooks,"counter_stands":stands,"boss_position":_point(center+config.boss_offset),"safe_return":_point(Vector2(left+config.safe_inset,floor_y-config.player_half_height)),"arena_center":_point(center)}
func _platform(id: String, rect: Rect2, one_way: bool) -> Dictionary:
	return {"id":id,"rect":_rect(rect),"one_way":one_way}
func _point(point: Vector2) -> Array: return [point.x,point.y]
func _rect(rect: Rect2) -> Array: return [rect.position.x,rect.position.y,rect.size.x,rect.size.y]
