from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
root=Path.cwd();basis=root/'build/forest_depth/snapshots/version_lifecycle01';dest=root/'build/forest_depth/snapshots/version_node_helper01';out=root/'build/forest_depth/versions/node_helper01';assert not dest.exists()
prior=json.loads((basis/'build/snapshot-receipt.json').read_text());inventory=prior['source_files'];assert all(hashlib.sha256((basis/p).read_bytes()).hexdigest()==h for p,h in inventory.items())
dest.mkdir(parents=True);links={}
for name,sha in inventory.items():
 src=basis/name;dst=dest/name;dst.parent.mkdir(parents=True,exist_ok=True)
 if name.startswith('assets/') and src.suffix.lower() in {'.png','.jpg','.jpeg','.webp','.ogg','.wav','.ttf','.otf','.woff','.woff2'}:
  os.link(src,dst);links[name]={'sealed_basis':str(src),'sha256':sha}
 else:shutil.copyfile(src,dst);shutil.copymode(src,dst)
 assert hashlib.sha256(dst.read_bytes()).hexdigest()==sha
for file in ['forest_depth_version_runner.gd','forest_depth_version_app_case.gd']:
 (dest/'tests'/file).write_bytes((out/file).read_bytes())
now={name:hashlib.sha256((dest/name).read_bytes()).hexdigest() for name in inventory}
now['tests/forest_depth_version_app_case.gd']=hashlib.sha256((dest/'tests/forest_depth_version_app_case.gd').read_bytes()).hexdigest()
delta=[name for name in now if inventory.get(name)!=now[name]]
assert set(delta)=={'tests/forest_depth_version_runner.gd','tests/forest_depth_version_app_case.gd'}
subprocess.run(['git','init','--quiet',str(dest)],check=True);(dest/'.git/objects/info/alternates').write_text(str(basis/'.git/objects')+'\n');head=prior['base_commit']
if (basis/'.git/shallow').exists():shutil.copyfile(basis/'.git/shallow',dest/'.git/shallow')
subprocess.run(['git','update-ref','--no-deref','HEAD',head],cwd=dest,check=True);subprocess.run(['git','read-tree','HEAD'],cwd=dest,check=True);(dest/'.git/info/exclude').write_text('build/\n.godot/\n')
(dest/'build/verification').mkdir(parents=True)
r={'scope':'Controlled Nodehelper test candidate: same2010 original runtime except extracted runner and NEW actual Appcase Node helper. Original App bodies exactly reconstruct. Not current source approval. Independent genuine Git HEAD/index/readonly alternates/cache/userdata; only sealed immutable media hardlinks.','base_commit':head,'source_copy_guard':True,'source_files':now,'source_root':str(basis),'snapshot_root':str(dest),'created':time.time(),'controlled_delta':delta,'baseline_source_files':inventory,'shared_media_links':links}
(dest/'build/snapshot-receipt.json').write_text(json.dumps(r,indent=2)+'\n');(out/'snapshot-receipt.json').write_text(json.dumps(r,indent=2)+'\n')
assert all(hashlib.sha256((basis/name).read_bytes()).hexdigest()==sha for name,sha in inventory.items())
print(json.dumps({'files':len(now),'delta':delta,'baseline_unchanged':True,'snapshot':str(dest)}))
