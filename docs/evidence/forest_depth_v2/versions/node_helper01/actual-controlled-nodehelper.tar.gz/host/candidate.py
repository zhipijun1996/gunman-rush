from pathlib import Path
import difflib,hashlib,json
root=Path.cwd();basis=root/'build/forest_depth/snapshots/version_lifecycle01';out=root/'build/forest_depth/versions/node_helper01'
original=(basis/'tests/forest_depth_version_runner.gd').read_text();start=original.index('func app_case(map_index: int) -> void:');old_app=original[start:]
helper='''extends Node
## Actual original legacy App cases, owned only by the version test runner.
const AUDIO := preload("res://tests/audio_teardown.gd")
var reporter: WeakRef
var legacy_version: String
func check(ok: bool, label: String) -> void:
	reporter.get_ref().check(ok,label)
func frames(count: int) -> void:
	for index: int in count:
		await get_tree().physics_frame
		await get_tree().process_frame
'''+old_app.replace('func app_case(map_index: int) -> void:','func run(map_index: int) -> void:',1).replace('root.add_child(app)','get_tree().root.add_child(app)').replace('LEGACY.VERSION','legacy_version').replace('cases.append(identity)','reporter.get_ref().cases.append(identity)')
proxy='''func app_case(map_index: int) -> void:
	# Dynamic actual Node consumer avoids compiling App's typed graph into this
	# generator runner. All original checks/cases are forwarded by the helper.
	var helper: Node=load("res://tests/forest_depth_version_app_case.gd").new()
	helper.reporter=weakref(self)
	helper.legacy_version=LEGACY.VERSION
	root.add_child(helper)
	await helper.run(map_index)
	helper.free()
'''
new=original[:start].replace('const AUDIO := preload("res://tests/audio_teardown.gd")\n','')+proxy
# Source-level equivalence proof for the extracted complete App bodies.
recovered=helper[helper.index('func run(map_index: int) -> void:'):].replace('func run(map_index: int) -> void:','func app_case(map_index: int) -> void:',1).replace('get_tree().root.add_child(app)','root.add_child(app)').replace('legacy_version','LEGACY.VERSION').replace('reporter.get_ref().cases.append(identity)','cases.append(identity)')
assert recovered==old_app
(out/'forest_depth_version_runner.gd').write_text(new);(out/'forest_depth_version_app_case.gd').write_text(helper)
(out/'candidate.diff').write_text(''.join(difflib.unified_diff(original.splitlines(True),new.splitlines(True),fromfile='original/tests/forest_depth_version_runner.gd',tofile='candidate/tests/forest_depth_version_runner.gd')))
(out/'source-contract.json').write_text(json.dumps({'scope':'Unexecuted controlled test architecture candidate. No production source changes. Original App bodies mechanically extracted, exact reconstructed source equals original. Helpers use actual Node lifecycle/real App; dynamic load boundary, no helper preload in runner.','original_sha256':hashlib.sha256(original.encode()).hexdigest(),'exact_reconstructed_App_methods_equal':True,'original_check_calls':original.count('check('),'retained_check_calls_combined':new.count('check(')+helper.count('check(')-1,'files':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [out/'forest_depth_version_runner.gd',out/'forest_depth_version_app_case.gd']}},indent=2)+'\n')
