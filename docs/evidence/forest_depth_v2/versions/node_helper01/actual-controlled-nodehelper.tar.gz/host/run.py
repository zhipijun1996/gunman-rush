from pathlib import Path
import contextlib,fcntl,hashlib,json,os,subprocess,sys,time
root=Path('/workspace/gunman-rush-design');snap=root/'build/forest_depth/snapshots/version_node_helper01';out=root/'build/forest_depth/versions/node_helper01';native=snap/'build/forest_depth/versions/node_helper01';native.mkdir(parents=True,exist_ok=False)
# Identical load-only probe body to actual failing static_dependency01 control.
baseline=root/'build/forest_depth/snapshots/version_lifecycle01/build/forest_depth/versions/static_dependency01/load_full.gd';probe=native/'load_only.gd';probe.write_bytes(baseline.read_bytes());probe_sha=hashlib.sha256(probe.read_bytes()).hexdigest()
os.chdir(snap);sys.path.insert(0,str(snap/'tools'));os.environ.update(GUNMAN_TOOLCHAIN_ROOT='/workspace/toolchains',GUNMAN_DATA_HOME=str(snap/'build/user-data'),XDG_CONFIG_HOME=str(snap/'build/user-config'),XDG_CACHE_HOME=str(snap/'build/user-cache'),PYTHONDONTWRITEBYTECODE='1')
from run_tests import run_engine
import level_formal
before=level_formal.source_files();snapshot=json.loads((snap/'build/snapshot-receipt.json').read_text());start=time.monotonic();receipt={'scope':'Controlled test Nodehelper dependency graph; no production changes. Only if exact new load-only graph exits clean run one original complete90 wrapper. Original load-only and all failure evidence retained.','static_passed':False,'full_wrapper_exit_code':None,'source_before':before,'probe_sha256':probe_sha,'original_load_only_probe_identical':probe.read_bytes()==baseline.read_bytes()}
with (root/'build/verification/engine.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);print('acquired global engine for load-only then conditional full90',flush=True)
 try:
  with (native/'import.log').open('w') as log,contextlib.redirect_stdout(log):run_engine(['--headless','--path','.','--editor','--quit'],90)
  argv=['--verbose','--headless','--fixed-fps','60','--path','.','--script','build/forest_depth/versions/node_helper01/load_only.gd','--','--output=res://build/forest_depth/versions/node_helper01/load_only.json'];receipt['static_argv']=argv
  with (native/'load_only.log').open('w') as log,contextlib.redirect_stdout(log):run_engine(argv,30)
  data=json.loads((native/'load_only.json').read_text());assert data['loaded_full_script'] and data['loaded_full_sha256']==snapshot['source_files']['tests/forest_depth_version_runner.gd']
  receipt['static_passed']=True
  argv=[sys.executable,'tools/run_forest_depth_versions.py','--verbose','--output-dir','build/forest_depth/versions/node_helper_full01'];receipt['full_argv']=argv
  with (native/'full_outer.log').open('w') as log:result=subprocess.run(argv,cwd=snap,stdout=log,stderr=subprocess.STDOUT)
  receipt['full_wrapper_exit_code']=result.returncode
  if result.returncode==0:
   full=json.loads((snap/'build/forest_depth/versions/node_helper_full01/capture.json').read_text())
   original=json.loads((root/'build/forest_depth/snapshots/version_lifecycle01/build/forest_depth/versions/lifecycle01/capture.json').read_text())
   receipt['all90_checks_exact_original']=full['assertions']==90 and full['failures']==0 and full['checks']==original['checks']
   receipt['all11_case_data_exact_original']=full['cases']==original['cases']
   assert receipt['all90_checks_exact_original'] and receipt['all11_case_data_exact_original'],'Helper changed original functional observations'
 except Exception as error:receipt['exception']=type(error).__name__+': '+str(error)
 finally:
  receipt['source_after']=level_formal.source_files();receipt['source_guard']=before==receipt['source_after'];receipt['all_snapshot_raw_bytes_unchanged']=all(hashlib.sha256((snap/p).read_bytes()).hexdigest()==sha for p,sha in snapshot['source_files'].items());receipt['probe_guard']=hashlib.sha256(probe.read_bytes()).hexdigest()==probe_sha;receipt['elapsed_seconds']=time.monotonic()-start
  (out/'host-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print('engine released nodehelper candidate',flush=True)
assert receipt['source_guard'] and receipt['all_snapshot_raw_bytes_unchanged'] and receipt['probe_guard']
sys.exit(0 if receipt['static_passed'] and receipt['full_wrapper_exit_code']==0 else 1)
