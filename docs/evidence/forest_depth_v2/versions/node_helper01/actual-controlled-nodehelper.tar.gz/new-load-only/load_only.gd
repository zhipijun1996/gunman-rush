extends SceneTree
var observation: Dictionary={"scope":"load existing full runner only; never instantiate it or execute its run/App functions"}
func _initialize() -> void: run.call_deferred()
func run() -> void:
 var script: Script=load("res://tests/forest_depth_version_runner.gd")
 observation["loaded_full_script"]=script!=null and script.can_instantiate()
 observation["loaded_full_sha256"]=FileAccess.get_sha256("res://tests/forest_depth_version_runner.gd")
 script=null
 finish.call_deferred()
func finish() -> void:
 var output := ""
 for argument: String in OS.get_cmdline_user_args():
  if argument.begins_with("--output="): output=argument.trim_prefix("--output=")
 var file:=FileAccess.open(output,FileAccess.WRITE)
 file.store_string(JSON.stringify(observation,"\t"))
 file.close()
 file=null
 print("STATIC DEPENDENCY LOAD PROBE: complete")
 quit(0 if observation.loaded_full_script else 1)
