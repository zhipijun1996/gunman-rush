from pathlib import Path
import hashlib,json
root=Path.cwd();snap=root/'build/forest_depth/snapshots/version_lifecycle01';out=root/'build/forest_depth/versions/app_branch_diagnosis01';native=snap/'build/forest_depth/versions/app_branch_diagnosis01';native.mkdir(parents=True,exist_ok=False)
original=snap/'tests/forest_depth_version_runner.gd';s=original.read_text();s=s.replace('var exit_observations: Dictionary = {}','var exit_observations: Dictionary = {}\nvar diagnostic_selector := ""')
s=s.replace('func run() -> void:\n\tvar registry', '''func run() -> void:
	for argument: String in OS.get_cmdline_user_args():
		if argument.begins_with("--diagnostic="): diagnostic_selector=argument.trim_prefix("--diagnostic=")
	if diagnostic_selector not in ["", "generation", "app1", "app2"]:
		push_error("Unsupported version diagnostic selector")
		quit(2)
		return
	if diagnostic_selector in ["app1", "app2"]:
		await app_case(1 if diagnostic_selector=="app1" else 2)
		deferred_finish.call_deferred()
		return
	var registry''')
s=s.replace('\tfor map_index: int in [1,2]:\n\t\tawait app_case(map_index)', '\tif diagnostic_selector!="generation":\n\t\tfor map_index: int in [1,2]:\n\t\t\tawait app_case(map_index)')
s=s.replace('"exit_lifecycle":exit_observations}', '"exit_lifecycle":exit_observations,"diagnostic_selector":diagnostic_selector,"full_version_check":diagnostic_selector==""}')
s=s.replace('\tprint("FOREST DEPTH VERSIONS: %s assertions, %s failures" % [assertions,failures])', '\tif diagnostic_selector=="": print("FOREST DEPTH VERSIONS: %s assertions, %s failures" % [assertions,failures])\n\telse: print("FOREST VERSION DIAGNOSTIC %s: %s assertions, %s failures" % [diagnostic_selector,assertions,failures])')
p=native/'diagnostic.gd';p.write_text(s)
(out/'source.json').write_text(json.dumps({'scope':'Build-only selector on exact failing full runner; default full90 path unchanged, selectors explicitly not full approval. No production changes.','original_script':str(original.relative_to(snap)),'original_sha256':hashlib.sha256(original.read_bytes()).hexdigest(),'diagnostic_script':str(p.relative_to(snap)),'diagnostic_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'selectors':{'generation':'original full generation/delegate equality+experimentalQueen data, no App','app2':'only original app_case2, no hash fallback reload','app1':'only original app_case1, including actual hash fallback reload'},'per_selector_seconds':30,'cold_import_seconds':90},indent=2)+'\n')
