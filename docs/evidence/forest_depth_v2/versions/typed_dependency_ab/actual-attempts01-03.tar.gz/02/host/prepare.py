from pathlib import Path
import hashlib,json
root=Path.cwd();snap=root/'build/forest_depth/snapshots/version_lifecycle01';dest=snap/'build/forest_depth/versions/typed_dependency_ab02';dest.mkdir(parents=True,exist_ok=False)
body='''
var observations: Dictionary={}
var refs: Dictionary={}
func _initialize() -> void: run.call_deferred()
func run() -> void:
 var tuning := PlayerTuning.load_default()
 var old := LEGACY.new()
 var registry := ThornForestRegionGenerator.new()
 var equality := RandomStageGenerator.new()
 var direct: Dictionary=old.generate("typed-dependency-probe",tuning,1,{"grapple":true})
 var delegated: Dictionary=registry.generate("typed-dependency-probe",tuning,1,{"grapple":true})
 observations["real_generated_equal"]=direct.ok and delegated.ok and equality._same_data(direct,delegated)
 observations["tuning_script_id"]=tuning.get_script().get_instance_id()
 var explicit_script: Script=TUNING
 observations["explicit_script_id"]=explicit_script.get_instance_id()
 observations["same_script_identity"]=tuning.get_script()==TUNING
 refs={"tuning":weakref(tuning),"legacy":weakref(old),"registry":weakref(registry),"equality":weakref(equality),"tuning_script":weakref(tuning.get_script())}
 for label: String in refs: observations[label]={"before_alive":is_instance_valid((refs[label] as WeakRef).get_ref())}
 explicit_script=null
 tuning=null
 old=null
 registry=null
 equality=null
 finish.call_deferred()
func finish() -> void:
 for label: String in refs: observations[label]["after_return_alive"]=is_instance_valid((refs[label] as WeakRef).get_ref())
 var output := ""
 for arg: String in OS.get_cmdline_user_args():
  if arg.begins_with("--output="): output=arg.trim_prefix("--output=")
 var file:=FileAccess.open(output,FileAccess.WRITE)
 file.store_string(JSON.stringify(observations,"\\t"))
 file.close()
 file=null
 print("TYPED DEPENDENCY PROBE: complete")
 quit(0 if observations.real_generated_equal else 1)
'''
constants={'A':['const LEGACY := preload("res://scripts/generation/thorn_forest_region_v1.gd")','const TUNING := preload("res://scripts/player/player_tuning.gd")'],'B':['const TUNING := preload("res://scripts/player/player_tuning.gd")','const LEGACY := preload("res://scripts/generation/thorn_forest_region_v1.gd")']}
files={}
for label,lines in constants.items():
 p=dest/(label+'.gd');p.write_text('extends SceneTree\n'+'\n'.join(lines)+'\n'+body);files[str(p.relative_to(snap))]=hashlib.sha256(p.read_bytes()).hexdigest()
(root/'build/forest_depth/versions/typed_dependency_ab02/probe-source.json').write_text(json.dumps({'hypothesis':'Only preload order differs. Both exercise real legacy/delegate data equality and identical local-release lifecycle. Diagnostic, not replacement of full version consumer.','snapshot':str(snap),'files':files,'body_sha256':hashlib.sha256(body.encode()).hexdigest()},indent=2)+'\n')
