from pathlib import Path
import contextlib,fcntl,hashlib,json,os,sys,time
root=Path('/workspace/gunman-rush-design');snap=root/'build/forest_depth/snapshots/version_lifecycle01';out=root/'build/forest_depth/versions/typed_dependency_ab03';native=snap/'build/forest_depth/versions/typed_dependency_ab03'
os.chdir(snap);sys.path.insert(0,str(snap/'tools'))
os.environ.update(GUNMAN_TOOLCHAIN_ROOT='/workspace/toolchains',GUNMAN_DATA_HOME=str(snap/'build/user-data'),XDG_CONFIG_HOME=str(snap/'build/user-config'),XDG_CACHE_HOME=str(snap/'build/user-cache'),PYTHONDONTWRITEBYTECODE='1')
from run_tests import run_engine
import level_formal
before=level_formal.source_files();original=json.loads((snap/'build/snapshot-receipt.json').read_text());probes=json.loads((out/'probe-source.json').read_text());results=[];start=time.monotonic()
with (root/'build/verification/engine.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);print('acquired engine for ONE A/B',flush=True)
 try:
  with (native/'import.log').open('w') as log,contextlib.redirect_stdout(log):
   run_engine(['--headless','--path','.','--editor','--quit'],90)
  for case in ['A','B']:
   argv=['--verbose','--headless','--fixed-fps','60','--path','.','--script',f'build/forest_depth/versions/typed_dependency_ab03/{case}.gd','--',f'--output=res://build/forest_depth/versions/typed_dependency_ab03/{case}.json']
   row={'case':case,'argv':argv,'native_cap_seconds':30};tick=time.monotonic()
   try:
    with (native/(case+'.log')).open('w') as log,contextlib.redirect_stdout(log):run_engine(argv,30)
    row['strict_passed']=True
   except Exception as error:row.update(strict_passed=False,exception=type(error).__name__+': '+str(error))
   row['elapsed_seconds']=time.monotonic()-tick
   if (native/(case+'.json')).exists():row['observations']=json.loads((native/(case+'.json')).read_text())
   results.append(row)
 finally:
  receipt={'scope':'ONE minimal preload-order A/B diagnostic, not full version check. No production changes or error filtering.', 'results':results,'elapsed_seconds':time.monotonic()-start,'source_guard':before==level_formal.source_files(),'all_original_snapshot_source_bytes_unchanged':all(hashlib.sha256((snap/p).read_bytes()).hexdigest()==sha for p,sha in original['source_files'].items()),'probe_source_guard':all(hashlib.sha256((snap/p).read_bytes()).hexdigest()==sha for p,sha in probes['files'].items()),'cold_import_cap_seconds':90,'native_files':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in native.iterdir() if p.is_file()}}
  (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print('released engine ONE A/B',flush=True)
assert receipt['source_guard'] and receipt['all_original_snapshot_source_bytes_unchanged'] and receipt['probe_source_guard']
