extends SceneTree
const TUNING := preload("res://scripts/player/player_tuning.gd")
const LEGACY := preload("res://scripts/generation/thorn_forest_region_v1.gd")

var observations: Dictionary={}
var refs: Dictionary={}
func _initialize() -> void: run.call_deferred()
func run() -> void:
 var tuning := PlayerTuning.load_default()
 var old := LEGACY.new()
 var registry := ThornForestRegionGenerator.new()
 var equality := RandomStageGenerator.new()
 var direct: Dictionary=old.generate("typed-dependency-probe",tuning,1,{"grapple":true})
 var delegated: Dictionary=registry.generate("typed-dependency-probe",tuning,1,{"grapple":true})
 observations["real_generated_equal"]=direct.ok and delegated.ok and equality._same_data(direct,delegated)
 observations["tuning_script_id"]=tuning.get_script().get_instance_id()
 observations["explicit_script_id"]=TUNING.get_instance_id()
 observations["same_script_identity"]=tuning.get_script()==TUNING
 refs={"tuning":weakref(tuning),"legacy":weakref(old),"registry":weakref(registry),"equality":weakref(equality),"tuning_script":weakref(tuning.get_script())}
 for label: String in refs: observations[label]={"before_alive":is_instance_valid((refs[label] as WeakRef).get_ref())}
 tuning=null
 old=null
 registry=null
 equality=null
 finish.call_deferred()
func finish() -> void:
 for label: String in refs: observations[label]["after_return_alive"]=is_instance_valid((refs[label] as WeakRef).get_ref())
 var output := ""
 for arg: String in OS.get_cmdline_user_args():
  if arg.begins_with("--output="): output=arg.trim_prefix("--output=")
 var file:=FileAccess.open(output,FileAccess.WRITE)
 file.store_string(JSON.stringify(observations,"\t"))
 file.close()
 file=null
 print("TYPED DEPENDENCY PROBE: complete")
 quit(0 if observations.real_generated_equal else 1)
