from pathlib import Path
import fcntl,hashlib,json,os,subprocess,sys,time
root=Path('/workspace/gunman-rush-design');snap=root/'build/forest_depth/snapshots/version_lifecycle01';out=root/'build/forest_depth/versions/lifecycle_hypothesis01'
env=os.environ.copy();env.update(GUNMAN_TOOLCHAIN_ROOT='/workspace/toolchains',GUNMAN_DATA_HOME=str(snap/'build/user-data'),XDG_CONFIG_HOME=str(snap/'build/user-config'),XDG_CACHE_HOME=str(snap/'build/user-cache'),PYTHONDONTWRITEBYTECODE='1')
argv=[sys.executable,'tools/run_forest_depth_versions.py','--verbose','--output-dir','build/forest_depth/versions/lifecycle01']
started=time.monotonic();code=2
with (root/'build/verification/engine.lock').open('a') as lock:
 # Fail immediately if the promised engine handoff was inaccurate; no background queue.
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);print('acquired global engine lock',flush=True)
 try:
  code=subprocess.run(argv,cwd=snap,env=env).returncode
 finally:
  original=json.loads((snap/'build/snapshot-receipt.json').read_text())
  unchanged=all((snap/p).is_file() and hashlib.sha256((snap/p).read_bytes()).hexdigest()==sha for p,sha in original['source_files'].items())
  receipt={'scope':'ONE bounded version runner-local lifecycle hypothesis; strict verbose native90/import90, no sleep/retry/production fix; not v2 gameplay admission','argv':argv,'cwd':str(snap),'exit_code':code,'all_snapshot_raw_bytes_unchanged':unchanged,'copy_guard':original['source_copy_guard'],'elapsed_seconds':time.monotonic()-started}
  (out/'host-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print('engine lock released',flush=True)
 if not unchanged:sys.exit(2)
sys.exit(code)
