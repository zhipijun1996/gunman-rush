from pathlib import Path
import os,json,subprocess,time,hashlib
R=Path('/workspace/gunman-rush-design');S=R/'build/forest_depth/snapshots/cavity_matrix01';O=R/'build/forest_depth/traversal/cavity_matrix01'
env={**os.environ,'GUNMAN_TOOLCHAIN_ROOT':'/workspace/toolchains','GUNMAN_DATA_HOME':str(S/'build/userdata'),'XDG_CONFIG_HOME':str(S/'build/userconfig'),'XDG_CACHE_HOME':str(S/'build/usercache')}
argv=['python3','tools/run_forest_depth_region.py','--matrix','--output','build/forest_depth/region/matrix01']
r={'scope':'Fresh current-at-copy no-C candidate original16 representative routes; not Boss/fullrelease or final clean source commit. Original import90 and native240 each; first failure stops. Prior borer seams have separate sources.','snapshot':str(S),'snapshot_receipt_sha256':hashlib.sha256((S/'build/snapshot-receipt.json').read_bytes()).hexdigest(),'argv':argv,'outer_cap_seconds':4000,'status':'running'}
def save():(O/'outer-receipt.json').write_text(json.dumps(r,indent=2)+'\n')
save();start=time.monotonic()
try:
 with (O/'outer.log').open('w') as log:
  p=subprocess.run(argv,cwd=S,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=4000)
 r['exit_code']=p.returncode;r['status']='passed' if p.returncode==0 else 'failed'
except subprocess.TimeoutExpired:r['timed_out']=True;r['status']='timeout'
finally:
 r['seconds']=time.monotonic()-start
 r['all_original_snapshot_sources_unchanged']=all((S/k).is_file()and hashlib.sha256((S/k).read_bytes()).hexdigest()==v for k,v in json.loads((S/'build/snapshot-receipt.json').read_text())['source_files'].items());save()
raise SystemExit(0 if r['status']=='passed'and r['all_original_snapshot_sources_unchanged']else 1)
