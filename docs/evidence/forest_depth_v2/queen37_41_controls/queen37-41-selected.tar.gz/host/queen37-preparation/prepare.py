from pathlib import Path
import hashlib,json,ast
root=Path('/workspace/gunman-rush-design');snap=root/'build/forest_depth/snapshots/queen37-crossline-A'
p=snap/'scripts/bosses/thorn_queen_weave_definition.gd';old=p.read_bytes();s=old.decode()
a='Vector2(200,570)]';b='Vector2(200,450)]'
c='Vector2(888,585)]';d='Vector2(888,465)]'
assert s.count(a)==1 and s.count(c)==1
s=s.replace(a,b).replace(c,d);p.write_text(s)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
receipt={'task':'FOREST-DEPTH-02-QUEEN37','base_commit':'9fdf7fad08550ea0da46b59ef7126fa721571f28','scope':'Build-only A third crossline; main unchanged; original S old failure retained; not promotion','production_overlay':{'path':str(p.relative_to(snap)),'before':hashlib.sha256(old).hexdigest(),'after':sha(p),'replacements':[[a,b],[c,d]]},'unchanged_quotas':['travel180','speed45','preview1.2','grow.65','damage1','interval.7','Queen24HP','all Player parameters','all branches','migration paths','all strategies/checks/caps'], 'cases':['adaptive_full','full_edge'],'strategy_same_bytes':{},'native_budget_each':120,'cold_import_budget':90,'verdict':'unverified; pair observes old strategies under new space, not successful response proof'}
for rel in ['tests/thorn_queen_sweep_runner.gd','tests/support/forest_queen_gameplay_fixture.gd','tools/run_thorn_queen_sweep.py','scripts/bosses/thorn_queen_weave_band.gd','resources/bosses/thorn_queen_v2.tres']:
 assert (root/rel).read_bytes()==(snap/rel).read_bytes();receipt['strategy_same_bytes'][rel]=sha(snap/rel)
(root/'build/forest_depth/queen/queen37-preparation/overlay.json').write_text(json.dumps(receipt,indent=2)+'\n')
