from pathlib import Path
import json,hashlib
root=Path('/workspace/gunman-rush-design')
items=[('37-H','queen37-crossline-A','round37-adaptive_full'),('37-edge','queen37-crossline-A','round37-edge-full_edge'),('38-lifecycle-driver-failure','queen38-refuge','round38-crossline_refuge'),('39-ordinary-refuge','queen39-refuge-lifecycle','round39-crossline_refuge')]
result={'scope':'Actual failure/success comparison only, no design acceptance; main unchanged','cases':{}}
for label,snap,name in items:
 base=root/'build/forest_depth/snapshots'/snap;p=base/'build/forest_depth/queen'/name/'capture.json'
 if not p.is_file():continue
 d=json.loads(p.read_text());r=json.loads((p.parent/'receipt.json').read_text())
 result['cases'][label]={'path':str(p.relative_to(root)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'failures':d['failures'],'assertions':d['assertions'],'cases':d['cases'],'source_guard':r['source_guard'],'verifier_guard':r['verifier_guard'],'selected':d['selected'],'player_damage_events':[e for e in d['events'] if e.get('event')=='policy_result' and e.get('target')=='player'],'response_events':[e for e in d['events'] if e.get('event','').startswith('crossline_response')],'continuous_motor':all(f['tick']==i+1 and f['motor_steps']==i+1 for i,f in enumerate(d['frames']))}
out=root/'build/forest_depth/queen/queen37-preparation/actual-audit.json';out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print({k:(v['assertions'],v['failures']) for k,v in result['cases'].items()})
