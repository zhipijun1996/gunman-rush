# A crossline first experiment — 37/38/39 actual results

Candidate only, main production untouched. Author owns original Queen and this modification, cannot independent-sign. Root requested repair of final reviewer structural counterexample, not confirmation of old36 CONTINUE. S9fdf7fad old source/film/local remains original; old third y570..585 minus180 radius6 never intersects middle feet360. The old16–24s safe-middle behavior is a real content defect, not merely a boring driver. Current frozen S remains nonfinal.

## Change and controls

Only snapshot Definition third start(200,450), tip(888,465). Travel180/speed45, 1.2+.65 warning/growth, damage1/.7, Queen24HP, Player/physics/resources, 140/300/164-wide branches and world unchanged. This A retains left bank beyond line endpoint and floor recovery; B full-width12 was explicitly not chosen to block every refuge. Moving knots/new migration not added. Baseline37 HEAD9fdf7fad; fresh38/39 HEAD1c8e619f after root docs changes, but original baseline inventories all2037 runtime paths/SHA exactly equal. Receipt binds original raw and verifier domains, not merely class names.

| Actual run | Strict native | Outcome | Meaning |
| --- | --- | --- | --- |
|37 same-byte adaptive purpose|18/1, original must-defeat guard fails|1411ticks, Player dead, Queen5HP|Two genuine borrows/cuts then old middle tracking takes five actual field2 hits; old strategy is no longer safe, not value approval |
|37 same-byte strongest edge|11/0|24→0 at1115, PlayerHP2/E80|Legitimate fast clear remains; body419 plus two new field2 hits953/1070 |
|38 new ordinary refuge driver|13/1|stopped589, Queen12HP, PlayerHP4|Driver incorrectly broke before deferred third-field spawn next physics; no actual refuge test yet, preserved failed source/raw |
|39 same A, lifecycle-only correction|15/0|24→0 at1115, PlayerHP4/E100|Normal main cut then one real gap jump to left refuge avoids new field2 damage; no H, no state writes |

Each actual run used original public wrapper coldimport90/native120 and strict errors/leak/source/verifier guards. No cap increases, no194all, no movies, no App, no main change. 37 initial pair first failure stopped; edge was then separately root-authorized observation, not hidden retry. 38 failure is not retagged39 success. Fresh source files are kept per-run, not overlaid retrospectively.

## Real new response, and limits

39 normal entry/P1 output takes the original Queen body hit419 (HP5→4), never rebaselines. It then ordinarily shoots the main knot, starts third field on actual next physics. At735, actual ascending line at middle is y429.95. Normal input walks to actual full-foot takeoff317.068/341.925; jump starts766 toward safe x178. Real left full-body support must persist12 frames; no teleport or fallback support exemption. Network2 remains alive HP2 and pulse0. Player continues actual muzzle/body-surface normal fire from left and kills1115 at160.566/381.925.

There is **only one transfer** before kill. The prepared return after descending line below banks never executes. Do not call this a complete out/back/recurring phase-cycle. New response differs from edge in both main-knot cut and movement timing; HP4vs2 is a combined real strategy result, not isolated proof of jump advantage. Ground recharge also means E100vs80 is not net efficiency proof. The preserved edge win is not rejected for taking damage.

This first experiment proves the crossline reaches old stationary middle and that a legal normal response exists without shrinking banks or buffing H. It does not yet prove satisfying sustained phase3 gameplay, H responsive full victory, or that early left-bank station plus main cut cannot dominate. Much of39 after arrival shoots from left refuge; whether intentional safe recovery plus attack access creates a useful directional decision or merely relocates the old camp problem is explicitly for independent design review. No claim of readably safe H body crossing or successful third H. Do not promote A based solely on old H dying.

## Exact artifacts

- `build/forest_depth/snapshots/queen37-crossline-A/build/forest_depth/queen/round37-adaptive_full/` — original H failure capture/log/receipt.
- Same snapshot `round37-edge-full_edge/` — original same-function ordinary clear.
- `build/forest_depth/snapshots/queen38-refuge/build/forest_depth/queen/round38-crossline_refuge/` — original lifecycle-driver failure.
- `build/forest_depth/snapshots/queen39-refuge-lifecycle/build/forest_depth/queen/round39-crossline_refuge/` — actual corrected response.
- Outer `build/forest_depth/queen/{round37-outer,round37-edge-outer,round38-outer,round39-outer}/` — exact argv/budgets/terminal receipts.
- Snapshot original inventories/overlay binding; `queen37-preparation/overlay.json`, `queen38-preparation/overlay.json`, `queen39-preparation/overlay.json` identify actual source differences.
- `queen37-preparation/actual-audit.json`, `audit.py` bind captures/SHA and actual Player damage, line decisions, first left support and original source guards. `queen38-preparation/response.gd.txt` is original38 response producer;39 lifecycle fix is separate frozen runner.

Different final-experience reviewer was consulted before selecting A and receives this actual scope; implementation author does not sign acceptance. No current-source save/schema/public release/audio/device/user-fun claim.
