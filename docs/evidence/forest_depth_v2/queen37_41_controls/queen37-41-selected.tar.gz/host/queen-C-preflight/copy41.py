from pathlib import Path
import hashlib,json,os,shutil,subprocess,stat,time
root=Path('/workspace/gunman-rush-design');source=root/'build/forest_depth/snapshots/queen37-crossline-A';dest=root/'build/forest_depth/snapshots/queen41-cheap-low-peek';assert not dest.exists()
old=json.loads((source/'build/snapshot-receipt.json').read_text());names=old['source_files'].keys();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();before={r:sha(source/r) for r in names};dest.mkdir(parents=True)
links={}
for rel,h in before.items():
 s=source/rel;d=dest/rel;d.parent.mkdir(parents=True,exist_ok=True)
 if rel.startswith('assets/') and s.suffix.lower() in ['.png','.jpg','.jpeg','.webp','.ogg','.wav','.ttf','.woff','.woff2','.otf']:
  os.link(s,d);links[rel]={'source':str(s),'sha256':h,'mode':stat.S_IMODE(s.stat().st_mode)}
 else:shutil.copyfile(s,d);shutil.copymode(s,d)
 assert sha(d)==h,rel
assert before=={r:sha(source/r) for r in names}
subprocess.run(['git','init','--quiet',str(dest)],check=True);objects=subprocess.check_output(['git','rev-parse','--path-format=absolute','--git-path','objects'],cwd=root,text=True).strip();(dest/'.git/objects/info/alternates').write_text(objects+'\n');subprocess.run(['git','update-ref','--no-deref','HEAD',old['base_commit']],cwd=dest,check=True);subprocess.run(['git','read-tree','HEAD'],cwd=dest,check=True);(dest/'.git/info/exclude').write_text('build/\n.godot/\n')
(dest/'build').mkdir();receipt={'scope':'Cold frozen A37 actual2037 clone for strongest ordinary leg; not current-main/D source proof','base_commit':old['base_commit'],'source_root':str(source),'snapshot_root':str(dest),'source_files':before,'source_copy_guard':True,'shared_media_links':links,'created':time.time()};(dest/'build/snapshot-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
# Only existing testproducer opt-in; all production A37 exact.
p=dest/'tests/thorn_queen_sweep_runner.gd';s=p.read_text();s=s.replace('func run() -> void:',(root/'build/forest_depth/queen/queen-C-preflight/ordinary-peek-once.gd.txt').read_text()+'\nfunc run() -> void:\n\tif selected=="ordinary_low_peek": await ordinary_peek_once()');p.write_text(s)
p=dest/'tools/run_thorn_queen_sweep.py';p.write_text(p.read_text().replace("'shore_H','adaptive_full'","'shore_H','adaptive_full','ordinary_low_peek'"))
changes={rel:{'before':h,'after':sha(dest/rel)} for rel,h in before.items() if sha(dest/rel)!=h};assert set(changes)=={'tests/thorn_queen_sweep_runner.gd','tools/run_thorn_queen_sweep.py'}
(root/'build/forest_depth/queen/queen-C-preflight/overlay41.json').write_text(json.dumps({'scope':'ordinary one-R leg only; A37 production exact, no C actor','changes':changes,'base_source_copy_guard':True},indent=2)+'\n')
print(json.dumps({'actual_source_count':len(before),'copy_guard':True,'source':str(source),'snapshot':str(dest),'production_equals_A37':True}))
