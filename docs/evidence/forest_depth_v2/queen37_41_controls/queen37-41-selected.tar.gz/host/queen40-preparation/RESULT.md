# QUEEN40 shared-prefix active third-knot golden

Build-only continuation of root-authorized A experiment, not main promotion or independent acceptance. Read `../queen37-preparation/RESULT.md` first: old stationary H dies5times to new real crossline, old ordinary edge legitimately kills1115HP2, normal main-cut/left-refuge39 kills1115HP4. Original S old middle-safety defect,37Hfailure and38driver-failure remain unchanged. Implementation author owns old Queen/A and cannot sign new design acceptance.

## Actual same-start comparison

A production endpoints200450→888465 only; all old Player/24HP/travel180/speed45/1.2+.65/damage1/.7/world/branches unchanged. Fresh40 inventory all2037 baseline files exactly equals37 original2037; no main edits. Opt-in `third_hook`/`third_shoot` in existing canonical runner/wrapper, same adaptive first two borrows/cuts and initial resources. New branch executes only after real third field exists; no new stage fixture, teleports, resources or immunity. Same source both captures, before/after and verifier guards true. Original wrapper editor90/native120; once per mode, no retries, clean strict exit.

The first710 frames match across **all physical/state/timing fields**, only real queen_motor_id excluded because two native processes assign different native instance IDs. Do not call full frame objects identical; source/motion ownership is checked within each capture. At710 age.2: Player648.426/300.588, actual origin648.426/294.588, target720260, HP5/E84/two rounds. The original spawned at698 with body528.695/253.555 during actual prior R; no invented safe spawn or standingx500 was required.

| Mode | Real third action | Network removal | Complete24HP | Player damage/endE |
| --- | --- | --- | --- | --- |
| H→one R |711request,717real Knot2contact,727kick,734firstfree,735shoot |736 knot1→0, field2 age.633|1496tick|0 /100 |
| Two ordinary shots |712 and728 actualrequests, normal recoil/motion|736 knot1→0, field2 age.633|1479tick|0 /100 |

Native22/0 and19/0. H ends its response749 near566.176/341.925; two-shot response742 near505.875/341.925. H physically rises/pulls around live720260 then backshots onto middle; ordinary first recoil landsmiddle then second grounded recoil remainslegal. Original recovery and three later low excursions stay real, arena containment unchanged.

This verifies an optional H3 action actually exists; it does **not** verify a superior strategy. Ordinary is17ticks faster and both no damage, same actual cut tick and finalE. Ordinary bullets hit the knot and naturally refund energy, so fewer bullets cannot be advertised as20permanent energy saved. At736 both E84. H does provide a different aerial movement/contact→kick→backshot route; whether that is worth choosing is now an independent gameplay judgment, not a benefit inferred from H count. Killing the network before growth is earned active manipulation in both modes, not timed invulnerability; it also means these two methods do not themselves experience mature third-line pressure. That comes from37/39 with exact causal limits.

## Remaining source/test semantics, not hidden fixes

Inherited old row field `third_H_omitted_as_redundant=true` is wrong in new hook mode. Raw remains exact; actual third_borrow=true, real contact and input trace prove three H. This is a new opt-in metadata bug, not a physics result. Before promotion the new selection must override that label; do not retroactively modify original40capture or cite the label as no-H.

Old canonical local69 includes explicit assertion “wide middle receiver stays safe through full moving third weave.” That was the old content contract and is itself the final review’s counterexample; it cannot survive as the new intended phase3 claim. We did not run/all194 or remove/weaken it. Original old69/source/case must remain frozen. Only after content value is independently accepted should the current probe assert the stronger actual semantics: mature live third field can pressure middle through paired SAT+Policy; intentional left full-width receiver provides real recovery for the full cycle; normal transfer/return remains body-supported; same borrowed knot and ordinary shot actually sever the live field. Independent reviewer must review this semantic change. No silent green through keeping permanent middle immunity.

## Original artifact paths

`build/forest_depth/snapshots/queen40-third-intercept/build/forest_depth/queen/round40-third_{hook,shoot}/`: exact capture/native/import/receipt. Whole current frozen40 sources in snapshot, originalbaseline `build/snapshot-receipt.json`, explicit changes `build/forest_depth/queen/queen40-preparation/overlay.json`. Outer actual argv/caps/time `build/forest_depth/queen/round40-outer/receipt.json` (28.673s +10.273s). `actual-audit.json/audit.py` here bind raw SHA and independent-comparison inputs; all are implementation observations, not independent admission.

No main source, save/schema, App, Harness194, movie, public default, audio/device or player-quality approval. Engine terminal/released. Independent final-experience reviewer receives original37–40 package and decides whether active third-network choice plus left refuge addresses the structural defect or merely relocates stationary dominance.
