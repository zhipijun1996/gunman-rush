from pathlib import Path
import json,hashlib
root=Path('/workspace/gunman-rush-design');snap=root/'build/forest_depth/snapshots/queen40-third-intercept';runs={};raws={}
for mode in ['hook','shoot']:
 p=snap/'build/forest_depth/queen'/('round40-third_'+mode);d=json.loads((p/'capture.json').read_text());r=json.loads((p/'receipt.json').read_text());raws[mode]=d
 runs[mode]={'path':str(p.relative_to(root)),'raw_sha256':hashlib.sha256((p/'capture.json').read_bytes()).hexdigest(),'native_sha256':hashlib.sha256((p/'native.log').read_bytes()).hexdigest(),'assertions':d['assertions'],'failures':d['failures'],'case':d['cases'][0],'source_guard':r['source_guard'],'verifier_guard':r['verifier_guard'],'third_events':[e for e in d['events'] if e.get('event','').startswith('third_response') or(e.get('field')==2 and e.get('event') in ['weave_severed','knot_health_severed'])],'player_policy':[e for e in d['events'] if e.get('event')=='policy_result' and e.get('target')=='player']}
ignored=['queen_motor_id'];count=0
for f,g in zip(raws['hook']['frames'],raws['shoot']['frames']):
 if {k:v for k,v in f.items() if k not in ignored}!={k:v for k,v in g.items() if k not in ignored}:break
 count+=1
result={'scope':'Offline actual source/raw comparison only; no independent or player quality signoff','prefix':{'equal_frame_count':count,'excluded_fields':ignored,'reason':'Actual instance IDs differ between fresh native processes; actor ownership verified within each actual capture; no physical field, event time, coordinate or resource normalized','whole_frame_objects_equal':False},'runs':runs,'known_metadata_error':'Inherited third_H_omitted_as_redundant is true for third_hook but actual third_borrow/contact and R are real; raw preserved, label must be overridden before promotion'}
(root/'build/forest_depth/queen/queen40-preparation/actual-audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(count,{k:(v['assertions'],v['case']['ticks'],v['case']['player_damage']) for k,v in runs.items()})
