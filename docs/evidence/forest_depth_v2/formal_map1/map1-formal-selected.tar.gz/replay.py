from pathlib import Path
import subprocess,json,importlib.util
R=Path(__file__).resolve().parent
subprocess.run(['python3','replay.py'],cwd=R/'routes8',check=True)
def load(path,name):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
old=R/'controls/old';raw=json.loads((old/'capture.json').read_text());producer=load(old/'context/tools/run_forest_depth_region.py','old_original')
try:producer.validate(raw)
except AttributeError:print('Old original reader AttributeError preserved, never relabelled wrapper pass')
else:raise AssertionError('Old original failure unexpectedly changed')
fixed=load(old/'context/tools/reader-fixed-offline.py','old_offline_fixed');assert not fixed.validate(raw)
new=R/'controls/thorn';m=load(new/'context/tools/run_forest_depth_region.py','thorn_original');assert not m.validate(json.loads((new/'capture.json').read_text()))
print('MAP1 SELECTED OFFLINE:8 actual accepted/2 original rejected; old wrapper failure preserved/same raw fixed offline;new Thorn control accepted; no native rerun')
