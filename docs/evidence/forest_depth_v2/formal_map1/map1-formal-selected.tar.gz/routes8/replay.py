from pathlib import Path
import json,importlib.util
R=Path(__file__).resolve().parent
for i,row in enumerate(json.loads((R/'replay-cases.json').read_text())):
 p=R/'contexts'/row['context']/'tools/run_forest_depth_region.py';s=importlib.util.spec_from_file_location('original'+str(i),p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
 errors=m.validate(json.loads((R/row['case']).read_text()));print(row['case'],errors)
 assert bool(errors)==row['expected_errors']
print('FORMAL MAP1 BASELINE OFFLINE: eight accept plus two original reject; no native rerun')
