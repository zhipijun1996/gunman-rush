from pathlib import Path
import hashlib,importlib.util,json,sys,tarfile,re
root=Path.cwd();out=root/'build/forest_depth/independent/map2-eight-review';archive=root/'docs/evidence/forest_depth_v2/formal_map2/map2-eight-selected.tar.gz'
assert hashlib.sha256(archive.read_bytes()).hexdigest()=='a6a359f5cbe8a7155a65c1119a5cac6ced697923a69263e5fcbe1c9e5628ebd4'
with tarfile.open(archive) as tar:
 members=tar.getmembers();assert len(members)==129 and all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in members)
 index=json.load(tar.extractfile('members.json'));assert len(index)==128
 for name,sha in index.items():assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==sha,name
 # Only selected source consumers extracted; all other data read directly from tar.
 for m in members:
  if m.name.startswith('producer/'):
   p=out/'unpacked'/m.name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(tar.extractfile(m).read())
 summary=json.load(tar.extractfile('summary.json'));rows=[]
 contexts={name.split('/')[1]:json.load(tar.extractfile(name)) for name in index if name.startswith('contexts/') and name.endswith('snapshot-receipt.json')}
 for context,receipt in contexts.items():
  for name in index:
   prefix='producer/'+context+'/'
   if name.startswith(prefix):assert index[name]==receipt['source_files'][name[len(prefix):]],name
 for row in summary['rows']:
  paths=[name for name in index if name.startswith('actual/'+row['output']+'/') and name.endswith('/capture.json') and json.load(tar.extractfile(name))['route']==row['route']]
  assert len(paths)==1;name=paths[0];d=json.load(tar.extractfile(name));assert index[name]==row['capture_sha256']
  consumer=out/'unpacked/producer'/row['snapshot']/'tools/run_forest_depth_region.py'
  sys.path.insert(0,str(root/'tools'));spec=importlib.util.spec_from_file_location('review_'+row['output']+'_'+row['route'],consumer);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
  errors=m.validate(d);assert not errors,(name,errors)
  assert len(d['frames'])==row['frames'] and len(d['completed_legs'])==len(d['itinerary'])==row['legs']
  assert [f['tick'] for f in d['frames']]==list(range(1,len(d['frames'])+1)) and all(f['motor_steps']==1 and f['health']>0 for f in d['frames'])
  assert d['initial_snapshot']['config']==d['final_snapshot']['config']
  assert d['actual_stage_map']==d['manifest']['map_index']==2 and d['manual_motor_step'] is False and d['position_or_resource_injection'] is False
  native=tar.extractfile(name.removesuffix('capture.json')+'native.log').read().decode();assert not m.ERRORS.search(native)
  receipt=json.load(tar.extractfile('actual/'+row['output']+'/receipt.json'));assert receipt['source_stable'] and receipt['status']=='passed' and receipt['import']['exit_code']==0
  matching=[r for r in receipt['runs'] if r['route']==row['route']];assert len(matching)==1 and matching[0]['exit_code']==0 and not matching[0]['errors']
  rows.append({'capture':name,'sha256':index[name],'snapshot':row['snapshot'],'route':row['route'],'frames':len(d['frames']),'health':[d['initial_snapshot']['health'],d['final_snapshot']['health']],'damage_events':sum(e.get('kind')=='committed_damage' and e.get('target')=='player' for e in d['events']),'claimed':d['cache_claimed'],'gate_open':d['gate_saved_open'],'frozen_reader_errors':errors})
 # Both real first failures remain rejected by their own archived consumers.
 failures=[]
 for output in ['map2_formal01','map2_formal05']:
  name=next(n for n in index if n.startswith('retained-failures/'+output+'/') and n.endswith('/capture.json'))
  d=json.load(tar.extractfile(name));p=out/'old-reader'/output/'tools/run_forest_depth_region.py';p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(tar.extractfile('retained-failures/'+output+'/producer/tools/run_forest_depth_region.py').read())
  spec=importlib.util.spec_from_file_location('old_'+output,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);errors=m.validate(d);assert errors
  failures.append({'path':name,'still_rejected':True,'errors':errors})
 hashes={context:hashlib.sha256(json.dumps(receipt['source_files'],sort_keys=True).encode()).hexdigest() for context,receipt in contexts.items()}
 result={'status':'CONTINUE_limited_actual_consumer_evidence','archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'regular_members':len(members),'indexed_members_verified':len(index),'eight_original_frozen_readers_accept':True,'rows':rows,'retained_failures':failures,'source_contexts':hashes,'scope':'Reviewer authored base generator; independent of these actual route drivers/receipts. This is source/provenance/runtime-consumer review, not independent approval of my own level design or content/fun/device/wholeQueen.'}
 (out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
