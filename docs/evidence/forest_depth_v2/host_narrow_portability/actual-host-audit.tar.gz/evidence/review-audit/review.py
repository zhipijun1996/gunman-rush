from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,importlib.util,subprocess,copy,time
R=Path.cwd();O=R/'build/verification/narrow-portability/review-audit';S=R/'docs/evidence/forest_depth_v2/narrow02';D=O/'fresh-unpacked'
sha=lambda b:hashlib.sha256(b).hexdigest()
receipt=json.loads((S/'archive-receipt.json').read_text());raw=(S/receipt['archive']).read_bytes();assert len(raw)==receipt['bytes'] and sha(raw)==receipt['sha256']
expected=json.loads((S/'members.json').read_text());D.mkdir()
with tarfile.open(S/receipt['archive']) as t:
 rows=t.getmembers();assert len(rows)==147 and len({r.name for r in rows})==147
 for r in rows:
  p=PurePosixPath(r.name);assert r.isfile() and not p.is_absolute() and '..' not in p.parts and r.size<100000000
  q=D.joinpath(*p.parts);assert q.resolve().is_relative_to(D.resolve());q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(t.extractfile(r).read())
actual={p.relative_to(D).as_posix():{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in D.rglob('*') if p.is_file()}
assert set(actual)==set(expected)|{'members.json'} and json.loads((D/'members.json').read_text())==expected
assert all(actual[n]==v for n,v in expected.items())
bindings=[]
for version in ('narrow01','narrow02'):
 C=D/'checker-context'/version;inv=json.loads((C/'snapshot-receipt.json').read_text())['source_files'];n=0
 for p in C.rglob('*'):
  if p.is_file() and p.name!='snapshot-receipt.json':assert sha(p.read_bytes())==inv[p.relative_to(C).as_posix()];n+=1
 bindings.append({'version':version,'selected_source_count':n,'original_inventory_count':len(inv)})
provenance=json.loads((D/'copy-provenance.json').read_text())
for row in provenance:assert sha((D/row['member']).read_bytes())==row['sha256'] and (D/row['member']).stat().st_size==row['bytes']
# New independent process replay, preserve exact original diagnostics.
p=subprocess.run(['python3','replay.py'],cwd=D,capture_output=True,text=True,timeout=60);(O/'independent-replay.log').write_text(p.stdout+p.stderr);assert p.returncode==0
mods={}
for v in ('narrow01','narrow02'):
 spec=importlib.util.spec_from_file_location(v,D/'checker-context'/v/'tools/run_forest_directional_golden.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);mods[v]=m
cases={n:json.loads((D/'new02'/f'{n}.json').read_text()) for n in ('intended','noH','naivejump','onlyR')}
controls=[]
def check(name,case,mut):
 d=copy.deepcopy(cases[case]);mut(d);(O/(name+'.json')).write_text(json.dumps(d));errors=mods['narrow02'].validate(d);controls.append({'name':name,'errors':errors});assert errors,name
check('missing_H_and_requests','intended',lambda d:(d.update(events=[e for e in d['events'] if not e['kind'].startswith('hook_')],requests=[r for r in d['requests'] if r['kind']!='grapple'])))
check('missing_R_and_requests','intended',lambda d:(d.update(events=[e for e in d['events'] if e['kind']!='shot_fired'],requests=[r for r in d['requests'] if r['kind']!='shoot_release'])))
check('claimed_complete_no_return','intended',lambda d:d.update(frames=d['frames'][:180],events=[e for e in d['events'] if e['tick']<=180],requests=[e for e in d['requests'] if e['tick']<=180],passed=True,reached=True,returned=True))
check('invented_energy_and_shots','intended',lambda d:[f.update(energy=999999,shots=99) for f in d['frames']])
check('all_H_targets_rebound','intended',lambda d:[e.update(target='invented_anchor') for e in d['events'] if 'target' in e])
check('remove_policy_same_summary','onlyR',lambda d:d.update(damage_events=[],policy_returns=[]))
check('clean_miss_fake_exit','noH',lambda d:d.update(reached=True,returned=True,passed=True))
check('factory_danger_hidden','intended',lambda d:d['manifest'].update(dangers=[]))
# Physical body movement falsification with same summary and events.
check('teleport_middle_frame','intended',lambda d:d['frames'][120].update(position=[90000,90000]))
result={'archive_sha256':receipt['sha256'],'safe_regular_members':len(actual),'verified_listed_members':len(expected),'copy_provenance_rows':len(provenance),'source_bindings':bindings,'independent_replay_exit':p.returncode,'controls':controls,'time':time.time()}
(O/'independent-results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
