import pathlib,importlib.util,json
r=pathlib.Path(__file__).resolve().parent
for version in ['narrow01','narrow02']:
 p=r/'checker-context'/version/'tools/run_forest_directional_golden.py';s=importlib.util.spec_from_file_location(version,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
 if version=='narrow02':
  for v in ['intended','noH','naivejump','onlyR']:
   errors=m.validate(json.loads((r/'new02'/(v+'.json')).read_text()));print(version,v,errors);assert not errors
 else:
  for v in ['noH','naivejump','window_minus4','window_minus2']:
   errors=m.validate(json.loads((r/'original01/controls'/(v+'.json')).read_text()));print(version,v,errors);assert errors
print('NARROW02 PORTABLE OFFLINE REPLAY: passed; no native rerun')
