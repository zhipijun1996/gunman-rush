"""Build-only input-timing experiment. Does not execute Godot or edit runtime."""
from pathlib import Path
import hashlib,json,difflib
root=Path('/workspace/gunman-rush-design');snap=root/'build/forest_depth/snapshots/narrow01';out=root/'build/forest_depth/traversal/narrow01-window-prepared';out.mkdir(exist_ok=False)
source=(snap/'tests/forest_directional_golden_runner.gd').read_text()
needle='if controller.traversal.state==&"free" and age>20:action(&"shoot_release",Vector2.LEFT);set_phase("recoil_out")'
assert source.count(needle)==1
records=[]
for offset in [-4,-2,0,3,6,9]:
 changed=source.replace('var variant := "intended"','var variant := "intended"\nvar first_kick_tick := -1')
 changed=changed.replace(needle,f'if first_kick_tick>=0 and tick>=first_kick_tick+ceili(controller.traversal.definition.hook_launch_seconds*Engine.physics_ticks_per_second)+2+({offset}):action(&"shoot_release",Vector2.LEFT);set_phase("recoil_out")')
 changed=changed.replace('func action_changed(state: StringName) -> void:\n','func action_changed(state: StringName) -> void:\n\tif state==&"hook_kick" and first_kick_tick<0:first_kick_tick=tick\n')
 filename='window_'+str(offset).replace('-','minus')+'.gd';(out/filename).write_text(changed)
 (out/(filename+'.diff')).write_text(''.join(difflib.unified_diff(source.splitlines(keepends=True),changed.splitlines(keepends=True),fromfile='immutable_narrow01_runner',tofile=filename)))
 records.append({'offset':offset,'driver':filename,'sha256':hashlib.sha256(changed.encode()).hexdigest(),'reference':'first actual kick event + ceil(real launch seconds * actual physics hz) + 2 scheduled-driver ticks; base originalfree+1 verified later from actual events, not assumed acceptance'})
(out/'preparation.json').write_text(json.dumps({'scope':'No native yet. Same immutable narrow01 content; sole intervention is scheduled first shot timing, not body/resources. Early shot may legitimately cancel unfinished hook_kick; cannot claim original24px kick assertion. Late damage may stop route before R; do not force it. All results are window diagnostics, not automatic acceptance.','original_runner_sha256':hashlib.sha256(source.encode()).hexdigest(),'samples':records},indent=2)+'\n')
print('prepared',len(records),'no engine executed')
