from pathlib import Path
import os,sys,json,hashlib,fcntl,subprocess,time,importlib.util,shutil
root=Path('/workspace/gunman-rush-design');snap=root/'build/forest_depth/snapshots/narrow01';out=root/'build/forest_depth/traversal/narrow01-controls';out.mkdir(exist_ok=False)
env={**os.environ,'GUNMAN_TOOLCHAIN_ROOT':'/workspace/toolchains','GUNMAN_DATA_HOME':str(snap/'build/narrowuserdata'),'XDG_CONFIG_HOME':str(snap/'build/narrowconfig'),'XDG_CACHE_HOME':str(snap/'build/narrowcache'),'LP_NUM_THREADS':'1'}
spec=importlib.util.spec_from_file_location('frozen',snap/'tools/run_forest_directional_golden.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
report={'scope':'Same immutable narrow01 runtime/geometry. Original three fixed controls, then explicit build-only driver first-shot timing interventions. Not original intended-chain acceptance for early interrupted kicks.','source_before':m.inventory(),'snapshot_receipt_sha256':hashlib.sha256((snap/'build/snapshot-receipt.json').read_bytes()).hexdigest(),'runs':[]}
def save():(out/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
save()
def execute(name,argv,limit,capture=None,driver=None):
 start=time.monotonic();log=out/(name+'.log');row={'name':name,'argv':argv,'limit':limit}
 if driver:row['intervention_driver_sha256_before']=hashlib.sha256(driver.read_bytes()).hexdigest()
 try:
  with log.open('w') as stream:r=subprocess.run(argv,cwd=snap,env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=limit)
  row.update(exit_code=r.returncode,seconds=time.monotonic()-start,strict_errors=bool(m.ERRORS.search(log.read_text(errors='replace'))),log_sha256=hashlib.sha256(log.read_bytes()).hexdigest())
 except subprocess.TimeoutExpired:row.update(status='timeout',seconds=time.monotonic()-start)
 if capture and capture.exists():
  data=json.loads(capture.read_text());row.update(capture=str(capture),capture_sha256=hashlib.sha256(capture.read_bytes()).hexdigest(),actual={k:data.get(k) for k in ['passed','reached','returned','recovered','initial_health','final_health','damage_events','policy_returns','failure']},original_frozen_validator_errors=m.validate(data))
  shutil.copyfile(capture,out/(name+'.json'))
 if driver:row['intervention_driver_sha256_after']=hashlib.sha256(driver.read_bytes()).hexdigest()
 row['source_stable']=m.inventory()==report['source_before'];report['runs'].append(row);save();print(json.dumps({k:v for k,v in row.items() if k not in ['actual','argv']}),flush=True)
 return row
with (root/'build/verification/engine.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 for v in ['noH','naivejump','onlyR']:
  target=snap/('build/forest_depth/traversal/narrow01-controls-'+v)
  row=execute(v,['python3','tools/run_forest_directional_golden.py','--layout','narrow','--variant',v,'--output-dir',str(target)],55,target/(v+'.json'))
  if not row['source_stable'] or row.get('strict_errors'):break
 else:
  for offset in [-4,-2,0,3,6,9]:
   name='window_'+str(offset).replace('-','minus');source=root/('build/forest_depth/traversal/narrow01-window-prepared/'+name+'.gd');driver=snap/('build/window-drivers/'+name+'.gd');driver.parent.mkdir(exist_ok=True,parents=True);shutil.copyfile(source,driver)
   capture=out/(name+'-native.json')
   row=execute(name,['bash','tools/godot.sh','--headless','--fixed-fps','60','--path','.','--script',str(driver.relative_to(snap)),'--','--layout=narrow','--variant=intended','--output='+str(capture)],45,capture,driver)
   if not row['source_stable'] or row.get('strict_errors'):break
report['source_after']=m.inventory();report['source_stable']=report['source_before']==report['source_after'];report['status']='collected' if len(report['runs'])==9 and report['source_stable'] else 'incomplete';save();print('global engine lock released',flush=True)
