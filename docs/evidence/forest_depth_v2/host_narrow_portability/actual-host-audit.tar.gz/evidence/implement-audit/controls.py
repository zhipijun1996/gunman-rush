import pathlib,importlib.util,json,copy,hashlib,subprocess,os,time
out=pathlib.Path(__file__).resolve().parent;r=out/'unpacked';spec=importlib.util.spec_from_file_location('portable_narrow02',r/'checker-context/narrow02/tools/run_forest_directional_golden.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
base={v:json.loads((r/'new02'/f'{v}.json').read_text()) for v in ['intended','noH','naivejump','onlyR']}
controls=[]
def check(name,variant,edit):
 d=copy.deepcopy(base[variant]);edit(d);errors=m.validate(d);p=out/'mutations'/f'{name}.json';p.parent.mkdir(exist_ok=True);p.write_text(json.dumps(d));controls.append({'name':name,'variant':variant,'mutated_capture':str(p),'errors':errors,'rejected':bool(errors)});assert errors,name
check('delete-hook-contact','intended',lambda d:d.__setitem__('events',[e for e in d['events'] if e['kind']!='hook_contact_kick']))
check('delete-shot-event','intended',lambda d:d.__setitem__('events',[e for e in d['events'] if e['kind']!='shot_fired']))
check('delete-return-keep-summary','intended',lambda d:d.__setitem__('frames',d['frames'][:90]))
check('remove-last-support','intended',lambda d:[f.__setitem__('grounded',False) for f in d['frames'][-12:]])
check('inflate-energy','intended',lambda d:d['frames'][60].__setitem__('energy',99999))
check('wrong-manifest-danger','intended',lambda d:d['manifest'].__setitem__('dangers',[]))
check('remove-damage-and-return','onlyR',lambda d:(d.__setitem__('damage_events',[]),d.__setitem__('policy_returns',[])))
check('fake-epoch-preservation','onlyR',lambda d:d['policy_returns'][0].__setitem__('actor_epoch_after',d['policy_returns'][0]['actor_epoch_before']))
check('clean-miss-skips-recovery-step','noH',lambda d:d.__setitem__('events',[e for e in d['events'] if e['kind']!='jumped']))
check('naive-summary-false-positive','naivejump',lambda d:d.__setitem__('reached',True))
# Verify isolated byte corruption cannot keep integrity under the published external member map.
p=out/'mutations/context-player-tuning.json';original=r/'checker-context/narrow02/config/player_tuning.json';p.write_bytes(original.read_bytes()+b'\n');expected=json.loads((r/'members.json').read_text())['checker-context/narrow02/config/player_tuning.json'];controls.append({'name':'selected-context-member-one-byte-corruption','mutated_file':str(p),'actual_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'expected_sha256':expected['sha256'],'rejected':hashlib.sha256(p.read_bytes()).hexdigest()!=expected['sha256']})
# Inspect archived selected source against the archived inventory; missing runtime assets are intentional, not runnable closure.
contexts=[]
for v in ['narrow01','narrow02']:
 c=r/'checker-context'/v;receipt=json.loads((c/'snapshot-receipt.json').read_text());contexts.append({'version':v,'receipt_keys':list(receipt),'selected_source_count':len([p for p in c.rglob('*') if p.is_file()])})
(out/'controls.json').write_text(json.dumps({'scope':'offline validator and archive integrity negative controls; not native outcomes','controls':controls,'contexts':contexts},indent=2))
print(json.dumps({'mutations':len(controls),'all_rejected':all(x['rejected'] for x in controls)}))
