import json,pathlib,subprocess,os,time,hashlib
out=pathlib.Path(__file__).resolve().parent;root=pathlib.Path('/workspace/forest-depth-harness-audit');r=out/'unpacked';env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'};runs=[]
for label,argv in [('offline-replay',['python3',str(r/'replay.py')]),('resolved-mechanism-comparisons',['python3','tests/test_mechanism_comparisons.py'])]:
 start=time.time();res=subprocess.run(argv,cwd=root,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=60);log=out/(label+'.log');log.write_text(res.stdout);runs.append({'id':label,'argv':argv,'cwd':str(root),'exit_code':res.returncode,'started_unix':start,'seconds':time.time()-start,'log':str(log),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()});assert res.returncode==0,(label,res.stdout)
# Source inventories in each native snapshot receipt bind the selected frozen validator context.
contexts=[]
for v in ['narrow01','narrow02']:
 c=r/'checker-context'/v;d=json.loads((c/'snapshot-receipt.json').read_text());rows=[]
 for p in c.rglob('*'):
  if p.is_file() and p.name!='snapshot-receipt.json':
   rel=p.relative_to(c).as_posix();sha=hashlib.sha256(p.read_bytes()).hexdigest();assert d['source_files'].get(rel)==sha,(v,rel);rows.append(rel)
 contexts.append({'version':v,'selected_source_files_bound':len(rows),'full_inventory_count':len(d['source_files']),'native_snapshot_base':d['base_commit'],'scope':d['scope'],'copy_guard_recorded':d['source_copy_guard']})
(out/'executions-and-bindings.json').write_text(json.dumps({'runs':runs,'contexts':contexts,'generic_check_scope':'9 declaration-contract tests only; does not validate gameplay or archive native execution'},indent=2));print(json.dumps({'run_exit_codes':[x['exit_code'] for x in runs],'contexts':contexts}))
