import json,tarfile,pathlib,hashlib,time,subprocess
root=pathlib.Path('/workspace/forest-depth-harness-audit');out=root/'build/verification/narrow-portability/implement-audit';src=root/'docs/evidence/forest_depth_v2/narrow02';receipt=json.loads((src/'archive-receipt.json').read_text());expected=json.loads((src/'members.json').read_text());a=src/receipt['archive'];assert hashlib.sha256(a.read_bytes()).hexdigest()==receipt['sha256'];assert a.stat().st_size==receipt['bytes']
dest=out/'unpacked';dest.mkdir(exist_ok=False)
with tarfile.open(a,'r:gz') as t:
 members=t.getmembers();assert len(members)==receipt['members'];names=[m.name for m in members];assert len(names)==len(set(names))
 for m in members:
  p=pathlib.PurePosixPath(m.name);assert m.isfile() and not p.is_absolute() and '..' not in p.parts and m.size<100_000_000
  target=dest.joinpath(*p.parts);assert target.resolve().is_relative_to(dest.resolve());target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(t.extractfile(m).read())
 actual={p.relative_to(dest).as_posix():{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in dest.rglob('*') if p.is_file()}
 assert set(actual)==set(expected)|{'members.json'}
 assert json.loads((dest/'members.json').read_text())==expected
 for n,v in expected.items():assert actual[n]==v,(n,v,actual[n])
(out/'integrity.json').write_text(json.dumps({'archive':receipt,'actual_regular_members':len(actual),'listed_members':len(expected),'all_member_hashes_and_sizes_match':True,'member_names_safe_unique_regular_files':True,'outside_source_modified':False},indent=2))
print(json.dumps({'extracted':str(dest),'regular_members':len(actual),'listed':len(expected),'archive_sha256':receipt['sha256']}))
