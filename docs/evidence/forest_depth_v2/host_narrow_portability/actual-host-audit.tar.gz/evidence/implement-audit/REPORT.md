# narrow02-portability：真实host implement工作报告

执行者`/root/forest_ecology_review`；actual live implement lease，task narrow02-portability/attempt1；request_hash `a813208fbcefe22f33f29a319d7b26d4c968ce50a0fbfc418ebd4a5e6909ccc6`。本报告为ready_for_review，不是审查接受；等待另一真实代理独立复验。

## 独立性与输入边界

档案作者forest_traversal没有担任本次implement。我曾对该动作黄金作有限机制CONTINUE审查，该旧报告已收入此包；我不是archive/replay/checker作者。此历史参与予以披露，不能把本次离线移植审计当新的独立机制验收，也不能自己签最终accept。

执行工作树`/workspace/forest-depth-harness-audit`是bee850c加明确选择的Python/Skills/evidence dirty overlay的独立稀疏源，不是可运行游戏快照；没有Godot调用。AGENTS与lease完整skill/prompt已读。稀疏树缺current_state/handoff/architecture/acceptance_tests，已记录而不编造读取；这些旧状态入口不是本次离线解包/replay依赖。原生snapshot信息来自包中原receipt，不把本稀疏工作树或当前HEAD冒称其原生来源。

## 新实际工作

1. 以外部archive-receipt核实际tar.gz：12,873,956bytes；SHA256 `7eec0666241184bdda7108244e4a432a5c8a4294eb80f2ce399d54d842b57bfe`。
2. 全147成员先验证无绝对/..路径、重名、链接/特殊节点，再逐regular file安全写入ignored build/verification。没有调用不受控extractall，没有向源目录回写。
3. 外部members.json列146项，不自包含members.json自身；tar共147与archive-receipt一致。内外members字典相同，全部146项实际size/SHA相等。不是“147项全部在自包含manifest中”。
4. narrow01和narrow02各20份所选源码/配置，分别匹配其snapshot-receipt.source_files；原native inventories共1983/1984份。所选集合刻意不含全运行资产和缓存，不能据此重跑native。
5. 实际`python3 unpacked/replay.py` exit0：new02 intended/noH/naivejump/onlyR均由其原02context checker接受；original01 noH/naivejump/window_minus4/window_minus2仍被原01context拒绝。原失败原因完整保留，不重写01成成功。
6. 11个独立破坏控制全部拒绝：删真实hook_contact_kick；删accepted shot；删返程却保reached摘要；末12帧伪无支持；能量99999；清manifest危险；onlyR删损血和回退；回退epoch不递增；noH删恢复跳；naive伪reached；selected context一字节修改破坏成员hash。JSON变体仅位于build内副本，原包/源码未改。它们测试离线验证/完整性，不冒充新的原生坏例。
7. 精确resolved check `python3 tests/test_mechanism_comparisons.py` exit0，9 tests/0。**只检查通用机制对照声明合同，不验证游戏或本archive原生轨迹。** replay与此check的真实argv/cwd/start/elapsed/exit/logSHA见executions-and-bindings.json。

## 具体输出与复验入口

本目录包含unpack_verify.py、controls.py、run-recorded.py和实际integrity.json、controls.json、executions-and-bindings.json、sourceguard.json、相应log及mutations。另一审查者应新输出到其自己的ignored build目录：先核外部tar/hash/member字节与20+20 selected bindings，再新鲜运行原replay和有意义变体，不仅阅读我的summary。

原生、原电影、原receipt留其历史路径/命令/engine身份；没有改历史绝对argv。包中AVI/全200MB快照/全426PNG等排除范围已明确，MP4/精选帧和Policy/raw支撑各自有限声明。本人本次未重新播放影片或签像素/听音。

## 范围限度

源哈希应由生产控制器按live lease校核：`51cbd4fa20affab28da9170217a2c6b5617d68465e67b3e4b43f4deec72a281a`。本任务未改tracked/untracked源，所有新写入仅ignored build/verification；没有commit/push/merge/publish、没有Godot、没有能力/数值/断言修改。

校验raw与原checker可移植且拒绝上述破坏，只证明离线可复核及已列有限守卫。它不在不可信新capture上证明全部物理真实性，不穷尽所有伪造，不扩大原机制CONTINUE为正式区域、全部360°内容、玩家趣味、设备或G5。范围完成仍须不同真实审查者，不能预造review响应。
