"""Offline evidence replay only. No Godot/native/App execution."""
from pathlib import Path
import json,gzip,copy,importlib.util
R=Path(__file__).resolve().parent
def load(name):
 spec=importlib.util.spec_from_file_location(name,R/(name+'/run_forest_depth_region.py'));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.ROOT=R/'context';return m
old=load('producer_reader');new=load('corrected_reader');d=json.loads(gzip.decompress((R/'actual/capture.json.gz').read_bytes()));contact=next(e for e in d['events']if e['kind']=='hook_contact_kick'and e.get('target')=='hollow__cavity_ring_b');t=contact['tick'];request=next(r for r in d['requests']if r['kind']=='grapple'and r['tick']>next(e['tick']for e in d['events']if e['kind']=='cavity_bay_support'));rt=request['tick'];end=next(c['tick']for c in d['completed_legs']if c['edge_id']=='borer_crossing');mutants={}
def probe(name,x):mutants[name]=new.validate(x)
x=copy.deepcopy(d);next(f for f in x['frames']if f['tick']==t)['hook_tip']=[910,340];probe('tip_falsely_target_centre',x)
x=copy.deepcopy(d);f=next(f for f in x['frames']if f['tick']==t);f['position'][0]-=10;f['body'][0]-=10;next(e for e in x['events']if e['kind']=='hook_contact_kick'and e['tick']==t)['position'][0]-=10;probe('coherent_body_event_10px_short_of_stop',x)
x=copy.deepcopy(d);f=next(f for f in x['frames']if f['tick']==t);f['position'][0]+=50;f['body'][0]+=50;f['hook_tip'][0]+=50;next(e for e in x['events']if e['kind']=='hook_contact_kick'and e['tick']==t)['position'][0]+=50;probe('coherent_tip_body_stop_but_wrong_target_ring',x)
x=copy.deepcopy(d);next(e for e in x['events']if e['kind']=='hook_contact_kick'and e['tick']==t)['target']='hollow__cavity_ring_a';probe('wrong_real_contact_target',x)
x=copy.deepcopy(d);next(e for e in x['events']if e['kind']=='hook_contact_kick'and e['tick']==t)['kind']='fake_contact';probe('no_actual_contact_event',x)
x=copy.deepcopy(d);next(r for r in x['requests']if r['kind']=='grapple'and r['tick']==rt)['grounded_before']=True;next(f for f in x['frames']if f['tick']==rt-1)['grounded']=True;probe('coherent_fake_grounded_H2',x)
x=copy.deepcopy(d);next(r for r in x['requests']if r['kind']=='grapple'and r['tick']==rt)['hook_origin_before'][0]+=10;probe('false_fixed_request_origin',x)
x=copy.deepcopy(d)
for f in x['frames']:
 if end-11<=f['tick']<=end:f['position'][0]=997;f['body'][0]=985
probe('partial_receiver_12_not_actual_node430',x)
result={'scope':'Offline same actual580raw; producer reader reproduces original rejection; corrected reader accepts;8actual mutant controls reject. Not native rerun.','original_errors':old.validate(d),'corrected_errors':new.validate(d),'mutants':mutants};assert result['original_errors']==['leg_7_elbow_second_contact_not_actual_motor_arrival'];assert not result['corrected_errors']and all(mutants.values());print(json.dumps(result,indent=2))
