from pathlib import Path
import os,sys,fcntl,subprocess,time,json,hashlib
root=Path('/workspace/gunman-rush-design');snap=root/'build/forest_depth/snapshots/drop_shaft01';out=root/'build/forest_depth/drop_shaft/attempt01'
env=os.environ.copy();env.update(GUNMAN_TOOLCHAIN_ROOT='/workspace/toolchains',GODOT_BIN='/workspace/toolchains/godot/4.7.2/Godot_v4.7.2-stable_linux.x86_64',GUNMAN_DATA_HOME=str(snap/'build/user-data'),XDG_CONFIG_HOME=str(snap/'build/user-config'),XDG_CACHE_HOME=str(snap/'build/user-cache'),PYTHONDONTWRITEBYTECODE='1')
argv=[sys.executable,'tools/run_forest_hollow_upper.py','--drop-shaft','--variants','shaft_HR','noH_shaft_oneR','noH_shaft_twoR','noH_shaft_miss','--output-dir','build/forest_depth/drop_shaft/first01'];receipt={'scope':'C1 first normal-input local hypothesis; no regional approval','argv':argv,'cwd':str(snap),'cold_import_cap':90,'each_native_cap':45,'engine':env['GODOT_BIN']};start=time.monotonic()
with (root/'build/verification/engine.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 print('C1 actual engine acquired',flush=True)
 try:
  with (out/'outer.log').open('w') as log:
   p=subprocess.run(argv,cwd=snap,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=285)
  receipt['returncode']=p.returncode
 except BaseException as e:receipt['exception']=repr(e)
 finally:
  receipt['elapsed_seconds']=time.monotonic()-start
  capture=snap/'build/forest_depth/drop_shaft/first01'
  receipt['files']={str(p.relative_to(snap)):hashlib.sha256(p.read_bytes()).hexdigest() for p in capture.glob('*') if p.is_file()}
  original=json.loads((snap/'build/snapshot-receipt.json').read_text());receipt['all_snapshot_source_unchanged']=all((snap/p).is_file() and hashlib.sha256((snap/p).read_bytes()).hexdigest()==sha for p,sha in original['source_files'].items())
  (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
  print('C1 actual engine released '+json.dumps(receipt),flush=True)
