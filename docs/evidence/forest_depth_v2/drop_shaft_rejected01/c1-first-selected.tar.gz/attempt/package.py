from pathlib import Path
import tarfile,json,hashlib
root=Path('/workspace/gunman-rush-design');out=root/'build/forest_depth/drop_shaft/attempt01';raw=root/'build/forest_depth/snapshots/drop_shaft01/build/forest_depth/drop_shaft/first01'
files={}
for p in raw.iterdir():
 if p.is_file():files['native/'+p.name]=p
for p in out.iterdir():
 if p.is_file() and p.name not in ['c1-first-selected.tar.gz','archive-receipt.json']:files['attempt/'+p.name]=p
for p in (out/'selected-source').iterdir():files['producer/'+p.name]=p
index={name:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}for name,p in files.items()}
index_path=out/'members.json';index_path.write_text(json.dumps(index,indent=2)+'\n');files['members.json']=index_path
archive=out/'c1-first-selected.tar.gz'
with tarfile.open(archive,'w:gz')as tar:
 for name,p in sorted(files.items()):tar.add(p,arcname=name,recursive=False)
with tarfile.open(archive)as tar:
 members=[m for m in tar.getmembers()if m.isfile()]
 for name,spec in index.items():assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==spec['sha256']
receipt={'archive':str(archive),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size,'regular_members':len(members),'indexed_members':len(index),'scope':'Original failed hypothesis and strongest one-R success; original source/reader retained alongside hardened offline reader, no post-hardening native; full source inventory but selected producer bytes only; does not claim fully portable 200MB runtime.'}
(out/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
