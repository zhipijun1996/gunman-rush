from pathlib import Path
import json,importlib.util,hashlib
R=Path(__file__).resolve().parent;C=R/'context';inv=json.loads((C/'snapshot-receipt.json').read_text())['source_files'];post=json.loads((R/'receipt.json').read_text())['source_after_import']
for p in C.rglob('*'):
 if p.is_file() and p.name!='snapshot-receipt.json':
  rel=p.relative_to(C).as_posix()
  if '__pycache__' in p.parts:continue
  assert hashlib.sha256(p.read_bytes()).hexdigest()==(inv[rel] if rel in inv else post[rel])
s=importlib.util.spec_from_file_location('original',C/'tools/run_forest_depth_region.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
for p in sorted((R/'cases').glob('*/capture.json')):
 errors=m.validate(json.loads(p.read_text()));print(p.name,p.parent.name,errors);assert not errors
print('COLD ECOLOGY SELECTED OFFLINE:two accepted original captures; not native rerun or content approval')
