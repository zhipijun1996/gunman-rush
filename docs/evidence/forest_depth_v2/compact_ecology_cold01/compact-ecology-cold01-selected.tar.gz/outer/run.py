from pathlib import Path
import json,hashlib,time,subprocess,os,shutil,fcntl
R=Path('/workspace/gunman-rush-design');S=R/'build/forest_depth/snapshots/ecology_formal01';O=R/'build/forest_depth/region/ecology-cold01-outer';copy=json.loads((S/'build/snapshot-receipt.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r={'scope':'Actual new compact ecology B fast/growth from frozen recipe; cold CLI self-import proof, not gameplay/content admission','snapshot':str(S),'copy_receipt_sha256':sha(S/'build/snapshot-receipt.json'),'import_cap':90,'per_case_cap':240,'outer_cap':585,'argv':['python3','tools/run_forest_depth_region.py','--seed','forest-depth-hollow-02','--map','1','--routes','fast','growth','--output','build/forest_depth/region/ecology_formal01'],'status':'prepared'}
def save():(O/'receipt.json').write_text(json.dumps(r,indent=2)+'\n')
assert not (S/'build/forest_depth/region/ecology_formal01').exists();assert all(sha(S/p)==h for p,h in copy['source_files'].items());save()
try:
 with (R/'build/verification/engine.lock').open('a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX)
  cache=S/'.godot';r['cache_existed']=cache.exists();r['cache_files_before']={str(p.relative_to(cache)):sha(p) for p in cache.rglob('*') if p.is_file()} if cache.exists() else {}
  if cache.exists():shutil.rmtree(cache)
  r['cold_godot_absent_before_CLI']=not cache.exists();assert r['cold_godot_absent_before_CLI'];r['status']='running';save()
  env={**os.environ,'GUNMAN_TOOLCHAIN_ROOT':'/workspace/toolchains','GUNMAN_DATA_HOME':str(S/'build/ecology-cold-user'),'XDG_CONFIG_HOME':str(S/'build/ecology-cold-config'),'XDG_CACHE_HOME':str(S/'build/ecology-cold-cache'),'LP_NUM_THREADS':'1'};start=time.monotonic()
  with (O/'stdout.log').open('w') as stream:p=subprocess.run(r['argv'],cwd=S,env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=585)
  r.update(status='terminal',exit_code=p.returncode,seconds=time.monotonic()-start,stdout_sha256=sha(O/'stdout.log'));save();print(json.dumps({k:v for k,v in r.items() if k!='cache_files_before'}),flush=True)
except subprocess.TimeoutExpired:
 r['status']='outer_timeout';save();raise
finally:
 r['original_snapshot_source_unchanged']=all((S/p).is_file() and sha(S/p)==h for p,h in copy['source_files'].items());r['engine_released']=True;save();print('engine lock released',flush=True)
