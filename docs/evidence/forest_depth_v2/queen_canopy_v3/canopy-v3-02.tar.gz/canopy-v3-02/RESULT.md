# Canopy-v3 driver comprehension iteration02

Same2083 source domain as frozen01, **only existing runner changed**. Content,24HP/2HP, Player, weapon, H, damage, resource costs, validators, three-phase geometry and field/flight timing unchanged. All2083 match frozen overlay after actual runs. First cold90/native120/outer210 per selector; no script/parse/leak errors. LegacyQueen/all194 untouched. Root's later versions-reader correction is not retroactively attributed to this sealed01-based snapshot.

| Actual tactic | Native assertions | Kill / recovery tick | HP / energy |
|---|---:|---:|---:|
| H purpose: borrow, reverse gun-cut, R away |17/0|614 /625|4 /80|
| Ordinary keep: leave locked S for right root |18/0|500 /511|4 /65.5|
| Ordinary lure: occupy right first, induce right net, cut |19/0|876 /887|3 /100|

H: real receiver kick425 at(516.741,182.325), target(480,220), aim(−.698169,+.715933). Genuine projectile Policycommit427 reduces remaining knot1→0, not H callback auto-cut; R moves right/up off S. Receiver field cuts atage.566/growth0. The high knot remains1HP/live, not reset. One real Queenbody contact548, no receiver-net damage. Original01 four-hit/HP1 result remains unchanged.

Keep: observes actual phase3/field warning231 lockingS, normal movement leaves old S238. Two genuine horizontal R shots consume real guns/energy; right whole-foot12 confirmed314. Both living knots remain2HP and both fields persist. Continued real Boss shots kill500; bodycontact358 costs1HP. This proves a legal ordinary no-cut response, not the old01 unresponsive keep driver that died488.

Lure: high net is first genuinely shot clear; at200 Boss16HP the player voluntarily pauses Boss fire while all movement/attacks/fields continue. Normal two-R travel reaches right root whole-foot12 at282. Only after that resumes Boss fire; phase3 at324 records last full-footright and sampledPlayer(947.925,541.925). The actual new row is knot850410 / strand732540→948540, visibly different from S. Two genuine normal projectiles cut it during warning(age.45/growth0); no synthetic health lock or field clear. Bodycontacts224/357 leaveHP3. This route demonstrates controllability, but its current execution is slower and hurts more; not a superior strategy claim.

Old01 ordinary_cut remains an independently captured strong tactic:626kill/637support12,HP5/E100. It was not re-run merely to fill a matrix; its evidence is bound to01. H is slower than keep by114tick, has14.5 more final energy at equalHP4. Cut is safest/energy-full with slightly slower626 thanH614. These endpoints do not prove all-metric dominance or essential H. Independent review must judge actual optional movement, aim/recoil/cut causality and learning value, not hook counts or technical passes.

No final3phase quality, normal movie, save/fresh reload/malformed matrix, actual natural-entryApp, compatibility finalCI, audio/device or player acceptance is inferred. Those consumers remain separate future work. Native slot has been explicitly released; no further run is queued.
