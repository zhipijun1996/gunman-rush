from pathlib import Path
import json,gzip,shutil,hashlib
r=Path('/workspace/gunman-rush-design');o=r/'build/forest_depth/queen/canopy-v3-02';snap=r/'build/forest_depth/snapshots/queen-canopy-v3-02';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();audit={}
for st in ['purpose','ordinary_keep','lure']:
 raw=snap/('build/forest_depth/queen/canopy-v3-02-'+st);dest=o/'raw'/st;dest.mkdir(parents=True,exist_ok=True)
 for p in raw.iterdir():
  if p.suffix=='.json' and p.name in ['capture.json','partial.json']:
   with p.open('rb') as s,(dest/(p.name+'.gz')).open('wb') as t:
    with gzip.GzipFile(filename='',fileobj=t,mode='wb',mtime=0) as z:shutil.copyfileobj(s,z)
  else:shutil.copy2(p,dest/p.name)
 d=json.loads((raw/'capture.json').read_text());es=d['events'];audit[st]={'assertions':d['assertions'],'failures':d['failures'],'cases':d['cases'],'phases':[e for e in es if e.get('event')=='canopy_phase_started'],'fields':[e for e in es if e.get('event')=='canopy_field_preview'],'hook_contacts':[e for e in es if e.get('event')=='actual_hook_target_contact'],'player_damage':[e for e in es if e.get('event')=='policy_result' and e.get('target')=='player'],'knot_commits':[e for e in es if e.get('event')=='policy_result' and str(e.get('target')).startswith('queen/canopy')],'route_cues':[e for e in es if e.get('event') in ['receiver_reverse_cut_request','normal_shore_response_started','normal_shore_crossing_R','normal_new_shore_support12','lure_prepare_actual_right_support']]}
(o/'actual-audit.json').write_text(json.dumps(audit,indent=2)+'\n');cp=json.loads((snap/'build/snapshot-receipt.json').read_text());after={p:sha(snap/p) for p in cp['source_files']};assert after==cp['source_files'];(o/'full-source-post.json').write_text(json.dumps({'source_files':after,'all2083_equal':True},indent=2)+'\n');selected=o/'selected-source'
for p in json.loads((o/'source-checkpoint.json').read_text())['files']:
 target=selected/(p+'.txt');target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(snap/p,target)
shutil.copy2(r/'build/forest_depth/queen/canopy-v3-02-outer/receipt.json',o/'outer-receipt.json')
files={str(p.relative_to(o)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in o.rglob('*') if p.is_file() and p.name!='index.json'};(o/'index.json').write_text(json.dumps({'scope':'Driver comprehension only on same frozen01 content/validators: actual purpose reverse-cut, ordinary keep oldS change shore, lure different right row; technical only pending independent whole review','files':files,'actual_source':str(snap),'source_domain':2083,'old01_index_sha256':sha(r/'build/forest_depth/queen/canopy-v3-01/index.json'),'ordinary_cut_626_only_old01':True,'main_oldQueen194_unchanged':True,'caps':{'cold':90,'native':120,'outer':210}},indent=2)+'\n');print(json.dumps({'index_sha256':sha(o/'index.json'),'bytes':sum(v['bytes'] for v in files.values()),'files':len(files)}))
