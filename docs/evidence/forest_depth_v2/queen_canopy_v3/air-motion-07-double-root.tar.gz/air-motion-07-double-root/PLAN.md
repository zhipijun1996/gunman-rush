# B: dual broad roots — one bounded experimental batch

This is a real content reorganization, not a replay of04 or06.06 was never run. Main Queen/Player/Definition are unchanged.2063 authored paths copy from frozen04, overlay only existing runner/wrapper. Real Queen Motor/Policy/damage/refund contracts remain exact04. Full source guards and independent userdata apply.

Geometry: arena(400,0,560,600); floor(400,600,560,36); S(400,360,100,240)solid; rib(650,260,50,340)solid; right root(720,560,240,76)solid; cap(400,20,560,40)solid. S100/right root240 remain wide, left unused yard removed. A640300/B800250 unchanged. Low recovery Area2D575490 is a fixed optional non-solid anchor; it neither blocks Queen nor lies on either original H cast line. Both real BossArenaSeal walls must be closed/layer1 before controls; observed ID/shape data is recorded. This is an explicit initial gold fixture, not final natural entry.

Original A/B attack paths remain exact04, all actual movement360/second. C is separated into readable crown preview/path930110→426110→550110 and low-root preview/path550110→550550→530550→620550→550440. Each has original.65 preview, no tracking or teleport. Low sweep Queen bottom577 vs standing Player top564 overlaps13; sides506..644 leave6 to solids, floor clearance23. This is a one-loop24HP prototype, not final three phases.

Selectors, first failure stops:

1. `air_purpose`: original first H/backshotR/actual second H/second real airborne shot prefix, unchanged cue and input. New post-shot defense reads actual B body and normally jumps on broad right permanent root rather than trying old drop-through/idle. Original complete-loop/support12/HP>0/whole-body/500frame recovery guard retained. New arena bounds/floor heights replace original obsolete coordinates. Estimated full loop~719 leaves a narrow but original500frame post228 observation bound; real failure is preserved, not silently extended.
2. `air_ordinary`: initial full HP/resources/S12; normal jump, nine actual muzzle/Queen surface aiming and real refunds throughout migration, no total-shot limit. Normal movement must clear rib before pursuing right; low-floor ordinary full jump + one genuine downward R can attempt recovery to S, briefly pausing fire for that manoeuvre.1800frame actual full24HP kill+whole support12 remains required. No H.
3. `air_camp`: two separately initialized same-resource observations, crown/S and left-floor575582. Real ordinary approach/jump/shooting, local axis offsets recoil; max1200frames or two actual complete loops each, actual terminal permitted. Record true health/output/forced movement; no kill requirement for exposing stable safe output. No H.

Every selector retains cold import90/native120/outer210. Neither a tool failure nor a losing ordinary strategy proves H value. H04 only fired twice and cannot serve as a continuous-DPS comparison. This candidate can be dropped. Main production version, legacy194 and save/App integration are outside this batch.
