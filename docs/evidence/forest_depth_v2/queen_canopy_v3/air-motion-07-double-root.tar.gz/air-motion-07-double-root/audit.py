from pathlib import Path
import json,hashlib,gzip,shutil,collections
r=Path('/workspace/gunman-rush-design');o=r/'build/forest_depth/queen/air-motion-07-double-root';snap=r/'build/forest_depth/snapshots/queen-air-motion07-double-root';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();results={}
for selector in ['air_purpose','air_ordinary','air_camp']:
 raw=snap/('build/forest_depth/queen/air-motion-07-'+selector);d=json.loads((raw/'capture.json').read_text());caseaudit={}
 for row in d['cases']:
  name=row['id'];fs=[f for f in d['frames'] if f['case']==name];es=[e for e in d['events'] if e.get('case')==name];by={f['tick']:f for f in fs};shots=[e for e in es if e.get('event')=='accepted_shot'];hits=[e for e in es if e.get('event')=='policy_result' and e.get('target')=='boss'];harms=[e for e in es if e.get('event')=='policy_result' and e.get('target')=='player'];stood=[f for f in fs if f['grounded'] and abs(f['player'][1]-342)<1];common=collections.Counter((round(f['player'][0],2),round(f['player'][1],2)) for f in stood)
  caseaudit[name]={'row':row,'bounds_all':all(412<=f['player'][0]<=948 and 18<=f['player'][1]<=582 for f in fs),'actual_time_scale_values':sorted(set(f['actual_time_scale'] for f in fs)),'focus_any':any(f['actual_focus'] for f in fs),'shot_ticks':[e['tick'] for e in shots],'actual_boss_hit_ticks':[e['tick'] for e in hits],'actual_player_damage':harms,'boss_kill_tick':next((e['tick'] for e in hits if e['hp']==0),None),'standing_S_frames':len(stood),'standing_S_common':[{'center':list(k),'frames':v} for k,v in common.most_common(4)],'airborne_hit_refund_events':[e for e in es if e.get('event')=='air_actual_energy_recovery' and e.get('airborne')],'hook_contacts':[e for e in es if e.get('event')=='actual_hook_target_contact'],'closed_actual_walls':[e for e in es if e.get('event')=='air_actual_closed_wall']}
 results[selector]={'assertions':d['assertions'],'failures':d['failures'],'cases':caseaudit}
 dest=o/'raw'/selector;dest.mkdir(parents=True,exist_ok=True)
 for p in raw.iterdir():
  if p.suffix=='.json' and p.name.startswith(('capture','partial')):
   with p.open('rb') as s,(dest/(p.name+'.gz')).open('wb') as t:
    with gzip.GzipFile(filename='',fileobj=t,mode='wb',mtime=0) as z:shutil.copyfileobj(s,z)
  else:shutil.copy2(p,dest/p.name)
(o/'actual-audit.json').write_text(json.dumps(results,indent=2)+'\n');inventory=json.loads((o/'checkpoint-inventory.json').read_text());actual={p:sha(snap/p) for p in inventory};assert inventory==actual;(o/'post-native-full-inventory.json').write_text(json.dumps({'source_files':actual,'all2063_equal_checkpoint':True},indent=2)+'\n');selected=o/'selected-source'
for p in ['tests/thorn_queen_sweep_runner.gd','tools/run_thorn_queen_sweep.py','scripts/bosses/thorn_queen_v2.gd','tests/support/forest_queen_gameplay_fixture.gd','scripts/world/grapple_anchor.gd','scripts/combat/shot_energy_policy.gd']:
 target=selected/(p+'.txt');target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(snap/p,target)
files={str(p.relative_to(o)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in o.rglob('*') if p.is_file() and p.name!='index.json'};(o/'index.json').write_text(json.dumps({'scope':'B dual-root prototype three finite selectors technicalPASS; whole core REVISE due new S-edge safe ordinary kill; main untouched','files':files,'actual_sources':str(snap),'not_final_three_phase':True,'legacy05_fail_preserved':str(r/'build/forest_depth/queen/air-motion-05-controls/index.json'),'06_unexecuted':True},indent=2)+'\n');print(json.dumps({'index_sha':sha(o/'index.json'),'files':len(files),'bytes':sum(a['bytes'] for a in files.values()),'all2063_guard':True}))
