from pathlib import Path
import os,subprocess,hashlib,shutil,json,time,stat
root=Path('/workspace/gunman-rush-design'); dest=root/'build/forest_depth/snapshots/queen-canopy-v3-01'; seal=root/'build/forest_depth/snapshots/queen-air-motion07-double-root'; out=root/'build/forest_depth/queen/canopy-v3-01'
assert not dest.exists()
raw=subprocess.check_output(['git','ls-files','-z','--cached','--others','--exclude-standard'],cwd=root).decode().split('\0')
names=sorted({r for r in raw if r and not r.startswith(('build/','docs/','.git/','.agents/')) and (root/r).is_file()})
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();before={r:sha(root/r) for r in names};dest.mkdir(parents=True);links={}
for r,h in before.items():
 s=root/r;d=dest/r;d.parent.mkdir(parents=True,exist_ok=True);sealed=seal/r
 if r.startswith('assets/') and s.suffix.lower() in ('.png','.jpg','.jpeg','.webp','.ogg','.wav','.ttf','.woff','.woff2','.otf') and sealed.is_file() and sha(sealed)==h and stat.S_IMODE(s.stat().st_mode)==stat.S_IMODE(sealed.stat().st_mode):
  os.link(sealed,d);links[r]=str(sealed)
 else:shutil.copy2(s,d)
 assert sha(d)==h,r
assert before=={r:sha(root/r) for r in names}
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();subprocess.run(['git','init','--quiet',str(dest)],check=True);objects=subprocess.check_output(['git','rev-parse','--path-format=absolute','--git-path','objects'],cwd=root,text=True).strip();(dest/'.git/objects/info/alternates').write_text(objects+'\n');subprocess.run(['git','update-ref','--no-deref','HEAD',head],cwd=dest,check=True);subprocess.run(['git','read-tree','HEAD'],cwd=dest,check=True);(dest/'.git/info/exclude').write_text('build/\n.godot/\n');(dest/'build').mkdir()
r={'scope':'Actual current main complete runtime/test/tools, new canopy production13 + root v10/legacy compatibility delta; no overlay, no admission','base_commit':head,'source_root':str(root),'snapshot_root':str(dest),'source_files':before,'shared_media_links':links,'source_copy_guard':True,'created':time.time()};(dest/'build/snapshot-receipt.json').write_text(json.dumps(r,indent=2)+'\n');(out/'copy-receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'files':len(names),'guard':True,'snapshot':str(dest)}))
