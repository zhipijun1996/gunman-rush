from pathlib import Path
import os,json,subprocess,time,hashlib
R=Path('/workspace/gunman-rush-design');S=R/'build/forest_depth/snapshots/cavity_v4_02';O=R/'build/forest_depth/traversal/cavity_v4_02'
env={**os.environ,'GUNMAN_TOOLCHAIN_ROOT':'/workspace/toolchains','GUNMAN_DATA_HOME':str(S/'build/userdata'),'XDG_CONFIG_HOME':str(S/'build/userconfig'),'XDG_CACHE_HOME':str(S/'build/usercache')}
cases=[['--seed','forest-depth-hollow-02','--map','2','--route','growth','--output','build/forest_depth/region/v4-leftloop-golden'],['--matrix','--output','build/forest_depth/region/v4-leftloop-matrix']]
r={'scope':'Fresh v4 real left camp loop and invalid-safe cache observer: cache0growth first; only if PASS original16. Prior death/ERROR source preserved, not latest final ecology/player proof.','snapshot':str(S),'snapshot_receipt_sha256':hashlib.sha256((S/'build/snapshot-receipt.json').read_bytes()).hexdigest(),'runs':[],'status':'running'}
def save():(O/'outer-receipt.json').write_text(json.dumps(r,indent=2)+'\n')
save();start=time.monotonic()
try:
 for i,args in enumerate(cases):
  argv=['python3','tools/run_forest_depth_region.py']+args;row={'argv':argv,'outer_cap_seconds':4000 if i==1 else 355};r['runs'].append(row);save();t=time.monotonic()
  with (O/f'outer{i:02d}.log').open('w') as log:p=subprocess.run(argv,cwd=S,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=row['outer_cap_seconds'])
  row['exit_code']=p.returncode;row['seconds']=time.monotonic()-t;save()
  if p.returncode!=0:break
 r['status']='passed'if len(r['runs'])==2 and all(x['exit_code']==0 for x in r['runs'])else'failed'
except subprocess.TimeoutExpired:r['timed_out']=True;r['status']='timeout'
finally:
 r['seconds']=time.monotonic()-start;r['all_original_snapshot_sources_unchanged']=all((S/k).is_file()and hashlib.sha256((S/k).read_bytes()).hexdigest()==v for k,v in json.loads((S/'build/snapshot-receipt.json').read_text())['source_files'].items());save()
raise SystemExit(0 if r['status']=='passed'and r['all_original_snapshot_sources_unchanged']else 1)
