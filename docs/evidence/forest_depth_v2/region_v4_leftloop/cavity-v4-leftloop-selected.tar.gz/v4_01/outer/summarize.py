from pathlib import Path
import json,hashlib
R=Path('/workspace/gunman-rush-design');S=R/'build/forest_depth/snapshots/cavity_v4_01';O=R/'build/forest_depth/traversal/cavity_v4_01';B=S/'build/forest_depth/region';result={'scope':'Actual v4 high finalapproach snapshot: three goldens then original16. Snapshot predates same-height west618 enemy candidate; not that newer ecology, Boss fight, fullrelease or player/device proof. v3 evidence separate.','snapshot':str(S),'groups':[]}
for name in ['v4-golden00','v4-golden01','v4-golden02','v4-matrix']:
 P=B/name
 if not (P/'receipt.json').exists():
  result['groups'].append({'name':name,'status':'not_run_first_failure_stop','cases':[]});continue
 r=json.loads((P/'receipt.json').read_text());g={'name':name,'status':r['status'],'source_stable':r.get('source_stable'),'receipt_sha256':hashlib.sha256((P/'receipt.json').read_bytes()).hexdigest(),'cases':[]}
 for i,row in enumerate(r['runs']):
  p=P/f'{i:02d}-map{row["map"]}-{row["route"]}'/'capture.json';d=json.loads(p.read_text());damage=[e for e in d['events']if e['kind']=='committed_damage' and e.get('target')=='player'];clegs=[e for e in d['completed_legs']if e['edge_id']=='borer_crossing'];cf=next((f for f in d['frames']if clegs and f['tick']==clegs[0]['tick']),None)
  g['cases'].append({'seed':row['seed'],'map':row['map'],'route':row['route'],'status':row['status'],'errors':row['errors'],'frames':len(d['frames']),'family':d['manifest'].get('family'),'choices':d['manifest']['choices'],'claimed_ids':d.get('claimed_ids',[]) ,'cache_claimed':d['cache_claimed'],'pointer_events':d['pointer_events'],'modal_frames':len(d['modal_frames']),'duplicate_checked':d['duplicate_checked'],'gate_saved_open':d.get('gate_saved_open'),'gate_shape_disabled':d.get('gate_shape_disabled'),'final_health':d['frames'][-1]['health'],'damage':damage,'cavity_C':{'tick':cf['tick'],'energy':cf['energy'],'shots':cf['shots'],'health':cf['health']}if cf else None,'capture':str(p),'capture_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'actual_north_belly_steps':[e for e in d['completed_legs']if e['edge_id']=='north_belly']})
 result['groups'].append(g)
result['cache1_true_claim_cases']=[{'seed':c['seed'],'map':c['map'],'route':c['route'],'ids':c['claimed_ids']}for g in result['groups']for c in g['cases']if c['choices'].get('cache_route')==1 and c['cache_claimed'] and len(c['pointer_events'])==2 and c['modal_frames']>=5 and c['duplicate_checked']]
(O/'actual-results.json').write_text(json.dumps(result,indent=2)+'\n');print([(g['name'],g['status'],len(g['cases']))for g in result['groups']]);print('cache1_claims',len(result['cache1_true_claim_cases']))
