"""Fresh double-window real-input golden and cheap alternatives, NOT region promotion.

Run only in a guarded runtime snapshot under the host's shared engine lock.
First budget: import 90s; four native processes share ONE total 90s deadline.
"""
import argparse
import contextlib
import hashlib
import json
from pathlib import Path
import re
import subprocess
import time

import level_formal
from run_tests import run_engine
from run_forest_directional_golden import _resource_errors

ROOT = Path(__file__).resolve().parents[1]
VARIANTS = ('intended', 'noH_oneR', 'noH_twoR', 'miss_retry')
OWN = ('scripts/generation/forest_hollow_trunk_geometry.gd',
       'scripts/demo/forest_hollow_trunk_golden.gd',
       'tests/forest_hollow_trunk_runner.gd', 'tools/run_forest_hollow_trunk.py')


def validate(data):
    errors = []
    frames = data.get('frames', [])
    if len(frames) < 30:
        return ['complete continuous body trace required']
    if data.get('midroute_injection') is not False or data.get('manual_motor_step') is not False:
        errors.append('real normal-input consumer required')
    if data.get('audio_released') is not True:
        errors.append('audio not drained')
    if data.get('initial_hp') != data.get('final_hp') or data.get('damage_events') or data.get('policy_returns'):
        errors.append('candidate recovery must be natural, without health/segment return')
    platforms = {row['id']: row for row in data['manifest']['platforms']}
    for i, frame in enumerate(frames):
        if frame.get('tick') != i+1 or frame.get('motor_steps') != 1:
            errors.append('continuous actual single Motor step trace required')
            break
        x, y = frame['position']
        if frame.get('body') != [x-12, y-18, 24, 36]:
            errors.append('full production 24x36 body missing')
            break
        for key in frame.get('supports', []):
            px, py, w, _ = platforms[key]['rect']
            if not frame['grounded'] or abs(y+18-py)>1 or x+12<px or x-12>px+w:
                errors.append('support flag disagrees with actual body and platform')
    tuning = json.loads((ROOT/'config/player_tuning.json').read_text())
    errors += _resource_errors(frames, data.get('events', []), tuning)
    variant = data.get('variant')
    if variant.startswith('noH') and (any(e['kind']=='hook_cast' for e in data['events']) or any(f.get('hook_enabled') is not False for f in frames)):
        errors.append('noH comparison actually cast H')
    if variant in ('intended', 'miss_retry'):
        if data.get('failure') or not all(data.get(k) is True for k in ('reached','returned','lower_entered')):
            errors.append('complete upper outward/lower return/belly loop required')
        hook_targets = {e.get('target') for e in data['events'] if e['kind']=='hook_kick'}
        if not {'upper_window_ring','lower_window_ring'} <= hook_targets:
            errors.append('both actual window hook contacts required')
        if not any(e['kind']=='shot_fired' and e['direction'][0]<-.9 for e in data['events']):
            errors.append('actual rightward recoil shot required')
        if not any(e['kind']=='shot_fired' and e['direction'][0]>.9 for e in data['events']):
            errors.append('actual leftward recoil shot required')
        if variant=='miss_retry' and not (data.get('recovered') and data.get('retried')):
            errors.append('intentional miss must naturally recover and retry complete loop')
    # Cheap alternatives retain their actual success OR failure; not forced to lose.
    elif data.get('failure'):
        errors.append('comparison did not finish a bounded recoverable observation: '+data['failure'])
    return sorted(set(errors))


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir', default='build/forest_depth/hollow_trunk/native01')
    args=parser.parse_args()
    out=(ROOT/args.output_dir).resolve()
    if not out.is_relative_to(ROOT/'build/forest_depth/hollow_trunk') or out.exists():
        parser.error('Fresh output below build/forest_depth/hollow_trunk required')
    out.mkdir(parents=True)
    before=level_formal.source_files()
    own={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in OWN}
    snapshot=json.loads((ROOT/'build/snapshot-receipt.json').read_text())
    receipt={'scope':'New double-window development golden; not full region/content/device/player acceptance',
             'new_first_budgets_seconds':{'import':90,'all_native_combined':90},
             'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
             'source_before':before,'producer_before':own,'cases':[],'passed':False}
    started=time.monotonic()
    try:
        with (out/'import.log').open('w') as log, contextlib.redirect_stdout(log):
            import_text=run_engine(['--headless','--path','.','--editor','--quit'],90)
        if re.search(r'(?m)^ERROR:|SCRIPT ERROR:|SHADER ERROR:',import_text):
            raise RuntimeError('Strict native import ERROR')
        deadline=time.monotonic()+90
        for variant in VARIANTS:
            row={'variant':variant,'passed':False}
            receipt['cases'].append(row)
            argv=['--headless','--fixed-fps','60','--path','.', '--script',
                  'tests/forest_hollow_trunk_runner.gd','--','--variant='+variant,
                  '--output=res://'+str((out/(variant+'.json')).relative_to(ROOT))]
            row['argv']=argv
            try:
                with (out/(variant+'.log')).open('w') as log, contextlib.redirect_stdout(log):
                    remaining=deadline-time.monotonic()
                    if remaining<=0: raise RuntimeError('Original combined native90 budget exhausted')
                    text=run_engine(argv,remaining)
                if re.search(r'(?m)^ERROR:|SCRIPT ERROR:|SHADER ERROR:',text):
                    raise RuntimeError('Strict native ERROR')
                if not re.search(r'^FOREST HOLLOW: '+re.escape(variant)+r' terminal ',text,re.M):
                    raise RuntimeError('actual terminal marker absent')
                data=json.loads((out/(variant+'.json')).read_text())
                row['validation_errors']=validate(data)
                row['passed']=not row['validation_errors']
                row['outcome']={k:data.get(k) for k in ('reached','returned','recovered','lower_entered','failure')}
                row['frames']=len(data['frames'])
            except Exception as error:
                row['error']=str(error)
                # Stop at first actual execution failure; keep native JSON/log exactly.
                raise
        receipt['passed']=all(row['passed'] for row in receipt['cases'])
        if not receipt['passed']:
            raise RuntimeError('Actual hollow-trunk comparison rejected; see per-case validation errors')
    finally:
        receipt['elapsed_seconds']=time.monotonic()-started
        receipt['source_after']=level_formal.source_files()
        receipt['producer_after']={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in OWN}
        receipt['source_guard']=before==receipt['source_after'] and own==receipt['producer_after']
        receipt['snapshot_all_raw_bytes_unchanged']=all((ROOT/p).is_file() and hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==v for p,v in snapshot['source_files'].items())
        receipt['logs']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir() if p.is_file()}
        (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
        if not receipt['source_guard'] or not receipt['snapshot_all_raw_bytes_unchanged']:
            raise RuntimeError('Source changed during hollow golden')
    print('PASS: new hollow-trunk real-input loop/comparisons only; NOT full region')


if __name__=='__main__':
    main()
