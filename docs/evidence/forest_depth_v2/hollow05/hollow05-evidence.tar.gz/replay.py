from pathlib import Path
import ast,hashlib,json,math,re
R=Path(__file__).resolve().parent
index=json.loads((R/'members.json').read_text())
for name,row in index.items():assert hashlib.sha256((R/name).read_bytes()).hexdigest()==row['sha256'],name
ctx={'ROOT':R/'frozen05','json':json,'math':math,'re':re}
for file,name in [('tools/run_forest_directional_golden.py','_resource_errors'),('tools/run_forest_hollow_trunk.py','validate')]:
 source=ast.parse((R/'frozen05'/file).read_text());node=next(n for n in source.body if isinstance(n,ast.FunctionDef) and n.name==name);exec(compile(ast.Module(body=[node],type_ignores=[]),file,'exec'),ctx)
for variant in ['airH_recoil','deepH_zeroR','return_R','return_none']:
 d=json.loads((R/'native05'/(variant+'.json')).read_text());errors=ctx['validate'](d);assert not errors,(variant,errors)
 assert all(f['tick']==i+1 and f['motor_steps']==1 and all(abs(a-b)<.001 for a,b in zip(f['body'],[f['position'][0]-12,f['position'][1]-18,24,36])) for i,f in enumerate(d['frames']))
 print(variant,len(d['frames']),errors)
report=json.loads((R/'independent-review/recomputed.json').read_text())
for variant,row in report['cases'].items():
 assert not row['solid_body_penetrations'] and not row['unexplained_large_displacement_ticks'] and not row['energy_charge_replay_error_ticks']
 assert hashlib.sha256((R/'native05'/(variant+'.json')).read_bytes()).hexdigest()==row['raw_sha256']
assert report['cases']['return_none']['full_support_runs']['outer_root']==[[147,152,6]]
assert report['cases']['deepH_zeroR']['frames']-report['cases']['return_R']['frames']==39
movie=json.loads((R/'movie05/capture.json').read_text());native=json.loads((R/'native05/deepH_zeroR.json').read_text())
assert all(movie[k]==native[k] for k in ['frames','events','requests','manifest'])
for n in range(1,5):assert json.loads((R/('history%02d/native/receipt.json'%n)).read_text())['passed'] is False
print('HOLLOW05 PORTABLE OFFLINE REPLAY: passed; original01-04 rejection retained; none6 is not12; no engine')
