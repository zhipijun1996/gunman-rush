from pathlib import Path
import json,hashlib,math,re,subprocess
R=Path('/workspace/gunman-rush-design');S=R/'build/forest_depth/snapshots/hollow05';B=S/'build/forest_depth/hollow_trunk';O=R/'build/forest_depth/traversal/hollow05-independent'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
T=json.load(open(S/'config/player_tuning.json'))
resource=(S/'resources/player/plains_shot_energy.tres').read_text();definition=(S/'scripts/resources/definitions/shot_energy_definition.gd').read_text()
def number(name):
 match=re.search(r'(?m)^'+name+r'\s*=\s*([\d.]+)',resource) or re.search(r'var '+name+r'\s*:=\s*([\d.]+)',definition)
 return float(match.group(1))
E={name:number(name) for name in ['capacity','initial_current','shot_energy_cost','ground_recovery','recovery_delay']}

def pointseg(p,a,b):
 v=[b[i]-a[i] for i in (0,1)];n=sum(x*x for x in v);t=max(0,min(1,sum((p[i]-a[i])*v[i] for i in (0,1))/n)) if n else 0
 return math.dist(p,[a[i]+v[i]*t for i in (0,1)])
def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
def segseg(a,b,c,d):
 if cross(a,b,c)*cross(a,b,d)<0 and cross(c,d,a)*cross(c,d,b)<0:return 0
 return min(pointseg(a,c,d),pointseg(b,c,d),pointseg(c,a,b),pointseg(d,a,b))
def rectdist(a,b,r):
 x,y,w,h=r;corners=[[x,y],[x+w,y],[x+w,y+h],[x,y+h]]
 if any(x<=p[0]<=x+w and y<=p[1]<=y+h for p in [a,b]):return 0
 return min(segseg(a,b,corners[i],corners[(i+1)%4]) for i in range(4))
def support(f,p):
 x,y=f['position'];px,py,w,_=p['rect'];return f['grounded'] and x-12>=px-.001 and x+12<=px+w+.001 and abs(y+18-py)<1 and p['id'] in f['supports']
def runs(frames,p):
 out=[];seq=[]
 for f in frames:
  if support(f,p):seq.append(f)
  elif seq:out.append(seq);seq=[]
 if seq:out.append(seq)
 return out
out={'scope':'Independent read-only raw/body/query/source recomputation, no native or author-checker edits','cases':{}}
receipt=json.load(open(B/'native01/receipt.json'));sr=json.load(open(S/'build/snapshot-receipt.json'));mr=json.load(open(B/'movie05/receipt.json'))
out['source_checks']={'all_snapshot_source_files_match':all((S/p).is_file() and sha(S/p)==h for p,h in sr['source_files'].items()),'snapshot_file_count':len(sr['source_files']),'native_source_before_after_equal':receipt['source_before']==receipt['source_after'],'native_own_before_after_equal':receipt['producer_before']==receipt['producer_after'],'movie_source_before_after_equal':mr['source_before']==mr['source_after'],'native_movie_common_source_equal':all(mr['source_before'][p]==h for p,h in receipt['source_before'].items() if p in mr['source_before']),'native_raw_log_hashes_match':all(sha(B/'native01'/p)==h for p,h in receipt['logs'].items()),'movie_files_hashes_match':all(sha(B/'movie05'/p)==x['sha256'] for p,x in mr['files'].items()),'current_producer_hashes':{p:sha(S/p) for p in receipt['producer_before']},'native_receipt_sha256':sha(B/'native01/receipt.json'),'movie_receipt_sha256':sha(B/'movie05/receipt.json')}
all_data={}
for variant in ['airH_recoil','deepH_zeroR','return_R','return_none']:
 d=json.load(open(B/'native01'/(variant+'.json')));all_data[variant]=d;f=d['frames'];ps=d['manifest']['platforms'];begin=d['return_start_tick'];by={z['tick']:z for z in f}
 overlaps=[];delta=[];ground_partial=[]
 for z in f:
  x,y=z['position']
  for p in ps:
   if p['one_way']:continue
   px,py,w,h=p['rect'];ix=min(x+12,px+w)-max(x-12,px);iy=min(y+18,py+h)-max(y-18,py)
   if min(ix,iy)>.2:overlaps.append([z['tick'],p['id'],ix,iy])
  if z['grounded'] and not z['supports']:ground_partial.append(z['tick'])
 for a,b in zip(f,f[1:]):
  if math.dist(a['position'],b['position'])>1150/60+.25:delta.append(b['tick'])
 windows={}
 for p in ps:
  rr=runs(f,p)
  if rr:windows[p['id']]=[[x[0]['tick'],x[-1]['tick'],len(x)] for x in rr]
 events=d['events'];cast=[e for e in events if e['kind']=='hook_cast'];statechains=[]
 for e in cast:
  start=e['tick'];end=next(x['tick'] for x in events if x['kind']=='free' and x['tick']>start);ev=[x for x in events if start<=x['tick']<=end and x['kind'].startswith('hook_') or x['kind']=='free' and x['tick']==end]
  request=next(q for q in d['requests'] if q['kind']=='grapple' and q['tick']==start);assert request['queued']
  sf=by[start];pos=e['position'];origin=[pos[0],pos[1]-6];target=next(x for x in ev if x['kind']=='hook_pull')['target'];anchor=next(x['position'] for x in d['manifest']['hook_anchors'] if x['id']==target);dist=math.dist(origin,anchor);assert math.dist(request['direction'],[(anchor[i]-origin[i])/dist for i in [0,1]])<.002
  if start>begin:
   path=[];last=sf['hook_start']
   for z in f:
    if z['tick']<=start:continue
    if z['tick']>next(x['tick'] for x in ev if x['kind']=='hook_pull'):break
    if z['hook_tip']!=last:
     if z['probe_contacts'] and z['hook_state']=='hook_pull':a=z['probe_contacts'][0]['source'];b=z['probe_contacts'][0]['finish']
     else:a=last;b=z['hook_tip']
     path.append((a,b));last=z['hook_tip']
   clearance=min(rectdist(a,b,p['rect'])-12 for a,b in path for p in ps)
   # This concerns collision-head centre sweeps, not a fresh ray from fallingbody.
   statechains.append({'cast_tick':start,'request_origin':origin,'target':target,'target_distance':dist,'hook_start_fixed_until_hit':all(by[t]['hook_start']==origin for t in range(start,next(x['tick'] for x in ev if x['kind']=='hook_pull')+1)),'actual_events':[{'kind':x['kind'],'tick':x['tick'],'position':x['position'],'target':x.get('target')} for x in ev],'capsule_radius':12,'min_head_capsule_clearance_solid':clearance,'sweeps':path,'actual_final_query_contacts':by[next(x['tick'] for x in ev if x['kind']=='hook_pull')]['probe_contacts']})
 rr=[e for e in events if e['kind']=='shot_fired' and e['tick']>begin]
 # Independent exact no-enemy energy/charge replay with actual controller ordering.
 energy=E['initial_current'];delay=0.;charges=T['max_air_shots'];prev_ground=False;resource_errors=[];dt=1/T['physics_hz']
 for z in f:
  shots=[e for e in events if e['tick']==z['tick'] and e['kind']=='shot_fired'];jumped=any(e['kind']=='jumped' and e['tick']==z['tick'] for e in events);recovery=max(0,dt-delay);delay=max(0,delay-dt)
  if prev_ground:energy=min(E['capacity'],energy+E['ground_recovery']*recovery)
  started=prev_ground and not jumped
  for e in shots:
   energy-=E['shot_energy_cost'];delay=E['recovery_delay']
   if not started:charges-=1
   assert any(q['kind']=='shoot_release' and q['tick']==z['tick'] and q['queued'] and math.dist(q['direction'],e['direction'])<.001 for q in d['requests'])
  if z['grounded']:charges=T['max_air_shots']
  elif started:charges=max(0,charges-len(shots))
  if abs(energy-z['energy'])>.001 or charges!=z['shots']:resource_errors.append(z['tick'])
  prev_ground=z['grounded']
 departure=next(e for e in events if e.get('to')=='air_descent');depart=by[departure['tick']]
 out['cases'][variant]={'raw_sha256':sha(B/'native01'/(variant+'.json')),'frames':len(f),'return_start_tick':begin,'return_observed_ticks':len(f)-begin,'reached':d['reached'],'returned':d['returned'],'lower_entered':d['lower_entered'],'direct_recovered':d['direct_recovered'],'actual_health':[d['initial_hp'],d['final_hp']],'policy_damage':d['damage_events'],'policy_returns':d['policy_returns'],'continuous_ticks_and_single_motor':all(z['tick']==i+1 and z['motor_steps']==1 for i,z in enumerate(f)),'complete_body_payload_matches':all(all(abs(a-b)<.001 for a,b in zip(z['body'],[z['position'][0]-12,z['position'][1]-18,24,36])) for z in f),'solid_body_penetrations':overlaps,'unexplained_large_displacement_ticks':delta,'partial_grounded_ticks':ground_partial,'full_support_runs':windows,'same_departure_fields':{k:depart[k] for k in ['position','velocity','health','energy','shots']},'return_shots':[e['tick'] for e in rr],'actual_hook_chains_return':statechains,'energy_charge_replay_error_ticks':resource_errors,'body_offscreen_ticks':[z['tick'] for z in f if not z['body_on_screen']]}
movie=json.load(open(B/'movie05/capture.json'));out['movie_raw_matches_native']={k:movie[k]==all_data['deepH_zeroR'][k] for k in ['frames','events','requests','manifest']};out['movie_decoding']={'frames':329,'fps':60,'duration':329/60,'mp4_sha256':sha(B/'movie05/gameplay.mp4'),'movie_log_version':'Godot4.7.2.stable.official.ed1daf0bf; GLcompat Mesa llvmpipe','voice_audio_device_unverified':True}
old=json.load(open(O/'recomputed.json')) if (O/'recomputed.json').exists() else {}
old.update(out);out=old
(O/'recomputed.json').write_text(json.dumps(out,indent=2)+'\n')
print('source',out['source_checks']);print({v:{k:x[k] for k in ['frames','solid_body_penetrations','unexplained_large_displacement_ticks','energy_charge_replay_error_ticks']} for v,x in out['cases'].items()});print('head',[x['actual_hook_chains_return'] for x in out['cases'].values()]);print('movie',out['movie_raw_matches_native'])
