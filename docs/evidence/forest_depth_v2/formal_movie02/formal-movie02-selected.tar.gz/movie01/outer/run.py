from pathlib import Path
import os,json,subprocess,time,hashlib
R=Path('/workspace/gunman-rush-design');S=R/'build/forest_depth/snapshots/formal_movie01';O=R/'build/forest_depth/traversal/formal_movie01';binary=Path('/workspace/toolchains/godot/4.7.2/Godot_v4.7.2-stable_linux.x86_64')
env={**os.environ,'GUNMAN_TOOLCHAIN_ROOT':'/workspace/toolchains','GUNMAN_DATA_HOME':str(S/'build/userdata'),'XDG_CONFIG_HOME':str(S/'build/userconfig'),'XDG_CACHE_HOME':str(S/'build/usercache')}
argv=['python3','tools/run_forest_depth_region.py','--seed','forest-depth-hollow-00','--map','2','--route','growth','--movie','--output','build/forest_depth/region/formal-movie01']
r={'scope':'One actual formal DemoApp map2 root00 growth continuous exploration. Includes C and real pointer reward to Bossgate, NOT change_mind branch or Boss fight/player/device/audio approval.','snapshot':str(S),'snapshot_receipt_sha256':hashlib.sha256((S/'build/snapshot-receipt.json').read_bytes()).hexdigest(),'engine_binary':{'path':str(binary),'sha256':hashlib.sha256(binary.read_bytes()).hexdigest()},'argv':argv,'wrapper_outer_cap_seconds':425,'status':'running'}
def save():(O/'outer-receipt.json').write_text(json.dumps(r,indent=2)+'\n')
save();t=time.monotonic()
try:
 with (O/'outer.log').open('w')as log:p=subprocess.run(argv,cwd=S,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=425)
 r['exit_code']=p.returncode;r['status']='passed'if p.returncode==0 else'failed'
except subprocess.TimeoutExpired:r['status']='timeout';r['timed_out']=True
finally:
 r['seconds']=time.monotonic()-t;r['all_snapshot_sources_unchanged']=all((S/k).is_file()and hashlib.sha256((S/k).read_bytes()).hexdigest()==v for k,v in json.loads((S/'build/snapshot-receipt.json').read_text())['source_files'].items());save()
raise SystemExit(0 if r['status']=='passed'and r['all_snapshot_sources_unchanged']else 1)
