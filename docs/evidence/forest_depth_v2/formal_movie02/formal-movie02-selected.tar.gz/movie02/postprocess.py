import sys
sys.path.pop(0)
from pathlib import Path
import json,subprocess,hashlib,time
R=Path('/workspace/gunman-rush-design');S=R/'build/forest_depth/snapshots/formal_movie02';O=R/'build/forest_depth/traversal/formal_movie02';B=S/'build/forest_depth/region/formal-movie02';P=B/'00-map2-growth';r=json.loads((B/'receipt.json').read_text());assert r['status']=='passed'and r['source_stable'];d=json.loads((P/'capture.json').read_text());avi=P/'gameplay.avi';mp4=O/'gameplay.mp4';assert not mp4.exists()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
argv=['ffmpeg','-hide_banner','-loglevel','error','-i',str(avi),'-c:v','libx264','-threads','1','-preset','veryfast','-crf','20','-pix_fmt','yuv420p','-c:a','aac','-movflags','+faststart',str(mp4)]
t=time.monotonic();subprocess.run(argv,check=True,timeout=90)
probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames','-show_streams','-show_format','-of','json',str(mp4)],timeout=30));video=next(x for x in probe['streams']if x['codec_type']=='video');assert video['avg_frame_rate']=='60/1';assert int(video['nb_read_frames'])==r['runs'][0]['movie']['frames']
choices=[]
def add(row,label):
 if row:choices.append({'presentation_frame':row['presentation_frame'],'movie_seconds':row['presentation_frame']/60,'tick':row.get('tick'),'label':label,'actual_row':row})
add(d['frames'][0],'first_observed_physics')
for target in ['north_court_ring','hollow__cavity_ring_a','hollow__cavity_ring_b','crown_approach_ring_0']:
 add(next((e for e in d['events']if e['kind']=='hook_contact_kick'and e.get('target')==target),None),'actual_H_contact/'+target)
add(next((e for e in d['events']if e['kind']=='hollow_port_departure'and e.get('port')=='S'),None),'supported_S_observation')
add(next((e for e in d['events']if e['kind']=='cavity_bay_support'),None),'supported_bay_before_H2')
add(next((e for e in d['events']if e['kind']=='hollow_port_arrival'and e.get('port')=='C'),None),'actual_C_arrival')
for i,e in enumerate([e for e in d['events']if e['kind']=='shot_fired'][:2]):add(e,'actual_recoil/'+str(i))
if d['modal_frames']:add(d['modal_frames'][2],'real_frozen_pointer_modal')
if d['pointer_events']:add(d['pointer_events'][-1],'actual_pointer_release')
add(d['frames'][-1],'last_observed_supported_gate')
by_frame={}
for c in choices:by_frame.setdefault(c['presentation_frame'],[]).append(c)
K=O/'keyframes';K.mkdir(exist_ok=False);frames=sorted(by_frame);vf='select='+ '+'.join(f'eq(n\\,{n})'for n in frames)
extract=['ffmpeg','-hide_banner','-loglevel','error','-i',str(avi),'-vf',vf,'-fps_mode','vfr','-frames:v',str(len(frames)),str(K/'frame_%02d.png')];subprocess.run(extract,check=True,timeout=60)
index=[]
for i,n in enumerate(frames,1):
 p=K/f'frame_{i:02d}.png';assert p.is_file();index.append({'path':str(p),'sha256':sha(p),'presentation_frame':n,'movie_seconds':n/60,'labels':by_frame[n]})
(K/'index.json').write_text(json.dumps({'scope':'Actual decoded AVI frame indices using recorded Engine.get_frames_drawn; physics tick is independent. Pixel identity and renderer startup offset require actual view; not audio/player/device acceptance.','frames':index,'extraction_argv':extract},indent=2)+'\n')
metadata={'scope':'One continuous original formal DemoApp growth; includes real C reward to gate, no change_mind return/Boss fight. Normal60fps playback, software renderer walltime not claimed real-time. No audio listening/device/player approval.','encoder_argv':argv,'seconds':time.monotonic()-t,'mp4_ffprobe':probe,'mp4':{'path':str(mp4),'sha256':sha(mp4),'bytes':mp4.stat().st_size},'avi':{'path':str(avi),'sha256':sha(avi),'bytes':avi.stat().st_size},'capture_sha256':sha(P/'capture.json'),'native_log_sha256':sha(P/'native.log'),'original_movie_metadata':r['runs'][0]['movie'],'first_last_physics':[d['frames'][0],d['frames'][-1]],'first_last_requests':[d['requests'][0],d['requests'][-1]],'keyframe_index_sha256':sha(K/'index.json')};(O/'media-receipt.json').write_text(json.dumps(metadata,indent=2)+'\n');print(json.dumps({'mp4':metadata['mp4'],'frames':int(video['nb_read_frames']),'keys':len(index)}))
