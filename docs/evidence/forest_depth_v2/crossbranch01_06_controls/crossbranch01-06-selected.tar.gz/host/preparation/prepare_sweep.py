import json,math
from pathlib import Path
root=Path('/workspace/gunman-rush-design')
f=root/'build/forest_depth/snapshots/region_v7_movie01/build/forest_depth/region/v7-growth-movie01/00-map2-growth/capture.json'
d=json.loads(f.read_text());rects=[(p['id'],p['rect'],p.get('one_way',False)) for p in d['manifest']['platforms']]
rects += [('candidate_reward',[-610,268,290,24],True),('candidate_lower_return',[-220,618,140,24],True)]
a=(76.,452.);b=(-350.,252.);half=(14.,16.);legs=[]
for start,end,vy in [(a,b,-540.),(b,a,-220.)]:
 t=(-vy+math.sqrt(vy*vy+2*620*(end[1]-start[1])))/620;vx=(end[0]-start[0])/t
 rows=[];hits=[];clearance=[]
 for i in range(math.ceil(t*60)+1):
  sec=min(i/60,t);x=start[0]+vx*sec;y=start[1]+vy*sec+310*sec*sec;vely=vy+620*sec
  for id,r,ow in rects:
   overlap=x+14>r[0]+1e-6 and x-14<r[0]+r[2]-1e-6 and y+16>r[1]+1e-6 and y-16<r[1]+r[3]-1e-6
   if overlap and (not ow or vely>0):hits.append({'frame':i,'id':id,'position':[x,y],'one_way':ow})
  # Complete body to actual proposed reward disk; excludes only endpoint safe circle none.
  cx,cy=-525.,250.;dx=max(x-14-cx,0,cx-(x+14));dy=max(y-16-cy,0,cy-(y+16));clearance.append(math.hypot(dx,dy))
  rows.append({'frame':i,'t':sec,'position':[x,y],'velocity':[vx,vely]})
 legs.append({'start':start,'end':end,'vy':vy,'vx':vx,'analytic_duration':t,'sample_frames':rows,'intersections':hits,'minimum_cache_body_distance':min(clearance)})
o=root/'build/forest_depth/ecology/f2-crossbranch01';o.mkdir(parents=True,exist_ok=True);(o/'static-sweep.json').write_text(json.dumps({'scope':'Analytic center/body samples at 60Hz, NOT Godot swept collision or support proof. One-way ignored ascending as consumer contract; no snap allowed in eventual runtime.','input':str(f),'body':[28,32],'legs':legs},indent=2)+'\n')
print([(x['analytic_duration'],x['vx'],len(x['intersections']),x['minimum_cache_body_distance']) for x in legs])
