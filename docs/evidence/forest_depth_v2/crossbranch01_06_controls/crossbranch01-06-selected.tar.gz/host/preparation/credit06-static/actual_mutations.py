"""Run only on an unmodified fresh native capture with the new actual observations."""
import copy, hashlib, json, pathlib, sys
ROOT=pathlib.Path('/workspace/gunman-rush-design');sys.path.insert(0,str(ROOT/'tools'))
import run_forest_depth_enemies as consumer
raw=pathlib.Path(sys.argv[1]);out=pathlib.Path(sys.argv[2]);data=json.loads(raw.read_text())
consumer.validate_crossbranch(data)
credit=next(e for e in data['events'] if e['kind']=='actual_shot_energy_credit' and data['itinerary'][e['leg']]['kind']=='hollow_cavity')
tick=credit['tick'];frame=next(f for f in data['frames'] if f['tick']==tick);prev=next(f for f in data['frames'] if f['tick']==tick-1)
key=next(iter(set(frame['shot_economy']['hits'])-set(prev['shot_economy']['hits'])))
spawn=next(e for e in data['events'] if e['kind']=='actual_projectile_spawned' and f"{e['session_id']}/{e['packet']}"==key)
hit=next(e for e in data['events'] if e['kind']=='committed_damage' and e['tick']==tick and e['event_id']==f"{spawn['owner_id']}:{spawn['session_id']}:{spawn['serial']}")
ci=data['events'].index(credit);si=data['events'].index(spawn);hi=data['events'].index(hit);fi=data['frames'].index(frame)
def delete_event(d,index):d['events'].pop(index)
def delete_packet(d):d['frames'][fi]['shot_economy']['combat_packets'].pop(key)
def delete_hits(d):d['frames'][fi]['shot_economy']['hits'].pop(key)
def wrong_owner_coherent(d):
 s=d['events'][si];s['owner_id']+=1;h=d['events'][hi];h['source']='player_projectile:'+str(s['owner_id']);h['event_id']=f"{s['owner_id']}:{s['session_id']}:{s['serial']}"
def wrong_session(d):d['events'][si]['session_id']+=1
def drop_history(d):
 oldkey=next(iter(prev['shot_economy']['hits']))
 d['events'][ci]['hits'].pop(oldkey,None)
 d['frames'][fi]['shot_economy']['hits'].pop(oldkey,None)
 d['frames'][fi]['shot_economy']['combat_packets'].pop(oldkey,None)
mutations={
 'delete_Policy_hit':lambda d:delete_event(d,hi),
 'delete_actual_spawn':lambda d:delete_event(d,si),
 'delete_actual_shot_fired':lambda d:d['events'].__setitem__(slice(None),[e for e in d['events'] if not(e['kind']=='shot_fired' and e.get('serial')==spawn['serial'])]),
 'delete_credit_signal':lambda d:delete_event(d,ci),
 'delete_independent_combat_packet':delete_packet,
 'delete_policy_hit_receipt':delete_hits,
 'wrong_source':lambda d:d['events'][hi].__setitem__('source','player_projectile:1'),
 'wrong_owner_coherent_source_and_event':wrong_owner_coherent,
 'wrong_session':wrong_session,
 'wrong_serial':lambda d:d['events'][si].__setitem__('serial',spawn['serial']+99),
 'wrong_target':lambda d:d['events'][hi].__setitem__('target','not_the_actual_enemy'),
 'wrong_HP':lambda d:d['events'][hi].__setitem__('health_after',hit['health_after']+.5),
 'wrong_fired_airborne':lambda d:d['events'][si].__setitem__('fired_airborne',not spawn['fired_airborne']),
 'extra_energy':lambda d:d['frames'][fi].__setitem__('energy',frame['energy']+.5),
 'extra_credit':lambda d:d['events'][ci].__setitem__('amount',credit['amount']+1),
 'duplicate_refund':lambda d:d['events'].insert(ci+1,copy.deepcopy(credit)),
 'drop_prior_dedup_history':drop_history,
 'wrong_projectile_direction':lambda d:d['events'][si].__setitem__('direction',[0,1]),
 'wrong_weapon_epoch':lambda d:d['events'][si].__setitem__('weapon_epoch',999),
 'expired_projectile':lambda d:d['events'][si].__setitem__('lifetime',.01),
}
rows=[]
for name,change in mutations.items():
 changed=copy.deepcopy(data);change(changed);error=None
 try:consumer.validate_crossbranch(changed)
 except Exception as exc:error=str(exc)
 rows.append({'id':name,'rejected':error is not None,'error':error})
result={'scope':'Actual fresh baseline accepted; independent raw corruptions rejected by same strict consumer','raw':str(raw),'sha256':hashlib.sha256(raw.read_bytes()).hexdigest(),'baseline_accepted':True,'actual_credit_tick':tick,'actual_packet':key,'negative_results':rows,'all_rejected':all(r['rejected'] for r in rows)}
out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False,indent=2));sys.exit(0 if result['all_rejected'] else 1)
