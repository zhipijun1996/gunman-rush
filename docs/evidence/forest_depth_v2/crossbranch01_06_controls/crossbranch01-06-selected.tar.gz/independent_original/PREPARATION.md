# Projectile refund delta — preparation, not acceptance

Reviewer previously wrote the original formal-region base trace/reader. Review is limited to the other author's new refund observation/replay delta, excluding original driver/gameplay approval. No native run, no受审 source edits.

Production order read directly:

- ShootAbility appends real projectile before shot_fired. The observer can identify owner/session/serial/packet/fired_airborne/lifetime from the existing actual object. get_projectiles() replaces the backing array, so pure observation should read _projectiles without mutation.
- FrameDamagePolicy invokes each accepted result's on_committed before batch_resolved. on_weapon_damage calls shot-energy first (signal after unique _hits insertion/grant and optional queued round), then combat_energy.committed_hit. Thus credit signal can precede committed_damage event; new combat packet is only expected by the independent final frame sample.
- ShotEnergyPolicy key is session/energy_receipt packet, not necessarily shot serial. It accepts a matching active session, deduplicates _hits, caps actual resource grant, and returns one shot only if fired_airborne. New round uses queue_grant, whose actual application is the next controller grant-processing opportunity. Grounded state can reset charges separately.
- Projectile lifetime, actual owner/session, weapon epoch and accepted projectile damage must bind to the spawn record, real observed frame identities and target HP/packet evidence. A lone script event is insufficient authorization to add energy.

Planned negative controls on NEW raw (not old05 synthesized fields): delete credit/hit/accepted packet/shot/spawn; wrong owner/session/serial/target/weapon epoch; HP not decreasing or fabricated amount; duplicate credit; credit beyond lifetime; grant when not fired airborne; early/same-frame queued round; remove independent frame ledger; coherent energy alteration. Keep all original .001 resource comparisons, no-hit behavior, budgets and first-failure policy.

Original05 economy failure remains a real historical failure with missing independent spawn fields. New raw must have a new source identity; do not backfill it or retag old05 PASS. Complete author reader diff and fresh raw are pending.
