from pathlib import Path
import json,hashlib,copy,sys,re,runpy,contextlib,io
R=Path.cwd();S=R/'build/forest_depth/snapshots/crossbranch_controls06';P=S/'build/forest_depth/ecology/crossbranch_controls06';O=R/'build/forest_depth/independent/projectile-refund-review/actual06';O.mkdir(exist_ok=True);sys.path.insert(0,str(R/'tools'));import run_forest_depth_enemies as consumer
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();receipt=json.loads((P/'receipt.json').read_text());assert receipt['passed'] and receipt['source_guard'] and receipt['source_before']==receipt['source_after'] and receipt['verifier_before']==receipt['verifier_after'];assert all(sha(S/p)==h for p,h in receipt['source_before'].items());assert all(sha(S/p)==h for p,h in receipt['verifier_before'].items())
for p in ['tools/run_forest_depth_region.py','tests/forest_depth_region_trace.gd']:assert (R/p).read_bytes()==(S/p).read_bytes()
rows=[];all_data=[]
for row,folder in zip(receipt['formal_runs'],sorted(x for x in P.iterdir()if x.is_dir())):
 assert row['passed'] and row['timeout_seconds']==240
 log=(folder/'native.log').read_text();assert '4.7.2' in log and re.search(r'FOREST DEPTH ROUTE: .* / 0 failures',log) and not re.search(r'(?m)^ERROR:|SCRIPT ERROR:|Parse Error:|ObjectDB.*leaked|resources? still in use at exit',log)
 d=json.loads((folder/'capture.json').read_text());consumer.validate_crossbranch(d);all_data.append(d)
 credits=[e for e in d['events'] if e['kind']=='actual_shot_energy_credit'];rows.append({'strategy':row['strategy'],'raw':str((folder/'capture.json').relative_to(R)),'raw_sha256':sha(folder/'capture.json'),'native_log_sha256':sha(folder/'native.log'),'frames':len(d['frames']),'credits':[{'tick':e['tick'],'amount':e['amount'],'fired_airborne':e['fired_airborne'],'energy':e['energy']} for e in credits],'full_consumer_accepted':True})
d=all_data[0];by={f['tick']:f for f in d['frames']};c=next(e for e in d['events']if e['kind']=='actual_shot_energy_credit' and e['tick']==994);key='2/4';spawn=next(e for e in d['events']if e['kind']=='actual_projectile_spawned' and f"{e['session_id']}/{e['packet']}"==key);hit=next(e for e in d['events']if e['kind']=='committed_damage'and e['tick']==994 and e['event_id'].endswith(':'+str(spawn['serial'])))
assert by[176]['energy']==80 and by[177]['energy']==100 and by[177]['shots']==1 and by[178]['shots']==2
assert c['amount']==14.5 and c['energy']==100 and by[994]['shot_economy']['hits'][key] and by[994]['shot_economy']['combat_packets'][key]==7
# Real observed airborne spawn and later callback; current contact can be grounded.
assert spawn['fired_airborne'] is True
ci=d['events'].index(c);si=d['events'].index(spawn);hi=d['events'].index(hit)
def bad_owner(z):
 e=z['events'][si];e['owner_id']+=1;z['events'][ci]['owner_id']=e['owner_id'];z['events'][hi]['source']='player_projectile:'+str(e['owner_id']);z['events'][hi]['event_id']=f"{e['owner_id']}:{e['session_id']}:{e['serial']}"
def bad_session(z):
 e=z['events'][si];e['session_id']+=1;z['events'][ci]['session_id']=e['session_id'];z['events'][hi]['event_id']=f"{e['owner_id']}:{e['session_id']}:{e['serial']}"
def bad_direction(z):
 e=z['events'][si];e['direction']=[-x for x in e['direction']]
 for shot in z['events']:
  if shot['kind']=='shot_fired' and shot.get('serial')==e['serial']:shot['aim']=e['direction']
def erased_history(z):
 for f in z['frames']:
  if f['tick']>=994:
   for ledger in ['hits','combat_packets']:f['shot_economy'][ledger].pop('2/1',None)
 for e in z['events']:
  if e['kind']=='actual_shot_energy_credit' and e['tick']>=994:e['hits'].pop('2/1',None)
def missing_epoch(z):
 z['events'][si].pop('weapon_epoch')
 for f in z['frames']:f['shot_economy'].pop('weapon_epoch')
mut=[]
for name,fn in [('compound_owner_signal_policy',bad_owner),('compound_session_signal_policy',bad_session),('compound_direction_and_shot_keep_actual_Router',bad_direction),('erase_historical_ledger_all_later_samples_and_signals',erased_history),('remove_all_independent_epoch',missing_epoch)]:
 z=copy.deepcopy(d);fn(z);err=None
 try:consumer.validate_crossbranch(z)
 except Exception as e:err=str(e)
 assert err,name;mut.append({'case':name,'rejected':True,'error':err})
# Actually replay author's twenty mutations through the current consumer, save new output.
script=R/'build/forest_depth/ecology/f2-crossbranch01/credit06-static/actual_mutations.py';argv=sys.argv[:];sys.argv=[str(script),str(P/'00-crossbranch_ordinary_one_R/capture.json'),str(O/'author_twenty_independent_replay.json')]
try:
 with contextlib.redirect_stdout(io.StringIO()):
  try:runpy.run_path(str(script),run_name='__main__')
  except SystemExit as e:assert e.code==0
finally:sys.argv=argv
replayed=json.loads((O/'author_twenty_independent_replay.json').read_text());assert len(replayed['negative_results'])==20 and replayed['all_rejected']
res={'status':'ACCEPT_BOUNDED_NEW_OBSERVATION_AND_PROJECTILE_REFUND_REPLAY_ACTUAL06','reviewer':'/root/forest_runtime_review','scope':'Other-author new observation/credit replay only; original base driver previously reviewer-authored and excluded','native_run_by_reviewer':False,'source_sha256':{p:sha(S/p)for p in ['tools/run_forest_depth_region.py','tests/forest_depth_region_trace.gd','tools/run_forest_depth_enemies.py']},'actual_wrapper_elapsed_seconds':receipt['elapsed_seconds'],'source_inventory_verified':len(receipt['source_before']),'verifier_inventory_verified':len(receipt['verifier_before']),'actual_rows':rows,'observed_air_refund':{'spawn172_airborne':next(e for e in d['events']if e['kind']=='actual_projectile_spawned'and e['tick']==172)['fired_airborne'],'hit177_energy80_to100_shots1_then178shots2':True,'cavity994_refund_cap':14.5,'cavity_spawn_tick':spawn['tick'],'cavity_hit_grounded':by[994]['grounded']},'author_twenty_replayed_all_rejected':True,'independent_compound_mutants':mut,'scope_limits':['No H mechanic/fun or branch-value judgment','No current final-source/globalCI approval','Original05 remains missing-observation economy FAIL','Airborne177/178 ordering independently observed, not proof original cavity replay validates all future airborne queue grants','Synthetic static failures remain preserved; no old capture backfill']}
(O/'review.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps({'status':res['status'],'source_inventory':res['source_inventory_verified'],'rows':[{'strategy':r['strategy'],'credits':r['credits']}for r in rows],'independent_mutants':len(mut),'author_mutants':20},indent=2))
