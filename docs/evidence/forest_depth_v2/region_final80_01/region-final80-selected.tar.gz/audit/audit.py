import sys
sys.path.pop(0)
from pathlib import Path
import json,hashlib,collections,importlib.util,math
R=Path('/workspace/gunman-rush-design');S=R/'build/forest_depth/snapshots/region_final80_01';B=S/'build/forest_depth/region/final-v6-corpus01';O=R/'build/forest_depth/traversal/region_final80_01';r=json.loads((B/'receipt.json').read_text());snap=json.loads((S/'build/snapshot-receipt.json').read_text());spec=importlib.util.spec_from_file_location('frozen_final80',S/'tools/run_forest_depth_region.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v);v.ROOT=S
rows=[];source_ok=all((S/p).is_file()and hashlib.sha256((S/p).read_bytes()).hexdigest()==h for p,h in snap['source_files'].items());assert source_ok
for i,row in enumerate(r['runs']):
 P=B/f'{i:02d}-map{row["map"]}-{row["route"]}';cp=P/'capture.json';lp=P/'native.log';d=json.loads(cp.read_text());assert hashlib.sha256(cp.read_bytes()).hexdigest()==row['capture_sha256'];assert hashlib.sha256(lp.read_bytes()).hexdigest()==row['log_sha256'];errors=v.validate(d);assert not errors,(i,errors)
 enemy={x['id']:{'behavior':x['behavior_id'],'group':x.get('encounter_group'),'states':collections.Counter(),'min_health':float('inf'),'terminal_observed':False,'policy_source_resolutions':0,'net_HP_drop_ticks_as_source':[],'actual_H_contacts':0}for x in d['manifest']['enemies']};hp=d['initial_snapshot']['health'];drops=[];heals=[];policies=[e for e in d['events']if e.get('kind')=='committed_damage'and e.get('target')=='player'];policy_tick=collections.defaultdict(list)
 for e in policies:
  policy_tick[e['tick']].append(e)
  for id,en in enemy.items():
   if str(e.get('source','')).startswith(id):en['policy_source_resolutions']+=1
 for f in d['frames']:
  for e in f['enemies']:
   if e['id']in enemy:
    en=enemy[e['id']];en['states'][e['state']]+=1;en['min_health']=min(en['min_health'],e['health']);en['terminal_observed']|=e['terminal']
  delta=hp-f['health']
  if delta>1e-6:
   event={'tick':f['tick'],'net_loss':delta,'position':f['position'],'leg':f['leg'],'policy_sources_same_tick':[e.get('source')for e in policy_tick[f['tick']]]};drops.append(event)
   for id,en in enemy.items():
    if any(str(src).startswith(id)for src in event['policy_sources_same_tick']):en['net_HP_drop_ticks_as_source'].append(f['tick'])
  elif delta< -1e-6:heals.append({'tick':f['tick'],'net_gain':-delta})
  hp=f['health']
 contacts=[e for e in d['events']if e.get('kind')=='hook_contact_kick']
 for id,en in enemy.items():
  en['actual_H_contacts']=sum(e.get('target')==id for e in contacts);en['states']=dict(en['states']);en['min_health']=None if math.isinf(en['min_health'])else en['min_health']
 cc=[e for e in d['completed_legs']if e['edge_id']=='borer_crossing'];C=next((f for f in d['frames']if cc and f['tick']==cc[0]['tick']),None);m=d['manifest'];
 rows.append({'index':i,'seed':row['seed'],'map':row['map'],'route':row['route'],'family':m['family'],'choices':m['choices'],'manifest_hash':m['manifest_hash'],'actual_native_exit':row['exit_code'],'strict_status':row['status'],'offline_errors':errors,'frames':len(d['frames']),'minimum_HP':min(f['health']for f in d['frames']),'final_HP':d['frames'][-1]['health'],'final_energy':d['frames'][-1]['energy'],'player_policy_resolutions':len(policies),'net_HP_drops':drops,'net_HP_heals':heals,'C':{'tick':C['tick'],'HP':C['health'],'energy':C['energy'],'shots':C['shots']}if C else None,'claimed_ids':d['claimed_ids'],'actual_pointer_claim':bool(d['cache_claimed']and len(d['pointer_events'])==2 and len(d['modal_frames'])>=5 and d['duplicate_checked']),'enemies':enemy,'actual_H_contact_targets':dict(collections.Counter(e.get('target')for e in contacts)),'route_edges':m['routes'][d['route']],'capture':str(cp),'capture_bytes':cp.stat().st_size,'capture_sha256':row['capture_sha256'],'log':str(lp),'log_sha256':row['log_sha256']})
assert len(rows)==80 and[(x['seed'],x['map'],x['route'])for x in rows]==v.corpus_cases();assert all(x['strict_status']=='passed'for x in rows)
manifest_ids=collections.defaultdict(set)
for x in rows:manifest_ids[(x['seed'],x['map'])].add(x['manifest_hash'])
assert all(len(x)==1 for x in manifest_ids.values())
summary={'scope':'Offline actual80 package audit only: fixed original routes on exact snapshot with A2 upperpair. Not final-source CI, later formalecology extension, optional expedition usage, wholefun/player/device proof. Native results are original, not rerun.','snapshot':str(S),'source_head':r['source_head'],'source_files':len(snap['source_files']),'all_snapshot_original_source_hashes_rechecked':source_ok,'strict80_receipt_passed':r['status']=='passed'and r['source_stable'],'cases':len(rows),'unique_seed_map_route':len({(x['seed'],x['map'],x['route'])for x in rows}),'actual_frame_count':sum(x['frames']for x in rows),'raw_bytes':sum(x['capture_bytes']for x in rows),'minimum_HP_any_frame':min(x['minimum_HP']for x in rows),'minimum_final_HP':min(x['final_HP']for x in rows),'minHP_cases':[{'index':x['index'],'seed':x['seed'],'map':x['map'],'route':x['route'],'minHP':x['minimum_HP'],'finalHP':x['final_HP']}for x in rows if x['minimum_HP']==min(y['minimum_HP']for y in rows)],'family_case_counts':dict(collections.Counter(x['family']for x in rows)),'seed_map_choices':[{'seed':s,'map':i,'family':next(x['family']for x in rows if x['seed']==s and x['map']==i),'choices':next(x['choices']for x in rows if x['seed']==s and x['map']==i)}for s,i in manifest_ids],'cavity_route_cases':sum(x['C']is not None for x in rows),'literal_live_enemy_H_contacts':sum(sum(en['actual_H_contacts']for en in x['enemies'].values())for x in rows),'source_scope_warnings':['Policy resolution events keep producer name committed_damage; amount alone does not prove actual HP loss. Net frame HP drops reported separately; simultaneous healing may mask damage.','Lantern travel/dwell and configured thread fields are autonomous/metadata, not proof of a meaningful player encounter or strategy.','No new ecology child extension or optional live-return expedition was invoked by original four routes.'],'rows':rows}
(O/'actual-audit.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items()if k not in ['rows','seed_map_choices']}))
