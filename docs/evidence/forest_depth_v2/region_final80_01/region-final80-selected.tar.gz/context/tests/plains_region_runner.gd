extends SceneTree
var failed := 0
var assertions := 0
var selected_fixture := ""
var fixture_arguments := 0
func check(value: bool, message: String) -> void:
	assertions += 1
	if not value:
		failed += 1
		printerr("FAIL: " + message)
func _initialize() -> void:
	for argument: String in OS.get_cmdline_user_args():
		if argument.begins_with("--fixture="):
			fixture_arguments+=1
			selected_fixture=argument.trim_prefix("--fixture=")
	call_deferred("run")
func run() -> void:
	if fixture_arguments>0:
		await run_fixture()
		return
	DirAccess.make_dir_recursive_absolute("res://build/verification/generated/plains_cohesion")
	var g := PlainsRegionGenerator.new()
	var tuning := PlayerTuning.load_default()
	corpus(g,tuning)
	for family: String in PlainsRegionGenerator.FAMILIES:
		var r := g.generate("region-"+family,tuning,false,family)
		check(r.ok,"family generates " + family)
		if r.ok: print("REGION ",family," areas=",r.manifest.areas.size()," fallback=",r.manifest.fallback_id)
	var fixed := g.generate("sample",tuning,true,"woven_layers")
	check(fixed.ok,"fixed 12 node sample validates")
	if fixed.ok: print("SAMPLE ",fixed.manifest.areas.size()," fallback=",fixed.manifest.fallback_id)
	var app := DemoApp.new()
	app.meta_persistence_enabled = false
	root.add_child(app)
	check(app.start_plains("region-app"),"formal connected region starts")
	for i: int in 10: await physics_frame
	var actual_stage := app.stage as PlainsRegionStage
	check(actual_stage != null and actual_stage.assembly_ok,"formal uses region assembler")
	check(app.director.profile.is_valid(true) and app.director.stage_index == 1,"formal two-map region profile")
	check(is_instance_valid(actual_stage) and actual_stage.exits.is_empty(),"no room progression exits")
	if actual_stage != null:
		check(actual_stage.generated.manifest.areas.size() in [20,23] and actual_stage.generated.manifest.fallback_id.is_empty(),"normal automatic-family App must deliver randomized map, not fallback")
		check(actual_stage.boss != null,"Boss exists from start without seven exits")
		check(app.controller.motor.tuning.max_jumps == 1 and app.controller.motor.tuning.max_air_shots == 2,"base action resources preserved")
		check(RunManifest.from_snapshot(JSON.parse_string(app.director.manifest.canonical_json())) != null,"formal region manifest JSON roundtrip")
	app.abandon_run()
	for i: int in 3: await physics_frame
	app.free()
	var trace = load("res://tests/plains_region_trace.gd").new()
	trace.tree = self
	trace.check = check
	if fixed.ok:
		await trace.journey(fixed.manifest,tuning,"tour")
		await trace.tutorial_return(fixed.manifest,tuning)
	var intro_fallback:=g.verified_fallback("intro-fallback-proof",tuning,"intro")
	check(intro_fallback.ok,"first-map difficulty has its own complete verified fallback")
	if intro_fallback.ok:
		await trace.journey(intro_fallback.manifest,tuning,"tour")
		await trace.adventure(intro_fallback.manifest,tuning)
	var fallback:=g.verified_fallback("forced-fallback-proof",tuning)
	check(fallback.ok and fallback.manifest.fallback_id=="verified_exploration_region" and fallback.manifest.rewards.size()==4,"complete exploration fallback is reproducible")
	if fallback.ok:
		await trace.journey(fallback.manifest,tuning,"tour")
		await trace.adventure(fallback.manifest,tuning)
	for family: String in PlainsRegionGenerator.FAMILIES:
		var r:=g.generate("region-"+family,tuning,false,family)
		var intro:=g.generate("intro-"+family,tuning,false,family,"intro")
		check(intro.ok and intro.manifest.difficulty=="intro" and intro.manifest.areas.size()==20,"intro still delivers a complete randomized exploration world")
		if intro.ok:
			await trace.journey(intro.manifest,tuning,"fast")
			await trace.journey(intro.manifest,tuning,"tour")
			await trace.adventure(intro.manifest,tuning)
		if r.ok:
			await trace.journey(r.manifest,tuning,"fast")
			await trace.journey(r.manifest,tuning,"growth")
			await trace.journey(r.manifest,tuning,"tour")
			await trace.adventure(r.manifest,tuning)
	await trace.release_test_world()
	print("REGION ASSERTIONS: ",assertions," FAILED: ",failed)
	quit(1 if failed else 0)

func corpus(g: PlainsRegionGenerator,tuning: PlayerTuning) -> void:
	var summary:= {"version":PlainsRegionGenerator.VERSION,"seeds":150,"families":{},"fallbacks":0,"travel_signatures":0}
	var travels: Dictionary={}
	for family: String in PlainsRegionGenerator.FAMILIES:
		var signatures: Dictionary={}
		var cycles_min:=100
		var forks_min:=100
		for i: int in 50:
			var seed_value: String="corpus/%s/%s" % [family,i]
			var r:=g.generate(seed_value,tuning,false,family)
			check(r.ok,"bounded corpus generation " + seed_value)
			if not r.ok: continue
			var m: Dictionary=r.manifest
			check(m.family==family and m.fallback_id.is_empty(),"requested distinct topology is delivered without fallback")
			if not m.fallback_id.is_empty(): summary.fallbacks+=1
			check(m.areas.size() in [20,23],"random map within requested 18–24 node scope")
			var ports_ok:=true
			for area: Dictionary in m.areas:
				for port: Dictionary in area.ports:
					ports_ok=ports_ok and port.actions.jumps<=tuning.max_jumps and port.actions.air_shots<=tuning.max_air_shots
					for edge: Dictionary in m.connections:
						if edge.id!=port.connection: continue
						for index: int in edge.get("modules",[]):
							if m.nodes[index].module_id=="plains_recoil_span": ports_ok=ports_ok and port.actions.air_shots>=1 and port.actions.requires_burst
			check(ports_ok,"real connection ports declare recoil requirements without extra action resources")
			check(g.validate(JSON.parse_string(JSON.stringify(m)),tuning),"entire serialized map replay validates")
			var n:=g.generate(seed_value,tuning,false,family)
			check(m.manifest_hash==n.manifest.manifest_hash,"all separated random streams reproduce")
			var open_edges: Array=[]
			for e: Dictionary in m.connections:
				if e.condition=="open": open_edges.append([e.a,e.b,e.bidirectional])
			var graph_signature:=JSON.stringify(open_edges)
			signatures[graph_signature]=true
			var trace=load("res://tests/plains_region_trace.gd").new()
			var assembler:=PlainsRegionAssembler.new()
			assembler.manifest=m
			trace.stage=assembler
			var path: Array=trace.path_to("area_0_1",str(m.prep_id))
			var journey: Array=[]
			for step: Dictionary in path: journey.append([step.edge.a,step.edge.b,step.forward])
			travels[JSON.stringify(journey)]=true
			check(not path.is_empty(),"Boss prep reachable before any reward/shop/key/enemy-clear")
			assembler.free()
			cycles_min=mini(cycles_min,g._cycles(m))
			forks_min=mini(forks_min,m.areas.filter(func(a: Dictionary): return g._degree(m,a.id)>=3).size())
			check(m.rewards.size()==4 and m.rewards.filter(func(c: Dictionary): return c.tier=="high" or c.tier=="region_top").size()==2,"reward strong-item count is independent of map scale")
			if i==0:
				var file:=FileAccess.open("res://build/verification/generated/plains_cohesion/geometry_"+family+".json",FileAccess.WRITE)
				file.store_string(JSON.stringify(m,"  ",true))
			summary.families[family]={"graph_signatures":signatures.size(),"minimum_cycles":cycles_min,"minimum_forks":forks_min}
		check(signatures.size()>=10,"actual connection topology varies within " + family)
	check(travels.size()>=12,"seed changes actual early-Boss itinerary beyond cosmetic/hash variation")
	summary.travel_signatures=travels.size()
	summary.automatic_seeds=50
	summary.automatic_fallbacks=0
	for i: int in 50:
		var r:=g.generate("automatic-family/%s" % i,tuning)
		check(r.ok and r.manifest.fallback_id.is_empty() and r.manifest.areas.size() in [20,23],"automatic family selection follows same reproducible stream schedule")
		if r.ok and not r.manifest.fallback_id.is_empty(): summary.automatic_fallbacks+=1
	var file:=FileAccess.open("res://build/verification/generated/plains_cohesion/geometry_corpus.json",FileAccess.WRITE)
	file.store_string(JSON.stringify(summary,"  ",true))
	# Rehashed cheating still fails: fake passage, removed collision, inflated reward.
	var original: Dictionary=g.generate("tamper",tuning).manifest
	for kind: String in ["geometry","connection","reward"]:
		var changed: Dictionary=original.duplicate(true)
		if kind=="geometry": changed.nodes[0].geometry.platforms[0][2]=1
		elif kind=="connection": changed.connections[0].b="windkeeper"
		else: changed.rewards[0].coins=9999
		changed.manifest_hash=g._hash(changed)
		check(not g.validate(changed,tuning),"rehashed forged " + kind + " rejected")


func fixture_catalog() -> Dictionary:
	var result := {"baseline":{},"sample/tour":{"kind":"sample","mode":"tour"},"sample/tutorial_return":{"kind":"sample","mode":"tutorial_return"},"intro-fallback/tour":{"kind":"intro-fallback","mode":"tour"},"intro-fallback/adventure":{"kind":"intro-fallback","mode":"adventure"},"advanced-fallback/tour":{"kind":"advanced-fallback","mode":"tour"},"advanced-fallback/adventure":{"kind":"advanced-fallback","mode":"adventure"}}
	for family: String in PlainsRegionGenerator.FAMILIES:
		for mode: String in ["fast","tour","adventure"]:
			result["intro/%s/%s" % [family,mode]]={"kind":"intro","family":family,"mode":mode}
		for mode: String in ["fast","growth","tour","adventure"]:
			result["advanced/%s/%s" % [family,mode]]={"kind":"advanced","family":family,"mode":mode}
	return result

func run_fixture() -> void:
	var catalog := fixture_catalog()
	print("REGION FIXTURE INVENTORY: ",JSON.stringify(catalog.keys()))
	if fixture_arguments!=1 or not catalog.has(selected_fixture):
		check(false,"unknown, empty or duplicate explicit fixture request")
		print("REGION FIXTURE INVALID: ",selected_fixture)
		quit(1)
		return
	DirAccess.make_dir_recursive_absolute("res://build/verification/generated/plains_cohesion")
	var generator := PlainsRegionGenerator.new()
	var tuning := PlayerTuning.load_default()
	if selected_fixture=="baseline":
		await fixture_baseline(generator,tuning)
	else:
		var spec: Dictionary=catalog[selected_fixture]
		var generated: Dictionary
		match str(spec.kind):
			"sample": generated=generator.generate("sample",tuning,true,"woven_layers")
			"intro-fallback": generated=generator.verified_fallback("intro-fallback-proof",tuning,"intro")
			"advanced-fallback": generated=generator.verified_fallback("forced-fallback-proof",tuning)
			"intro": generated=generator.generate("intro-"+str(spec.family),tuning,false,str(spec.family),"intro")
			"advanced": generated=generator.generate("region-"+str(spec.family),tuning,false,str(spec.family))
		check(generated.get("ok",false),"original fixture manifest generates "+selected_fixture)
		if generated.get("ok",false):
			var trace=load("res://tests/plains_region_trace.gd").new()
			trace.tree=self
			trace.check=check
			match str(spec.mode):
				"tutorial_return": await trace.tutorial_return(generated.manifest,tuning)
				"adventure": await trace.adventure(generated.manifest,tuning)
				_: await trace.journey(generated.manifest,tuning,str(spec.mode))
			await trace.release_test_world()
	print("REGION ASSERTIONS: ",assertions," FAILED: ",failed)
	print("REGION FIXTURE: ",selected_fixture," ASSERTIONS: ",assertions," FAILED: ",failed)
	quit(1 if failed else 0)

func fixture_baseline(g: PlainsRegionGenerator,tuning: PlayerTuning) -> void:
	# Original corpus includes all150 forced-family and50 automatic-family seeds,
	# reproducibility and3 rehashed tamper negatives. Run it once, not per route.
	corpus(g,tuning)
	for family: String in PlainsRegionGenerator.FAMILIES:
		var r := g.generate("region-"+family,tuning,false,family)
		check(r.ok,"family generates " + family)
		if r.ok: print("REGION ",family," areas=",r.manifest.areas.size()," fallback=",r.manifest.fallback_id)
	var fixed := g.generate("sample",tuning,true,"woven_layers")
	check(fixed.ok,"fixed 12 node sample validates")
	if fixed.ok: print("SAMPLE ",fixed.manifest.areas.size()," fallback=",fixed.manifest.fallback_id)
	var app := DemoApp.new()
	app.meta_persistence_enabled = false
	root.add_child(app)
	check(app.start_plains("region-app"),"formal connected region starts")
	for i: int in 10: await physics_frame
	var actual_stage := app.stage as PlainsRegionStage
	check(actual_stage != null and actual_stage.assembly_ok,"formal uses region assembler")
	check(app.director.profile.is_valid(true) and app.director.stage_index == 1,"formal two-map region profile")
	check(is_instance_valid(actual_stage) and actual_stage.exits.is_empty(),"no room progression exits")
	if actual_stage != null:
		check(actual_stage.generated.manifest.areas.size() in [20,23] and actual_stage.generated.manifest.fallback_id.is_empty(),"normal automatic-family App must deliver randomized map, not fallback")
		check(actual_stage.boss != null,"Boss exists from start without seven exits")
		check(app.controller.motor.tuning.max_jumps == 1 and app.controller.motor.tuning.max_air_shots == 2,"base action resources preserved")
		check(RunManifest.from_snapshot(JSON.parse_string(app.director.manifest.canonical_json())) != null,"formal region manifest JSON roundtrip")
	app.abandon_run()
	for i: int in 3: await physics_frame
	app.free()
	var intro_fallback:=g.verified_fallback("intro-fallback-proof",tuning,"intro")
	check(intro_fallback.ok,"first-map difficulty has its own complete verified fallback")
	var fallback:=g.verified_fallback("forced-fallback-proof",tuning)
	check(fallback.ok and fallback.manifest.fallback_id=="verified_exploration_region" and fallback.manifest.rewards.size()==4,"complete exploration fallback is reproducible")
	for family: String in PlainsRegionGenerator.FAMILIES:
		var intro:=g.generate("intro-"+family,tuning,false,family,"intro")
		check(intro.ok and intro.manifest.difficulty=="intro" and intro.manifest.areas.size()==20,"intro still delivers a complete randomized exploration world")
