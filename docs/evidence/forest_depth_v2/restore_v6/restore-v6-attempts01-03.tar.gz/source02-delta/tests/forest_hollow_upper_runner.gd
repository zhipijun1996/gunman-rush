extends "res://tests/forest_hollow_trunk_runner.gd"
## New input strategy; unchanged base observer, actual Player, Policy and teardown.
func create_room() -> Node2D:
	var candidate=super.create_room()
	candidate.geometry_override=ForestHollowUpperCandidate.build()
	return candidate
func drive() -> void:
	if finished:return
	tick+=1;age+=1;steps_before=player.motion_steps;room.tick=tick
	if tick>1600 or age>300:
		failure="bounded_upper_route/"+phase;finished=true;return
	if player.position.y>270 or player.position.x < -340 or player.position.x>810:
		failure="left_upper_candidate_bounds/"+phase;finished=true;return
	match phase:
		"settle":
			move_to(108)
			if absf(player.position.x-108)<2 and support("belly_entry"):stable+=1
			else:stable=0
			if stable>=12:
				controller.router.set_move_axis(0);jump(true);enter("upper_launch")
		"upper_launch":
			if age==6:jump(false)
			if age==7:
				if variant=="H0R":hook("upper_window_ring");enter("upper_pull")
				elif variant=="wrongH":action(&"grapple",Vector2.UP);enter("upper_cross")
				else:
					if variant in ["noH_oneR","noH_twoR"]:action(&"shoot_release",Vector2.LEFT)
					enter("upper_cross")
		"upper_pull":
			controller.router.set_move_axis(0)
			if controller.traversal.state==&"free" and age>20:enter("upper_cross")
		"upper_cross":
			move_to(380)
			if variant=="noH_twoR" and age==16 and not support("outer_crown"):action(&"shoot_release",Vector2.LEFT)
			if support("outer_crown"):stable+=1
			else:stable=0
			if stable>=12:
				reached=true;return_start_tick=tick;enter("crown_return")
			elif support("inner_root"):
				jump(false);recovered=true;enter("lower_loop_align")
		"lower_loop_align":
			move_to(720)
			if absf(player.position.x-720)<2 and support("inner_root"):
				controller.router.set_move_axis(0);jump(true);enter("lower_loop_first")
		"lower_loop_first":
			if player.position.y+18<116:jump(false)
			if support("outer_low_step"):stable+=1
			else:stable=0
			if stable>=12:jump(true);enter("lower_loop_second")
		"lower_loop_second":
			if player.position.y+18<16:jump(false)
			if support("outer_high_step"):stable+=1
			else:stable=0
			if stable>=12:jump(true);enter("lower_loop_crown")
		"lower_loop_crown":
			move_to(550)
			if player.position.y+18< -26:jump(false)
			if support("outer_crown"):stable+=1
			else:stable=0
			if stable>=12:reached=true;return_start_tick=tick;enter("crown_return")
		"crown_return":
			move_to(380)
			if absf(player.position.x-380)<2 and support("outer_crown"):
				action(&"drop_through",Vector2.ZERO);enter("return_floor")
		"return_floor":
			move_to(-275)
			if absf(player.position.x+275)<2 and support("inner_root"):
				controller.router.set_move_axis(0);jump(true);enter("return_left_step")
		"return_left_step":
			if player.position.y+18<116:jump(false)
			if support("inner_recovery_step"):stable+=1
			else:stable=0
			if stable>=12:jump(true);enter("return_entry")
		"return_entry":
			move_to(-180)
			if player.position.y+18<16:jump(false)
			if support("belly_entry"):stable+=1
			else:stable=0
			if stable>=12:returned=true;finished=true
