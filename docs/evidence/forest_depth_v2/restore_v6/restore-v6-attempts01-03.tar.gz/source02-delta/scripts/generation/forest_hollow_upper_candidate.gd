class_name ForestHollowUpperCandidate
extends RefCounted
## Author experiment: remove the upper walking bridge, retain a legal lower loop.
## Uses the existing module/player/runtime. Not admitted or inherited Hollow05.
const VERSION := "forest-hollow-floorless-upper-candidate-v1"
static func build() -> Dictionary:
	var data: Dictionary=ForestHollowTrunkGeometry.build()
	data.version=VERSION
	data.id="hollow_floorless_canopy"
	data.spawn=[0.0,0.0]
	data.goal=[380.0,-42.0]
	data.platforms=[
		{"id":"belly_entry","rect":[-220.0,18.0,340.0,60.0],"one_way":false},
		{"id":"belly_roof","rect":[-220.0,-520.0,430.0,410.0],"one_way":false},
		{"id":"trunk_above_window","rect":[210.0,-520.0,120.0,426.0],"one_way":false},
		{"id":"outer_crown","rect":[300.0,-24.0,300.0,24.0],"one_way":true},
		{"id":"inner_root","rect":[-310.0,220.0,1100.0,40.0],"one_way":false},
		{"id":"inner_recovery_step","rect":[-305.0,118.0,65.0,20.0],"one_way":true},
		{"id":"outer_low_step","rect":[650.0,118.0,140.0,20.0],"one_way":true},
		{"id":"outer_high_step","rect":[650.0,18.0,140.0,20.0],"one_way":true}
	]
	data.hook_anchors=[{"id":"upper_window_ring","position":[330.0,-40.0]}]
	data.dangers=[]
	data.world_bounds=[-340.0,-550.0,1160.0,850.0]
	data.windows=[{"id":"upper_lip","clear_rect":[210.0,-94.0,120.0,70.0],"anchor_id":"upper_window_ring","from":"M","to":"E"}]
	data.nodes.M={"position":[0.0,0.0],"support_id":"belly_entry","role":"observe_canopy_and_lower_loop"}
	data.nodes.E={"position":[380.0,-42.0],"support_id":"outer_crown","role":"crown_receive"}
	data["upper_candidate_contract"]={"launch":[108.0,0.0],"intent":"horizontal_H_then_coming_side_kick_then_natural_apex_right_to_crown_without_R","cheap":"same_launch_short_jump_then_one_left_R; two_R_if_one_fails","fallback":"wide_floor_then_external_two_normal_jumps_and_leftward_crown_jump","return":"drop_then_original_left_two_jump_recovery","native_verified":false}
	data.evidence_scope="New floorless horizontal relationship, no inherited H value; no enemies/hazards/formal generation/viewport admission."
	return data
