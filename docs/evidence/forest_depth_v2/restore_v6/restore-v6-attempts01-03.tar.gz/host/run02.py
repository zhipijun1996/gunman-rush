from pathlib import Path
import fcntl,hashlib,json,os,subprocess,sys
root=Path('/workspace/gunman-rush-design');snap=root/'build/forest_depth/snapshots/restore_v6_02'
env=os.environ.copy();env.update(GUNMAN_TOOLCHAIN_ROOT='/workspace/toolchains',GUNMAN_DATA_HOME=str(snap/'build/user-data'),XDG_CONFIG_HOME=str(snap/'build/user-config'),XDG_CACHE_HOME=str(snap/'build/user-cache'))
results=[]
with (root/'build/verification/engine.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX);print('acquired global engine lock',flush=True)
 try:
  for script,output in [('tools/run_forest_depth_restore.py','build/forest_depth/restore/v6_02'),('tools/run_forest_depth_versions.py','build/forest_depth/versions/versions03')]:
   result=subprocess.run([sys.executable,script,'--output-dir',output],cwd=snap,env=env)
   results.append({'script':script,'output':output,'exit_code':result.returncode})
   if result.returncode:break
 finally:
  original=json.loads((snap/'build/snapshot-receipt.json').read_text())
  unchanged=all((snap/p).is_file() and hashlib.sha256((snap/p).read_bytes()).hexdigest()==sha for p,sha in original['source_files'].items())
  (root/'build/forest_depth/restore/v6-preparation/host02-receipt.json').write_text(json.dumps({'results':results,'all_snapshot_raw_bytes_unchanged':unchanged,'copy_guard':original['source_copy_guard'],'scope':'Actual V6 normal-input earned-state App reload and pending current version compatibility'},indent=2)+'\n')
  print('engine lock released',flush=True)
 if not unchanged:sys.exit(2)
 if any(r['exit_code'] for r in results):sys.exit(1)
