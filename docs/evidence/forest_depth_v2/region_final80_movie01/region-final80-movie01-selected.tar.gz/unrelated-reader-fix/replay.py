import importlib.util,json,copy,hashlib,difflib
from pathlib import Path
R=Path('/workspace/gunman-rush-design');O=R/'build/forest_depth/traversal/upper_approach_base_reader_fix';S=R/'build/forest_depth/snapshots/approach_formal03'
def load(p,n):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);m.ROOT=S;return m
before=load(O/'before.py','before');after=load(R/'tools/run_forest_depth_region.py','after')
p=S/'build/forest_depth/ecology/approach_formal03-ordinary/00-approach_ordinary_early/capture.json';d=json.loads(p.read_text());row={'capture':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'before':before.validate(d),'after':after.validate(d)}
assert row['before']==['leg_10_actual_R'] and row['after']==[]
old_roles=[]
for role in ['live_lift','ordinary','',None]:
 x=copy.deepcopy(d)
 # Keep itinerary and source manifest in sync to isolate role-specific R guard.
 for leg in x['itinerary']:
  if leg.get('role')=='upper_approach':leg['role']=role
 def replace(v):
  if isinstance(v,dict):
   if v.get('role')=='upper_approach':v['role']=role
   for w in v.values():replace(w)
  elif isinstance(v,list):
   for w in v:replace(w)
 replace(x['manifest']);e=after.validate(x);assert 'leg_10_actual_R' in e;old_roles.append({'role':role,'errors':e})
live=S/'build/forest_depth/ecology/approach_formal03/00-approach_live_jump/capture.json';ld=json.loads(live.read_text());assert before.validate(ld)==after.validate(ld)==[]
out={'scope':'Offline same actual raw only, no native rerun; new role excludes generic R, child reader still owns strategy-specific R checks. All other old roles retain R.','ordinary':row,'live_before_after':[],'old_role_guard_mutants':old_roles,'before_sha256':hashlib.sha256((O/'before.py').read_bytes()).hexdigest(),'after_sha256':hashlib.sha256((R/'tools/run_forest_depth_region.py').read_bytes()).hexdigest()};(O/'receipt.json').write_text(json.dumps(out,indent=2));(O/'delta.diff').write_text(''.join(difflib.unified_diff((O/'before.py').read_text().splitlines(True),(R/'tools/run_forest_depth_region.py').read_text().splitlines(True),fromfile='before',tofile='after')));print(json.dumps(out,indent=2))
