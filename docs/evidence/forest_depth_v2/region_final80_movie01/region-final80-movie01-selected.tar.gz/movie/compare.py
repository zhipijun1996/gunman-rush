import json,hashlib
from pathlib import Path
R=Path('/workspace/gunman-rush-design');S=R/'build/forest_depth/snapshots/region_final80_01';O=R/'build/forest_depth/traversal/region_final80_movie01';P=S/'build/forest_depth/region';a=P/'final-v6-corpus01/09-map2-growth/capture.json';b=P/'final-v6-growth-movie01/00-map2-growth/capture.json';x=json.loads(a.read_text());y=json.loads(b.read_text())
def clean(v):
 if isinstance(v,dict):return {k:clean(w) for k,w in v.items() if k not in ('presentation_frame','process_frame')}
 if isinstance(v,list):return [clean(w) for w in v]
 return v
keys=[k for k in x if isinstance(x[k],list) and ('frame' in k or 'event' in k or 'request' in k or 'modal' in k or 'pointer' in k)]
r={'scope':'Same frozen80 project headless versus single actual GL. Only presentation/process metadata removed; no native replay.','headless_sha256':hashlib.sha256(a.read_bytes()).hexdigest(),'movie_sha256':hashlib.sha256(b.read_bytes()).hexdigest(),'streams':{k:{'equal':clean(x[k])==clean(y[k]),'headless_count':len(x[k]),'movie_count':len(y[k])} for k in keys},'physical_frames':len(y['frames']),'min_health':min(f['health'] for f in y['frames']),'final_health':y['final_snapshot']['health'],'final_snapshot_equal':x['final_snapshot']==y['final_snapshot'],'manifest_equal':x['manifest']==y['manifest'],'completed_legs_equal':clean(x['completed_legs'])==clean(y['completed_legs'])}
(O/'actual-same80-input-state-comparison.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
