from pathlib import Path
import json,gzip,hashlib,tarfile,io,difflib
R=Path('/workspace/gunman-rush-design');S=R/'build/forest_depth/snapshots/region_final80_01';B=R/'build/forest_depth/traversal/region_final80_movie01';O=R/'docs/evidence/forest_depth_v2/region_final80_movie01';O.mkdir(parents=True,exist_ok=True)
F=S/'build/forest_depth/region/final-v6-growth-movie01';N=F/'00-map2-growth';items={}
def add(name,p):items[name]=Path(p).read_bytes()
def js(name,value):items[name]=(json.dumps(value,indent=2)+'\n').encode()
def sha(b):return hashlib.sha256(b).hexdigest()
for p in B.iterdir():
 if p.is_file() and p.name!='package.py':add('movie/'+p.name,p)
for p in (B/'keyframes').iterdir():
 if p.is_file():add('movie/keyframes/'+p.name,p)
add('producer/snapshot-receipt.json',S/'build/snapshot-receipt.json')
for p in [F/'receipt.json',F/'import.log',N/'native.log',N/'display.log']:add('actual/'+p.name,p)
items['actual/capture.json.gz']=gzip.compress((N/'capture.json').read_bytes(),mtime=0)
inv=json.loads((S/'build/snapshot-receipt.json').read_text())['source_files']; selected=[]
for k,h in inv.items():
 if k.startswith(('scripts/generation/','scripts/player/','scripts/input/','scripts/damage/')) or k in ['scripts/demo/demo_app.gd','scripts/demo/thorn_forest_region_stage.gd','tests/forest_depth_region_trace.gd','tests/forest_depth_region_runner.gd','tools/run_forest_depth_region.py','project.godot','config/player_tuning.json']:
  b=(S/k).read_bytes();assert sha(b)==h
  try:b.decode('utf-8')
  except UnicodeDecodeError:continue
  items['selected-producer/'+k]=b;selected.append(k)
linked=R/'docs/evidence/forest_depth_v2/region_final80_01';js('producer/full-text-closure-link.json',{'relative_path':'../region_final80_01/region-final80-selected.tar.gz','sha256':sha((linked/'region-final80-selected.tar.gz').read_bytes()),'receipt':json.loads((linked/'archive-receipt.json').read_text()),'scope':'All 1907 consumed text sources in context/; full2033 source inventory. 126 binary assets are SHA only, not copied. Selected producer here is not standalone native project.'})
fix=R/'build/forest_depth/traversal/upper_approach_base_reader_fix'
for name in ['before.py','receipt.json','delta.diff','replay.py']:add('unrelated-reader-fix/'+name,fix/name)
after=R/'tools/run_forest_depth_region.py';rr=json.loads((fix/'receipt.json').read_text());assert sha(after.read_bytes())==rr['after_sha256'];add('unrelated-reader-fix/after.py',after)
for kind,rel in [('ordinary','approach_formal03-ordinary/00-approach_ordinary_early/capture.json'),('live','approach_formal03/00-approach_live_jump/capture.json')]:
 p=R/'build/forest_depth/snapshots/approach_formal03/build/forest_depth/ecology'/rel;items['unrelated-reader-fix/'+kind+'-capture.json.gz']=gzip.compress(p.read_bytes(),mtime=0)
js('unrelated-reader-fix/IDENTITY.json',{'scope':'Unrelated post-movie base checker role fix. These approach03 actual raws are not movie producer, not native reruns, and are validated offline. Only ecology_choice role upper_approach excluded from generic R; child strategy predicates remain. Frozen movie uses before.py bytes.','before_sha':rr['before_sha256'],'after_sha':rr['after_sha256']})
avi=N/'gameplay.avi';js('producer/excluded-AVI.json',{'path':str(avi),'bytes':avi.stat().st_size,'sha256':sha(avi.read_bytes()),'scope':'Original retained in build; exact decoded frame identity and ffprobe in media receipt. AVI excluded from archive; full MP4 included.'})
text='''One original root00/map2/growth continuous GL, same warm region_final80_01 source.\nOriginal exact outer invocation: flock build/verification/engine.lock python3 build/forest_depth/traversal/region_final80_movie01/run.py\nInner argv/env and budgets are in movie/run.py; original import90/native240, outer425; no timeout changes.\nActual exit0/62.313s; all2033 snapshot source hashes unchanged. 580 observed Motor frames; AVI/MP4 596@60, 9.933s.\nComplete frames/events/requests/modal/pointer equal same80 actual raw after removing ONLY presentation_frame/process_frame. HP min/final3.\nNew northshortcut: old Ncampback->S334 to87 ticks, cavity148->160, common tail202; total815->580. This is multi-change descriptive comparison, not isolated causal experiment.\nActual A2 second cast airborne after fullbody bay departure; windup falls before near-horizontal pull. Does not mean continually diagonal downward pull.\nOrdinary bot does not prove live-anchor use, intended ecology strategy, human discovery, fun, all random levels, Boss fight, audio/device or final-source CI. Camp same-position short waits are not trade interactions.\nBase actualGitHEAD51e594b38465326655ae0c8515d686241415ade8 + explicit dirty snapshot overlay; not clean/final source CI. Later ecology extension is excluded.\nFull raw gzip is reversible; MP4 complete; keyframes map real Engine.draw indices, physics tick is not movie time. Raw AVI stays original build path with hash.\nSource closure: sibling region_final80_01 archive has all1907 consumed text sources; selected source here plus full2033 inventory. No binary assets, .godot or standalone runnable project claimed.\nUnrelated upper_approach reader correction is segregated; before/after, same actual early/live raws and four old-role mutants retained. No native rerun for that reader change.\n''';items['evidence.txt']=text.encode();add('packaging/package.py',B/'package.py')
index={k:{'sha256':sha(v),'bytes':len(v)} for k,v in sorted(items.items())};js('members.json',index)
archive=O/'region-final80-movie01-selected.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as t:
 for k,b in sorted(items.items()):
  info=tarfile.TarInfo(k);info.size=len(b);info.mtime=0;info.mode=0o644;t.addfile(info,io.BytesIO(b))
with tarfile.open(archive) as t:
 for k,v in index.items():assert sha(t.extractfile(k).read())==v['sha256']
receipt={'archive':archive.name,'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'regular_members':len(items),'indexed_members':len(index),'all_members_verified':True,'selected_text_source_count':len(selected),'source_inventory_count':len(inv),'scope':'Offline package only. No native or browser; no original file rewritten. Full source context via exact sibling corpus archive SHA. Unrelated reader fix segregated.'};(O/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');(O/'members.json').write_text(json.dumps(index,indent=2)+'\n');(O/'README.md').write_text(text);print(json.dumps(receipt,indent=2))
