from pathlib import Path
import tarfile,hashlib,json,shutil
root=Path('/workspace/gunman-rush-design');snap=root/'build/forest_depth/snapshots/aircatch01';raw=snap/'build/forest_depth/hollow_trunk/aircatch01';out=root/'build/forest_depth/aircatch/attempt01';selected=out/'selected-source';selected.mkdir(exist_ok=True)
for rel in ['scripts/generation/forest_hollow_trunk_geometry.gd','tests/forest_hollow_trunk_runner.gd','tools/run_forest_hollow_trunk.py','scripts/demo/forest_hollow_trunk_golden.gd','scripts/player/traversal_ability.gd','scripts/player/traversal_definition.gd','scripts/player/player_motor.gd','resources/player/traversal.tres','config/player_tuning.json']:
 p=snap/rel
 if p.is_file():shutil.copyfile(p,selected/(rel.replace('/','__')+'.txt'))
shutil.copyfile(snap/'build/snapshot-receipt.json',out/'full-source-snapshot-receipt.json')
files={'native/'+p.name:p for p in raw.iterdir()if p.is_file()}
for p in out.iterdir():
 if p.is_file()and p.name not in ['aircatch01-selected.tar.gz','archive-receipt.json','members.json']:files['attempt/'+p.name]=p
for p in selected.iterdir():files['producer/'+p.name]=p
index={n:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}for n,p in files.items()};idx=out/'members.json';idx.write_text(json.dumps(index,indent=2)+'\n');files['members.json']=idx;archive=out/'aircatch01-selected.tar.gz'
with tarfile.open(archive,'w:gz')as tar:
 for name,p in sorted(files.items()):tar.add(p,arcname=name,recursive=False)
with tarfile.open(archive)as tar:
 members=[m for m in tar.getmembers()if m.isfile()]
 for name,v in index.items():assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==v['sha256']
r={'archive':str(archive),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size,'regular_members':len(members),'indexed_members_verified':len(index),'scope':'Actual local H0R/1R physics comparison, full source SHA inventory plus selected bytes, not whole portable runtime or regional acceptance'};(out/'archive-receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
