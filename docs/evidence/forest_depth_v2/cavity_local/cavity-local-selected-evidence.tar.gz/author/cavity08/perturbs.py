from pathlib import Path
import os,json,subprocess,time,hashlib
root=Path('/workspace/gunman-rush-design');snap=root/'build/forest_depth/snapshots/cavity08';out=root/'build/forest_depth/traversal/cavity08';env=os.environ.copy();env.update(GUNMAN_TOOLCHAIN_ROOT='/workspace/toolchains',GUNMAN_DATA_HOME=str(snap/'build/userdata'),XDG_CONFIG_HOME=str(snap/'build/userconfig'),XDG_CACHE_HOME=str(snap/'build/usercache'))
r={'scope':'New horizontal excavated cavity S-C-S first actual diagnosis; exact upper02 frozen base plus three-file authored overlay; not formal M/E integration','snapshot':str(snap),'snapshot_receipt_sha256':hashlib.sha256((snap/'build/snapshot-receipt.json').read_bytes()).hexdigest(),'runs':[]}
start=time.monotonic()
try:
 for name,argv,cap in [('standing_recoil3',['python3','tools/run_forest_hollow_upper.py','--skip-import','--cavity','--variants','cavity_HR','--standing-hook','--recoil-offset=3','--output-dir','build/forest_depth/cavity/standing_recoil3'],60),('standing_start8',['python3','tools/run_forest_hollow_upper.py','--skip-import','--cavity','--variants','cavity_HR','--standing-hook','--launch-offset=8','--output-dir','build/forest_depth/cavity/standing_start8'],60)]:
  row={'name':name,'argv':argv,'timeout_seconds':cap};r['runs'].append(row);t=time.monotonic()
  with (out/(name+'-outer.log')).open('w')as log:
   try:p=subprocess.run(argv,cwd=snap,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=cap);row['exit_code']=p.returncode
   except subprocess.TimeoutExpired:row['timed_out']=True;raise
  row['seconds']=time.monotonic()-t;row['log_sha256']=hashlib.sha256((out/(name+'-outer.log')).read_bytes()).hexdigest()
  if name=='import' and row.get('exit_code')!=0:break
  # Each predeclared perturbation executes once; reject remains reject.
finally:
 r['elapsed_seconds']=time.monotonic()-start;r['original_snapshot_source_unchanged']=all((snap/k).exists() and hashlib.sha256((snap/k).read_bytes()).hexdigest()==h for k,h in json.loads((snap/'build/snapshot-receipt.json').read_text())['source_files'].items());(out/'standing-perturb-native-receipt.json').write_text(json.dumps(r,indent=2)+'\n')
