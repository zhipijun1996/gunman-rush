from pathlib import Path
import sys,os,json,hashlib,subprocess,selectors,re,time,signal
S=Path.cwd();sys.path.insert(0,str(S/'tools'))
import level_formal
from run_forest_hollow_upper import validate
O=S/'build/forest_depth/cavity/movie08';O.mkdir(parents=True,exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
r={'scope':'One exact cavity08 horizontal H/kick/R two-cell S-C-S complete loop; not M/E formal generation/player/device approval','passed':False,'native_cap_seconds':45,'source_before':level_formal.source_files(),'snapshot_receipt_sha256':sha(S/'build/snapshot-receipt.json'),'script_sha256':sha(Path(__file__)),'engine_binary':{'path':'/workspace/toolchains/godot/4.7.2/Godot_v4.7.2-stable_linux.x86_64','sha256':sha(Path('/workspace/toolchains/godot/4.7.2/Godot_v4.7.2-stable_linux.x86_64'))}}
started=time.monotonic();display=None;proc=None
try:
 env={**os.environ,'LIBGL_ALWAYS_SOFTWARE':'1','LP_NUM_THREADS':'1','OMP_NUM_THREADS':'1'}
 with (O/'display.log').open('wb') as stream:
  display=subprocess.Popen(['/workspace/toolchains/xvfb/usr/bin/Xvfb','-displayfd','1','-screen','0','1280x720x24','-nolisten','tcp','-ac'],stdout=subprocess.PIPE,stderr=stream)
  with selectors.DefaultSelector() as selector:
   selector.register(display.stdout,selectors.EVENT_READ)
   assert selector.select(15),'Xvfb display not ready'
   number=display.stdout.readline().decode().strip();assert number.isdigit()
  env['DISPLAY']=':'+number
  argv=['bash','tools/godot.sh','--rendering-method','gl_compatibility','--audio-driver','Dummy','--fixed-fps','60','--write-movie',str(O/'gameplay.avi'),'--path','.','--script','tests/forest_hollow_upper_runner.gd','--','--variant=cavity_HR','--cavity','--standing-hook','--output=res://build/forest_depth/cavity/movie08/capture.json']
  r['argv']=argv
  with (O/'native.log').open('w') as log:
   proc=subprocess.Popen(argv,cwd=S,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
   try:r['exit_code']=proc.wait(timeout=45)
   except subprocess.TimeoutExpired:
    os.killpg(proc.pid,signal.SIGTERM);proc.wait(timeout=5);raise
 text=(O/'native.log').read_text()
 assert r['exit_code']==0 and 'OpenGL API' in text
 assert not re.search(r'(?m)^ERROR:|SCRIPT ERROR:|Parse Error:|ObjectDB.*leaked|resources? still in use at exit',text)
 data=json.loads((O/'capture.json').read_text());r['validation_errors']=validate(data);assert not r['validation_errors']
 probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames','-show_streams','-show_format','-of','json',str(O/'gameplay.avi')]))
 video=next(row for row in probe['streams'] if row['codec_type']=='video');n,d=map(int,video['avg_frame_rate'].split('/'));assert n/d==60
 r['ffprobe']=probe;r['movie_frames']=int(video['nb_read_frames']);r['movie_seconds']=r['movie_frames']/60
 subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-i',str(O/'gameplay.avi'),'-c:v','libx264','-preset','veryfast','-crf','20','-pix_fmt','yuv420p','-c:a','aac','-movflags','+faststart',str(O/'gameplay.mp4')],check=True,timeout=45)
 r['passed']=True
finally:
 if display is not None:
  display.terminate();display.wait(timeout=5);display.stdout.close()
 r['source_after']=level_formal.source_files();r['source_guard']=r['source_before']==r['source_after'];r['elapsed_seconds']=time.monotonic()-started
 snap=json.loads((S/'build/snapshot-receipt.json').read_text());r['all_snapshot_raw_unchanged']=all((S/p).is_file() and sha(S/p)==value for p,value in snap['source_files'].items())
 r['files']={p.name:{'sha256':sha(p),'bytes':p.stat().st_size}for p in O.iterdir()if p.is_file()}
 (O/'receipt.json').write_text(json.dumps(r,indent=2)+'\n')
 assert r['source_guard'] and r['all_snapshot_raw_unchanged']
print('PASS: actual same-source cavity H-kick-R full S-C-S GL movie only')
