from pathlib import Path
import os,subprocess,json,time,hashlib
root=Path('/workspace/gunman-rush-design');snap=root/'build/forest_depth/snapshots/cavity08';out=root/'build/forest_depth/traversal/cavity08';env={**os.environ,'GUNMAN_TOOLCHAIN_ROOT':'/workspace/toolchains','GUNMAN_DATA_HOME':str(snap/'build/userdata'),'XDG_CONFIG_HOME':str(snap/'build/userconfig'),'XDG_CACHE_HOME':str(snap/'build/usercache')};argv=['python3',str(out/'capture_movie.py')];t=time.monotonic()
with (out/'movie-outer.log').open('w') as log:p=subprocess.run(argv,cwd=snap,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=105)
(out/'movie-outer-receipt.json').write_text(json.dumps({'scope':'complete standing-H purpose local room only','argv':argv,'cwd':str(snap),'exit_code':p.returncode,'seconds':time.monotonic()-t,'script_sha256':hashlib.sha256((out/'capture_movie.py').read_bytes()).hexdigest()},indent=2)+'\n')

raise SystemExit(p.returncode)
