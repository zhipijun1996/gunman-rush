# Cavity06 actual environment integration

Cavity01/02 recovery failures and04 outsidewrong/05 insidewrong failures remain unchanged. Those previous captures prove body/input geometry only; the reused empty-danger Hollow room lacked emitters. This candidate adds existing production DemoContactEmitter for every actual manifest danger and registers segment unsafe bounds; successful ENV return uses existing policy protection. The same body/platform/anchor/danger arrays and same purpose/strong/ordinary/wrong05 inputs are retained.

Legacy module renderer classifies ceiling-only hazard as DEEP DROP. Cavity room now clears that renderer danger list (not manifest/Policy geometry), draws exact filled/bordered rectangles and correctly facing spikes from same manifest, module z=-1. No new geometry/hidden bounds/input locks or damage inflation. Default empty-danger room behaviour unchanged. All4 cases must be fresh under this consumer, not just wrong.
