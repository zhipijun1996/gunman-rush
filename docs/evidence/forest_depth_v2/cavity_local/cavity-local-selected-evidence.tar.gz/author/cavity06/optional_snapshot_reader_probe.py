from pathlib import Path
import hashlib,json,sys,tempfile,subprocess
sys.path=[p for p in sys.path if Path(p).resolve()!=Path(__file__).parent.resolve()]
from unittest.mock import patch
MAIN=Path('/workspace/gunman-rush-design');sys.path.insert(0,str(MAIN/'tools'));import run_forest_hollow_upper as module
results=[]
for mode in ['genuine_git_no_snapshot','changed_source','tampered_snapshot']:
 with tempfile.TemporaryDirectory(prefix='upper-reader-unit-',dir=MAIN/'build') as tmp:
  root=Path(tmp);(root/'build').mkdir();marker=root/'marker';marker.write_text('fixed')
  subprocess.run(['git','init','-q',str(root)],check=True)
  subprocess.run(['git','add','marker'],cwd=root,check=True)
  subprocess.run(['git','-c','user.name=ReaderFixture','-c','user.email=fixture@invalid','commit','-qm','fixture only'],cwd=root,check=True)
  def inventory():return {'marker':hashlib.sha256(marker.read_bytes()).hexdigest()}
  if mode=='tampered_snapshot':(root/'build/snapshot-receipt.json').write_text(json.dumps({'source_files':{'marker':'0'*64}}))
  def no_native(argv,timeout):
   if mode=='changed_source':marker.write_text('changed')
   raise RuntimeError('probe stop before any engine; not runtime evidence')
  with patch.object(module,'ROOT',root),patch.object(module.level_formal,'source_files',inventory),patch.object(module,'run_engine',no_native),patch.object(sys,'argv',['probe','--skip-import','--output-dir','build/probe']):
   try:module.main()
   except RuntimeError as exc:exception=str(exc)
   else:raise AssertionError('stub must fail before native, never generate fake pass')
  receipt=json.loads((root/'build/probe/receipt.json').read_text())
  assert receipt['passed'] is False
  if mode=='genuine_git_no_snapshot':assert receipt['copy_source_guard'] is None and receipt['source_guard'] and receipt['git_commit'] and exception.startswith('probe stop')
  elif mode=='changed_source':assert receipt['source_guard'] is False and exception=='source drift'
  else:assert receipt['copy_source_guard'] is False and exception=='source drift'
  results.append({'mode':mode,'engine_executed':False,'passed_fake_runtime':False,'reader_unit_assertions_passed':True,'exception':exception,'source_guard':receipt['source_guard'],'copy_source_guard':receipt['copy_source_guard'],'actual_temporary_git_commit':receipt['git_commit']})
output=MAIN/'build/forest_depth/traversal/cavity06/offline-new-verifier/optional-snapshot-reader-unit.json';output.write_text(json.dumps({'scope':'reader infrastructure UNIT ONLY; engine stub deliberately raises before native, no fabricated successful capture/receipt retained','verifier_sha256':hashlib.sha256(Path(module.__file__).read_bytes()).hexdigest(),'cases':results},indent=2)+'\n');print('reader units3 passed; no engine executed')
