# Limited input perturbation only

Frozen06 real ENV consumer/factory preserved, only driver records/consumes cast/recoil offsets and new strict reader. Three predeclared samples: cast−3; cast+3; recoil+3. Default0 inputs should remain same trajectory, to be checked by purpose GL later. No geometry/Player/physics/resource modifications. Native45 each, no retry search. A safe ENV/Segment recovery with missedC is recorded as a failed purpose route, never relabelled success. Original06 whole-wrapper FAIL remains, new verifier has separate SHA.
