# FOREST-DEPTH-02 horizontal cavity candidate

New author hypothesis, not admission. Parent requested actual goldens rather than another label.

1. Horizontal borer cavity: a 550px-long excavated roof has 110px actual clear height, upper/lower visible Policy thorns, a 130px middle observation pocket and broad exterior return. Side H draws forward, mandatory coming-side kick reverses, horizontal R commits forward; the pocket really lands before a second H (once per flight). Strong cheap is earliest legal two horizontal R per cell, plus the roof loop remains available. Initial choice because it changes horizontal approach and commitment rather than adding another upward ladder.
2. Falling L-root seam: drop from D, side catch, diagonal R into E with a bent clear corridor. Preserves discovery from the lower route, but duplicates the proven lower-side-H material and is at high risk of the already-proven single-R hole replacement. Deferred rather than falsely declared impossible.

Coordinates are local shared-tree coordinates. Original M/E/D/R and their lower bodies are exact; new S(-245,-318)/C(430,-318) are above them. This first scope validates S→C→S, not M→S or C→E formal seams. The original roof/above-trunk are split at -430/-276 and hazards occupy -430..-410 and -300..-276; free body centre interval is [-392,-318]. First ring(-35,-350), second(330,-350). Hook start is fixed body+(0,-6), actual range231/head12/stop30/kick24 retained. Middle pocket x40..170, S x-350..-220, C x330..600. Current physical feasibility is UNVERIFIED. No H2 before real middle landing.

Fixed batch: cavity_HR first. Only on success run noH_cavity_twoR and cavity_wrongR. Wrong R is downward recoil towards the upper spikes, requiring actual Policy loss and S segment recovery12; no invented harm condition for all alternatives. All budgets45s, continuous real Motor/Router and source guards, no position/resource injection. External roof return is legal ordinary jumps, no invisible walls. No promotion if cheap equivalently erases movement judgement.


## Correction after original plan/native01

The original once-per-flight generalisation above is wrong and retained as the historical author mistake. Root independently identified Traversal.advance successful hook_contact_kick calls restore_air_actions before hook_kick. Successful physical contact restores H even airborne; R alone does not. The bay remains an observation/recovery design choice, not a mandatory H reset. Original01/02 capture metadata hook_once_per_airborne is likewise incorrect descriptive metadata, not runtime behaviour.
