from pathlib import Path
import hashlib,json,os,shutil,stat,subprocess,sys,time
root=Path('/workspace/gunman-rush-design/build/forest_depth/snapshots/upper_canopy02');destination=Path(sys.argv[1]).resolve();assert destination.is_relative_to(Path('/workspace/gunman-rush-design/build/forest_depth/snapshots')) and not destination.exists()
roots=['scripts','scenes','resources','config','assets','shaders','addons','tests','tools']
def files():
 result={}
 for directory in roots:
  p=root/directory
  if p.is_dir():
   for item in p.rglob('*'):
    if item.is_file() and '__pycache__' not in item.parts and item.suffix!='.pyc':result[str(item.relative_to(root))]=hashlib.sha256(item.read_bytes()).hexdigest()
 for name in ['project.godot','export_presets.cfg','.gitignore','.gitattributes']:
  p=root/name
  if p.is_file():result[name]=hashlib.sha256(p.read_bytes()).hexdigest()
 return result
before=files();destination.mkdir(parents=True)
# Forward-only storage optimization. Never link the mutable authoring workspace.
sealed_media_basis=root
shared_media_links={}
media_suffixes={'.png','.jpg','.jpeg','.webp','.ogg','.wav','.ttf','.woff','.woff2'}
for relative,expected in before.items():
 src=root/relative;dst=destination/relative;dst.parent.mkdir(parents=True,exist_ok=True)
 sealed=sealed_media_basis/relative
 if relative.startswith('assets/') and src.suffix.lower() in media_suffixes and sealed.is_file() and not sealed.is_symlink() and stat.S_IMODE(src.stat().st_mode)==stat.S_IMODE(sealed.stat().st_mode) and hashlib.sha256(sealed.read_bytes()).hexdigest()==expected:
  os.link(sealed,dst)
  shared_media_links[relative]={'from':str(sealed),'sha256':expected,'mode':stat.S_IMODE(sealed.stat().st_mode),'mtime_ns':sealed.stat().st_mtime_ns}
 else:
  shutil.copyfile(src,dst);shutil.copymode(src,dst)
 assert hashlib.sha256(dst.read_bytes()).hexdigest()==expected,relative
assert before==files(),'Source changed while copying; snapshot REJECTED before any native run'
subprocess.run(['git','init','--quiet',str(destination)],check=True)
objects=Path(subprocess.check_output(['git','rev-parse','--path-format=absolute','--git-path','objects'],text=True).strip())
(destination/'.git/objects/info/alternates').write_text(str(objects)+'\n')
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
shallow=Path(subprocess.check_output(['git','rev-parse','--git-path','shallow'],text=True).strip())
if shallow.exists():shutil.copyfile(shallow,destination/'.git/shallow')
subprocess.run(['git','update-ref','--no-deref','HEAD',head],cwd=destination,check=True)
subprocess.run(['git','read-tree','HEAD'],cwd=destination,check=True)
(destination/'.git/info/exclude').write_text('build/\n.godot/\n')
if (root/'.godot').exists():shutil.copytree(root/'.godot',destination/'.godot')
(destination/'build/verification').mkdir(parents=True)
receipt={'scope':'Runtime source snapshot only, base actualGitHEAD plus actual dirty runtime overlay. Nonconsumer docs omitted, not a clean checkout or fullrelease proof. Genuine source objects read-only alternate; independent HEAD/index/cache/userdata.','base_commit':head,'source_files':before,'source_copy_guard':True,'created':time.time(),'source_root':str(root),'snapshot_root':str(destination),'shared_media_links':shared_media_links,'media_storage_scope':'New snapshots only: identical SHA+mode immutable binary assets may share a sealed snapshot inode, never mutable main. Existing media bytes/mode/mtime remain unchanged; inode link-count/ctime change. No old snapshot path replaced or metadata normalized. Import sidecars and all code remain independent copies. Unlink/copy a shared binary before any future edit; sealed snapshots are read-only evidence.'}
(destination/'build/snapshot-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
(destination.parent/(destination.name+'-receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'snapshot':str(destination),'files':len(before),'base_commit':head,'copy_guard':True}))

main=Path('/workspace/gunman-rush-design')
overlay_paths=['scripts/generation/forest_hollow_upper_candidate.gd','tests/forest_hollow_upper_runner.gd','tools/run_forest_hollow_upper.py']
overlay_before={p:hashlib.sha256((main/p).read_bytes()).hexdigest()for p in overlay_paths}
changes={}
for p in overlay_paths:
 changes[p]={'before':before[p],'after':overlay_before[p]}
 shutil.copyfile(main/p,destination/p)
 assert hashlib.sha256((destination/p).read_bytes()).hexdigest()==overlay_before[p]
 receipt['source_files'][p]=overlay_before[p]
assert overlay_before=={p:hashlib.sha256((main/p).read_bytes()).hexdigest()for p in overlay_paths}
receipt['scope']='Frozen upper02 runtime base plus exact three authored geometry/driver/checker overlay. Selected shared upper seam experiment; not current main equivalence or clean commit.'
receipt['base_snapshot_receipt_sha256']=hashlib.sha256((root/'build/snapshot-receipt.json').read_bytes()).hexdigest()
receipt['overlay_guard']=True
receipt['overlay_source_changes']=changes
receipt['source_copy_guard']=all((destination/p).is_file() and hashlib.sha256((destination/p).read_bytes()).hexdigest()==h for p,h in receipt['source_files'].items())
assert receipt['source_copy_guard']
(destination/'build/snapshot-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
(destination.parent/(destination.name+'-receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'overlay_guard':True,'source_copy_guard':True,'source_files':len(receipt['source_files']),'changes':changes}))
