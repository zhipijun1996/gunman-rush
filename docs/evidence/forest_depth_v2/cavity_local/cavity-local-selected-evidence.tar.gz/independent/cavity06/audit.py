import hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[4];s=ROOT/'build/forest_depth/snapshots/cavity06';p=s/'build/forest_depth/cavity/intended01';out={'scope':'Offline raw geometry/body/event audit, no engine','sources':{},'cases':{}}
for n in ['scripts/demo/forest_hollow_trunk_golden.gd','scripts/damage/demo_contact_emitter.gd','scripts/player/traversal_ability.gd','scripts/generation/forest_hollow_upper_candidate.gd','tests/forest_hollow_upper_runner.gd']:
 out['sources'][n]=hashlib.sha256((s/n).read_bytes()).hexdigest()
def intersect(a,b):return min(a[0]+a[2],b[0]+b[2])>max(a[0],b[0]) and min(a[1]+a[3],b[1]+b[3])>max(a[1],b[1])
for n in ['cavity_HR','noH_cavity_twoR','noH_cavity_outer','cavity_wrongR']:
 f=p/(n+'.json');r=json.loads(f.read_text());fs=r['frames'];ds=r['manifest']['dangers'];c=next((x for x in fs if x['tick']==r['return_start_tick']),None)
 crossings=[x for x in fs if -220<x['position'][0]<330 and x['body'][1]<-300 and x['phase'] not in ['cavity_return_walk','cavity_return_roof']]
 out['cases'][n]={'capture':str(f.relative_to(ROOT)),'sha':hashlib.sha256(f.read_bytes()).hexdigest(),'frames':len(fs),'contiguous':list(range(1,len(fs)+1))==[x['tick'] for x in fs],'oneMotor':all(x['motor_steps']==1 for x in fs),'all_on_screen':all(x['body_on_screen'] for x in fs),'damage_events':r['damage_events'],'policy_returns':r['policy_returns'],'reached':r['reached'],'returned':r['returned'],'failure':r['failure'],'no_midroute_injection':not r['midroute_injection'],'manual_motor':r['manual_motor_step'],'body_danger_overlap_frames':[(x['tick'],i) for x in fs for i,d in enumerate(ds) if intersect(x['body'],d)],'target_C_tick':r['return_start_tick'],'C_energy':c['energy'] if c else None,'C_hp':c['health'] if c else None,'final':fs[-1],'hooks':[e for e in r['events'] if e.get('kind') in ['hook_cast','hook_contact_kick','hook_kick']],'shots':[e for e in r['events'] if e.get('kind')=='shot_fired'],'full_support_C':None}
 if c:
  exitrect=next(z['rect'] for z in r['manifest']['platforms'] if z['id']=='cavity_exit');out['cases'][n]['full_support_C']=c['body'][0]>=exitrect[0] and c['body'][0]+24<=exitrect[0]+exitrect[2]
 q=out['cases'][n];q['final']={k:q['final'][k] for k in ['tick','position','health','energy','shots','supports','body']}
(ROOT/'build/forest_depth/independent/cavity06/raw-audit.json').write_text(json.dumps(out,indent=2)+'\n')
for k,v in out['cases'].items():print(k,{n:v[n] for n in ['frames','oneMotor','all_on_screen','target_C_tick','C_energy','body_danger_overlap_frames','final']})
