# Cavity06 原生四路局部审查（影片待补）

2026-10-17，`/root/forest_ecology_review`。gameplay-reviewer；不同作者只读，不改生产、不占engine。输入冻结`snapshots/cavity06`、其`build/forest_depth/cavity/intended01/{cavity_HR,noH_cavity_twoR,noH_cavity_outer,cavity_wrongR}.json/.log`和原receipt；本目录`audit.py/raw-audit.json`独立重算。**局部机制CONTINUE；G2可见边界/全速连续片、容错扰动及正式生成准入UNVERIFIED。** 主生成未启用，不能称地区整合完成。

## 先分清证据身份

01/02恢复失败、04/05原件缺Emitter/不正确危险消费者不能证明当前环境安全。06实际在manifest三危险矩形各创建DemoContactEmitter：ENVIRONMENT、中心和half_size正等于矩形、interval.7，并将同矩形加入Segment危险范围；H保护只屏蔽MONSTER，不屏蔽ENV。Module遗留危险渲染列表清空只为防止天花被误画DEEP DROP；实际manifest、Policy和Segment仍使用同一三矩形。overlay从同矩形画实色边框/朝向正确刺，不能用图形变更冒几何变更。

原四个native都正常返回、strictclean；原wrapper整体仍FAIL `charges_not_actual_accepted_shot_and_ground_reset`，因为ENV回退在未grounded当帧合法恢复shots2。保留此失败，不能改称旧reader通过。作者正在新reader离线解释该合法reset；本报告**尚未审其新reader或原始包重放**，并不签wrapper总体PASS。

## 动作、代价和真实回退

| 策略 | C到达tick | C能量 | S返程完成tick | HP |
|---|---:|---:|---:|---:|
| H+R两单元 |163|72|548|5→5|
| 强普通4R |121|30|506|5→5|
| 普通无H无R屋顶绕路 |323|100|708|5→5|
| H后向下误R |未达|—|68实际稳定S|5→4|

每例真实逐tick连续，Motor_steps每帧1，没有midroute injection。前三完整24×36 body逐帧不交三危险矩形，C处全身横向完整支撑；回S都有实际12稳定帧。H contact40/116真实ring_a/b，两枪55/131；强普通四枪20/36/74/90，无H；普通法无枪/钩但经过实际左台→屋顶→右落点。每单元bay是真落地恢复与再观察，不借虚空补行动。contact后restore_air_actions刷新H是当前合同，不能按一H/airtime否定后续钩。

H不比4R快；其价值是同一狭道以较少普通枪精力到C（72vs30），且比完全不耗资源外绕少160tick=2.67秒。允许4R熟练快解和普通安全外绕。去掉H仍有另外两种有效解，因此本局部应作为**有代价取舍的H特色快捷解**，不证明森林大部分内容已经依赖H。C→S三成功法共385tick=6.42秒相同返路，末能量全100；不得把C结余改写成返S终态节能收益。长返路可承担回望/恢复，但尚未验证其玩法节奏，不批量复制成空回廊。

错误R真实因果：tick55正常向下射击让身体上推；ENVreturn原`from=(-100.400,-407.604)`，body上边-425.604，与天花[-430,-410]实际相交。tick56当前frame已经回spawn(-245,-318)，HP4/shots2；actor_epoch1→2，原Policy源`hollow_thorns_0`伤1，随后S稳定12。不能仅因post-return帧不交刺而否认碰撞，也不能把新epoch清算误当driver回血/恢复。该例证明事故ENV容错，不是主路必须损血。

## 关键限制与最小下一步

1. 狭道净高110，body高36给定静态中心范围，但不能据此宣称全轨迹余量37px。按body水平投影实际与危险重叠重算，H出程最小下沿距地刺**3.270px/t32**，最小顶沿距天花**11.657px/t92**；强普通最小顶沿11.657px。exact当前路线安全，尚缺粗输入/延迟扰动，不能签时序宽容或大师门槛已解决。无需缩body/扩大射程；先少量同内容输入偏移反证，失败则保留失败定位，不改Player救。
2. raw全body_on_screen为真，两个下一环在接近时有实际visibility信息；这不等于刺尖、顶板边界和目的落点在正常镜头里已可读。本轮尚未看06实机像素/连续片，**G2明确UNVERIFIED**。等同source完整影片，再看天花向下刺、地刺、safe bay、环与落点是否一致，尤其t31–40的3px近底过渡和错误R撞顶。不能用无Emitter旧片或仅metadata签公平。
3. 该测试从S起，成功返S；未验证M→S、C→正式E的连续资源/Port契约，更不签主生成多Seed、生态阻路、奖励回程或正式save。main几何factory重构需另绑定源验证，不将06旧source原件冒新默认。
4. 可保留观察→两个水平H/斜侧拉接反向R→安全bay再决策→C宽台→外绕恢复的实玩语法；避免第二单元只是机械重复两次成为长链模板。下一决定应消费完整影片和有限输入容错，而不是重复长engine或以函数/hash数量证明价值。

本报告只签原生动作/资源/Policy关系的有限事实和机制继续，不签原wrapper通过、完整G2、玩家趣味/音频/设备或整区完成。后续影片另增量复审。
