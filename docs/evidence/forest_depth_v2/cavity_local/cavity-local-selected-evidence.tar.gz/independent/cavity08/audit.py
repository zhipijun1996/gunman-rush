import hashlib,json,sys,importlib.util,copy
from pathlib import Path
ROOT=Path(__file__).resolve().parents[4];s=ROOT/'build/forest_depth/snapshots/cavity08';p=s/'build/forest_depth/cavity';out={'scope':'Independent offline raw/reader/keyframe identity audit; no engine','reader_sha':hashlib.sha256((s/'tools/run_forest_hollow_upper.py').read_bytes()).hexdigest(),'cases':{},'mutants':[]}
sys.path.insert(0,str(s/'tools'));spec=importlib.util.spec_from_file_location('cavity_reader',s/'tools/run_forest_hollow_upper.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
for label,sub,file in [('standing','standing01','cavity_HR.json'),('R_plus3','standing_recoil3','cavity_HR.json'),('start_plus8','standing_start8','cavity_HR.json'),('GL','movie08','capture.json')]:
 f=p/sub/file;r=json.loads(f.read_text());fs=r['frames'];dangers=r['manifest']['dangers'];gaps=[]
 for a in fs:
  if a['tick']>r['return_start_tick']:continue
  b=a['body']
  for i,d in enumerate(dangers):
   if min(b[0]+24,d[0]+d[2])>max(b[0],d[0]):gaps.append((b[1]-d[1]-d[3] if i==0 else d[1]-b[1]-36,a['tick'],i))
 c=fs[r['return_start_tick']-1];out['cases'][label]={'path':str(f.relative_to(ROOT)),'sha':hashlib.sha256(f.read_bytes()).hexdigest(),'reader_errors':m.validate(r),'frames':len(fs),'C':r['return_start_tick'],'C_energy':c['energy'],'final_hp':r['final_hp'],'final_energy':fs[-1]['energy'],'min_vertical_gap':min(gaps),'all_body_on_screen':all(x['body_on_screen'] for x in fs),'hook_and_shot_events':[e for e in r['events'] if e['kind'] in ['hook_cast','hook_contact_kick','hook_kick','free','shot_fired','jumped']]}
 if label=='standing':hr=r
 if label=='GL':gl=r
keys=['tick','position','velocity','body','grounded','supports','hook_state','hook_used','shots','energy','health','motor_steps']
out['headless_GL_equal']={'physical':[[{k:f[k] for k in keys} for f in r['frames']] for r in [hr,gl]][0]==[{k:f[k] for k in keys} for f in gl['frames']],'events':hr['events']==gl['events'],'requests':hr['requests']==gl['requests']}
wrong=json.loads((ROOT/'build/forest_depth/snapshots/cavity06/build/forest_depth/cavity/intended01/cavity_wrongR.json').read_text());out['wrong06_new_reader_errors']=m.validate(wrong)
controls={
 'return_fake_from':lambda r:r['policy_returns'][0].update({'from':[-245,-318]}),
 'wrong_epoch':lambda r:r['policy_returns'][0].update({'actor_epoch_after':1}),
 'wrong_source':lambda r:r['damage_events'][0].update({'source':'hollow_thorns_1'}),
 'fake_reset_energy':lambda r:r['frames'][55].update({'energy':100}),
 'delete_return':lambda r:r.update({'policy_returns':[]}),
 'delete_H_contact':lambda r:r.update({'events':[e for e in r['events'] if e['kind']!='hook_contact_kick']}),
}
for n,change in controls.items():
 r=copy.deepcopy(hr if n=='delete_H_contact' else wrong);change(r)
 try:errors=m.validate(r);out['mutants'].append({'name':n,'reject':bool(errors),'errors':errors})
 except Exception as e:out['mutants'].append({'name':n,'reject':True,'exception':str(e)})
idx=json.loads((ROOT/'build/forest_depth/traversal/cavity08/keyframes/index.json').read_text());out['movie_sha_matches_index']=hashlib.sha256((ROOT/idx['movie']).read_bytes()).hexdigest()==idx['movie_sha256'];out['keyframes_sha_match']=all(hashlib.sha256((ROOT/x['file']).read_bytes()).hexdigest()==x['sha256'] for x in idx['frames'])
(ROOT/'build/forest_depth/independent/cavity08/raw-audit.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='cases'},indent=2));print({k:{a:v[a] for a in ['frames','C','C_energy','min_vertical_gap','reader_errors']} for k,v in out['cases'].items()})
