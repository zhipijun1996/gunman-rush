# Cavity08 站地H与可见边界增量独审

2026-10-17；审查者 `/root/forest_ecology_review`，实现者 `/root/forest_traversal`。采用gameplay-reviewer；只读冻结consumer/raw/reader与实际电影，未改生产、未运行engine。承接`../cavity06/REVIEW-raw.md`，不重写旧失败。

**局部CONTINUE：站地斜上H→原生接触kick→反向R横移→安全湾→第二段同语法→宽C→屋顶返S，作为H特色资源取舍挑战成立，可用于下一连接黄金。** G2仅接受本次实际画面可见边界与动作空间接口的有限观察；未完整实时播放60fps或亲自操控，未听音轨，不签手感/音画同步/趣味/设备或最终美术。新生成S/C接缝、cache_route、M/E连续入口/出口与整区准入仍UNVERIFIED。不是森林大部分内容H依赖已经成立。

## 冻结与观察范围

权威输入`snapshots/cavity08`；`build/forest_depth/cavity/{standing01,standing_recoil3,standing_start8}/cavity_HR.json`；完整GL `movie08/{capture.json,gameplay.mp4,receipt.json,native.log}`。电影SHA `9f2101c0ac164f3ea110dd038f37d0c4fc9a2d6788e186bc0d2876932f57d9c8`、538帧60fps/8.9667秒；capture实际534连续观察，不声称编码帧号等物理tick。

亲自打开并查看作者keyframes/index.json绑定的**全部12张1280×720原尺寸帧**：视频n12/.2s、30/.5s、38/.633s、52/.867s、80/1.333s、106/1.767s、122/2.033s、155/2.583s、315/5.25s、450/7.5s、522/8.7s、537/8.95s。另独立FFmpeg每6帧采样解码得到90张10fps序列，实际看完本目录sheet0–2，覆盖0–8.9秒。该方法是全时间范围像素抽样，不冒称完整60fps实时播放。末n537是正常退出后的黑帧，n522已回到可见S；不以黑帧掩盖未完成动作。

原receipt source_guard/exit0/validation_errors[]且native完整；独立当前重算snapshot全部2033 source哈希无变，movie receipt绑定905source哈希无变。room/geometry/Traversal/PlayerMotor与06逐字节相同，改动是驾驶语法/reader，不是改身体/危险/能力救关。独立绑定/计算见`audit.py/raw-audit.json`。

## 已看到的空间与动作

- .2s从S能看完整顶板向下刺、两块底刺、安全bay、两个金环和C出口；粉红框/实色危险与金环/棕绿支撑面区分明确。可先停观察，风险来自可见夹道，不靠镜头外刺。
- .5–.867s主角从站地斜上拉入第一环，接触后向左kick，再射左弹获得右反冲。原尺寸帧可分辨身体、环、枪火和上下刺边界；没有素材遮掉唯一落点。1.333s稳定bay，第一单元与第二单元之间有实际落脚和再观察。
- 1.767–2.583s第二段同语法到宽C，下一环与出口提前可见。站地H免去起跳时机，动作由空间与原生contact/kick反馈串联；对旧jump-H早−3顶刺事故的修正来自换合法解法，原失败仍有效，不改几何。
- 3.0–5.9s沿右侧台跳上顶板；6.0–8.0s沿屋顶长横返，8.7s回S。摄像机跟随，原空洞和已走支路在返程下方可回望，边界与左右台可读。返路节奏主要是小跳后长走，无新H判断：可以当这一小样的安全恢复/回望，但不应当作新的H挑战或多次复制的主要内容。
- 临时粉框与高对比刺已能传达判定，材质有明显矩形大块重复/硬裁接口；本轮美术不准入商业完成度。无需为了清晰度先重画森林美术。

## 真实动作、资源与有限扰动

站地目的：H13/80、真实contact33/102、kick40/109、free47/116后R48/117，两环两枪，C149/E77.5/HP5，完整返S534/末E100。初始不jump；后续返程普通跳是另一路。headless与GL实际534帧physical keys逐帧相等、requests/events相等，已独立重算，不只信作者receipt。

R延迟+3tick真实C155、全程540帧；**起点+8是launch_offset=8px，不是8tick**，真实先走到x≈−237并稳定，H25，C161、全程546帧，增加时间主要是对齐；两者都是2枪/E77.5/HP5且完整返S。它们证明这两个有限扰动可成立，不证明任意延迟/任意起点/粗瞄准均可。

完整body与危险实际横投影相交时，站地目的最小地刺间隙2.921px/t25，起点+8是3.101px/t37。数值仍近边，不能写“净高110所以全程宽容37px”；但此近边段是原生H拉入而非要求玩家精确手动操纵3px缝，已存在起点变化实证，不能仅按余量小直接判不公平。旧jump早−3的顶刺ENV/HP4/S12保留为该旧语法失败，不拿新解覆盖失败链。

取舍边界：新H C77.5，对06同几何4R C30/121tick、普通外绕C100/323tick。H比4R慢28tick、比完全不耗资源外绕快174tick=2.9秒；因此是速度/资源/路径三种选择，不宣称H最快。返S均自然恢复100，节能价值只在C节点，未证明后接战斗/奖励能消费该结余。06强/普通/wrong消费者的危险绑定已审；08未重新采它们，复用范围只因geometry/room/物理一致，并不把它们改名08新native。

## 新reader的有限复核

冻结reader `tools/run_forest_hollow_upper.py` SHA `5ab53471eb687074e3a0a1f298c973abd47cbfccb5fe0af1f181dc2652a16985`。逐读ENVreset证明、原成本/延迟/地面回复计算；只在同tick真实ENV源、from全body交同危险、HP减1、epoch+1、spawn位置一致后允许Segment当帧shot/Hreset，不回血/补能。

实际离线运行：三站地raw+GL均errors[]；原06wrong同字节raw也errors[]。独立六控制全部拒绝：ENV from移安全区、epoch未增、伪危险来源、返程补能100、删return、删Hcontact。旧06reader不能处理合法未grounded reset的FAIL仍保留；这是新reader新的范围接受，不倒改旧PASS身份。该复核不是通用防伪器完整认证，不声称全部malformed输入已覆盖。

## 允许推进与仍待项

可推进一个带真实S/C接缝的连接黄金，保留4R/外绕合法解与wide bay恢复，不应把H变钥匙。注意每个单元目前同一个H→R判断，扩展时应让第二单元承担不同发现/资源/返回关系；不要只加第三第四个同夹道来造丰富。

本次没有发现必须先改生产几何的阻塞；可见边界和站地choreo继续。完整实时手感/声音、玩家认可、复杂输入容错、正式入口/生成连通/奖励保存、新接缝全body/最坏资源、区域核心H依赖仍未验。长385tick回程与终点能量全恢复应保留在之后宏观体验审查，不能被局部通过抹去。
