from pathlib import Path
import json,sys
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R/'common/tools'));import run_forest_hollow_upper as reader
paths=list((R/'snapshots/cavity06/actual/intended01').glob('*.json'))+[R/'snapshots/cavity08/actual'/n/'cavity_HR.json' for n in ['standing01','standing_recoil3','standing_start8']]+[R/'snapshots/cavity08/actual/movie08/capture.json'];rows=[]
for p in paths:
 if p.name=='receipt.json':continue
 errors=reader.validate(json.loads(p.read_text()));rows.append({'capture':str(p.relative_to(R)),'errors':errors});assert not errors,(p,errors)
print(json.dumps({'scope':'offline later08 verifier only, not new native wrapper acceptance','cases':rows},indent=2))
