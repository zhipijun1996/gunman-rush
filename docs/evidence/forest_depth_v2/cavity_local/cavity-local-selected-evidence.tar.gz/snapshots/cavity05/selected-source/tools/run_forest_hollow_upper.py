"""Bounded floorless canopy comparison; existing real Hollow consumer, not promotion."""
import argparse,contextlib,hashlib,json,re,time
from pathlib import Path
import level_formal
from run_tests import run_engine
from run_forest_directional_golden import _resource_errors
ROOT=Path(__file__).resolve().parents[1]
VARIANTS=('H0R','noH_zeroR','noH_oneR','wrongH','noH_bay','cavity_HR','noH_cavity_twoR','cavity_wrongR','noH_cavity_outer')
def validate_cavity(d):
    errors=[];fs=d.get('frames',[]);ps={p['id']:p for p in d['manifest']['platforms']}
    if not fs:return ['continuous capture missing']
    if d.get('failure') or not d.get('returned'):errors.append('actual bounded complete recovery required')
    if not d.get('audio_released') or d.get('manual_motor_step') is not False or d.get('midroute_injection') is not False:errors.append('real input/lifecycle required')
    for i,f in enumerate(fs):
        if f['tick']!=i+1 or f['motor_steps']!=1:errors.append('one real Motor per continuous tick');break
        x,y=f['position']
        if f['body']!=[x-12,y-18,24,36] and any(abs(a-b)>.001 for a,b in zip(f['body'],[x-12,y-18,24,36])):errors.append('body envelope missing')
        for key in f['supports']:
            px,py,w,_=ps[key]['rect']
            if not f['grounded'] or abs(y+18-py)>1 or x-12<px or x+12>px+w:errors.append('false fullsupport')
    errors+=_resource_errors(fs,d['events'],json.loads((ROOT/'config/player_tuning.json').read_text()))
    if not all('cavity_observe' in f['supports'] for f in fs[-12:]):errors.append('real S recovery fullsupport12 missing')
    if d['variant']=='cavity_wrongR':
        if d.get('reached') or not d['damage_events'] or not d['policy_returns'] or d['final_hp']!=d['initial_hp']-1:errors.append('wrong direction actual Policy damage and segment recovery required')
    else:
        if not d.get('reached') or d['damage_events'] or d['policy_returns']:errors.append('direct real cavity route without damage required')
        for support in (['cavity_exit'] if d['variant']=='noH_cavity_outer' else ['cavity_bay','cavity_exit']):
            n=0;best=0
            for f in fs:
                n=n+1 if support in f['supports'] else 0;best=max(best,n)
            if best<12:errors.append(support+' fullsupport12 missing')
        contacts=[e for e in d['events'] if e['kind']=='hook_contact_kick']
        if d['variant']=='cavity_HR' and {e.get('target') for e in contacts}!={'cavity_ring_a','cavity_ring_b'}:errors.append('actual two cell H contacts required')
        if d['variant'].startswith('noH') and any(e['kind']=='hook_cast' for e in d['events']):errors.append('control used H')
        if d['variant']=='noH_cavity_outer' and any(e['kind']=='shot_fired' for e in d['events']):errors.append('ordinary outside control used R')
    return sorted(set(errors))
def validate(d):
    if 'cavity_contract' in d['manifest']:return validate_cavity(d)
    errors=[];fs=d.get('frames',[]);ps={p['id']:p for p in d['manifest']['platforms']}
    if not fs:return ['continuous capture missing']
    if d.get('manual_motor_step') is not False or d.get('midroute_injection') is not False:errors.append('normal input consumer required')
    if d.get('failure') or not d.get('reached') or not d.get('returned'):errors.append('actual crown and complete natural entry return required')
    if not d.get('audio_released'):errors.append('audio release missing')
    if d['damage_events'] or d['policy_returns'] or d['initial_hp']!=d['final_hp']:errors.append('natural recovery without damage/segment required')
    for i,f in enumerate(fs):
        if f['tick']!=i+1 or f['motor_steps']!=1:errors.append('continuous one Motor per frame required');break
        x,y=f['position']
        if any(abs(a-b)>.001 for a,b in zip(f['body'],[x-12,y-18,24,36])):errors.append('full body missing');break
        for key in f['supports']:
            px,py,w,_=ps[key]['rect']
            if not f['grounded'] or abs(y+18-py)>1 or x-12<px or x+12>px+w:errors.append('support/body mismatch')
    errors+=_resource_errors(fs,d['events'],json.loads((ROOT/'config/player_tuning.json').read_text()))
    if not all('belly_entry' in f['supports'] for f in fs[-12:]):errors.append('final entry fullsupport12 missing')
    shared=bool(d['manifest'].get('upper_candidate_contract',{}).get('preserved_lower_ports'))
    crown=next((e for e in d['events'] if e.get('to')==('shared_depart' if shared else 'crown_return')),None)
    if not crown or not all('outer_crown' in f['supports'] for f in fs if crown['tick']-11<=f['tick']<=crown['tick']):errors.append('crown fullsupport12 missing')
    all_shots=[e for e in d['events'] if e['kind']=='shot_fired']
    shots=[e for e in all_shots if not shared or e['tick']<=d['return_start_tick']]
    hooks=[e for e in d['events'] if e['kind']=='hook_contact_kick']
    if d['variant']=='H0R' and (shots or not any(e['target']=='upper_window_ring' for e in hooks) or d['recovered']):errors.append('zero-shot actual H direct crossing required')
    if shared:
        if not d.get('lower_entered'):errors.append('actual preserved lower-window D reception missing')
        landing=next((e for e in d['events'] if e.get('from')=='shared_inner_land' and e.get('to')=='return_floor'),None)
        if not landing or not all('inner_root' in f['supports'] for f in fs if landing['tick']-11<=f['tick']<=landing['tick']):errors.append('lower-window actual D fullsupport12 missing')
        lower=[e for e in d['events'] if e['tick']>d['return_start_tick']]
        if d['variant'].startswith('noH'):
            if sum(e['kind']=='shot_fired' for e in lower)!=1:errors.append('actual cheapest lower one-R return required')
        elif not any(e['kind']=='hook_contact_kick' and e.get('target')=='lower_window_ring' for e in lower):errors.append('actual preserved deep lower H contact missing')
    if d['variant'].startswith('noH') and any(e['kind']=='hook_cast' for e in d['events']):errors.append('noH control cast')
    if d['variant']=='noH_oneR' and len(shots)!=1:errors.append('one actual shot control required')
    if d['variant']in ('noH_zeroR','wrongH','noH_bay','cavity_HR','noH_cavity_twoR','cavity_wrongR','noH_cavity_outer') and shots:errors.append('zero-shot control actually fired')
    if d['variant']=='wrongH' and not d['recovered']:errors.append('wrong hook must actually recover below')
    return sorted(set(errors))
def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--variants',nargs='+',choices=VARIANTS,default=['H0R']);ap.add_argument('--output-dir',required=True);ap.add_argument('--skip-import',action='store_true');ap.add_argument('--shared',action='store_true');ap.add_argument('--cavity',action='store_true');a=ap.parse_args()
    out=(ROOT/a.output_dir).resolve()
    if out.exists() or not out.is_relative_to(ROOT/'build'):ap.error('fresh output under build required')
    out.mkdir(parents=True);before=level_formal.source_files();snapshot=json.loads((ROOT/'build/snapshot-receipt.json').read_text());r={'scope':'new canopy physical/resource hypothesis only; no regional admission','source_before':before,'cases':[],'passed':False};start=time.monotonic()
    try:
        if not a.skip_import:
            with (out/'import.log').open('w')as log,contextlib.redirect_stdout(log):run_engine(['--headless','--path','.','--editor','--quit'],90)
        for variant in a.variants:
            row={'variant':variant,'passed':False};r['cases'].append(row);argv=['--headless','--fixed-fps','60','--path','.','--script','tests/forest_hollow_upper_runner.gd','--','--variant='+variant,'--output=res://'+str((out/(variant+'.json')).relative_to(ROOT))];
            if a.shared:argv.append('--shared')
            if a.cavity:argv.append('--cavity')
            row['argv']=argv
            with (out/(variant+'.log')).open('w')as log,contextlib.redirect_stdout(log):text=run_engine(argv,45)
            if re.search(r'(?m)^ERROR:|SCRIPT ERROR:|SHADER ERROR:|ObjectDB.*leaked|resources? still in use',text):raise RuntimeError('strict native error')
            if 'FOREST HOLLOW: '+variant+' terminal 'not in text:raise RuntimeError('terminal marker missing')
            d=json.loads((out/(variant+'.json')).read_text());row['validation_errors']=validate(d);row['passed']=not row['validation_errors'];row['frames']=len(d['frames']);row['shots']=sum(e['kind']=='shot_fired'for e in d['events']);row['recovered']=d['recovered'];row['crown_tick']=d['return_start_tick']
            if not row['passed']:raise RuntimeError('candidate failed: '+str(row['validation_errors']))
        r['passed']=True
    finally:
        r['source_after']=level_formal.source_files();r['source_guard']=r['source_after']==before;r['copy_source_guard']=all((ROOT/p).is_file()and hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==h for p,h in snapshot['source_files'].items());r['elapsed_seconds']=time.monotonic()-start;r['logs']={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in out.iterdir()if p.is_file()};(out/'receipt.json').write_text(json.dumps(r,indent=2)+'\n')
        if not r['source_guard']or not r['copy_source_guard']:raise RuntimeError('source drift')
    print('PASS: floorless canopy specified actual routes only; not admitted')
if __name__=='__main__':main()
