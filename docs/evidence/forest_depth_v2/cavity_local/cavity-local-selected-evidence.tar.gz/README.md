# Selected horizontal-cavity local evidence

Selected source, real raw traces/logs/commands, full source inventories, complete08 compressed movie and original-size keyframes. NOT a complete native project: assets/cache/engine binary/raw AVI are excluded. No missing project reconstruction, CI ZIP or device/player claim. Copy receipts distinguish frozen basis and small driver/reader overlays, never clean-current-main equivalence.

Historical01/02 full-routeFAIL,03 copy-only/superseded,04 outside-wrongFAIL,05 same-state-wrong missingEmitterFAIL and06 original wrapper resource-resetFAIL remain unmodified.01-05 positive physical traces are GEOMETRY/ACTION ONLY and cannot prove live environment.06 introduces real production ENV emitter/Segment return, same physical rectangles; original old resource reader FAIL is preserved.08 later reader proves ENV source/body/HP/epoch/anchor reset and standing choreography; do not relabel06 native wrapper as newly passed.

06 purpose H+R C163/E72 versus noH4R C121/E30 and ordinary noH/noR C323/E100.08 standing-H C149/E77.5 eliminates useless jump. Same geometry real normalHP5.08 lateR3/start8 pass, old jump earlycast3 really hits ceiling and returns S/HP4, not erased. Signature is optional resource/time/method choice, never H necessary. All full returns refill E100; long385tick exterior return is a limitation. Local independent CONTINUE excludes M/S/C/E new seams, formal macro/enemy coupling, generic input comfort, final art, device/player acceptance.

Complete08 GL movie538@60fps=8.9667s; matching headless/GL534 physical frames+events+requests. Keyframe times are decoded movie frame n/60, not physics tick equality. Review checked12 frames+90 10fps sequence, not real-time60fps watching/hearing.

Run `python3 replay.py` for offline current08 reader on actual06 four +08 three/GL; old checkerFAIL is separate producer identity. No Godot/browser runs.
