from pathlib import Path
import os,json,subprocess,time,hashlib
R=Path('/workspace/gunman-rush-design');S=R/'build/forest_depth/snapshots/cavity_formal01';O=R/'build/forest_depth/traversal/cavity_formal01';env={**os.environ,'GUNMAN_TOOLCHAIN_ROOT':'/workspace/toolchains','GUNMAN_DATA_HOME':str(S/'build/userdata'),'XDG_CONFIG_HOME':str(S/'build/userconfig'),'XDG_CACHE_HOME':str(S/'build/usercache')};argv=['python3','tools/run_forest_depth_region.py','--seed','forest-depth-hollow-00','--map','1','--route','borer','--output','build/forest_depth/region/borer01'];started=time.monotonic();r={'scope':'First actual fresh-current-main borer consumer, dirty2012inventory bound; not old isolated-golden admission','argv':argv,'cwd':str(S),'snapshot_receipt_sha256':hashlib.sha256((S/'build/snapshot-receipt.json').read_bytes()).hexdigest()}
try:
 with (O/'native-outer.log').open('w')as log:
  p=subprocess.run(argv,cwd=S,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=355);r['exit_code']=p.returncode
finally:
 r['seconds']=time.monotonic()-started;r['all_original_snapshot_sources_unchanged']=all((S/k).is_file() and hashlib.sha256((S/k).read_bytes()).hexdigest()==v for k,v in json.loads((S/'build/snapshot-receipt.json').read_text())['source_files'].items());(O/'outer-receipt.json').write_text(json.dumps(r,indent=2)+'\n')
raise SystemExit(r.get('exit_code',1))
