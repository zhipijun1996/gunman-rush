import sys,json,copy,ast,hashlib
from pathlib import Path
sys.path.insert(0,'tools');import run_forest_depth_campaign_boss as v
base=Path('build/forest_depth/canopy-app-preparation');d=json.loads(Path('build/forest_depth/snapshots/canopy_app02/build/forest_depth/campaign/canopy_app02/capture.json').read_text());v.validate_canopy_policy_ledger(d)
tests=[]
for name in ['boss_source_owner','boss_actor_epoch','boss_foreign_frame','player_nan_amount','player_negative_amount','player_hp','player_lethal','shot_actor_owner','shot_session','player_actor_epoch']:
 m=copy.deepcopy(d);ev=m['combat']['events'];boss=next(x for x in ev if x.get('event')=='policy_result' and x.get('target')=='boss');player=next(x for x in ev if x.get('event')=='policy_result' and x.get('target')=='player');shot=next(x for x in ev if x.get('event')=='accepted_shot')
 if name=='boss_source_owner':boss['source']='player_projectile:999'
 elif name=='boss_actor_epoch':boss['actor_epoch']+=1
 elif name=='boss_foreign_frame':boss['physics_frame']=-1
 elif name=='player_nan_amount':player['amount']=float('nan')
 elif name=='player_negative_amount':player['amount']=-1
 elif name=='player_hp':player['hp']+=1
 elif name=='player_lethal':player['lethal']=True
 elif name=='shot_actor_owner':shot['motor_id']+=1
 elif name=='shot_session':shot['session']+=1
 elif name=='player_actor_epoch':player['actor_epoch']+=1
 try:v.validate_canopy_policy_ledger(m)
 except (ValueError,KeyError,TypeError) as e:tests.append({'id':name,'rejected':True,'reason':str(e)})
 else:tests.append({'id':name,'rejected':False})
a=ast.parse((base/'campaign-cli-before.py').read_text());b=ast.parse(Path(v.__file__).read_text());func=lambda t,n:ast.dump(next(x for x in t.body if isinstance(x,ast.FunctionDef) and x.name==n));legacy={n:func(a,n)==func(b,n) for n in ['validate','validate_queen']}
r={'scope':'Offline current ownership/HP-ledger ONLY against original02 fullfight raw. Original02 whole consumer remains FAILED (reload not attempted). Not fresh native or full-validator PASS.','original02_ledger_accepts':True,'mutants':tests,'legacy_AST_unchanged':legacy,'verifier_sha256':hashlib.sha256(Path(v.__file__).read_bytes()).hexdigest()};(base/'policy-reader-offline02.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2));assert all(t['rejected'] for t in tests) and all(legacy.values())
