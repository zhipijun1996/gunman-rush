from pathlib import Path
import json,hashlib,gzip,tarfile,io,difflib
root=Path.cwd();base=root/'build/forest_depth/canopy-app-preparation';dest=root/'docs/evidence/forest_depth_v2/canopy_app03';dest.mkdir(parents=True,exist_ok=True)
members={};bindings=[]
def add(name,data):
 assert name not in members;members[name]=data
selected=['tests/forest_depth_canopy_campaign_case.gd','tests/forest_depth_canopy_campaign_case.gd.uid','tests/forest_depth_canopy_campaign_pilot.gd','tests/forest_depth_canopy_campaign_pilot.gd.uid','tests/forest_depth_campaign_boss_runner.gd','tests/forest_depth_region_trace.gd','tests/audio_teardown.gd','tests/thorn_queen_canopy_runner.gd','tools/run_forest_depth_campaign_boss.py','tools/run_tests.py','tools/godot.sh','scripts/demo/demo_app.gd','scripts/demo/thorn_forest_region_stage.gd','scripts/generation/thorn_forest_region_generator.gd','scripts/generation/thorn_forest_region_v2.gd','scripts/generation/forest_boss_arena_factory.gd','scripts/bosses/thorn_queen_canopy_definition.gd','scripts/bosses/thorn_queen_canopy_encounter.gd','scripts/bosses/thorn_queen_canopy_presentation.gd','scripts/bosses/thorn_queen_weave_motor.gd','scripts/bosses/thorn_queen_weave_band.gd','scripts/bosses/boss_arena_seal.gd','scripts/damage/frame_damage_policy.gd','scripts/damage/damage_request.gd','scripts/damage/damage_result.gd','scripts/player/player_controller.gd','scripts/player/player_motor.gd','scripts/player/traversal_ability.gd','resources/bosses/thorn_queen_canopy.tres','resources/items/forest_heart_gold.tres','resources/weapons/pulse_gun.tres','resources/player/traversal.tres','scenes/bosses/thorn_queen_canopy.tscn','config/player_tuning.json']
for n in ['01','02','03']:
 snap=root/f'build/forest_depth/snapshots/canopy_app{n}';out=snap/f'build/forest_depth/campaign/canopy_app{n}';receipt=json.loads((snap/'build/snapshot-receipt.json').read_text());inventory=receipt['source_files']
 add(f'actual{n}/snapshot-receipt.json',(snap/'build/snapshot-receipt.json').read_bytes())
 add(f'actual{n}/inventory.json',(json.dumps(inventory,indent=2,sort_keys=True)+'\n').encode())
 for name in ['capture.json','native.log','import.log','receipt.json']:
  data=(out/name).read_bytes()
  add(f'actual{n}/'+(name+'.gz' if name=='capture.json' else name),gzip.compress(data,mtime=0) if name=='capture.json' else data)
  bindings.append({'case':n,'original':str(out/name),'archive_member':f'actual{n}/'+(name+'.gz' if name=='capture.json' else name),'original_sha256':hashlib.sha256(data).hexdigest(),'original_bytes':len(data),'lossless_gzip':name=='capture.json'})
 for name in ['run.py','outer.log','receipt.json']:add(f'actual{n}/outer/{name}',(base/f'native{n}'/name).read_bytes())
 for path in selected:
  src=snap/path
  if src.is_file():
   raw=src.read_bytes();assert hashlib.sha256(raw).hexdigest()==inventory[path];add(f'actual{n}/selected_source/{path}',raw)
  else:
   # Explicitly retain which desired mechanism source path did not exist.
   bindings.append({'case':n,'selected_path_not_present':path})
 if (out/'canopy-partial.json').is_file():
  raw=(out/'canopy-partial.json').read_bytes();add(f'actual{n}/canopy-partial.json.gz',gzip.compress(raw,mtime=0))
for name in ['entry-fix.json','case-before-entry-fix.gd','campaign-cli-before.py','campaign-runner-before.gd','policy-reader-offline02.json','replay_policy02.py','actual03-offline-revalidation.json','replay_actual03.py','package.py']:
 add('preparation/'+name,(base/name).read_bytes())
current=root/'tools/run_forest_depth_campaign_boss.py';frozen=root/'build/forest_depth/snapshots/canopy_app03/tools/run_forest_depth_campaign_boss.py'
add('offline_current/tools/run_forest_depth_campaign_boss.py',current.read_bytes())
add('offline_current/reader-delta.patch',''.join(difflib.unified_diff(frozen.read_text().splitlines(True),current.read_text().splitlines(True),fromfile='frozen03-native-verifier',tofile='offline-current-verifier')).encode())
add('bindings.json',(json.dumps(bindings,indent=2)+'\n').encode())
summary={'scope':'Selected original current-default canopy App evidence. Not a complete runnable native project, full CI, device, pixel or fun acceptance.','actual01':'FAILED: consumer observed only12 support frames, before unchanged0.65s seal telegraph closed. Native7 assertions/1failure, strictclean. Original early-entry per-frame observations were not persisted in01; route fullraw and initial/final remain. Not fabricated or recovered.','actual02':'FAILED wholecase: actual24HP fight, unique kill587/support12 at623/HP4→3, but grounded-only reload observer never triggered before death. Original full623 observedframes retained. Does not prove reload.','actual03':'Original frozen reader/native strictPASS46 assertions/0fail, outer30.884431622s/exit0,2068 sourcecopy/beforeafter guardtrue.704 observedentry/combat frames. Real phase2 saved Boss15HP/livingknot1HP/age0.516666667. Fresh Stage/Boss binding restored exact clocks/body/fields and actor ownership. Stale token Policy rejected.24 normalBoss commits/unique kill679/support12 at704. FightHP4→4: this particular fight proves no incurred fight damage, not invulnerability or all damage responses. Route itself entered HP4.','player_restore':'Actual production reload returns airborne Player1884.574,140.947 to legitimate S checkpoint1558,372, cancels H/motion/queuedinput and resets air actions. HP4/E80/cap5 preserved. Does not preserve airborne Player position or empty-gun count. Boss body/path/field clocks preserved, not restarted.','rewards':'Actual Viewport pointer MENU/RESUME/reward/GOLD/D/boundary. Goldcount0→1/maxHP5→7/HP4 and wallet0 unchanged. Duplicate GOLD rejected, compatible actualRunManifest records GOLD+D; HOME clears items/coins/abilities.','schema':'9 actual paused schema mutations each called valid_duel_snapshot and restore_combat_state, all rejected atomically. No invented snapshot geometry fields.','verifier_identity':'Native03 used immutable original verifier in actual03/selected_source. Reviewer found actual coherent cross-reload oldshot tuple acceptance after it passed. Offline-current adds one current actor/session binding line; same original03 raw accepted and13 coherent/nearby mutants rejected. Original native receipt/sourceguard is not relabeled as using offline-current verifier. Latest CI must execute latest verifier. Original02 partialledger-only revalidation is explicitly not wholecase PASS.','legacy':'Original validate and validate_queen AST remain exact. Old schema13 regression is pinned V7 by root, separate from this defaultV10/schema1 case. No claim old194 rerun locally.','pixels':'Headless only; no rendered label screenshot, browser, human fun, real device or audio listening claim. Audio service drain/weakrefs and strict engine exit only.','source':'Each snapshot base dd214ddec4394758d3d3efb71d604b86b7fdb7a3 + actual dirty runtime overlay; full2068 file inventories and original snapshot receipts retained. Selected code/config contracts match each inventory SHA. Assets/shaders/fonts/etc hashes retained in inventory but their binary payloads excluded; not a clean checkout or final-source CI.'}
add('SCOPE.json',(json.dumps(summary,indent=2,ensure_ascii=False)+'\n').encode())
index={name:{'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)} for name,data in sorted(members.items())};add('MEMBERS.json',(json.dumps(index,indent=2)+'\n').encode())
archive=dest/'canopy-app03-selected.tar.gz'
with archive.open('wb') as output:
 with gzip.GzipFile(fileobj=output,mode='wb',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as tar:
   for name,data in sorted(members.items()):
    info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tar:
 for member in tar.getmembers():
  assert member.isfile() and not member.name.startswith('/') and '..' not in Path(member.name).parts
  data=tar.extractfile(member).read();assert data==members[member.name]
  if member.name.endswith('capture.json.gz'):
   original=next(b for b in bindings if b.get('archive_member')==member.name);assert hashlib.sha256(gzip.decompress(data)).hexdigest()==original['original_sha256']
r={'archive':archive.name,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size,'regular_members':len(members),'indexed_members_excluding_self':len(index),'roundtrip_all_members':True,'lossless_capture_SHA_roundtrip':True,'source_selected_matches_full_inventory':True,'scope':summary}
(dest/'archive-receipt.json').write_text(json.dumps(r,indent=2,ensure_ascii=False)+'\n');(dest/'MEMBERS.json').write_text(json.dumps(index,indent=2)+'\n');(dest/'README.md').write_text('# Canopy App 03 evidence\n\nOriginal 01 and 02 are permanent failures. Original 03 passed the real App lifecycle and full24HP fight. A later reader-only cross-reload identity fix is validated offline against unchanged03 raw; it is not a new native run.\n\nSee archive SCOPE.json for exact limitations and original commands/receipts. This selected source archive is not a complete bootable project. Full source inventories bind all2068 original files. No binary assets, derived caches or movies are duplicated here. Headless evidence does not sign pixels, listening, player fun or device acceptance.\n')
print(json.dumps({'archive':str(archive),'bytes':r['bytes'],'sha256':r['sha256'],'members':len(members)}))
