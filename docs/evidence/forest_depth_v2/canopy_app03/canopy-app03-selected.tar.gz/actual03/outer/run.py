from pathlib import Path
import subprocess,os,signal,time,json,hashlib,sys,fcntl
root=Path('/workspace/gunman-rush-design');project=root/'build/forest_depth/snapshots/canopy_app03';out=Path(__file__).resolve().parent
seal=json.loads((project/'build/snapshot-receipt.json').read_text());paths=seal['source_files']
def inventory():return {p:hashlib.sha256((project/p).read_bytes()).hexdigest() for p in paths}
r={'scope':'actual App canopy03 headless only; no pixel/device/fun claim','snapshot':str(project),'snapshot_receipt_sha256':hashlib.sha256((project/'build/snapshot-receipt.json').read_bytes()).hexdigest(),'outer_budget_seconds':300,'source_before':inventory(),'passed':False}
cmd=[sys.executable,'tools/run_forest_depth_campaign_boss.py','--boss','canopy','--seed','forest-depth-hollow-00','--output-dir','build/forest_depth/campaign/canopy_app03'];r['argv']=cmd
start=time.monotonic()
with (root/'build/verification/engine.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX);r['lock_acquired']=True
 env=os.environ.copy();env.update(GUNMAN_TOOLCHAIN_ROOT='/workspace/toolchains',GUNMAN_DATA_HOME=str(project/'build/userdata'),XDG_CONFIG_HOME=str(project/'build/userconfig'),XDG_CACHE_HOME=str(project/'build/usercache'))
 r['environment']={k:env[k] for k in ['GUNMAN_TOOLCHAIN_ROOT','GUNMAN_DATA_HOME','XDG_CONFIG_HOME','XDG_CACHE_HOME']}
 try:
  with (out/'outer.log').open('w') as log:
   p=subprocess.Popen(cmd,cwd=project,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
   try:r['exit_code']=p.wait(timeout=300)
   except subprocess.TimeoutExpired:
    os.killpg(p.pid,signal.SIGTERM)
    try:p.wait(timeout=5)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
    r['timeout']=True;r['exit_code']=p.returncode
 finally:
  r['source_after']=inventory();r['source_guard']=r['source_before']==r['source_after'];r['sealed_original_match']=r['source_before']==paths;r['elapsed_seconds']=time.monotonic()-start;r['passed']=r.get('exit_code')==0 and r['source_guard'] and r['sealed_original_match'];(out/'receipt.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({k:v for k,v in r.items() if not k.startswith('source_') and k not in ['environment']},indent=2));sys.exit(0 if r['passed'] else 1)
