import sys,json,copy,ast,hashlib,importlib.util
from pathlib import Path
sys.path.insert(0,'tools');import run_forest_depth_campaign_boss as current
base=Path('build/forest_depth/canopy-app-preparation');snap=Path('build/forest_depth/snapshots/canopy_app03');raw=snap/'build/forest_depth/campaign/canopy_app03/capture.json';d=json.loads(raw.read_text());current.validate_canopy(d)
spec=importlib.util.spec_from_file_location('frozen03',snap/'tools/run_forest_depth_campaign_boss.py');old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
results=[]
for attack in ['cross_reload_old_projectile','source_owner','result_epoch','result_physics','nan_amount','delete_reload','fake_atomic_probe','drop_schema_probe','gold_free_heal','gold_free_coin','no_D','weaken_layout','wrong_scene','router_motor','router_physics','resume_inactive']:
 m=copy.deepcopy(d);ev=m['combat']['events'];target=next(e for e in ev if e.get('event')=='policy_result' and e.get('target')=='boss' and e.get('segment')=='after_reload')
 if attack=='cross_reload_old_projectile':
  used={e['event_id'] for e in ev if e.get('event')=='policy_result' and e.get('target')=='boss'}
  shot=next(e for e in ev if e.get('event')=='accepted_shot' and e['segment']=='before_reload' and ':'.join(str(e[k]) for k in ['motor_id','session','serial']) not in used)
  target['event_id']=':'.join(str(shot[k]) for k in ['motor_id','session','serial']);target['source']='player_projectile:'+str(shot['motor_id'])
 elif attack in ['router_motor','router_physics']:
  shot=next(e for e in ev if e.get('event')=='accepted_shot')
  request=next(e for e in ev if e.get('event')=='actual_queued_input' and e['action']=='shoot_release' and e['tick']==shot['tick'] and e['session']==shot['session'])
  request['motor_id' if attack=='router_motor' else 'physics_frame']=999 if attack=='router_motor' else 0
 elif attack=='resume_inactive':m['reload']['after_resume']['active']=False;m['reload']['after_resume']['app_boss_started']=False
 elif attack=='source_owner':target['source']='player_projectile:777'
 elif attack=='result_epoch':target['actor_epoch']+=1
 elif attack=='result_physics':target['physics_frame']=-123
 elif attack=='nan_amount':target['amount']=float('nan')
 elif attack=='delete_reload':m['combat']['reloaded']=False
 elif attack=='fake_atomic_probe':m['schema_negatives'][0]['after']['motion_clock']+=1
 elif attack=='drop_schema_probe':m['schema_negatives'].pop()
 elif attack=='gold_free_heal':m['after_gold']['hp']+=1
 elif attack=='gold_free_coin':m['after_gold']['wallet']+=12
 elif attack=='no_D':m['before_boundary']['double']=False
 elif attack=='weaken_layout':m['route']['manifest']['layout_version']='fake-v10'
 elif attack=='wrong_scene':m['route']['manifest']['boss_content']['scene']='res://scenes/bosses/thorn_queen_v2.tscn'
 row={'id':attack}
 if attack=='cross_reload_old_projectile':
  try:old.validate_canopy(m);row['original03_reader_accepts']=True
  except Exception as e:row['original03_reader_accepts']=False;row['original03_reason']=str(e)
 try:current.validate_canopy(m)
 except (ValueError,TypeError,KeyError) as e:row.update(rejected=True,reason=str(e))
 else:row['rejected']=False
 results.append(row)
legacy=ast.parse((base/'campaign-cli-before.py').read_text());now=ast.parse(Path(current.__file__).read_text());find=lambda tree,n:ast.dump(next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name==n));same={n:find(legacy,n)==find(now,n) for n in ['validate','validate_queen']}
r={'scope':'Actual03 captured once under original frozen verifier. Current reader strengthened offline ONLY, no native rerun or change to original receipts.','original_raw_sha256':hashlib.sha256(raw.read_bytes()).hexdigest(),'current_reader_sha256':hashlib.sha256(Path(current.__file__).read_bytes()).hexdigest(),'frozen03_reader_sha256':hashlib.sha256((snap/'tools/run_forest_depth_campaign_boss.py').read_bytes()).hexdigest(),'actual03_current_reader_accepts':True,'mutants':results,'legacy_AST_exact':same,'actual':{'observed_frames':len(d['combat']['frames']),'boss_policy_commits':len([e for e in d['combat']['events'] if e.get('event')=='policy_result' and e.get('target')=='boss']),'saved_phase':d['reload']['saved']['stage_phase'],'saved_boss_hp':d['reload']['saved']['health'],'saved_field_age':d['reload']['saved']['fields'][0]['weave']['age'],'saved_field_hp':d['reload']['saved']['fields'][0]['health'],'energy_before':d['reload']['before']['energy'],'energy_bound':d['reload']['after_bound']['energy'],'player_hp_initial_final':[d['combat']['initial']['player_hp'],d['combat']['final']['player_hp']],'before_player_position':d['reload']['before']['player'],'bound_checkpoint_player_position':d['reload']['after_bound']['player'],'teardown':d['teardown']}}
(base/'actual03-offline-round2.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2));assert all(x['rejected'] for x in results) and all(same.values())
