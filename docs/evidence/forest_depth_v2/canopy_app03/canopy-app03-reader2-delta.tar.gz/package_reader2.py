from pathlib import Path
import hashlib,json,tarfile,gzip,io,difflib
r=Path.cwd();b=r/'build/forest_depth/canopy-app-preparation';d=r/'docs/evidence/forest_depth_v2/canopy_app03';members={}
for path in ['reader-round1.py','offline-round1.json','actual03-offline-round2.json','replay_actual03_round2.py','package_reader2.py']:
 members[path]=(b/path).read_bytes()
members['current-reader.py']=(r/'tools/run_forest_depth_campaign_boss.py').read_bytes()
members['reader-round1-to-round2.patch']=''.join(difflib.unified_diff((b/'reader-round1.py').read_text().splitlines(True),members['current-reader.py'].decode().splitlines(True),fromfile='offline-reader-round1',tofile='offline-reader-round2')).encode()
scope={'scope':'Supplementary offline-only verifier strengthening. No native recapture. Original actual01/02/03 data and native sourceguard receipts and original selected archive remain byte-exact.','prior_archive_sha256':hashlib.sha256((d/'canopy-app03-selected.tar.gz').read_bytes()).hexdigest(),'changes':'Exact Router motor_id+Engine physics_frame to accepted shot; actual resumed active/Appstarted/seal/schema/phase/freshownership and preserved HP/E/cap/Scheckpoint. Previous crossreload owner fix retained.','actual03_full_current_reader_accepts':True,'original13_and3_adjacent_mutants_all_rejected':True,'legacy2_AST_exact':True,'limitations':'No new native run with this reader, no pixel/human/device/fun acceptance. Independent reviewer report is separate. Original selected archive offline_current is prior reader-round1, which missed3 adjacency attacks; latest consumer is current-reader.py in this supplement.'}
members['SCOPE.json']=(json.dumps(scope,indent=2)+'\n').encode();idx={p:{'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)} for p,raw in sorted(members.items())};members['MEMBERS.json']=(json.dumps(idx,indent=2)+'\n').encode();a=d/'canopy-app03-reader2-delta.tar.gz'
with a.open('wb') as f:
 with gzip.GzipFile(fileobj=f,mode='wb',mtime=0) as z:
  with tarfile.open(fileobj=z,mode='w') as t:
   for p,raw in sorted(members.items()):
    info=tarfile.TarInfo(p);info.size=len(raw);info.mode=0o644;t.addfile(info,io.BytesIO(raw))
with tarfile.open(a,'r:gz') as t:
 for x in t.getmembers():assert x.isfile() and t.extractfile(x).read()==members[x.name]
receipt={'archive':a.name,'sha256':hashlib.sha256(a.read_bytes()).hexdigest(),'bytes':a.stat().st_size,'regular_members':len(members),'indexed_members_excluding_self':len(idx),'roundtrip_all_members':True,**scope};(d/'reader2-archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
(d/'README.md').write_text('''# Canopy App 03 evidence

Original01 and02 remain failures. Original03 passed the real App lifecycle: natural defaultV10 entry, phase2 live-field pause/save/fresh bind,24HP fight, pointer GOLD/D/development boundary/Home, audio drain and actual actor WeakRef teardown. HP4→4 during this fight; this is not an invulnerability or all-damage claim. Reload legitimately returns airborne Player to declared S checkpoint while HP/E/capacity survive.

- `canopy-app03-selected.tar.gz`: original full raw(losslessgzip), logs/receipts,2068-file inventories and selected source for all3 actual runs, first entry fix, and first offline verifier identity repair. Original01 lacks the later-added per-entry-frame failure dump; its full route and initial/final evidence remain.
- `canopy-app03-reader2-delta.tar.gz`: latest offline-only verifier delta and16 nearby attacks. The selected archive’s prior offline reader missed3 further Router/resume attacks. This supplement preserves the preceding reader/report and original native receipt unchanged; the latest reader accepts unchanged03 raw and rejects all16. It has not been rerun natively here; finalCI must run current source.

Each archive includes exact member SHA receipts; external archive receipts bind both. These are selected source closures, not complete bootable projects. No binary assets/caches or movies are duplicated. Headless evidence does not sign visible knot labels, browser/device behavior, listening or human fun. Independent review lives separately under reviews/canopy_app03.
''')
print(json.dumps({'archive':str(a),'sha256':receipt['sha256'],'bytes':receipt['bytes'],'members':len(members)}))
