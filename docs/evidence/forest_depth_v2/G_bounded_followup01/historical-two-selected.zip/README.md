# Remaining two historical v1 consumers: one actual run

This is a non-clone host populated with 663 exact current-root input files (654 assets, two wrapper tools, complete legacy basis with authenticated retained old blobs and provenance). host-input-inventory.json records every SHA and byte size and the root commit plus explicit dirty overlay. The wrapper and helper were not edited or given an injected ROOT. They naturally resolve this host as ROOT. Original source archive, inventory and manifest remained byte-exact.

The unchanged wrapper restored an independent authenticated bee850c project/Git tree, used external Godot4.7.2, performed original cold import90 and before/after verify around each requested original check, and preserved original argv/caps/markers. The root engine.lock was held exclusively throughout and released at terminal. No retry or alternate fixture was run.

Actual wrapper exit0, total340.635s. Cold import27.968s; forest-region-matrix294.295s within600, all60 original10root×2map×3route cases passed; forest-formal-combat10.094s within360. cap-accounting.json conservatively adds all shared overhead to each check separately and still fits both current profile outer caps. Source and all host/root input SHA guards passed at terminal.

All native raw, logs, exact restored sources/assets/Git metadata/cache and receipts remain under build/remaining-two01; none are cleaned or rewritten. Root can select small report/log/provenance artifacts for durable transfer; do not copy entire fixture or imported cache unnecessarily. host-terminal-receipt.json binds input before/after guards, and wrapper report retains the original before/after verification outcomes and evidence ledger.

Scope is selected historical forest v1 only. This is not current forest v2 gameplay acceptance, a full profile rerun, public device/browser approval, or a rerun on a future immutable commit. Original G asset-restore failure and all earlier CI failures remain failures.
