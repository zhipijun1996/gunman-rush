from pathlib import Path
import subprocess,os,json,hashlib,time
ROOT=Path.cwd();OUT=ROOT/'build/verification/clean-docs-reader02';OUT.mkdir(exist_ok=False);project=OUT/'project'
paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],text=True).split('\0');paths=sorted(set(p for p in paths if p))
def sha(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  while b:=f.read(1048576):h.update(b)
 return h.hexdigest()
before={p:sha(ROOT/p)if(ROOT/p).is_file()else'deleted'for p in paths};head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();status=subprocess.check_output(['git','status','--porcelain'],text=True)
# Dedicated metadata/index with read-only alternate object access; no clone/fetch/pack/GC.
subprocess.run(['git','init','-q',str(project)],check=True,timeout=30)
object_dir=Path(subprocess.check_output(['git','rev-parse','--git-path','objects'],text=True).strip()).resolve()
(project/'.git/objects/info/alternates').write_text(str(object_dir)+'\n')
for key,value in [('gc.auto','0'),('maintenance.auto','false')]:subprocess.run(['git','config',key,value],cwd=project,check=True,timeout=30)
refs=subprocess.check_output(['git','for-each-ref','--format=%(objectname) %(refname)'],text=True).splitlines()
subprocess.run(['git','update-ref','--stdin'],cwd=project,input=''.join('update '+line.split(' ',1)[1]+' '+line.split(' ',1)[0]+'\n'for line in refs),text=True,check=True,timeout=30)
head_ref=subprocess.check_output(['git','symbolic-ref','HEAD'],text=True).strip()
subprocess.run(['git','symbolic-ref','HEAD',head_ref],cwd=project,check=True,timeout=30)
shallow=Path(subprocess.check_output(['git','rev-parse','--git-path','shallow'],text=True).strip())
if shallow.is_file():(project/'.git/shallow').write_bytes(shallow.read_bytes())
subprocess.run(['git','remote','add','origin',subprocess.check_output(['git','remote','get-url','origin'],text=True).strip()],cwd=project,check=True,timeout=30)
subprocess.run(['git','read-tree','HEAD'],cwd=project,check=True)
origin=subprocess.check_output(['git','remote','get-url','origin'],text=True).strip();subprocess.run(['git','remote','set-url','origin',origin],cwd=project,check=True)
for rel in paths:
 src=ROOT/rel;dest=project/rel
 if not src.exists():continue
 dest.parent.mkdir(parents=True,exist_ok=True)
 if src.is_symlink():os.symlink(os.readlink(src),dest)
 else:os.link(src,dest)
assert {p:sha(project/p)if(project/p).is_file()else'deleted'for p in paths}==before
(OUT/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
start=time.monotonic();receipt={'scope':'Original docs profile in a clean independent-index/shared-object source checkout, identical hardlinked inputs, no ignored diagnostic snapshots; no checker edit. Original root failure retained. Source write guards before/after mandatory.','source_commit':head,'original_status_before':status,'input_count':len(paths),'command':['python3','tools/harness.py','--profile','docs','--jobs','1','--release'],'timeout_seconds':600,'same_inputs_before':True}
try:
 with(OUT/'driver.log').open('w')as log:
  r=subprocess.run(receipt['command'],cwd=project,env={**os.environ,'GUNMAN_TOOLCHAIN_ROOT':'/workspace/toolchains'},stdout=log,stderr=subprocess.STDOUT,timeout=600)
 receipt['exit_code']=r.returncode
finally:
 after={p:sha(ROOT/p)if(ROOT/p).is_file()else'deleted'for p in paths};receipt['seconds']=time.monotonic()-start;receipt['original_inputs_unchanged']=after==before;receipt['isolated_inputs_unchanged']={p:sha(project/p)if(project/p).is_file()else'deleted'for p in paths}==before;receipt['original_head_unchanged']=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==head;receipt['original_status_unchanged']=subprocess.check_output(['git','status','--porcelain'],text=True)==status
 (OUT/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps(receipt,ensure_ascii=False),flush=True)
assert receipt['exit_code']==0 and all(receipt[k]for k in ('original_inputs_unchanged','isolated_inputs_unchanged','original_head_unchanged','original_status_unchanged'))
