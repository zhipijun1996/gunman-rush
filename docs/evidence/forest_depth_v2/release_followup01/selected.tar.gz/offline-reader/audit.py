from pathlib import Path
import sys,json,gzip,copy,hashlib,importlib.util,ast,time
R=Path('/workspace/gunman-rush-design');D=Path(__file__).resolve().parent;sys.path.insert(0,str(R/'tools'))
p=R/'tools/run_forest_depth_campaign_boss.py';before=p.read_bytes();spec=importlib.util.spec_from_file_location('reader_after',p);reader=importlib.util.module_from_spec(spec);spec.loader.exec_module(reader)
ci=next((R/'build/verification/0cf-core-selected').rglob('harness-guardian/*/capture.json'))
paths=[ci,R/'docs/evidence/forest_depth_v2/campaign_node_boundary01/guardian_node01/capture.json.gz',R/'docs/evidence/forest_guardian_campaign05/native05/capture.json']
loaded=[];rows=[]
for q in paths:
 b=q.read_bytes();d=json.loads(gzip.decompress(b) if q.suffix=='.gz' else b);reader.validate(d);loaded.append(d);rows.append({'path':str(q.relative_to(R)),'sha256':hashlib.sha256(b).hexdigest(),'layout':d['map2_manifest']['layout_version'],'full_validate_accepted':True})
changes=[]
def change(label,path,value=None,delete=False):changes.append({'id':label,'path':path,'value':value,'delete':delete})
base=['map2_manifest']
for field,value in [('layout_version','unknown-layout'),('layout_version','shared-tree-living-detour-v9'),('layout_version',None),('layout_version',[]),('version','thorn-forest-region-v999'),('region','plains'),('region',None),('map_index',1),('map_index',2.0),('map_index',True),('boss_contract',None),('boss_contract',[]),('boss_content',None),('boss_content',[]),('boss_content',True)]:change('wrong_'+field+'_'+str(len(changes)),base+[field],value)
for field,value in [('scene','res://scenes/bosses/thorn_queen_v2.tscn'),('resource','res://resources/bosses/thorn_queen_v2.tres'),('contract','forest-queen-canopy-v999'),('scene',None),('resource',1)]:change('content_'+field+'_'+str(len(changes)),base+['boss_content',field],value)
for field,value in [('admission','experimental_whole_boss_pending'),('admission','commercially_admitted'),('admission',True),('boss_contract','queen-weave-region-experimental'),('boss_contract',{}),('version','forest-queen-canopy-v999'),('version',3),('ok',False),('ok',1),('ok','true'),('ok',None)]:change('contract_'+field+'_'+str(len(changes)),base+['boss_contract',field],value)
for field in ['boss_content','boss_contract','layout_version','region']:change('missing_'+field,base+[field],delete=True)
change('extra_content_key',base+['boss_content','extra'],'unrecognized')
negative=[]
for mutation in changes:
 data=copy.deepcopy(loaded[0]);target=data
 for key in mutation['path'][:-1]:target=target[key]
 if mutation['delete']:del target[mutation['path'][-1]]
 else:target[mutation['path'][-1]]=mutation['value']
 try:reader.validate(data)
 except (ValueError,AssertionError,KeyError,TypeError) as error:
  negative.append({**mutation,'full_validate_rejected':True,'exception':type(error).__name__,'reason':str(error)})
 else:raise AssertionError('ACCEPTED MUTANT '+mutation['id'])
legacy=[]
for index,source in enumerate(loaded[1:],1):
 for key,value in [('admission','candidate_whole_boss_pending'),('version','forest-queen-canopy-v3'),('boss_contract','forest-queen-canopy-v3'),('ok',1)]:
  data=copy.deepcopy(source);data['map2_manifest']['boss_contract'][key]=value
  try:reader.validate(data)
  except (ValueError,AssertionError) as error:legacy.append({'historical_capture':index,'field':key,'value':value,'full_validate_rejected':True,'reason':str(error)})
  else:raise AssertionError('Legacy mutation accepted')
# Only two existing validator bodies change at their map2 identity checks.
old=ast.parse((D/'reader-before.py.txt').read_text());new=ast.parse(before.decode());old_functions={n.name:ast.dump(n) for n in old.body if isinstance(n,ast.FunctionDef)};new_functions={n.name:ast.dump(n) for n in new.body if isinstance(n,ast.FunctionDef)};unchanged=[name for name in old_functions if old_functions[name]==new_functions[name]];changed=[name for name in old_functions if old_functions[name]!=new_functions[name]];assert changed==['validate','validate_canopy'],changed
assert before==p.read_bytes()
result={'scope':'Offline reader migration on original0cf CI bytes; NO native replay or CI failure retag','reader_before_sha256':hashlib.sha256((D/'reader-before.py.txt').read_bytes()).hexdigest(),'reader_after_sha256':hashlib.sha256(before).hexdigest(),'reader_source_unchanged_during_audit':True,'positives':rows,'ci_full_validate_accepted':True,'negative_mutants':negative,'historical_negative_mutants':legacy,'rejected_mutants':len(negative)+len(legacy),'all_other_existing_functions_ast_unchanged':unchanged,'existing_functions_changed':changed}
(D/'result.json').write_text(json.dumps(result,indent=2)+'\n');(D/'reader-after.py.txt').write_bytes(before);print(json.dumps({'positive_full_validates':len(rows),'rejected_mutants':len(negative)+len(legacy),'changed_existing_functions':changed}))
old_text=(D/'reader-before.py.txt').read_text();new_text=before.decode()
normalized=new_text[:new_text.index('CANOPY_LAYOUT =')]+new_text[new_text.index('def validate(data):'):]
old_assert=next(line for line in old_text.splitlines() if "assert manifest['boss_contract']['ok']" in line)
normalized=normalized.replace('    validate_map2_boss_identity(manifest, allow_legacy=True)',old_assert)
start=old_text.index("    require(manifest['map_index']==2 and manifest['layout_version']=='shared-tree-canopy-hunt-v10'")
end=old_text.index('\n    initial=data[',start)
normalized=normalized.replace('    validate_map2_boss_identity(manifest)\n    initial=data[',old_text[start:end]+'\n    initial=data[')
assert normalized==old_text
result['normalized_whole_reader_equals_before']=True
result['normalization_scope']='Remove added identity constants/helper; restore exactly one Guardian identity assert and two Canopy identity requires. Every other original source byte is retained.'
(D/'result.json').write_text(json.dumps(result,indent=2)+'\n')
