from pathlib import Path
import hashlib,json,subprocess,sys,time,http.server,threading,functools
R=Path('/workspace/gunman-rush-design');O=R/'build/verification/0cf-input-diagnosis01';W=R/'build/verification/0cf-ci-browser01/web'
def inventory():return {str(p.relative_to(W)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(W.rglob('*')) if p.is_file()}
def git():return {'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip(),'status':subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all'],cwd=R).decode(),'diff_sha256':hashlib.sha256(subprocess.check_output(['git','diff','HEAD','--binary'],cwd=R)).hexdigest()}
web_before=inventory();git_before=git();(O/'protected-before.json').write_text(json.dumps({'web':web_before,'git':git_before},indent=2)+'\n')
source=(R/'tools/verify_action_budget_browser.py').read_text()
source=source.replace('from studio_gui_pointer import',"sys.path.insert(0,'/workspace/gunman-rush-design/tools')\nfrom studio_gui_pointer import")
header=r'''
import sys
sys.path.insert(0,'/workspace/gunman-rush-design/tools')
import atexit
from playwright.async_api import Mouse, BrowserContext
DIAG=Path('/workspace/gunman-rush-design/build/verification/0cf-input-diagnosis01/timeline.jsonl').open('w',buffering=1)
def diag(kind,**kw):
 DIAG.write(json.dumps({'host_monotonic':time.monotonic(),'kind':kind,**kw},ensure_ascii=False)+'\n')
atexit.register(DIAG.close)
for method_name in ('move','down','up','click'):
 original=getattr(Mouse,method_name)
 def wrap(method_name,original):
  async def observed(self,*a,**kw):
   diag('playwright_begin',method=method_name,args=a,kwargs=kw)
   try:return await original(self,*a,**kw)
   finally:diag('playwright_end',method=method_name)
  return observed
 setattr(Mouse,method_name,wrap(method_name,original))
_original_new_page=BrowserContext.new_page
async def observed_new_page(self,*a,**kw):
 page=await _original_new_page(self,*a,**kw)
 page.on('console',lambda msg:diag('console_received',text=msg.text) if ('STUDIO_EVENT ' in msg.text or 'POINTER_DIAG ' in msg.text) else None)
 await page.add_init_script(r"""for (const type of ['pointerdown','pointerup','pointermove','mousedown','mouseup','mousemove']) {window.addEventListener(type, e => console.log('POINTER_DIAG '+JSON.stringify({type:e.type,perf:performance.now(),timeStamp:e.timeStamp,x:e.clientX,y:e.clientY,buttons:e.buttons,button:e.button,target:e.target.tagName,trusted:e.isTrusted})),{capture:true,passive:true});}""")
 return page
BrowserContext.new_page=observed_new_page
'''
source=source.replace("OUT=Path('build/action_budget/browser');OUT.mkdir(parents=True,exist_ok=True)",header+"\nOUT=Path('/workspace/gunman-rush-design/build/verification/0cf-input-diagnosis01/browser-output');OUT.mkdir(parents=True,exist_ok=True)")
source=source.replace('  async def wait(pred,seconds=5):\n   end=',"  async def wait(pred,seconds=5):\n   diag('wait_begin',seconds=seconds)\n   end=")
source=source.replace('    if pred():return True',"    if pred():\n     diag('wait_end',result=True)\n     return True")
source=source.replace('   return False',"   diag('wait_end',result=False)\n   return False")
needle="  rows=[e for e in events[n:]if e['action']=='weapon_blink'];checks['mouse_two_blade_flashes']="
assert source.count(needle)==1
source=source.replace(needle,"  rows=[e for e in events[n:]if e['action']=='weapon_blink'];diag('fan_rows_sample',n=n,event_count=len(events),rows=rows);checks['mouse_two_blade_flashes']=")
(O/'driver.py').write_text(source)
class Handler(http.server.SimpleHTTPRequestHandler):
 def log_message(self,fmt,*args):
  with (O/'server.log').open('a') as f:f.write(fmt%args+'\n')
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Handler,directory=str(W)));threading.Thread(target=server.serve_forever,daemon=True).start();url=f'http://127.0.0.1:{server.server_port}/';started=time.monotonic();code=None;timeout=False
try:
 with (O/'driver.log').open('w') as f:
  try:code=subprocess.run([sys.executable,'-B',str(O/'driver.py'),url],cwd=O,stdout=f,stderr=subprocess.STDOUT,timeout=300).returncode
  except subprocess.TimeoutExpired:timeout=True
finally:
 server.shutdown();web_after=inventory();git_after=git();(O/'protected-after.json').write_text(json.dumps({'web':web_after,'git':git_after},indent=2)+'\n')
 receipt={'scope':'One original browser input sequence with read-only host/DOM logging; not a fix or device/native acceptance. No re-export.','url':url,'argv':[sys.executable,'-B',str(O/'driver.py'),url],'timeout_seconds':300,'exit_code':code,'timed_out':timeout,'seconds':time.monotonic()-started,'web_count':len(web_before),'web_bytes':sum(p.stat().st_size for p in W.rglob('*') if p.is_file()),'web_unchanged':web_before==web_after,'git_before':git_before,'git_after':git_after,'git_unchanged':git_before==git_after,'original_driver_sha256':hashlib.sha256((R/'tools/verify_action_budget_browser.py').read_bytes()).hexdigest(),'diagnostic_driver_sha256':hashlib.sha256(source.encode()).hexdigest(),'build_info':json.loads((W/'build-info.json').read_text())}
 (O/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
