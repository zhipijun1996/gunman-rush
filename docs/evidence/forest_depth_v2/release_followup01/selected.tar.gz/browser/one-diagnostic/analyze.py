from pathlib import Path
import json,ast,hashlib
R=Path('/workspace/gunman-rush-design');O=Path(__file__).resolve().parent
x=[json.loads(s) for s in (O/'timeline.jsonl').read_text().splitlines()];a=ast.parse((R/'tools/verify_action_budget_browser.py').read_text());b=ast.parse((O/'driver.py').read_text())
def dumpnodes(t,p):return [ast.dump(n,include_attributes=False) for n in ast.walk(t) if p(n)]
asserts=lambda t:dumpnodes(t,lambda n:isinstance(n,ast.Assert))
checks=lambda t:dumpnodes(t,lambda n:isinstance(n,ast.Assign) and any(isinstance(z,ast.Subscript) and ast.unparse(z.value)=='checks' for z in n.targets))
ops={name:dumpnodes(a,lambda n:isinstance(n,ast.Call) and ast.unparse(n.func)==name)==dumpnodes(b,lambda n:isinstance(n,ast.Call) and ast.unparse(n.func)==name) for name in ['page.wait_for_timeout','page.mouse.move','page.mouse.down','page.mouse.up','page.mouse.click']}
events=[]
for r in x:
 if r['kind']=='console_received' and r['text'].startswith('STUDIO_EVENT '):events.append({'host_monotonic':r['host_monotonic'],'event':json.loads(r['text'].split('STUDIO_EVENT ',1)[1])})
fan=[r for r in events if r['event']['weapon']=='fan_shuriken'];reset=next(r for r in fan if r['event']['action']=='practice_reset');sample=next(r for r in x if r['kind']=='fan_rows_sample');lo=reset['host_monotonic']-.2;hi=sample['host_monotonic']+.8
selected=[]
for r in x:
 if lo<=r['host_monotonic']<=hi:
  if r['kind']=='console_received':
   if r['text'].startswith('POINTER_DIAG '):selected.append({'host_monotonic':r['host_monotonic'],'kind':'DOM','event':json.loads(r['text'].split('POINTER_DIAG ',1)[1])})
   elif r['text'].startswith('STUDIO_EVENT '):
    e=json.loads(r['text'].split('STUDIO_EVENT ',1)[1]);
    if e['action'] in ['practice_reset','weapon_packet','weapon_phase','weapon_blink','shot']:selected.append({'host_monotonic':r['host_monotonic'],'kind':'STUDIO','event':e})
  else:selected.append(r)
out={'scope':'One diagnostic sequence only; original failed run retained. No Godot internal armed/blocked flags observed.','assert_AST_exact':asserts(a)==asserts(b),'all_check_assignments_AST_exact':checks(a)==checks(b),'original_assert_count':len(asserts(a)),'check_assignment_count':len(checks(a)),'original_input_and_wait_calls_exact':ops,'timeline_rows':len(x),'fan_rows_at_sample':sample,'fan_packets_and_blinks':[r for r in fan if r['event']['action'] in ['weapon_packet','weapon_blink']],'fan_interval':selected}
(O/'analysis.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k not in ['fan_rows_at_sample','fan_packets_and_blinks','fan_interval']},indent=2))
