# One bounded 0cf browser input diagnosis

Result: the single actual diagnostic sequence completed with exit 0, 24/24 checks true, no browser errors, 103.100s under the original 300s cap. This is **not a repair**, and does not replace the original `0cf-ci-browser01` failure (four fan checks false) or prove the cause of that failure. No further run was performed.

The local server served the existing exact 0cf web directory without copying or re-exporting it. All 264 protected files / 233,138,914 bytes have identical SHA256 inventories before/after. Git remained clean at `0cf4aa5816c735fdd6e83bfb95d8ee0f70d129ee` with identical diff hash. Build ID is `30d8b215ac15`, full PCK 90,293,200 bytes. Native Godot was not run. The original script closed both browser contexts and browser; the orchestrator shut down the HTTP server and exited. No diagnostic process remains intentionally running.

## Instrumentation and unchanged actions

`driver.py` is an ignored temporary copy of the original `tools/verify_action_budget_browser.py` (original SHA256 `8476ea70f6f9d6cdaf99c715cee786a055cf1a3ca1c4ade4e13419c3ff199e0e`). Additional code only records host monotonic timestamps around Playwright Mouse calls, existing wait begin/end/results, fan rows sampling, received STUDIO console events, and passive capture DOM pointer/mouse events. It does not prevent input, mutate game state or add input/waits. Output paths and the import path are local to this diagnostic.

The independent AST comparison in `analysis.json` confirms all four original assert statements, all 24 check assignments and all direct `page.mouse.move/down/up/click` and `page.wait_for_timeout` call expressions are exact. The original fire uses its unchanged 40ms wait; the following 100ms wait and all timeouts remain unchanged. Logging can perturb scheduling; this run is not a timing-identical replay.

There was an initial **pre-browser Python import preparation failure**: the helper import preceded the added sys.path. Its full source/log/receipt/protection inventories are retained separately in `preflight-import-failure/`. It exited before Chromium or any browser input. Correcting only that import ordering enabled the one actual browser sequence above. That setup error is not represented as an actual input run or silently overwritten.

## Actual fan timeline

`timeline.jsonl` contains 526 host-timestamped records; `analysis.json` retains the selected complete fan interval and sample rows.

- Actual practice reset: physics tick 1466, host 53830.037330.
- First right fire DOM receives trusted down at (790,590), buttons=1, and trusted up at the same coordinates, buttons=0. The corresponding host receipts are approximately 53830.524450 / 53830.684207. The game starts packet 4 at tick 1499 immediately after the observed release and produces the first blink at 1503 with rightward aim.
- Reaim-and-hold receives trusted down at (180,670), buttons=1; the game produces packet 4's second blink at 1521 with leftward aim. The original wait returns True at host 53831.155643.
- The script releases that held pointer, then samples rows at **53831.264585**. Exactly packet 4's two accepted blinks are present at that sample, with the original full/half distance, 18-tick delay and opposite horizontal recoil directions.
- At **53831.265112**, only **0.527ms after sampling**, console delivers a newly started packet 8, followed by its blinks at ticks 1532 and 1550. Thus this successful run, like old 89dcc, contains four fan blinks in the final event file even though only the first packet's two were present when checks were evaluated. Final-event totals are not the original sampling window.

DOM performance/timeStamp differences in this run also show event delivery can lag browser creation (roughly 163ms for the first fire down, 109ms for its up). These are observations of this successful run, not a measurement of the original failed run's main loop.

## What is established and what remains unknown

**Established for this run:** the first fan click's DOM down/up edges were delivered and accepted as a real packet; packet 4's two stages and reaim work. The later release generates another real packet whose console event reaches the observer just after checks sample rows. The original driver's discarded wait result and lack of first-packet acceptance assertion remain actual source weaknesses; a failed first click can proceed into a different action sequence without an immediate diagnostic failure.

**Not established:** whether the original 0cf failure lost a DOM edge, whether Godot ignored a delivered edge, whether a stale adapter block existed, whether a game main-loop stall caused the miss, or exactly when its rows were sampled. That old run has no DOM/operation timestamps or `_mouse_armed` / `_mouse_blocked` / `menu_pointer_block` / Router request observer. The present passive DOM logger cannot observe those Godot flags. A passing instrumented run cannot supply their old values.

The source-level hypothesis remains specific but unproven: router.clear during menu/reset can retain a blocked mouse until an observed release/neutrality; ActionStudio lacks the explicit neutral reconciliation used by Home/App UI close paths. The known existing contract intentionally protects held inputs. Do not change Player input or remove that protection based only on this hypothesis.

No repeated search for PASS is warranted. If a future narrow test-consumer change is authorized, it should preserve the original four mechanics assertions while explicitly requiring the initial accepted packet/first blink before reaim, checking the wait result and recording the exact packet/sample boundary. A missing first acceptance should retain a diagnostic FAIL rather than be repaired by blindly retrying clicks or extending waits. This report is not approval of such an unimplemented change, all browser consumers, native CI, physical devices or release readiness.
