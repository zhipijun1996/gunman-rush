from pathlib import Path
import re
root=Path('/workspace/gunman-rush-refactor/game/enemies/presentation')
terms={
 'stride_sin':'sin(stride)', 'stride_cos':'cos(stride)',
 'rear_stride_sin':'sin(stride + PI)', 'rear_stride_cos':'cos(stride + PI)',
 'patrol_breath_sin':'sin(clock * 3.6)', 'patrol_body_sin':'sin(stride - .22)',
 'patrol_head_sin':'sin(clock * 2.1 - .65)', 'patrol_gait_head_sin':'sin(stride - .65)', 'patrol_gait_lag_sin':'sin(stride - .55)',
 'charger_breath_sin':'sin(clock * 2.8)', 'charger_body_sin':'sin(stride - .38)',
 'charger_head_sin':'sin(clock * 1.9 - .80)', 'charger_gait_head_sin':'sin(stride - .75)',
 'hopper_breath_sin':'sin(clock * 3.5)', 'hopper_head_sin':'sin(clock * 2.4 - .7)', 'hopper_gait_head_sin':'sin(stride - .7)',
 'recovery_half_sin':'sin(recovery * PI)', 'recovery_full_sin':'sin(recovery * PI * 2.0)',
 'recovery_return_sin':'sin((1.0 - recovery) * PI * 2.0)', 'charger_hurt_sin':'sin((1.0 - hurt) * PI * 5.0)',
 'sentry_breath_sin':'sin(clock * 3.1)', 'sentry_muzzle_sin':'sin(clock * 2.2 - .55)',
 'sentry_body_sin':'sin(clock * 2.2)', 'sentry_leaf_sin':'sin(clock * 2.2 - .9)',
 'fan_wing_sin':'sin(clock * 12.5)', 'fan_body_sin':'sin(clock * 12.5 - .52)',
 'fan_pitch_sin':'sin(clock * 12.5 - .72)', 'fan_feet_sin':'sin(clock * 12.5 - 1.1)',
 'root_stem_sin':'sin(clock * 2.6)', 'root_hurt_sin':'sin((1.0 - hurt) * PI * 1.5)',
 'root_upper_sin':'sin(clock * 2.6 - .5)', 'root_bell_sin':'sin(clock * 2.6 - .95)', 'root_leaf_sin':'sin(clock * 2.6 - 1.2)',
}
p=root/'plains_revision_pose.gd'; pose=p.read_text()
pose=pose.replace('var live: PlainsRevisionPose\n','var live: PlainsRevisionPose\n# Draw-local scalar terms, evaluated once with the original 64-bit expressions.\n# Keep each offset wave distinct; trigonometric identities change rounding.\n'+''.join('var '+name+': float\n' for name in terms)+'var ground_quiet: float\nvar flora_quiet: float\n')
pose=pose.replace('\tif result.dead:\n','\tresult._prepare_motion_terms()\n\tif result.dead:\n',1)
pose+='\nfunc _prepare_motion_terms() -> void:\n'+''.join('\t'+name+' = '+expr+'\n' for name,expr in terms.items())+'\tground_quiet = 1.0-clampf(raw_load+raw_strike,0.0,1.0)*.75\n\tflora_quiet = 1.0-clampf(load+strike,0.0,1.0)*.8\n'
# Match whitespace variations while retaining every operation and operand.
def pattern(expr): return r'\s*'.join(re.escape(c) for c in re.sub(r'\s+','',expr))
def replace_waves(source, is_flora):
 for name,expr in sorted(terms.items(),key=lambda x:len(x[1]),reverse=True):
  if name.startswith('fan_') and is_flora: expr=expr.replace('clock * 12.5','beat')
  source=re.sub(pattern(expr),'pose.'+name,source)
 source=re.sub(pattern('sin(fore_phase)'),'pose.stride_sin',source)
 source=re.sub(pattern('sin(rear_phase)'),'pose.rear_stride_sin',source)
 source=re.sub(pattern('cos(fore_phase)'),'pose.stride_cos',source)
 source=re.sub(pattern('cos(rear_phase)'),'pose.rear_stride_cos',source)
 return source
p2=root/'plains_revision_ground.gd'; ground=p2.read_text()
# Live leaves consume the existing prepared context instead of unpack/repack.
start=ground.index('\tvar clock := pose.clock\n');end=ground.index('\tvar p := point\n',start)
ground=ground[:start]+ground[end:]
for kind,params in [('patrol',['travel','hurt','turn']),('charger',['travel','load','strike','recovery','hurt']),('hopper',['travel','load','strike','recovery','hurt','air','vertical'])]:
 ground=re.sub(r'(_'+kind+r'_live\(p, uv, size, ).*?(\))',r'\1pose, weights\2',ground,count=1)
 old=re.search(r'static func _'+kind+r'_live\([^\n]+\n',ground).group(0)
 new='static func _'+kind+'_live(point: Vector2, uv: Vector2, size: Vector2, pose: PlainsRevisionPose, weights: PlainsRevisionWeights) -> Vector2:\n'+''.join('\tvar '+key+' := pose.'+key+'\n' for key in params)
 ground=ground.replace(old,new)
ground=replace_waves(ground,False)
ground=ground.replace('\tvar clock := pose.clock\n','').replace('\tvar stride := pose.stride\n','').replace('\tvar fore_phase := stride\n','').replace('\tvar rear_phase := stride + PI\n','')
ground=ground.replace('1.0-clampf(pose.raw_load+pose.raw_strike,0.0,1.0)*.75','pose.ground_quiet')
p3=root/'plains_revision_flora.gd'; flora=replace_waves(p3.read_text(),True)
flora=flora.replace('\tvar clock := pose.clock\n','').replace('\tvar beat := clock*12.5\n','').replace('1.0-clampf(load+strike,0.0,1.0)*.8','pose.flora_quiet')
for file,content in [(p,pose),(p2,ground),(p3,flora)]: file.write_text(content)
print('Prepared',len(terms),'64-bit scalar waves, three existing leaves')
