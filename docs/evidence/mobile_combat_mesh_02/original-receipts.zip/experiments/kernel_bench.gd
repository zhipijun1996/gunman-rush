extends SceneTree
## Native synthetic kernel cost including prepare; not browser/phone FPS.
func _initialize() -> void:
	run.call_deferred()
func run() -> void:
	var rows: Array = []
	for round_index: int in 3:
		for kind: StringName in [&"patrol", &"charger", &"hopper", &"sentry", &"fan_sentry", &"root_bell"]:
			var rig := PlainsRevisionSkin.new(kind)
			var weights: Array[PlainsRevisionWeights] = []
			for uv: Vector2 in rig._units: weights.append(PlainsRevisionWeights.new(uv, kind))
			for situation: String in ["moving", "hurt_attack", "dying"]:
				var times: Array[float] = []
				var checksum := Vector2.ZERO
				for frame: int in 63:
					var values := {"clock":1.0+float(frame)/60.0,"stride":.2+float(frame)*.11,"travel":.8,"drive":.3,"appendage_follow":.6,"load":.6 if situation!="moving" else 0.0,"strike":.4 if situation!="moving" else 0.0,"recovery":.3,"hurt":.5 if situation!="moving" else 0.0,"dead":situation=="dying","death":.01+float(frame)*.01,"death_clock":.02+float(frame)*.01,"air":kind==&"fan_sentry","vertical":-45.0}
					var started := Time.get_ticks_usec()
					var pose := PlainsRevisionPose.prepare(values)
					for i: int in rig._points.size(): checksum += rig.deform_prepared(rig._points[i], rig._units[i], pose, weights[i])
					if frame >= 3: times.append(float(Time.get_ticks_usec()-started)/1000.0)
				var total := 0.0
				for sample: float in times: total += sample
				times.sort()
				rows.append({"round":round_index,"kind":kind,"case":situation,"vertices":rig._points.size(),"samples":times.size(),"mean_ms":total/times.size(),"p50_ms":times[30],"p95_ms":times[56],"checksum":[checksum.x,checksum.y]})
	print("MESH02_KERNEL "+JSON.stringify({"rows":rows,"scope":"Cloud native synthetic prepare+625 vertex kernel, cached UV weights as production; excludes upload/draw/GPU/AI/browser/phone. Dying kernel is not settled draw-cache performance."}))
	quit()
