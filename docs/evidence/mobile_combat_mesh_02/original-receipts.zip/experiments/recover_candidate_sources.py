from pathlib import Path
import re,json,hashlib,subprocess
root=Path('/workspace/gunman-rush-refactor');out=Path('/workspace/refactor-evidence/mobile-combat-mesh-02')
files=['game/enemies/presentation/plains_revision_pose.gd','game/enemies/presentation/plains_revision_ground.gd','game/enemies/presentation/plains_revision_flora.gd','tests/plains_revision_deform_equivalence_runner.gd']
current={f:(root/f).read_text() for f in files}
flora_file=files[2];test_file=files[3]
s=current[flora_file];start=s.index('static func _sentry(');end=s.index('static func _root_bell(')
section=s[start:end]
section,n=re.subn(r'^(\t+)if [a-z_]+ != 0\.0:\n\1\t([^\n]+)$',lambda m:m[1]+m[2],section,flags=re.M)
assert n==16,n
plain_flora=s[:start]+section+s[end:]
current_tests=current[test_file]
new_start=current_tests.index('\t# Exercise zero-mask fast paths')
new_end=current_tests.index('\nfunc _run()',new_start)
old_zero='''\t# A zero anatomical weight must also preserve signed-zero coordinates.
\tfor point: Vector2 in [Vector2.ZERO, Vector2(-0.0,-0.0), Vector2(1.25,-2.5)]:
\t\tfor angle: float in [0.0, .31, -.77]:
\t\t\tvar actual := PlainsRevisionFlora._joint_at(point, Vector2(.7,-2.9), angle, 0.0)
\t\t\tvar expected := FloraOracle._joint_at(point, Vector2(.7,-2.9), angle, 0.0)
\t\t\t_check(PackedVector2Array([actual]).to_byte_array() == PackedVector2Array([expected]).to_byte_array(), "Flora zero-weight rotation retains exact coordinate bits")
'''
early_tests=current_tests[:new_start]+old_zero+current_tests[new_end:]
manifest={}
for label in ['baseline','candidate-01','candidate-02','candidate-03','candidate-04','candidate-05']:
 receipt=json.loads((out/f'{label}-receipt.json').read_text()); wanted=receipt['source_sha256_before']
 contents={}
 for f in files:
  if label=='baseline': contents[f]=subprocess.check_output(['git','show','8dfaf7f3:'+f],cwd=root).decode()
  elif f==flora_file:
   value=plain_flora
   guards={'candidate-01':[],'candidate-02':['_joint','_joint_at','_scale_part'],'candidate-03':['_joint_at','_scale_part'],'candidate-04':['_joint','_scale_part']}.get(label,[])
   for name in guards:
    value=re.sub(r'(static func '+name+r'\([^\n]+\n)',r'\1\tif weight == 0.0: return point\n',value,count=1)
   contents[f]=current[f] if label=='candidate-05' else value
  elif f==test_file:
   contents[f]=subprocess.check_output(['git','show','8dfaf7f3:'+f],cwd=root).decode() if label in ['candidate-01','candidate-02'] else (current_tests if label=='candidate-05' else early_tests)
  else:contents[f]=current[f]
 for f,value in contents.items():
  digest=hashlib.sha256(value.encode()).hexdigest()
  assert digest==wanted[f],(label,f,digest,wanted[f])
  dest=out/'verified-source-snapshots'/label/f;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(value)
 manifest[label]=wanted
(out/'verified-source-snapshots/manifest.json').write_text(json.dumps({'method':'Baseline from Git8df; candidate source bytes recovered from recorded bounded edits and exact SHA-verified against each original receipt. Recovery happened after experiment, not an at-start snapshot claim.','sources':manifest},indent=2)+'\n')
print('Recovered six exact source vectors; all24 file hashes match original receipts')
