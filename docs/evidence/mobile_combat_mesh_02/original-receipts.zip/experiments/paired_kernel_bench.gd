extends SceneTree
const Base = preload("/workspace/refactor-evidence/mobile-combat-mesh-02/baseline_kernels.gd")
## Native synthetic kernel cost including prepare; not browser/phone FPS.
func _initialize() -> void:
	run.call_deferred()
func run() -> void:
	var rows: Array = []
	for round_index: int in 3:
		for kind: StringName in [&"patrol", &"charger", &"hopper", &"sentry", &"fan_sentry", &"root_bell"]:
			var rig := PlainsRevisionSkin.new(kind)
			var baseline := Base.BaselineSkin.new(kind)
			var weights: Array[PlainsRevisionWeights] = []
			for uv: Vector2 in rig._units: weights.append(PlainsRevisionWeights.new(uv, kind))
			for situation: String in ["moving", "hurt_attack", "dying"]:
				var times: Array[float] = []
				var baseline_times: Array[float] = []
				var baseline_checksum := Vector2.ZERO
				var checksum := Vector2.ZERO
				for frame: int in 63:
					var values := {"clock":1.0+float(frame)/60.0,"stride":.2+float(frame)*.11,"travel":.8,"drive":.3,"appendage_follow":.6,"load":.6 if situation!="moving" else 0.0,"strike":.4 if situation!="moving" else 0.0,"recovery":.3,"hurt":.5 if situation!="moving" else 0.0,"dead":situation=="dying","death":.01+float(frame)*.01,"death_clock":.02+float(frame)*.01,"air":kind==&"fan_sentry","vertical":-45.0}
					for variant: int in ([0,1] if frame%2==0 else [1,0]):
						var started := Time.get_ticks_usec()
						if variant == 0:
							var pose := Base.BaselinePose.prepare(values)
							for i: int in baseline._points.size(): baseline_checksum += baseline.deform_prepared(baseline._points[i], baseline._units[i], pose, weights[i])
						else:
							var pose := PlainsRevisionPose.prepare(values)
							for i: int in rig._points.size(): checksum += rig.deform_prepared(rig._points[i], rig._units[i], pose, weights[i])
						if frame >= 3:
							var elapsed := float(Time.get_ticks_usec()-started)/1000.0
							if variant == 0: baseline_times.append(elapsed)
							else: times.append(elapsed)
				var baseline_total := 0.0
				for sample: float in baseline_times: baseline_total += sample
				baseline_times.sort()
				var total := 0.0
				for sample: float in times: total += sample
				times.sort()
				rows.append({"round":round_index,"kind":kind,"case":situation,"vertices":rig._points.size(),"samples":times.size(),"mean_ms":total/times.size(),"p50_ms":times[30],"p95_ms":times[56],"checksum":[checksum.x,checksum.y],"baseline_checksum":[baseline_checksum.x,baseline_checksum.y],"baseline_mean_ms":baseline_total/baseline_times.size(),"baseline_p50_ms":baseline_times[30],"baseline_p95_ms":baseline_times[56]})
	print("MESH02_PAIRED_KERNEL "+JSON.stringify({"rows":rows,"scope":"Alternating same-process original baseline and current candidate synthetic prepare+625 vertex kernel, cached UV weights as production; excludes upload/draw/GPU/AI/browser/phone. Dying kernel is not settled draw-cache performance."}))
	quit()
