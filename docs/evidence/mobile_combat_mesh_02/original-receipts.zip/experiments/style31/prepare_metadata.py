from pathlib import Path
import subprocess,json,hashlib,copy
R=Path('/workspace/gunman-rush-refactor');E=Path('/workspace/refactor-evidence/mobile-combat-mesh-02/style31')
hash=lambda b:hashlib.sha256(b).hexdigest()
def git(c,p):return subprocess.check_output(['git','show',c+':'+p],cwd=R)
def write(p,v):
 q=R/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
base=subprocess.check_output(['git','rev-parse','119f4a7e'],cwd=R,text=True).strip();oldsrc=subprocess.check_output(['git','rev-parse','8dfaf7f3'],cwd=R,text=True).strip();source=subprocess.check_output(['git','rev-parse','ca505102'],cwd=R,text=True).strip()
oldstyle='docs/creative_direction/bibles/style-continuity-20261101-v30-map-query-boundary.json';newstyle='docs/creative_direction/bibles/style-continuity-20261101-v31-mobile-combat-mesh.json';A='docs/creative_direction/archive/mobile-combat-mesh-before-style31';registry='docs/creative_direction/bibles/registry.json';style=json.loads((R/oldstyle).read_bytes());before=copy.deepcopy(style)
changes=[];sources=[];files=[]
def archive(path,ap,c):
 raw=git(c,path);out=R/A/ap;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(raw);files.append(dict(path=ap,sha256=hash(raw),bytes=len(raw),source_commit=c));return raw
for row in style['runtime_reference']['references']:
 raw=(R/row['path']).read_bytes();now=hash(raw)
 if now==row['sha256']:continue
 assert row['path'] in ['game/enemies/presentation/plains_revision_'+x+'.gd' for x in ('flora','ground','pose')]
 assert raw==git(source,row['path'])
 ap='sources/'+row['path']+'.txt';old=archive(row['path'],ap,oldsrc);assert hash(old)==row['sha256']
 sources.append(dict(path=row['path'],archive_path=ap,sha256=hash(old),role=row['role'],source_commit=oldsrc))
 changes.append(dict(role=row['role'],path=row['path'],previous_sha256=row['sha256'],sha256=now));row['sha256']=now
assert len(changes)==3
for p in [registry,'docs/creative_direction/windchime_plains.json','docs/creative_direction/thorn_forest.json','tests/test_region_bible.py','tests/test_region_creative_direction.py','tools/harness/profiles.json']:
 assert (R/p).read_bytes()==git(base,p)
 archive(p,p,base)
manifest=dict(schema_version=1,parent='style30-creative33',source_commit=base,source_identity='Original metadata/tests/profiles from committed119f4a7e; three source leaves from committed8dfaf7f3 exactly match retained style30 hashes. No claim that119f contains the old source leaves.',scope='Three exact prior GD leaves and six original metadata/tests/profiles for finite historical replay. No media or runtime UID duplication and no refreshed acceptance.',selection=dict(original_reference_count=206,changed_source_count=3,media_copied=False,runtime_uid_copied=False),sources=sources,files=files)
write(A+'/manifest.json',manifest);mref=dict(path=A+'/manifest.json',sha256=hash((R/A/'manifest.json').read_bytes()))
impact=dict(task_id='MOBILE-COMBAT-MESH-02',source_commit=source,source_identity='Three current runtime leaves are exact committed ca505102 bytes, retained in metadata baseline119f4a7e; no uncommitted runtime candidate is attributed to the baseline.',candidate_source=[dict(path=r['path'],sha256=r['sha256']) for r in changes],scope='Technical source binding for exactly equivalent prepared pose/ground/flora mesh arithmetic. Preserve selected art/audio, geometry, vertex results, gameplay, resource and RNG rules. No new artwork/audio and no inherited user/device acceptance.',previous_binding_manifest=mref,original_reference_count=206,changed_references=changes,added_references=[],preserved='Exact206 role/path/order;203 references unchanged including every non-GD reference. Style30 and older source/media SHA, selection, acceptance and failure evidence remain unchanged.',binding_scope_limit='Only three existing GD references; no new asset, dynamic mechanism, runtime registry or visual selection.',validation='MOBILE-COMBAT-MESH-02 has separate root native7101/0 and371801 byte-exact vertices evidence and independent review; this binding does not replace those receipts or imply full-CI, export, visual/listening/user/device acceptance.',historical_failure=before['revision_impact']['historical_failure'])
style['version']='31';style['runtime_reference']['status']='technical_mobile_combat_mesh_source_binding_no_inherited_gameplay_art_audio_user_or_device_acceptance';style['supersedes']=dict(path=oldstyle,sha256=hash((R/oldstyle).read_bytes()));style['revision_impact']=impact
write(newstyle,style);ref=dict(path=newstyle,sha256=hash((R/newstyle).read_bytes()));reg=json.loads((R/registry).read_bytes());reg['shared_style_authority']=ref;write(registry,reg)
for region in ('windchime_plains','thorn_forest'):
 p='docs/creative_direction/'+region+'.json';d=json.loads((R/p).read_bytes());previous=hash((R/p).read_bytes());d['version']='creative-v34';d['region_bible']['supplemental_authority_path']=newstyle;d['region_bible']['supplemental_authority_sha256']=ref['sha256'];d['region_bible']['registry_sha256']=hash((R/registry).read_bytes());d['authority_sources'].append(ref)
 d['revision_impact']={k:copy.deepcopy(impact[k]) for k in ('task_id','source_commit','source_identity','candidate_source','scope')};d['revision_impact'].update(previous_direction=A+'/'+p,previous_sha256=previous,shared_style_path=newstyle,shared_style_sha256=ref['sha256'],previous_binding_manifest=mref,affected_consumers=[r['path'] for r in changes],validation=impact['validation'],historical_failure=impact['historical_failure']);write(p,d)
p=R/'tools/region_style_history.py';text=p.read_text();old='    return repository_file(path, root).read_bytes() if raw is None else raw\n';assert text.count(old)==1
text=text.replace(old,'    return style30_source(root, path) if raw is None else raw\n');text+=f'''\n\nSTYLE30_ARCHIVE = {A!r}\nSTYLE30_MANIFEST_SHA = {mref['sha256']!r}\n\n\ndef style30_source(root, path):\n    """Three prior30 leaves only; never used by current binding validators."""\n    raw = archived_source(root, STYLE30_ARCHIVE, path, STYLE30_MANIFEST_SHA)\n    return repository_file(path, root).read_bytes() if raw is None else raw\n''';p.write_text(text)
p='tools/harness/profiles.json';v=json.loads((R/p).read_bytes())
for name in ('region-bible-tests','region-bible-contract'):
 v['checks'][name]['inputs'] += [newstyle,A]
write(p,v)
(E/'metadata.json').write_text(json.dumps(dict(base=base,old_source=oldsrc,current_source=source,archive=A,style=newstyle,manifest=mref,changes=changes,old_style_sha256=hash((R/oldstyle).read_bytes())),indent=2)+'\n')
