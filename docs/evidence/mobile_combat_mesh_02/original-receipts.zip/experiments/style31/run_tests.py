import subprocess,time,json,hashlib
from pathlib import Path
R=Path('/workspace/gunman-rush-refactor');E=Path('/workspace/refactor-evidence/mobile-combat-mesh-02/style31');runs=[]
for name,argv,budget in [('current-01',['python3','tests/test_region_bible.py'],30),('history-01',['python3','tests/test_region_bible.py','--history'],30),('creative-01',['python3','tests/test_region_creative_direction.py'],60)]:
 t=time.monotonic()
 try:
  p=subprocess.run(argv,cwd=R,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=budget);raw=p.stdout;code=p.returncode;timed=False
 except subprocess.TimeoutExpired as e:raw=e.stdout or b'';code=None;timed=True
 log=E/(name+'.log');log.write_bytes(raw);row=dict(name=name,argv=argv,timeout_seconds=budget,elapsed_seconds=time.monotonic()-t,exit_code=code,timed_out=timed,log=str(log),log_sha256=hashlib.sha256(raw).hexdigest());runs.append(row);print(json.dumps(row),flush=True);(E/'test-runs-01.json').write_text(json.dumps(runs,indent=2)+'\n')
