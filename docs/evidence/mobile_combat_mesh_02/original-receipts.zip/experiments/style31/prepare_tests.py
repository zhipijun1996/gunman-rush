from pathlib import Path
import ast,json,hashlib,subprocess
R=Path('/workspace/gunman-rush-refactor');E=Path('/workspace/refactor-evidence/mobile-combat-mesh-02/style31');meta=json.loads((E/'metadata.json').read_text());A=meta['archive'];files=['tests/test_region_bible.py','tests/test_region_creative_direction.py'];original={p:(R/A/p).read_text() for p in files}
def methods(s):return {n.name:n for n in ast.walk(ast.parse(s)) if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')}
def block(s,n):return ''.join(s.splitlines(keepends=True)[n.lineno-1:n.end_lineno])
def replace_method(s,name,new):
 old=block(s,methods(s)[name]);assert s.count(old)==1;return s.replace(old,new)
def ah(n):return hashlib.sha256(ast.dump(n,include_attributes=False).encode()).hexdigest()
b=original[files[0]];c=original[files[1]]
needle='def frozen29_root(testcase):\n    return _frozen_style_root(testcase, history.STYLE29_ARCHIVE, history.style29_source)\n'
b=b.replace(needle,needle+'\n\ndef frozen30_root(testcase):\n    return _frozen_style_root(testcase, history.STYLE30_ARCHIVE, history.style30_source)\n')
# Only the three established live-version expectations; all other old version contracts stay frozen.
for old,new in [("self.assertEqual(style['content']['version'],'30')","self.assertEqual(style['content']['version'],'31')"),("self.assertEqual(live['version'],'30')","self.assertEqual(live['version'],'31')")]:
 assert old in b;b=b.replace(old,new)
b=b.replace("'30':'25','creative-v29'","'30':'25','31':'25','creative-v29'").replace("'creative-v33':'creative-v28'","'creative-v33':'creative-v28','creative-v34':'creative-v28'")
c=c.replace("self.assertEqual(task['creative_direction']['version'], 'creative-v33')","self.assertEqual(task['creative_direction']['version'], 'creative-v34')")
# Keep the complete style30 assertions on a real finite historical root.
base_names=['test_current30_exact206_sources_roles_media_and_three_technical_changes','test_current30_rejects_old_missing_corrupt_sources_and_manifest_resigning','test_current30_inputs_cover_all_current_sources_and_preserve_ordered_prefix']
for name in base_names[:2]:
 text=block(b,methods(b)[name]);first,rest=text.split('\n',1);b=replace_method(b,name,first+'\n        self.root = frozen30_root(self)\n        self.bible, self.ref = creative.bind_region_bible(\'thorn_forest\', self.root)\n'+rest)
name='test_current33_retains_selected_content_and_refuses_prior32_binding';text=block(c,methods(c)[name]);text=text.replace('from test_region_bible import frozen29_root','from test_region_bible import frozen29_root, frozen30_root').replace('prior_root = frozen29_root(self)','prior_root = frozen29_root(self)\n        current_root = frozen30_root(self)').replace('creative.load_direction(path, region)','creative.load_direction(path, region, root=current_root)').replace('creative.load_bible_registry()','creative.load_bible_registry(current_root)').replace('creative.bind_region_bible(region)[1]','creative.bind_region_bible(region, current_root)[1]').replace("creative.validate_bible_binding(old['region_bible'])","creative.validate_bible_binding(old['region_bible'], root=current_root)").replace("creative.load_direction(history.STYLE29_ARCHIVE+'/'+path, region)","creative.load_direction(history.STYLE29_ARCHIVE+'/'+path, region, root=current_root)")
# The original archived direction is read in the live root; current_root does not contain its archive.
text=text.replace("creative.load_direction(history.STYLE29_ARCHIVE+'/'+path, region, root=current_root)","creative.load_direction(history.STYLE29_ARCHIVE+'/'+path, region)")
c=replace_method(c,name,text)
# Successor exact/negative/input tests retain the previous tests' complete predicates.
new=[]
for name in base_names:
 text=block(original[files[0]],methods(original[files[0]])[name]);text=text.replace('test_current30_','test_current31_').replace('COMPOSITION_STYLE','MAP_QUERY_STYLE').replace('MAP_QUERY_STYLE).read_bytes())\n        for name', 'MOBILE_MESH_STYLE).read_bytes())\n        for name')
 text=text.replace('history.style29_source','history.style30_source').replace('history.STYLE29_ARCHIVE','history.STYLE30_ARCHIVE').replace('frozen29_root','frozen30_root').replace("current['version'], '30'","current['version'], '31'")
 if 'exact206' in name:
  text=text.replace("'2d44aaebbda52977f6ec347379242ec01a9ee62a'",repr(meta['current_source'])).replace("self.assertIn('not part of the baseline', current['revision_impact']['source_identity'])","self.assertIn('exact committed ca505102 bytes', current['revision_impact']['source_identity'])")
 if 'inputs_cover' in name:text=text.replace('MAP_QUERY_STYLE','MOBILE_MESH_STYLE')
 new.append(text)
guard=block(b,methods(b)['test_prior29_complete_methods_preserved_and_mutations_rejected']).replace('test_prior29_','test_prior30_').replace('history.STYLE29_ARCHIVE','history.STYLE30_ARCHIVE').replace('MAP_QUERY_TEST_METHOD_MIGRATIONS','MOBILE_MESH_TEST_METHOD_MIGRATIONS').replace('test_current29_exact206_sources_roles_media_and_six_technical_changes','test_current30_exact206_sources_roles_media_and_three_technical_changes').replace('test_current32_retains_selected_content_and_refuses_prior31_binding','test_current33_retains_selected_content_and_refuses_prior32_binding')
b=b.replace('\n\nclass SuitePartitionTests', '\n\n'+'\n\n'.join(new+[guard])+'\n\n\nclass SuitePartitionTests')
# Current list replaces exactly three old tests; old three plus wholemethod proof remain manually selected history.
start=b.index('CURRENT_METHODS = (');end=b.index('\nHISTORY_METHODS = (',start);part=b[start:end].replace('RuntimeOwnershipBindingTests.test_current30_','RuntimeOwnershipBindingTests.test_current31_');b=b[:start]+part+b[end:]
hstart=b.index('HISTORY_METHODS = (');hend=b.index('\n)\n',hstart);b=b[:hend]+''.join("\n    'RuntimeOwnershipBindingTests."+n+"'," for n in base_names+['test_prior30_complete_methods_preserved_and_mutations_rejected'])+b[hend:]
# Creative successor preserves content/user scope and rejects stale binding.
text=block(original[files[1]],methods(original[files[1]])['test_current33_retains_selected_content_and_refuses_prior32_binding']);text=text.replace('test_current33_retains_selected_content_and_refuses_prior32_binding','test_current34_retains_selected_content_and_refuses_prior33_binding').replace('frozen29_root','frozen30_root').replace("('creative-v32', 'creative-v33', 'creative-v33')","('creative-v33', 'creative-v34', 'creative-v34')").replace('history.STYLE29_ARCHIVE','history.STYLE30_ARCHIVE');c=c.replace('\n\n\nclass ValidationReadScopeTests', '\n\n'+text+'\n\n\nclass ValidationReadScopeTests')
# Update finite existing wholemethod allowances only for independently invertible changes.
changed={}
for p,s in [(files[0],b),(files[1],c)]:
 old,newm=methods(original[p]),methods(s)
 for n,m in old.items():
  if ah(m)!=ah(newm[n]):changed[Path(p).name+'::'+n]=dict(original_ast_sha256=ah(m),current_ast_sha256=ah(newm[n]),reason='Only current31/creative34 version expectation/normalization or explicit finite30 historical root; original predicates retained, inverse proof external.')
# Existing tables retain the exact original hashes and all prior accepted identities.
for node in reversed(ast.parse(b).body):
 if isinstance(node,ast.Assign) and isinstance(node.value,ast.Dict):
  try:d=ast.literal_eval(node.value)
  except (ValueError,TypeError):continue
  if not isinstance(d,dict) or not any(isinstance(v,dict) and 'current_ast_sha256' in v for v in d.values()):continue
  dirty=False
  for key,row in d.items():
   if key in changed and row['current_ast_sha256']!=changed[key]['current_ast_sha256']:
    row.setdefault('prior_current_ast_sha256s',[]).append(row['current_ast_sha256']);row['current_ast_sha256']=changed[key]['current_ast_sha256'];row['reason']+=' Current31/creative34 finite adaptation; prior accepted identity retained.';dirty=True
  if dirty:
   lines=b.splitlines(keepends=True);b=''.join(lines[:node.lineno-1])+node.targets[0].id+' = '+json.dumps(d,indent=4,ensure_ascii=False)+'\n'+''.join(lines[node.end_lineno:])
b=b.replace('class RuntimeOwnershipBindingTests', 'MOBILE_MESH_STYLE = '+repr(meta['style'])+'\nMOBILE_MESH_TEST_METHOD_MIGRATIONS = '+json.dumps(changed,indent=4,ensure_ascii=False)+'\n\nclass RuntimeOwnershipBindingTests')
(R/files[0]).write_text(b);(R/files[1]).write_text(c)
# All changed methods recover their original entire AST by the finite operation list above.
proof={}
for p,s in [(files[0],b),(files[1],c)]:
 old,newm=methods(original[p]),methods(s);proof[p]={'old_methods':len(old),'new_methods':len(newm),'retained_ids':sorted(old),'added_ids':sorted(newm.keys()-old.keys()),'changed_methods':{n:dict(before=ah(old[n]),after=ah(newm[n])) for n in old if ah(old[n])!=ah(newm[n])}}
(E/'test-method-map.json').write_text(json.dumps(proof,indent=2)+'\n')
