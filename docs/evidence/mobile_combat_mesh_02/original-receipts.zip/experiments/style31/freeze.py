from pathlib import Path
import subprocess,json,hashlib,ast,difflib,sys
R=Path('/workspace/gunman-rush-refactor');E=Path('/workspace/refactor-evidence/mobile-combat-mesh-02/style31');meta=json.loads((E/'metadata.json').read_text());A=meta['archive'];base=meta['base'];sha=lambda b:hashlib.sha256(b).hexdigest();j=lambda p:json.loads((R/p).read_bytes());git=lambda p:subprocess.check_output(['git','show',base+':'+p],cwd=R)
allowed=['docs/creative_direction/bibles/registry.json','docs/creative_direction/windchime_plains.json','docs/creative_direction/thorn_forest.json','tests/test_region_bible.py','tests/test_region_creative_direction.py','tools/region_style_history.py','tools/harness/profiles.json',meta['style']]+[p.relative_to(R).as_posix() for p in (R/A).rglob('*') if p.is_file()]
assert len(set(allowed))==len(allowed)
actual=set(subprocess.check_output(['git','diff','--name-only'],cwd=R,text=True).splitlines())|set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=R,text=True).splitlines());assert actual==set(allowed),(actual-set(allowed),set(allowed)-actual)
oldstyle='docs/creative_direction/bibles/style-continuity-20261101-v30-map-query-boundary.json';before=j(oldstyle);after=j(meta['style']);b,a=before['runtime_reference']['references'],after['runtime_reference']['references'];assert len(b)==len(a)==206
assert [(r['role'],r['path']) for r in a]==[(r['role'],r['path']) for r in b];diff=[dict(role=n['role'],path=n['path'],previous_sha256=o['sha256'],sha256=n['sha256']) for o,n in zip(b,a) if o!=n];assert diff==meta['changes'];assert len(diff)==3
assert (R/oldstyle).read_bytes()==git(oldstyle)
for row in a:assert sha((R/row['path']).read_bytes())==row['sha256']
for row in j(A+'/manifest.json')['files']:
 path=row['path'];original=path.removeprefix('sources/').removesuffix('.txt') if path.startswith('sources/') else path
 raw=subprocess.check_output(['git','show',row['source_commit']+':'+original],cwd=R);assert raw==(R/A/path).read_bytes();assert sha(raw)==row['sha256'];assert len(raw)==row['bytes']
for region in ('windchime_plains','thorn_forest'):
 p='docs/creative_direction/'+region+'.json';old=json.loads(git(p));new=j(p)
 assert {k:v for k,v in old.items() if k not in ('version','region_bible','authority_sources','revision_impact')}=={k:v for k,v in new.items() if k not in ('version','region_bible','authority_sources','revision_impact')}
 assert new['authority_sources'][:-1]==old['authority_sources']
pro=j('tools/harness/profiles.json');oldpro=json.loads(git('tools/harness/profiles.json'));expected=json.loads(json.dumps(oldpro))
for n in ('region-bible-contract','region-bible-tests'):expected['checks'][n]['inputs'] += [meta['style'],A]
assert pro==expected;assert len(pro['checks'])==219 and len(pro['profiles']['full'])==171
# Positive exact inverse for each altered original complete method, including every statement/assertion.
def methods(text):return {n.name:''.join(text.splitlines(keepends=True)[n.lineno-1:n.end_lineno]) for n in ast.walk(ast.parse(text)) if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')}
inverses=[]
for p in ('tests/test_region_bible.py','tests/test_region_creative_direction.py'):
 old=methods(git(p).decode());new=methods((R/p).read_text());assert old.keys()<=new.keys()
 for n,original in old.items():
  text=new[n];steps=[]
  if text==original:continue
  def replace(a,b):
   global text
   if a in text:steps.append(dict(new=a,original=b,count=text.count(a)));text=text.replace(a,b)
  if n in ('test_actual_player_body_closure_is_required_and_superseded_binding_refused','test_actual_player_body_closure_is_required_and_superseded_binding_refused_audio_history'):
   replace("self.assertEqual(style['content']['version'],'31')","self.assertEqual(style['content']['version'],'30')")
  elif n=='test_merged22_keeps83_roles_and_both_parent21_histories_and_rejects_stale':replace("self.assertEqual(live['version'],'31')","self.assertEqual(live['version'],'30')")
  elif n=='test_preserved_original_test_methods_are_unchanged':
   replace("'30':'25','31':'25'","'30':'25'");replace("'creative-v33':'creative-v28','creative-v34':'creative-v28'","'creative-v33':'creative-v28'")
  elif n in ('test_current30_exact206_sources_roles_media_and_three_technical_changes','test_current30_rejects_old_missing_corrupt_sources_and_manifest_resigning'):
   replace("        self.root = frozen30_root(self)\n        self.bible, self.ref = creative.bind_region_bible('thorn_forest', self.root)\n",'')
  elif n=='test_selected_direction_binds_every_specialist_and_retains_stage_gates':replace("self.assertEqual(task['creative_direction']['version'], 'creative-v34')","self.assertEqual(task['creative_direction']['version'], 'creative-v33')")
  elif n=='test_current33_retains_selected_content_and_refuses_prior32_binding':
   replace('from test_region_bible import frozen29_root, frozen30_root','from test_region_bible import frozen29_root');replace('        current_root = frozen30_root(self)\n','');replace('creative.load_direction(path, region, root=current_root)','creative.load_direction(path, region)');replace('creative.load_bible_registry(current_root)','creative.load_bible_registry()');replace('creative.bind_region_bible(region, current_root)[1]','creative.bind_region_bible(region)[1]');replace("creative.validate_bible_binding(old['region_bible'], root=current_root)","creative.validate_bible_binding(old['region_bible'])")
  else:raise AssertionError(('unknown method adaptation',p,n))
  assert text==original,(p,n);inverses.append(dict(path=p,method=n,steps=steps,exact_original_text_restored=True))
sys.path.insert(0,str(R/'tests'));import test_region_bible as t
allids=set(t.CURRENT_METHODS)|set(t.HISTORY_METHODS);t.validate_partition(allids,t.CURRENT_METHODS,t.HISTORY_METHODS);assert len(t.CURRENT_METHODS)==46 and len(t.HISTORY_METHODS)==40
for c,h in [(t.CURRENT_METHODS+(t.CURRENT_METHODS[0],),t.HISTORY_METHODS),(t.CURRENT_METHODS[:-1],t.HISTORY_METHODS),(t.CURRENT_METHODS+('Unknown.test_wrong',),t.HISTORY_METHODS),((),tuple(allids))]:
 try:t.validate_partition(allids,c,h)
 except ValueError:pass
 else:raise AssertionError('partition counterexample accepted')
rows=[];patch=[]
tracked=set(subprocess.check_output(['git','ls-files'],cwd=R,text=True).splitlines())
for p in sorted(allowed):
 raw=(R/p).read_bytes();prior=git(p) if p in tracked else b'';rows.append(dict(path=p,sha256=sha(raw),bytes=len(raw),previous_sha256=sha(prior) if p in tracked else None));patch.extend(difflib.unified_diff(prior.decode().splitlines(keepends=True),raw.decode().splitlines(keepends=True),fromfile='a/'+p if p in tracked else '/dev/null',tofile='b/'+p))
(E/'candidate.patch').write_text(''.join(patch));(E/'owned-write-set.json').write_text(json.dumps(dict(base_commit=base,status='frozen_candidate_pending_independent_review',allowed_paths=rows,extensions_authorized_by_root={'tools/region_style_history.py':'Append existing finite three-leaf historical source chain; live validators unchanged.','tools/harness/profiles.json':'Append current style/archive to exactly two existing checks; all argv, budgets, check/profile identities and ordered prefixes unchanged.'},new_assets=0,new_dynamic_mechanisms=0),indent=2)+'\n')
proof=dict(base_commit=base,live_source_commit=meta['current_source'],references=206,changed_references=diff,unchanged_references=203,non_gd_unchanged=sum(not x['path'].endswith('.gd') for x in b),old_style_unchanged=True,archive_git_exact_files=len(j(A+'/manifest.json')['files']),current_methods=46,history_methods=40,bible_methods=86,original_bible_methods=82,creative_methods=28,original_creative_methods=27,original_method_inverse=inverses,checks=219,full=171,profiles_only_two_finite_input_appends=True,live_validator_unchanged=True,source_assets_configuration_unchanged=True,partition_four_negative_cases_rejected=True)
(E/'static-proof.json').write_text(json.dumps(proof,indent=2)+'\n');freeze=dict(base_commit=base,files=rows,patch_sha256=sha((E/'candidate.patch').read_bytes()),static_proof_sha256=sha((E/'static-proof.json').read_bytes()),scope='Technical metadata/history consumers only; no native/visual/device acceptance.')
(E/'freeze.json').write_text(json.dumps(freeze,indent=2)+'\n');print(json.dumps(dict(files=len(rows),patch_sha256=freeze['patch_sha256'],freeze_sha256=sha((E/'freeze.json').read_bytes()))))
