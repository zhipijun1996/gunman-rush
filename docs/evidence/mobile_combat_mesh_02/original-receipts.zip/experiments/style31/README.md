# MOBILE-COMBAT-MESH-02：style31 / creative34 技术绑定

状态：候选已冻结，待非作者独审；未commit。主树基点119f4a7e，运行时三源精确来自ca505102。本次只修技术绑定与既有测试消费者，不再次修改运行代码/资源/配置。

- 新style31仅改变style30的Flora/Ground/Pose三GD引用SHA；206角色/path/顺序、其余203引用、全部非GD字节绑定保留。旧style30文件完全不动。
- 两creative34只更新版本、现行Bible技术绑定、追加新style authority与revision_impact；旧选择、quote、direction-only接受范围、所有设计内容不变，不继承视觉/听感/玩家/设备认可。
- 旧三GD从8dfaf7f3取确切Git原字节且匹配style30旧SHA；旧registry/creative2/tests2/profiles从119f4a7e取原件。manifest明确这两种来源，不伪称119f还包含旧三源。
- 沿已有region_style_history有限链加style30 adapter；旧索引叶缺失/变造拒绝，不回退live；未知叶继续原live解析。当前live validator源码不变且从不读历史替代当前源。
- root追加授权profiles只给region-bible-tests/contract原显式inputs末尾增加新style和archive；另三既有check使用全snapshot，无需重复输入清单。219注册、full171、所有profile/argv/预算/原有inputs顺序与重复项不变。

## 验证

原命令串行执行，未运行Godot/Chrome：

| 命令 | 实际结果 | 原预算 |
|---|---|---|
| python3 tests/test_region_bible.py | 46/0，16.582s | 30s |
| python3 tests/test_region_bible.py --history | 40/0，15.366s | 30s |
| python3 tests/test_region_creative_direction.py | 28/0，9.584s | 60s |
| python3 tools/region_creative_direction.py --check-bibles | PASS | 30s |
| python3 tools/region_creative_direction.py --directory docs/creative_direction | PASS | 30s |

原82 Bible/27 creative方法全保；8个旧方法仅当前版本期待/normalizer或有限历史root适配，static-proof逐旧函数全文有限逆恢复。新Bible3个当前style31合同替换原3个current30默认位置，旧3转手动history；另加原30 wholemethod反例守门在history。故current46保持、history36→40，Bible82→86；creative增加现34技术合同，27→28。未删旧断言/放宽预算/减少原current反例。

`static-proof.json`还验证206完整绑定、archive9原件逐Git、旧style30与生产字节不变、分区4负例及profiles有限变动。`candidate.patch`是完整18叶补丁；`owned-write-set.json`包含允许写集/扩写理由及逐文件SHA；`freeze.json`绑定最终源码向量。`test-runs-01.json`与三个完整日志保实际结果；CLI另见`binding-cli-results.json`。

已知之前Development任务表失败、style30三源漂移失败由root保留；本候选通过不追签之前失败。7101/0、371801 byte-exact运行时证据属root先前独立原生验证，本次未重跑、未把它描述为当前绑定候选新增的原生结果。完整Development/fullCI/导出/真机仍需root另验。
