from pathlib import Path
import ast,hashlib,json,os,sys,subprocess,tempfile,shutil,unittest,io
R=Path('/workspace/gunman-rush-refactor');E=Path('/workspace/refactor-evidence/mobile-combat-mesh-02/style31');B='119f4a7ebcd991f7b70d003f9db3c7b432f2019a'
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(p,c=B):return subprocess.check_output(['git','show',c+':'+p],cwd=R,env={**os.environ,'GIT_NO_LAZY_FETCH':'1'})
f=json.loads((E/'freeze.json').read_text());s=json.loads((E/'static-proof.json').read_text());proof={}
for row in f['files']:
 assert sha((R/row['path']).read_bytes())==row['sha256']
 if row['previous_sha256']:assert sha(git(row['path']))==row['previous_sha256']
proof['frozen_leaves_verified']=len(f['files'])
new=json.loads((R/'docs/creative_direction/bibles/style-continuity-20261101-v31-mobile-combat-mesh.json').read_text()); op=new['supersedes']['path'];old=json.loads(git(op));assert git(op)==(R/op).read_bytes()
a,b=old['runtime_reference']['references'],new['runtime_reference']['references'];assert len(a)==len(b)==206
assert [(x['role'],x['path']) for x in a]==[(x['role'],x['path']) for x in b]
changed=[y['path'] for x,y in zip(a,b) if x!=y];assert set(changed)=={f'game/enemies/presentation/plains_revision_{x}.gd' for x in ['flora','ground','pose']}
for x in b:assert sha((R/x['path']).read_bytes())==x['sha256']
for x,y in zip(a,b):
 if x['path'] not in changed:assert x==y
assert all(x==y for x,y in zip(a,b) if not x['path'].endswith('.gd'))
proof['reference_proof']={'total':206,'changed':changed,'other_unchanged':203,'non_gd_unchanged':sum(not x['path'].endswith('.gd') for x in a)}
A='docs/creative_direction/archive/mobile-combat-mesh-before-style31';m=json.loads((R/A/'manifest.json').read_text())
for row in m['files']:
 p=row['path'];orig=p.removeprefix('sources/').removesuffix('.txt') if p.startswith('sources/') else p
 assert (R/A/p).read_bytes()==git(orig,row['source_commit'])
proof['archived_exact_git_files']=len(m['files'])
for region in ['thorn_forest','windchime_plains']:
 p='docs/creative_direction/'+region+'.json';x=json.loads(git(p));y=json.loads((R/p).read_text());assert y['version']=='creative-v34';assert y['user_acceptance']=='direction_only_not_art_gameplay_or_device'
 for k in x.keys()-{'version','region_bible','authority_sources','revision_impact'}:assert x[k]==y[k]
 assert y['authority_sources'][:-1]==x['authority_sources']
proof['creative_content_preserved']=True
p='tools/harness/profiles.json';x=json.loads(git(p));y=json.loads((R/p).read_text());diff=[]
for name in x['checks']:
 if x['checks'][name]!=y['checks'][name]:
  diff.append(name);a=x['checks'][name];b=y['checks'][name];assert {k:v for k,v in a.items() if k!='inputs'}=={k:v for k,v in b.items() if k!='inputs'};assert b['inputs']==a['inputs']+['docs/creative_direction/bibles/style-continuity-20261101-v31-mobile-combat-mesh.json',A]
assert len(diff)==2
for k in x.keys()-{'checks'}:assert x[k]==y[k]
assert x['checks'].keys()==y['checks'].keys()
proof['checks_unchanged']=len(x['checks']);proof['input_append_only_checks']=diff;proof['profiles_argv_budgets_unchanged']=True
inverse={(q['path'],q['method']):q['steps'] for q in s['original_method_inverse']}
counts={}
for p in ['tests/test_region_bible.py','tests/test_region_creative_direction.py']:
 ot=git(p).decode();nt=(R/p).read_text();oa=ast.parse(ot);na=ast.parse(nt)
 def methods(t,src):return {z.name:ast.get_source_segment(src,z) for z in ast.walk(t) if isinstance(z,ast.FunctionDef) and z.name.startswith('test_')}
 om=methods(oa,ot);nm=methods(na,nt)
 for name,v in om.items():
  n=nm[name]
  for step in inverse.get((p,name),[]):assert n.count(step['new'])==step['count'];n=n.replace(step['new'],step['original'],step['count'])
  assert n==v,(p,name)
 counts[p]={'old_preserved':len(om),'new_total':len(nm)}
 if p.endswith('test_region_bible.py'):
  vals={z.targets[0].id:ast.literal_eval(z.value) for z in na.body if isinstance(z,ast.Assign) and len(z.targets)==1 and isinstance(z.targets[0],ast.Name) and z.targets[0].id in ['CURRENT_METHODS','HISTORY_METHODS']}
  cur=vals['CURRENT_METHODS'];hist=vals['HISTORY_METHODS'];assert len(cur)==len(set(cur))==46;assert len(hist)==len(set(hist))==40;assert not set(cur)&set(hist)
  actual={cl.name+'.'+me.name for cl in na.body if isinstance(cl,ast.ClassDef) for me in cl.body if isinstance(me,ast.FunctionDef) and me.name.startswith('test_')};assert set(cur)|set(hist)==actual
proof['method_inverse']=counts;proof['partition']={'current':46,'history':40,'disjoint_exhaustive':True}
assert git('tools/region_creative_direction.py')==(R/'tools/region_creative_direction.py').read_bytes()
sys.path[:0]=[str(R/'tools'),str(R/'tests')];import region_style_history as h;import region_creative_direction as c
saved=h.style30_source
h.style30_source=lambda *a:(_ for _ in ()).throw(AssertionError('live called historical reader'))
for region in ['thorn_forest','windchime_plains']:c.bind_region_bible(region,R)
h.style30_source=saved
proof['live_validator_unchanged_no_history_calls']=True
with tempfile.TemporaryDirectory(prefix='style31-independent-') as td:
 root=Path(td);shutil.copytree(R/A,root/A);leaf=root/'unindexed.txt';leaf.write_bytes(b'live-one');assert h.style30_source(root,'unindexed.txt')==b'live-one';leaf.write_bytes(b'live-two');assert h.style30_source(root,'unindexed.txt')==b'live-two';leaf.unlink()
 try:h.style30_source(root,'unindexed.txt')
 except ValueError:pass
 else:raise AssertionError('missing unknown source accepted')
 row=m['sources'][0];p=root/A/row['archive_path'];p.unlink();live=root/row['path'];live.parent.mkdir(parents=True);live.write_bytes(git(row['path']))
 try:h.style30_source(root,row['path'])
 except ValueError:pass
 else:raise AssertionError('indexed missing fell back')
proof['independent_history_controls']=['unknown leaf reads fresh live bytes','missing unknown leaf rejected','indexed missing rejected despite live source available']
import test_region_bible as tb
suite=unittest.TestSuite([tb.RuntimeOwnershipBindingTests('test_current31_rejects_old_missing_corrupt_sources_and_manifest_resigning'),tb.RuntimeOwnershipBindingTests('test_prior30_complete_methods_preserved_and_mutations_rejected')]);stream=io.StringIO();result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite);(E/'independent-targeted.log').write_text(stream.getvalue());assert result.wasSuccessful(),stream.getvalue();proof['targeted_actual_tests']={'count':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'log_sha256':sha(stream.getvalue().encode())}
for row in f['files']:assert sha((R/row['path']).read_bytes())==row['sha256']
(E/'independent-proof.json').write_text(json.dumps(proof,indent=2,ensure_ascii=False)+'\n');print(json.dumps(proof,ensure_ascii=False))
