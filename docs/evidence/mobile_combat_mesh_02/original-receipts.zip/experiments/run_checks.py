import hashlib
import json
from pathlib import Path
import subprocess
import sys

root = Path('/workspace/gunman-rush-refactor')
sys.path.insert(0, str(root / 'tools'))
import harness
out = Path('/workspace/refactor-evidence/mobile-combat-mesh-02')
label, *names = sys.argv[1:]
manifest = harness.load_manifest()
results = {}
sources = ['game/enemies/presentation/plains_revision_pose.gd', 'game/enemies/presentation/plains_revision_ground.gd', 'game/enemies/presentation/plains_revision_flora.gd', 'tests/plains_revision_deform_equivalence_runner.gd']
initial = {f:hashlib.sha256((root/f).read_bytes()).hexdigest() for f in sources}
head = subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
for name in names:
    check = ({'argv':['bash','tools/godot.sh','--headless','--audio-driver','Dummy','--path','.', '--script',str(out/'kernel_bench.gd')], 'timeout_seconds':90,'success_pattern':'^MESH02_KERNEL '} if name in ('kernel-bench','paired-bench') else manifest['checks'][name])
    if name == 'paired-bench':
        check['argv'][-1] = str(out/'paired_kernel_bench.gd')
        check['success_pattern'] = '^MESH02_PAIRED_KERNEL '
    result = harness.run_check(check,out/f'{label}-{name}.log',root=root)
    results[name] = result
    final = {f:hashlib.sha256((root/f).read_bytes()).hexdigest() for f in sources}
    receipt = {'git_head_at_start':head,'scope':'Original registered command via original run_check, or bounded new diagnostic; no full CI/browser/phone claim','source_sha256_before':initial,'source_sha256_after':final,'source_stable':initial==final,'results':results}
    (out/f'{label}-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(label,name,result['status'],result['duration_seconds'],flush=True)
    if result['status']!='passed' or initial != final: sys.exit(1)
