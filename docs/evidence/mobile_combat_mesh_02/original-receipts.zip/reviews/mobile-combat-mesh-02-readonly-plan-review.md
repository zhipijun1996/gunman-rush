# MOBILE-COMBAT-MESH-02：有限只读建议

范围：现有 PlainsRevisionPose/Ground/Flora/Skin 和 frozen-oracle runner；未修改源/测试，未运行引擎。只针对每次 draw 的625顶点CPU核，不据此声称手机帧率或卡顿根因。

## 建议先做的最小批次

生产只写 `game/enemies/presentation/plains_revision_pose.gd`、`plains_revision_ground.gd`、`plains_revision_flora.gd`。沿原 `Skin.draw_pose:92–93 → Pose.prepare一次 → deform_prepared625次` 消费，不增加manager、registry或平行算法。公开 `deform(Dictionary)` 继续走同一prepare/core，原oracle不动。

在Pose中以明确 `float` 字段保存**原标量表达式的原样结果**，Ground/Flora只替换该子表达式读取；不改变向量运算顺序、UV权重、pivot、joint/rotation或clamp位置。

- Ground:61–98 vitality的 `quiet`、各物种breath、相位偏移sin；patrol/charger gait反复 `sin(stride)`、`cos(stride)`、`sin(stride+PI)`、`cos(stride+PI)`；charger的brake、shiver；hopper的fold/extend/bounce。既有Ground私有live方法需能收到同一prepared pose，可以窄改私有参数，公开签名不必改。
- Flora:96–115 sentry的quiet/breath/inflation/chamber_angle/leaf_spring/leaf_idle；:172–188 fan的flight_beat/fan_open/carried_lift/feet-angle标量；:250–270 rootbell的breath/hurt_rebound/lower/upper-angle/bell_lag/leaf_lag。所有这些只依赖本姿态，无点/UV/size。
- 若第一轮仍有明确收益且范围小，可同法把death窗口/阻尼scalar挪入prepared pose；不要先一次搬完所有公式。Flora early death会使用 `pose.live`，其派生量应由现有递归prepare独立生成，保dead=false捕获姿态。

为什么可能有收益：当前同一sin/smoothstep/scalar表达式每625顶点重复，改为一次prepare后读属性。但仍有大量 `Vector2.rotated`、GDScript调用和向量组装，未实测不能宣称该批必有显著收益。

## 位级等价红线

1. GDScript float字段维持64bit；不要Vector2/Vector3或PackedFloat32存标量cache，否则会提前32bit舍入。
2. `sin(stride+PI)`不等于可位级替换成`-sin(stride)`；不能展开/重排乘加、factor合并、换TAU表达式或套trig恒等式。缓存原字符串子表达式最可审。
3. Ground quiet用raw_load/raw_strike与.75，Flora用clamped load/strike与.8；Ground turn clamped，Flora raw_turn；death/raw_death早返及handoff区间不统一。
4. 不把UV分支结果（front/leafside/hingechoice）放进每姿态公共值。size/pivot相关值不在现prepare参数中，本批不偷偷绑定某一物种固定size；runner明确测试可变size/bounds/kind。
5. 不跨draw按Dictionary身份缓存；同一Dictionary可原位变。已有Pose是draw-local，现生产消费者均prepare后只读，未发现手动new再写字段的消费者；若新增cache应继续明确这一短寿命合同。
6. 死亡 settled cache已经存在；不要为本批改变cache invalidation或为了提前return跳过原floor/landing规则。无效size/unknown种类路径仍与oracle相同。

更大的下轮候选：RootBell Flora:198–242/_fold_elbow:274–283 每点重复不依赖点的骨长/IK/angles，live:257–269也重复搬移hinge；但依赖size和Vector2实数精度，需要现有pose扩明确size/kind准备阶段并逐项保持向量舍入。它不属于本次最小scalar提取，先不要引第二context类。

## 原equivalence现有保障与有限缺口

`tests/plains_revision_deform_equivalence_runner.gd`现有5796断言/367640顶点，比较PackedVector2Array字节到frozen2ce oracle，含六物种全625grid、三种size、任意UV/offset、raw/clamped边界、earlydeath .14/.16/.20、airborne/live、同Dictionary变更、实际draw一context、settledcache、bounds/texture/kind变更及invalidsize/unknown。非常适合原样第一道gate，不改expected/oracle。

若本批移动trig：现样本clock/stride多为固定值和[-2,0,.5,1,2]，对所有phase/阈值邻域不是穷举。只追加有限可复现finite pose组合，覆盖PI/TAU邻近、较大正负clock/stride、raw/clamped混合和本批搬移death窗口两侧epsilon；用独立固定序列而非玩法RNG。不需要新增性能框架。NaN/Inf姿态尚无明确合同，避免借优化顺手规范它们；不宣称有限样本是全实数数学证明。

## 基准边界

测原本与候选的 **prepare+同一625顶点完整核**，保真实六kind与live/hurt/earlydeath/settled输出、相同size和姿态序列；先暖机、交替/多批采样、总计差与每mesh微秒均报。不能只计cache-hit核却排除新的prepare成本；公开one-point deform包装器因prepare变重可能变慢，应记录但以实际draw消费者为优先。输出byte mismatch或总体无改善时保失败并撤回候选，不通过降低网格/降帧/改shader/放宽oracle容差交付。
