class_name PlainsRegionalComposer
extends Node2D
## Actual candidate consumer of the complete formal region's world-space plan.
## No collision, layout, supports, Seed or decoration coordinates are authored here.
const CATALOG := "res://resources/visual_development/p1_regional_assets.json"
const GROUND_SHADER := preload("res://shaders/plains_regional_ground.gdshader")
var _stage: Node2D
var _plan: Dictionary
var _catalog: Dictionary
var _facts: Dictionary = {}
var _layers: Array[Dictionary] = []
var _old_background: CanvasLayer
var _background_was_visible := false
var _sky: ColorRect
var _camera_reference:=Vector2.ZERO

func install(stage: Node2D, plan: Dictionary) -> void:
	_stage=stage
	_plan=plan
	_facts={"version":"plains-regional-consumer-v1","seed":plan.get("seed",""),"manifest_hash":plan.get("manifest_hash",""),"plan_hash":plan.get("plan_hash",""),"production_pool":false,"terrain":[],"objects":[],"layers":[],"omitted":[],"surfaces":plan.get("surfaces",[]).duplicate(true),"renderer_writes_collision":false,"renderer_authored_layout":false,"material_coordinate_space":"world","terrain_method":"complete painted geological material on shared world-union geometry, opaque full-depth volume","rng_used":false}
	if not FileAccess.file_exists(CATALOG):
		_facts.omitted.append({"reason":"regional_catalog_missing"})
		publish_facts();return
	var parsed: Variant=JSON.parse_string(FileAccess.get_file_as_string(CATALOG))
	if not parsed is Dictionary:
		_facts.omitted.append({"reason":"regional_catalog_invalid"})
		publish_facts();return
	_catalog=parsed
	_camera_reference=_rect(plan.bounds).get_center()
	_facts.catalog_path=CATALOG
	_facts.catalog_sha256=FileAccess.get_sha256(CATALOG)
	_build_sky()
	_build_layers()
	_build_terrain()
	_build_landmarks()
	_retire_original_terrain()
	publish_facts()

func _build_sky() -> void:
	var app:=_stage.get_parent()
	if app!=null: _old_background=app.get_node_or_null("PlainsBackground") as CanvasLayer
	if _old_background!=null:
		_background_was_visible=_old_background.visible
		_old_background.hide()
	var layer:=CanvasLayer.new()
	layer.layer=-95
	add_child(layer)
	_sky=ColorRect.new()
	_sky.color=Color(str(_catalog.get("sky_color","dfe8e4")))
	_sky.mouse_filter=Control.MOUSE_FILTER_IGNORE
	layer.add_child(_sky)
	_resize_sky()
	get_viewport().size_changed.connect(_resize_sky)

func _resize_sky() -> void:
	if is_instance_valid(_sky): _sky.size=get_viewport_rect().size

func _build_terrain() -> void:
	var spec: Dictionary=_catalog.get("terrain",{})
	var texture:=_texture(str(spec.get("texture","")))
	if texture==null:return
	var source_sha:=FileAccess.get_sha256(str(spec.texture))
	var geometry: Array=[]
	var sources: Dictionary={}
	for solid: Dictionary in _plan.get("solids",[]):sources[str(solid.id)]=solid
	for body: Dictionary in _plan.get("geological_bodies",[]):
		if (body.get("holes",[]) as Array).is_empty():
			geometry.append(body)
			continue
		# Godot Polygon2D does not triangulate holes. Decompose this exact body
		# into its original collision source rectangles, sharing the same world
		# pigment and global exposed surfaces. Never fill an actual route void.
		for source_id: String in body.get("source_ids",[]):
			if not sources.has(source_id):continue
			var r:=_rect(sources[source_id].rect)
			geometry.append({"id":str(body.id)+"/"+source_id,"points":[[r.position.x,r.position.y],[r.end.x,r.position.y],[r.end.x,r.end.y],[r.position.x,r.end.y]],"source_ids":[source_id],"hole_safe_decomposition":true})
	# The exact original solid rectangles are a conservative projection only;
	# bounded rounded contour bodies, when present, remain owned by the plan.
	if geometry.is_empty():
		for solid: Dictionary in _plan.get("solids",[]):
			var r:=_rect(solid.rect)
			geometry.append({"id":solid.id,"points":[[r.position.x,r.position.y],[r.end.x,r.position.y],[r.end.x,r.end.y],[r.position.x,r.end.y]],"source_ids":[solid.id]})
	for body: Dictionary in geometry:
		var raw: Array=body.get("points",body.get("polygon",[]))
		var polygon:=_points(raw)
		if polygon.size()<3:
			_facts.omitted.append({"reason":"geological_body_polygon_invalid","id":body.get("id","")});continue
		if Geometry2D.triangulate_polygon(polygon).is_empty():
			_facts.omitted.append({"reason":"geological_body_cannot_triangulate","id":body.get("id","")});continue
		var bounds:=Rect2(polygon[0],Vector2.ZERO)
		for point: Vector2 in polygon:bounds=bounds.expand(point)
		var tops:=PackedVector4Array()
		for edge: Dictionary in _plan.get("terrain_edges",[]):
			if str(edge.face)!="top":continue
			var a:=_pair(edge.a);var b:=_pair(edge.b)
			if b.x<bounds.position.x-64.0 or a.x>bounds.end.x+64.0:continue
			if a.y>bounds.end.y+1.0 or a.y<bounds.position.y-450.0:continue
			tops.append(Vector4(a.x,a.y,b.x,b.y))
		if tops.size()>96:
			_facts.omitted.append({"reason":"local_exposed_surface_shader_budget_exceeded","id":body.get("id","")});continue
		var top_count:=tops.size()
		tops.resize(96)
		var material:=ShaderMaterial.new()
		material.shader=GROUND_SHADER
		material.set_shader_parameter("geological_paint",texture)
		material.set_shader_parameter("exposed_tops",tops)
		material.set_shader_parameter("top_count",top_count)
		material.set_shader_parameter("horizontal_period",float(spec.get("world_period",1160.0)))
		material.set_shader_parameter("painted_depth",float(spec.get("world_depth",260.0)))
		material.set_shader_parameter("source_surface",bounds.position)
		var node:=Polygon2D.new()
		node.name="RegionalGeology_"+str(body.get("id",_facts.terrain.size())).validate_node_name()
		node.polygon=polygon
		node.material=material
		node.z_index=-3
		add_child(node)
		_facts.terrain.append({"id":body.get("id",node.name),"source_ids":body.get("source_ids",[]),"source":spec.texture,"source_sha256":source_sha,"source_dimensions":[texture.get_width(),texture.get_height()],"points":raw,"exposed_top_count":top_count,"node_path":str(node.get_path()),"coordinate_space":"one global world phase","opaque_full_volume":true,"hole_safe_decomposition":body.get("hole_safe_decomposition",false),"collision_written":false})
	if _facts.terrain.is_empty():_facts.omitted.append({"reason":"no_regional_terrain_installed"})

func _build_layers() -> void:
	var bounds:=_rect(_plan.bounds)
	for belt: Dictionary in _plan.get("layer_belts",[]):
		var line:=_points(belt.world_polyline)
		if line.size()<2:continue
		var polygon:=line.duplicate()
		polygon.append(Vector2(line[-1].x,bounds.end.y+2200.0))
		polygon.append(Vector2(line[0].x,bounds.end.y+2200.0))
		var node:=Polygon2D.new()
		node.name="GlobalBelt_"+str(belt.id).validate_node_name()
		node.polygon=polygon
		var index:=int(belt.get("depth",0))
		var colors: Array=_catalog.get("belt_colors",["b4c6c0","94b3a9","759b90"])
		var tint:=Color(str(colors[mini(index,colors.size()-1)]))
		var paint_spec: Dictionary=_catalog.get("terrain",{})
		var paint:=_texture(str(paint_spec.get("texture","")))
		if paint==null:continue
		var tops:=PackedVector4Array()
		for point_index: int in line.size()-1:
			tops.append(Vector4(line[point_index].x,line[point_index].y,line[point_index+1].x,line[point_index+1].y))
		var top_count:=tops.size()
		tops.resize(96)
		var material:=ShaderMaterial.new()
		material.shader=GROUND_SHADER
		material.set_shader_parameter("geological_paint",paint)
		material.set_shader_parameter("exposed_tops",tops)
		material.set_shader_parameter("top_count",top_count)
		material.set_shader_parameter("horizontal_period",float(paint_spec.get("world_period",1160.0))*2.7)
		material.set_shader_parameter("painted_depth",float(paint_spec.get("world_depth",260.0))*3.5)
		material.set_shader_parameter("atmospheric_color",tint)
		material.set_shader_parameter("atmospheric_mix",0.72+float(2-index)*0.06)
		node.material=material
		node.z_index=-70+index*10
		add_child(node)
		_layers.append({"node":node,"depth":float(belt.parallax)})
		_facts.layers.append({"id":belt.id,"node_path":str(node.get_path()),"world_polyline":belt.world_polyline,"depth_factor":belt.parallax,"reset_per_place":false,"source":paint_spec.texture,"source_sha256":FileAccess.get_sha256(str(paint_spec.texture)),"geometry_source":"shared plan global geological silhouette","paint_mapping":"whole volume painting, enlarged world phase and atmospheric color","hand_painted_source":true})
	# One finite distant plate over the entire world, never repeated per area.
	var spec: Dictionary=_catalog.get("far_landmark",{})
	var path:=str(spec.get("texture",""))
	if not path.is_empty():
		var texture:=_texture(path)
		if texture!=null:
			var node:=Sprite2D.new()
			node.name="SingleRegionalDistantCivilization"
			node.texture=texture
			node.position=Vector2(bounds.get_center().x,bounds.position.y+420.0)
			node.scale=Vector2.ONE*maxf(float(spec.get("uniform_scale",1.4)),(bounds.size.x*0.12+1600.0)/float(texture.get_width()))
			node.z_index=-78
			add_child(node)
			_layers.append({"node":node,"depth":0.12,"base":node.position})
			_facts.layers.append({"id":"single_distant_civilization","source":path,"source_sha256":FileAccess.get_sha256(path),"node_path":str(node.get_path()),"instances":1,"depth_factor":0.12,"reset_per_place":false})

func _build_landmarks() -> void:
	var object_specs: Dictionary=_catalog.get("objects",{})
	for attachment: Dictionary in _plan.get("landmarks",[]):
		var role: String=str(attachment.get("asset_role","shelter" if str(attachment.get("role","")) in ["merchant","prep","boss"] else "tree"))
		if role=="wind_tree":role="tree"
		if role=="belfry":role="shelter"
		if not object_specs.has(role):continue
		var spec: Dictionary=object_specs[role]
		var texture:=_texture(str(spec.get("texture","")))
		if texture==null:continue
		var root:=_pair(attachment.position)
		var factor:=float(spec.get("world_height",320.0))/float(texture.get_height())
		var pivot:=_pair(spec.pivot_px)
		var support_id: String=str(attachment.get("surface_id",""))
		if support_id.is_empty():
			_facts.omitted.append({"reason":"landmark_missing_plan_owned_support","id":attachment.id});continue
		var source_polygon:=_points(spec.get("source_polygon",[]))
		var node:=Polygon2D.new()
		node.name="RootedRegional_"+str(attachment.id).validate_node_name()
		node.polygon=source_polygon
		node.uv=source_polygon
		node.texture=texture
		node.position=root-pivot*factor
		node.scale=Vector2.ONE*factor
		node.z_index=-5
		add_child(node)
		_facts.objects.append({"id":attachment.id,"role":role,"source":spec.texture,"source_sha256":FileAccess.get_sha256(str(spec.texture)),"node_path":str(node.get_path()),"surface_id":support_id,"world_anchor":[root.x,root.y],"uniform_scale":factor,"root_owned_by_plan":true})

func _retire_original_terrain() -> void:
	if _facts.terrain.is_empty():return
	var assembler:=_stage.get("assembler") as Node
	if assembler==null:return
	for module: Node in assembler.get("modules"):
		module.set("terrain_candidate_preview",true)
		module.queue_redraw()
	var supports:=assembler.get("ground_supports") as Node2D
	if is_instance_valid(supports):supports.hide()
	_facts.original_terrain_retired=true
	_facts.original_hazards_enemies_oneways_preserved=true

func _texture(path: String) -> Texture2D:
	if path.is_empty() or not ResourceLoader.exists(path):
		_facts.omitted.append({"reason":"regional_source_texture_missing","source":path});return null
	var result:=load(path) as Texture2D
	if result==null:_facts.omitted.append({"reason":"regional_source_not_texture","source":path})
	return result

func _process(_delta: float) -> void:
	var camera:=get_viewport().get_camera_2d()
	if camera==null:return
	var center:=camera.get_screen_center_position()
	for layer: Dictionary in _layers:
		var node:=layer.node as Node2D
		node.position=(layer.get("base",Vector2.ZERO) as Vector2)+(center-_camera_reference)*(1.0-float(layer.depth))

func _exit_tree() -> void:
	if is_instance_valid(_old_background):_old_background.visible=_background_was_visible

func publish_facts() -> void:
	set_meta("environment_composition",_facts)
	if is_instance_valid(_stage):_stage.set_meta("environment_composition",_facts)

func measured_nodes() -> Dictionary:return _facts.duplicate(true)
static func _pair(value: Array) -> Vector2:return Vector2(float(value[0]),float(value[1]))
static func _rect(value: Array) -> Rect2:return Rect2(float(value[0]),float(value[1]),float(value[2]),float(value[3]))
static func _points(values: Array) -> PackedVector2Array:
	var result:=PackedVector2Array()
	for value: Array in values:result.append(_pair(value))
	return result
