import sys,os,json,hashlib,subprocess,time
from pathlib import Path
ROOT=Path('/workspace/ui-workline');BASE=Path('/workspace/ui-baseline')
sys.path.insert(0,str(ROOT/'tools'))
import harness
folder=ROOT/'build/verification/demo-ui-film-v2';folder.mkdir(parents=True,exist_ok=False)
env=os.environ.copy();env.update(DISPLAY=':99',LIBGL_ALWAYS_SOFTWARE='1')
source=harness.git_metadata();driver=ROOT/'tests/demo_ui_01/movie_runner.gd'
sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
report={'status':'running','task':'DEMO-UI-01','source_metadata':source,'scope':'Real Godot title/menu/HUD/map comparison; official-policy scripted injury/heal fixtures, real jump/aim/release shot. No natural combat-route/hardware performance claim.','baseline':'Actual origin/main e9ab0e0743466b8983e34cc7de17bab1abf9d53a worktree; identical driver and fixed seed.','conditions':{'resolution':[1280,720],'fps':60,'renderer':'gl_compatibility llvmpipe','seed':'level-design-v2-baseline/08','persistence':False,'driver_sha256':sha(driver)},'comparison_differences':['Native pointer coordinates follow actual controls and differ by layout; camera and gameplay code are unchanged.','Before and after source SHAs differ. Injury/heal are explicit UI fixtures through official APIs.'],'captures':[],'user_acceptance':'unverified','device_acceptance':'unverified'}
try:
 pre=['bash','tools/godot.sh','--path','.','--rendering-method','gl_compatibility','--write-movie',str(folder/'preflight.avi'),'--fixed-fps','60','--quit-after','60','--script',str(driver),'--','--trace='+str(folder/'preflight.json')]
 result=harness.run_check({'argv':pre,'timeout_seconds':90,'success_pattern':r'^60 frames at 60 FPS'},folder/'preflight.log',ROOT,env)
 report['preflight']=result
 if result['status']!='passed':raise RuntimeError('same MovieWriter preflight failed')
 report['preflight_media']=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(folder/'preflight.avi')]))
 imp=harness.run_check({'argv':['bash','tools/godot.sh','--headless','--path','.','--editor','--quit'],'timeout_seconds':90,'success_pattern':r'^Godot Engine'},folder/'baseline-import.log',BASE,env)
 if imp['status']!='passed':raise RuntimeError('baseline import failed')
 for variant,cwd in [('before',BASE),('after',ROOT)]:
  movie=folder/(variant+'.avi');mp4=folder/(variant+'.mp4');trace=folder/(variant+'.json')
  cmd=['bash','tools/godot.sh','--path','.','--rendering-method','gl_compatibility','--write-movie',str(movie),'--fixed-fps','60','--script',str(driver),'--','--trace='+str(trace)]
  execution=harness.run_check({'argv':cmd,'timeout_seconds':240,'success_pattern':r'^DEMO UI MOVIE: 900 frames, damage=true heal=true shot=true$'},folder/(variant+'.log'),cwd,env)
  record={'variant':variant,'execution':execution,'command':cmd,'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=cwd,text=True).strip()};report['captures'].append(record)
  if execution['status']!='passed':raise RuntimeError(variant+' native recording failed')
  subprocess.run(['ffmpeg','-y','-i',str(movie),'-c:v','libx264','-crf','20','-pix_fmt','yuv420p','-c:a','aac',str(mp4)],check=True,stdout=subprocess.DEVNULL,stderr=(folder/(variant+'-encode.log')).open('w'),timeout=90)
  record.update(mp4_sha256=sha(mp4),trace_sha256=sha(trace),avi_sha256=sha(movie))
 (folder/'pair.txt').write_text("file 'before.mp4'\nfile 'after.mp4'\n")
 subprocess.run(['ffmpeg','-y','-f','concat','-safe','0','-i',str(folder/'pair.txt'),'-c','copy',str(folder/'comparison.mp4')],check=True,stdout=subprocess.DEVNULL,stderr=(folder/'concat.log').open('w'),timeout=30)
 report['comparison_sha256']=sha(folder/'comparison.mp4');report['source_stable']=source==harness.git_metadata()
 if not report['source_stable']:raise RuntimeError('candidate source changed')
 report['status']='passed'
except Exception as exc:
 report.update(status='failed',error=str(exc),source_stable=source==harness.git_metadata());raise
finally:
 (folder/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
 print(report['status'],report.get('error',''),flush=True)
