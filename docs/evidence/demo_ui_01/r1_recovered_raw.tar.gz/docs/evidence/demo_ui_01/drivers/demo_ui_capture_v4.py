import sys,os,json,hashlib,subprocess,shutil,copy
from pathlib import Path
ROOT=Path('/workspace/ui-workline');sys.path.insert(0,str(ROOT/'tools'));import harness
old=ROOT/'build/verification/demo-ui-film-v2';folder=ROOT/'build/verification/demo-ui-film-v4';folder.mkdir(exist_ok=False)
sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
original=json.loads((old/'report.json').read_text());source=harness.git_metadata();driver=ROOT/'tests/demo_ui_01/movie_runner.gd';assert sha(driver)==original['conditions']['driver_sha256']
report=copy.deepcopy(original);report.update(status='running',source_metadata=source,captures=[],source_stable=False)
report['baseline']+=' Reused exact prior baseline movie/trace from film-v2: baseline source and driver SHA unchanged; no relabeling.'
for suffix in ['.mp4','.json','.log'] :shutil.copyfile(old/('before'+suffix),folder/('before'+suffix))
report['captures']=[copy.deepcopy(original['captures'][0])];report['captures'][0]['reuse_from']='build/verification/demo-ui-film-v2/report.json'
env=os.environ.copy();env.update(DISPLAY=':99',LIBGL_ALWAYS_SOFTWARE='1')
try:
 movie=folder/'after.avi';mp4=folder/'after.mp4';trace=folder/'after.json';cmd=['bash','tools/godot.sh','--path','.','--rendering-method','gl_compatibility','--write-movie',str(movie),'--fixed-fps','60','--script',str(driver),'--','--trace='+str(trace)]
 execution=harness.run_check({'argv':cmd,'timeout_seconds':240,'success_pattern':r'^DEMO UI MOVIE: 900 frames, damage=true heal=true shot=true$'},folder/'after.log',ROOT,env)
 record={'variant':'after','execution':execution,'command':cmd,'source_commit':source['commit']};report['captures'].append(record)
 if execution['status']!='passed':raise RuntimeError('after recording failed')
 subprocess.run(['ffmpeg','-y','-i',str(movie),'-c:v','libx264','-crf','20','-pix_fmt','yuv420p','-c:a','aac',str(mp4)],check=True,stdout=subprocess.DEVNULL,stderr=(folder/'after-encode.log').open('w'),timeout=90)
 record.update(mp4_sha256=sha(mp4),trace_sha256=sha(trace),avi_sha256=sha(movie))
 (folder/'pair.txt').write_text("file 'before.mp4'\nfile 'after.mp4'\n")
 subprocess.run(['ffmpeg','-y','-f','concat','-safe','0','-i',str(folder/'pair.txt'),'-c','copy',str(folder/'comparison.mp4')],check=True,stdout=subprocess.DEVNULL,stderr=(folder/'concat.log').open('w'),timeout=30)
 report.update(comparison_sha256=sha(folder/'comparison.mp4'),source_stable=source==harness.git_metadata())
 if not report['source_stable']:raise RuntimeError('source drift')
 report['status']='passed'
except Exception as e:report.update(status='failed',error=str(e));raise
finally:
 (folder/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(report['status'],report.get('error',''))
