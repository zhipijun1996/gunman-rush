import sys,json,os
from pathlib import Path
root=Path('/workspace/ui-workline');sys.path.insert(0,str(root/'tools'));import harness
folder=root/'build/verification/demo-ui-frozen-v6';folder.mkdir(exist_ok=False);source=harness.git_metadata();assert not source['git_status'];results=[];env=os.environ.copy();env.update(DISPLAY=':99',LIBGL_ALWAYS_SOFTWARE='1')
old=json.loads((root/'build/verification/demo-ui-frozen-v2/report.json').read_text())
for c in old['results']:
 argv=[v.replace('demo-ui-native-v2','demo-ui-native-v6') for v in c['expanded_argv']]
 execution=harness.run_check({'argv':argv,'timeout_seconds':180,'success_pattern':{'ui-contract':r'^DEMO UI CONTRACT: 117 checks, 0 failures$','underworld-ui':r'^UNDERWORLD UI: 255 checks, 0 failures$','preview':r'^CLOUD PREVIEW TESTS: 25 assertions, 0 failures$','legacy':r'^DEMO UI LEGACY: 101 checks, 0 failures$','settings':r'^MENU SETTINGS LIFECYCLE: 14 assertions, 0 failures$','focus':r'^GRAPPLE FOCUS HUD: 25 checks / 0 failures$'}[c['id']]},folder/(c['id']+'.log'),root,env);execution['id']=c['id'];results.append(execution)
report={'source':source,'source_stable':source==harness.git_metadata(),'results':results};(folder/'report.json').write_text(json.dumps(report,indent=2)+'\n');print([(v['id'],v['status']) for v in results]);assert report['source_stable'] and all(v['status']=='passed' for v in results)
