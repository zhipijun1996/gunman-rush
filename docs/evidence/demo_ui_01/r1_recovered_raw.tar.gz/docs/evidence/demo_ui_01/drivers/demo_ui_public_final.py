import urllib.request,json,hashlib,time,concurrent.futures
from pathlib import Path
r=Path('/workspace/ui-workline');out=r/'build/verification';stage=json.loads((out/'demo-ui-preview-stage-v5.json').read_text());media=json.loads((out/'demo-ui-media-stage-v5.json').read_text());url=stage['url']
def fetch(u):
 sha=hashlib.sha256();size=0
 with urllib.request.urlopen(u,timeout=90) as response:
  status=response.status
  while True:
   b=response.read(1024*1024)
   if not b:break
   size+=len(b);sha.update(b)
 return {'url':u,'status':status,'bytes':size,'sha256':sha.hexdigest()}
report={'source_commit':stage['source_commit'],'build_id':stage['build_id'],'hosting_commit':'c676d703a80d1ba0eb47b9a04a40798c869286cf','pages_run':'https://github.com/zhipijun1996/gunman-rush-previews/actions/runs/39843594774','observed_at':time.time(),'checks':[]}
tasks=[('pack',url+stage['pack_verification']['pack'],stage['pack_verification']['pack_sha256']),('comparison',media['urls']['comparison.mp4'],media['comparison_sha256']),('html',url,None)]
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
 futures=[pool.submit(fetch,u) for name,u,sha in tasks]
 for (name,u,expected),future in zip(tasks,futures):
  entry=future.result();entry['name']=name;entry['expected_sha256']=expected;entry['passed']=entry['status']==200 and (expected is None or entry['sha256']==expected);report['checks'].append(entry)
for name,u in [('preview_build',url+'build-info.json'),('main_after','https://zhipijun1996.github.io/gunman-rush/build-info.json')]:
 with urllib.request.urlopen(u,timeout=60) as response:
  data=json.load(response);report[name]={'url':u,'body':data,'status':response.status}
report['build_matches']=report['preview_build']['body']==json.loads((r/'build/web/build-info.json').read_text());report['main_unchanged']=report['main_after']['body']==json.loads((out/'main-public-before.json').read_text())['body'];report['passed']=all(x['passed'] for x in report['checks']) and report['build_matches'] and report['main_unchanged'];(out/'demo-ui-public-verification-final.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report));raise SystemExit(not report['passed'])
