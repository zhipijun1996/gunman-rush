import sys,json,os,copy,shutil
from pathlib import Path
root=Path('/workspace/ui-workline');sys.path.insert(0,str(root/'tools'));import harness
folder=root/'build/verification/demo-ui-frozen-v5';folder.mkdir(exist_ok=False);source=harness.git_metadata();assert not source['git_status'];env=os.environ.copy();env.update(DISPLAY=':99',LIBGL_ALWAYS_SOFTWARE='1');old=json.loads((root/'build/verification/demo-ui-frozen-v4/report.json').read_text());assert old['source']==source and old['source_stable'];results=[]
for c in old['results']:
 if c['id']=='ui-contract':
  argv=[v.replace('demo-ui-native-v4','demo-ui-native-v5') for v in c['expanded_argv']];execution=harness.run_check({'argv':argv,'timeout_seconds':180,'success_pattern':r'^DEMO UI CONTRACT: 116 checks, 0 failures$'},folder/'ui-contract.log',root,env);execution['id']=c['id'];results.append(execution)
 else:
  assert c['status']=='passed';item=copy.deepcopy(c);item['reused_exact_report']='build/verification/demo-ui-frozen-v4/report.json';results.append(item);shutil.copy2(root/'build/verification/demo-ui-frozen-v4'/(c['id']+'.log'),folder/(c['id']+'.log'))
report={'source':source,'source_stable':source==harness.git_metadata(),'results':results,'scope':'UI fresh repeat after prior unexplained native process exit1 with no diagnostic; other five exact same-source proofs preserved without relabeling'};(folder/'report.json').write_text(json.dumps(report,indent=2)+'\n');print([(v['id'],v['status']) for v in results]);assert report['source_stable'] and all(v['status']=='passed' for v in results)
