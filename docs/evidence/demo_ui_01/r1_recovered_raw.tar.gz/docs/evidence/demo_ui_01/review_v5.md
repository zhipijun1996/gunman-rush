# DEMO-UI-01 · 最终触屏导航尺寸独立复审 V5

审查者：`/root/independent_review`，非实现作者。精确源码 `df5207ccc920f5d48813412a27d9d72dc79510ab`。本次只读源码、原始回执及实际 PNG；未运行引擎或浏览器，唯一写入为仓库外本文件。未签用户、实体设备或完整 Integration／Release。

## 限定结论

**ACCEPT：首轮可操作 UI 方向及本次触屏 MENU 几何修复可交付用户评价。** 此结论限于真实已观察／验证的功能与像素范围，不把失败浏览器轮次或尚未完成的公网全流程提升为通过。

## 源码复核

`DemoGameHud.present_touch_menu` 只调整既有 `TouchOverlay._pause_rect` 的 UI 命中边界，按实际 screen transform 将可见／命中区域设为至少108×48像素，字号至少14实际像素。新增 Panel／Label 均 MOUSE_FILTER_IGNORE，没有创建第二套按钮回调；原 TouchOverlay 的 unhandled touch、pause_requested、Router 清理和暂停逻辑仍唯一消费输入。DemoApp 只新增一行呈现调用，并在之后让地图导航读取扩大后的真实矩形避让。未改共享 TouchOverlay 脚本、伤害、资源、能力、Motor 或存档规则。

原 b520／2f8 两处 Popup 修复仍在：适配器挂在真实 Popup Viewport；开 Popup 时主动取消根 Scroll 的触控 owner，使释放事件交给新 Viewport 后不再残留原 `_finger`。二者对应原实际 DOM 故障，不是为测试增加假反馈。

## 原始验证回执

已读取 `build/verification/demo-ui-frozen-v7/report.json`：精确 df5207、源码干净且 source_stable=true；六组 fresh／exit0：UI contract130、Underworld UI255、Preview25、legacy101、settings14、grapple focus25，共550项，均0失败。报告SHA256 `1e0528208dc1faf317d8ec8947ce23975e72a0a09b8f92300225510f7df53bb5`。本审查只复核宿主执行的日志，不冒称独立重跑。

`demo-ui-native-v7/assertions.json` 的130项明确包含四个请求窗口尺寸的 MENU 至少48实际像素、字体至少14实际像素、实际触控仍经原暂停入口且不发射。原 probe1／probe2 错传物理／逻辑坐标的失败保留；probe3 修正为与原 menu_scroll_tests 一致的 root.push_input(local=true)，没有改玩法阈值追认。

## 本次实际查看的像素

- `build/verification/demo-ui-native-v7/touch-hud-844x390.png`：新的 MENU 可见约108×48，文字明显大于旧版；下方地图留有间隔，没有覆盖该命中区。
- `build/verification/demo-ui-browser-13/mobile-before-touchcancel.png` 与 `mobile-after-touchcancel.png`：取消前后均完整保留暂停页五个动作，后图仍有 CONTROLS、RETURN TO HOME，未回到 HUD。RESUME 的 cream 高亮影响旧 OCR 定位；画面事实不支持“取消已恢复游戏”。

读取 browser13 partial-report：模拟手机前10项通过，涵盖设置打开、Analog提交、Apply、真实Plains、扩大后的MENU暂停、设置返回暂停、雾图、地图关闭与关闭后首个Space。原最后一项“DOM touchcancel does not activate Resume”因 OCR 找不到高亮字报失败，**browser13 整轮仍是失败**，不回签其原件。下一轮以两个仅在暂停页存在的按钮证明取消后页面保留，是同一行为要求的观察修正；须等待实际新回执。

## 动态、公开站点与未验范围

读取 `demo-ui-film-v6/report.json`：宿主为本次精确源码实际录制，passed/source_stable=true；本人未完整播放或听音，不签动画连续性或音频内容。真实电影及基线复用仍以其原始报告为准。

本文件首次写入时 public browser14 尚未完成。公开版本、完整PCK字节、实际桌面／DOM手机全流程须引用后续真实回执，不能据本次读图推断。实体手柄／手机、高DPR／缺口安全区、用户美术与操作体验认可、完整Integration／Release均未在独审完成。早期技术／艺术限定接受继续保留原范围。

## 最终公网增量：browser16

随后已读取 `build/verification/demo-ui-browser-16/report.json`，URL 精确为：

`https://zhipijun1996.github.io/gunman-rush-previews/previews/DEMO-UI-01/df5207ccc920f5d48813412a27d9d72dc79510ab/5ae16004975a/`

此公开版本的 **desktop10＋模拟手机DOM11＝21项全部通过，failed=0，errors=[]**。覆盖实际设置与Popup提交、触控滚动与Apply、正式Plains组装、MENU暂停、设置返回暂停、雾图打开／缩放／关闭、关闭后首个Space不重开UI，以及DOM touchcancel后仍保留暂停页。本人复核原报告，未冒称独立浏览器重跑。browser16报告SHA256 `71f7e6d473f82d7a8a45b6537d7cc4d17ffb602e2341c4e02919f8bd4a209242`。

本次另直接打开 browser16 的 `mobile-actual-hud.png`、`mobile-map.png`、`mobile-after-touchcancel.png`：放大的MENU文字／矩形清楚；手机地图标题、真实已探索范围与两行工具栏可见；取消后仍显示完整暂停动作，符合本轮操作回执。前述browser13整轮失败继续保留，未回写为通过；新browser16使用修正后的页面观察完成新的公开验证。

已读取 `demo-ui-public-verification-final.json`：source=df5207、build=5ae16004975a，完整公开PCK **141868084字节**，SHA256 `5ae16004975a6921b4e306aac77b86ca100bcca2e2205f0152d3499ef4c09f0d`；公开MP4 **3547931字节**，SHA256 `93b03ef086fc9a310b9e16c273170236c7e944a207f6270bdb4b0d67369964c3`，均与期望一致。原正式站build/source保持703f9b040e5f／9c349f44，未被此独立Preview覆盖。该核验报告SHA256 `b747e2458696415256c524c20c583fa87966df99f9046a11070ad2622b1f4196`，绑定Pages run39843594774及hosting commit c676d703。

因此，**最终限定接受范围增加本次精确公开版本的上述桌面／模拟DOM手机真实操作和完整载体身份**。仍未签实体设备、用户审美／手感、完整Integration／Release；视频载体已核不等于本人完整观看／听过。
