# DEMO-UI-01 · 可操作交付

基线 `e9ab0e0743466b8983e34cc7de17bab1abf9d53a`；运行源码 **`df5207ccc920f5d48813412a27d9d72dc79510ab`**；Web **`5ae16004975a`**。后续证据／文档提交没有重建运行包。分支 `feature/demo-ui-01`，未合并源码 main。

- [独立 Godot Web Preview](https://zhipijun1996.github.io/gunman-rush-previews/previews/DEMO-UI-01/df5207ccc920f5d48813412a27d9d72dc79510ab/5ae16004975a/)
- [约30秒真实 Godot 改前／改后录像下载](https://zhipijun1996.github.io/gunman-rush-previews/deliveries/DEMO-UI-01/df5207ccc920f5d48813412a27d9d72dc79510ab/93b03ef086fc/comparison.mp4)
- [15秒改后录像](https://zhipijun1996.github.io/gunman-rush-previews/deliveries/DEMO-UI-01/df5207ccc920f5d48813412a27d9d72dc79510ab/93b03ef086fc/after.mp4)

本次公网完整141868084字节PCK和3547931字节合片均下载核SHA，build-info完全匹配；主站build-info与部署前相同。看 `public-verification.json`，不能用早期stage回执替代上线证据。托管提交 `c676d703a80d1ba0eb47b9a04a40798c869286cf`；[实际成功Pages运行](https://github.com/zhipijun1996/gunman-rush-previews/actions/runs/39843594774)。

从真实标题进入完整游戏，实验室中保留返回完整游戏入口，预览持久化仍禁用。bootstrap seed=`demo-ui-01-review`；标题主操作沿用正式Plains固定 `level-design-v2-baseline/08`，地区页空种子仍由原Crypto流程生成新种子。无伪装的静态整屏。

## 方向、正式数据与消费者

统一旧铜／羊皮纸／深绿的像素钟表语言，原生钟摆／风铃装饰；真实Control、Container、Theme、Button、OptionButton、Slider共用。爱心按health.current/capacity逐单位显示，实际存在小数才出现局部填充，10列换行并保留精确数值；受伤残影与恢复青绿反馈。射击精力按实际消耗分刻度、空中弹药为离散单元，武器／能力按真实拥有显示，共鸣与慢时仅相关状态出现；金币和音符读原钱包／元进度。不创造属性、重复资源或回写玩法。旧黑板在正常正式游戏中隐藏，F3原调试与实验室兼容HUD保留。

| 入口／实际消费者 | 范围和验证 |
|---|---|
| DemoMenu 标题、地区、暂停、设置、帮助、危险离开、结果 | 统一组件与焦点，原设置验证／取消／生命周期；原生与真实Web交互 |
| DemoApp 正式 Plains／Forest | 真实资源HUD，原生死亡／家园／重开、Forest H授予原规则、地区身份 |
| HomeScene | 同一HUD与真实钱包／音符／能力；原正式UI生命周期专项 |
| 迷雾地图／progression | 保留真迷雾、当前位置、地区与层数；平移／缩放／返回；不造路线／探索记录 |
| shop／exit／reward | 共用modal shell；原255项消费专项；强制奖励不能绕过、快速确认不重复提交 |
| ActorResourcesHud：Graybox／ModuleLab／FoundryLab／RandomStagePreview | 保留兼容类及实验布局；原101项资源／菜单与Preview生命周期；未逐个完整GUI走查所有实验室 |
| cloud_preview.gd | task_id==DEMO-UI-01时4行专用接入；游戏中隐藏遮挡开发条，实验室保留FULL GAME；其他任务不变 |
| TouchOverlay | 原脚本／输入规则不改；任务HUD只调整既有_pause_rect显示命中几何并用IGNORE面板／Label呈现，仍由原pause_requested唯一消费 |

中文字体本次313个实际UI字符串汉字均有字形，7543字形原子集及OFL许可不变；见 `font-final.json` 与任务asset_sources。标题复用原far.png，生成来源／Asouris原许可指向清楚，无新栅格或图像生成。

## 实际验证

`demo-ui-frozen-v7/report.json`记录精确df520干净树，`source_stable=true`。实际Godot4.7.2 Standard、Xvfb、llvmpipe，六组fresh **550项／0失败**：新UI130、原Underworld UI255、原Preview25、legacy101、settings14、grapple focus25。另原 `menu_scroll_touch_tests.gd` **44项／0失败**，见 `demo-ui-menu-scroll-v6.log`。原断言／预算未改，未跑完整CI或Windows导出。

原生Control专项含鼠标、触控、模拟手柄，关闭地图首次A不重开、取消不泄漏、死亡／家园／重开、13.5生命上限／部分生命、中文／长文本／快速提交。960×540、844×390、720×1280、1920×720实际窗口中菜单命中≥48px；真实TouchOverlay MENU现在108×48px且字≥14px，每种尺寸实际点击原暂停回调且无射击，地图避让。原始日志、assertions和PNG在native-v7／frozen-v7。

Web回执独立归档，不将模拟设备写成实体。公开版desktop10＋mobile11共21项0失败、engine errors=[]，鼠标／DOM触控的最终原件见 `browser-public/`；本地失败及局部成功不升级为公开全验。实体手机／手柄、刘海屏实际安全区、硬件性能、美术／音画主观认可仍未验。

`film-final-v6/report.json`与原日志记录真实MovieWriter：前后各900采样帧＋8清理帧，1280×720/60fps/48kHz双声道，合片30.287696秒。伤害、恢复为通过正式DamagePolicy／HealEffect的明确UI fixture；跳跃和瞄准松手射击是真实输入。基线是实际e9ab0e0工作区，按未变的基线／驱动明确复用原件，布局导致点击坐标不同。最终after重新实录df520；画面相同得出相同影片SHA不重标签。无自然战斗路线、硬件60fps或完整听审结论。最终影片原件与编码日志随源保留。

## 失败和修正

完整失败浏览器原件保存在 `failed-browser.tar.gz`，`failed-browser-manifest.json`列逐文件SHA，打包后回读验证每一份。可 `tar -xzf ... -C 任意空目录` 恢复。13取消前后关键PNG另存failure-snapshots供直接审阅。早期稀疏检出重新应用误删忽略build已向用户说明；缺失旧原件不补造，不追认，改用新冻结重跑。其后不再重放稀疏配置。

- 初期爱心被开发条遮挡、地图键与TouchOverlay MENU重叠、地图关闭首次A吸收、焦点键不稳定已修复；以新冻结原件为准。
- browser01发现设置初次打开滚动到底部，511ddd1修正；02–06的OCR误匹配／识别失败保留。
- 07真实手机Popup不能提交，b520将Adapter挂在实际Popup Viewport；08–11又暴露原ScrollAdapter保留触点占用，2f8在Popup打开时调用原cancel交接所有权。12实际确认选中→滑动→Applied→进入Plains；其后旧MENU文字太小使OCR失败。
- df520扩大实际TouchOverlay导航目标。13真实完成上述手机流程、MENU、地图缩放与关闭、首次Space；最终取消断言漏OCR高亮RESUME，原始前后像素与独审确认仍在暂停。新助手用RETURN TO HOME＋CONTROLS这两个暂停唯一操作证明取消没有恢复，不放宽行为要求，原失败保留。
- native probe1/2在缩放窗口误传逻辑坐标给会做屏幕变换的Input.parse_input_event；probe3改用原menu_scroll_tests同样的root.push_input(local=true)，实际UI／Overlay消费不绕过。原2份失败与诊断保留。
- frozen-v3漏宿主success_pattern失败；v4原UI进程仅启动后无诊断exit1，不能推断原因；v5只重跑UI并明示复用另5同SHA通过原件。最终v7六组全部fresh，旧失败不替换。
- 公开browser14/15的助手误用environment_proxy返回tuple导致启动失败，未进入游戏；16修正调用只取proxy配置，凭据不写日志。

`docs-check/`保留真实失败：稀疏工作区缺历史handoff／证据／图，未为纯UI恢复全仓历史。文档全检不是PASS。完整Integration／Release交总控，中央任务/current_state/handoff未改；本线质量卡为review，用户美术与实体设备G5仍未签。

## 容量和恢复

原容量超900MiB失败已保留。非latest CLOUD-PRODUCTION-01 f3bd1c3/f6e7a0f8c6a1完整362文件逐SHA核对移至托管仓archives/previews；旧地址明确退休，latest CLOUD及视频保留。UI A1–A4候选同样可恢复，未发布者不冒称上线。并发FINE-SPACE-05展示页和入口合并保留。最终站863411247字节，小于943718400预算；main正式站未覆盖。

恢复：源码检出df5207c，基线检出e9ab0e0；托管旧版从archives恢复transport到原site/previews路径，逐SHA核receipt并先腾预算，运行 `python3 _tools/cloud_delivery.py verify-host --host-root .` 再正常提交部署。无需破坏性reset或覆盖main。各report含精确expanded_argv；可复用 tests/demo_ui_01/ 正式驱动；宿主原件drivers/保留工作区绝对路径，复跑时按机器替换。
