# DEMO-UI-01 · 冻结源码独立复审 V2

审查者：`/root/independent_review`，非实现作者。2026-10-22。审查源码为 `511ddd113ec3c5388eb940a448d2985d27585d0b`；读取时 Git 工作区干净。本次唯一写入是本审查文档，未修改生产源码、未运行 Godot。

## 限定结论

**ACCEPT，范围仅为已读冻结源码及实际查看画面的首轮 UI 交付方向。** 新增设置初始滚动修复与任务专用 Preview 显示逻辑没有发现阻断问题。先前 R1／R2／R3 的源码修正仍在。允许将这一版本提供给用户实际操作评价，不签商业美术定稿、完整 Integration／Release、用户认可或实体设备验收。

## 本次源码观察

- `DemoMenu._restore_focus` 在容器布局后的下一帧处理滚动，首次进入将滚动位置设为 0；返回已有字段才执行 `ensure_control_visible`。页面代数及有效性检查仍阻断旧页面回调。设置移动模式、五个输入滑杆及音量滑杆的焦点键来自稳定字段，避免重建节点名变化导致恢复失效。
- `scripts/dev/cloud_preview.gd` 仅在任务为 `DEMO-UI-01` 时接入任务专属 `preview_affordance.gd`。它隐藏完整游戏本身的开发横条，避免遮住标题、HUD 和菜单；进入实验场景时继续保留返回完整游戏的按钮。自定义场景使 `app` 无效时也保留该入口。没有修改 Preview 的持久化禁用、返回重建、种子或游戏规则。
- 生命／精力／弹药／武器／共鸣／能力继续由现有正式状态读取；共享接入没有新增伤害、资源、能力授予或地图拓扑规则。

## 本次实际打开的原件

原生像素来自 `build/verification/demo-ui-native-v2/`：`title.png`、`formal-hud.png`、`max-growth.png`、`run-end.png`、`pause-844x390.png`。标题主操作明确；HUD 爱心、精力与弹药可区分；增长后的两行爱心和 `5.25/13.5` 数字完整可见；结果页明确说明再次出发从平原开始。手机尺寸暂停图中常用按钮有清楚的大命中区域，当前滚动位置优先显示已聚焦动作。

另打开实际 Web 截图 `build/verification/demo-ui-browser-02/desktop-movement-picker-0.png` 和 `build/verification/demo-ui-browser-03/desktop-movement-picker-0.png`：设置页标题、说明、`Touch movement` 与已聚焦 `Walk / Run` 字段同时可见，右侧滚动条位于顶部。OCR 未识别字段文字不等于 UI 缺失；上述结论来自直接看图。该静图不证明弹出菜单项已由 DOM 鼠标／触屏提交。

## 冻结验证回执复核

已读取 `build/verification/demo-ui-frozen-v2/report.json`，源码字段为本次精确 SHA，`source_stable=true`，六组原始执行均 `passed / exit_code=0`。报告 SHA256 为 `2c6e442189c0919d5c164f4dcb9d378a3fb38e3355c7e08d68a4cdd48dd32eae`。

逐份原始日志的真实完成数：UI contract **113**、原 Underworld UI **255**、Preview **25**、legacy **101**、settings **14**、grapple focus **25**，均 0 失败。Preview 不是 35 项。本人只读取宿主执行的回执；未冒称独立重跑。六份日志未发现脚本解析错误或原生对象／资源退出泄漏标记。

当前 `demo-ui-native-v2/assertions.json` 为 113 项／0 失败，SHA256 `9abe659031f30f840e2f15fa8843afda2f49c59417317e2616874d07a62aa143`，包含“首次设置页标题和字段可见”“关闭地图后首次 A 不重开地图”等具体断言。

## 真实电影与未验范围

已读取 `build/verification/demo-ui-film-v3/report.json`：声明真实基线 `e9ab0e0743466b8983e34cc7de17bab1abf9d53a` 与本次源码的前后片；原基线影片明确按未变的源和驱动复用，输入坐标随 UI 布局变化，伤害／恢复为正式 API fixture，未冒称自然战斗路线。

本次只用 ffprobe 与完整文件散列核实 `comparison.mp4` 的载体：1280×720、60fps、48kHz 双声道、30.287696 秒，SHA256 `93b03ef086fc9a310b9e16c273170236c7e944a207f6270bdb4b0d67369964c3`。**未完整播放、未听音轨**，因此不签连续动作／声音美感或实际音频内容；存在双声道流也不等于已经听过。

浏览器第三轮当时仍在运行。实际 DOM 触控取消、弹出选项提交、手机地图与高 DPR 安全区仍以完整浏览器回执为准；实体手柄／手机、玩家评价、完整集成与 Release 均未在本次独审验证。

早期回执因稀疏重新检出而不再全在本地；本复审依赖上述新冻结原件，不追认缺失的历史文件，也不将旧审查的局部结果升级为完整验收。
