import functools,hashlib,json,pathlib,subprocess,sys,threading,time
from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
root=pathlib.Path('/workspace/gunman-rush')
proof=root/'build/region_bible_v2/ci-browser-1248157-first'
report=json.loads((proof/'receipt.json').read_text())
assert report['status']=='passed'
web=pathlib.Path(report['served_directory'])
info=report['build_info']
out=root/'build/region_bible_v2/ci-forest-gui-1248157-first'
assert not out.exists()
def inventory():
 result={}
 for path in sorted(web.rglob('*')):
  if path.is_file():
   with path.open('rb') as f: result[str(path.relative_to(web))]=hashlib.file_digest(f,'sha256').hexdigest()
 return result
before=inventory()
assert before==report['web_inventory_after']
class Quiet(SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Quiet,directory=str(web)))
threading.Thread(target=server.serve_forever,daemon=True).start()
url=f'http://127.0.0.1:{server.server_port}/'
cmd=[sys.executable,str(root/'tools/verify_forest_browser.py'),url,'--output-dir',str(out),'--expected-commit',info['source_commit'],'--expected-build-id',info['build_id'],'--expected-forest-version','thorn-forest-region-v2','--expected-forest-layout','forest-bible-world-v15']
receipt={'source_commit':info['source_commit'],'build_id':info['build_id'],'command':cmd,'scope':'actual eight mouse/touch cases; not native routes, natural campaign GUI, player or physical device approval','started_at_unix':time.time(),'source_web_inventory_before':before,'status':'failed'}
try:
 with pathlib.Path('/tmp/gunman-bible-delivery/final-1248157/forest-gui.log').open('x') as log:
  r=subprocess.run(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT,timeout=510)
 receipt['exit_code']=r.returncode
 after=inventory();receipt['source_web_inventory_after']=after
 assert after==before
 assert r.returncode==0
 receipt['status']='passed'
finally:
 server.shutdown();server.server_close()
 receipt['ended_at_unix']=time.time()
 pathlib.Path('/tmp/gunman-bible-delivery/final-1248157/forest-gui-wrapper-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps({k:receipt.get(k) for k in ['status','source_commit','build_id','exit_code']},ensure_ascii=False))
