from pathlib import Path
import json,hashlib,sys,subprocess,time
ROOT=Path(__file__).resolve().parents[3];sys.path.insert(0,str(ROOT/'tools'))
import harness
out=Path(__file__).resolve().parent
phase=sys.argv[1]
commands={
 'import-original':(['bash','tools/godot.sh','--headless','--path','.','--editor','--quit'],90,r'Godot Engine v4\.7\.2'),
 'native-original':(['bash','tools/godot.sh','--headless','--fixed-fps','60','--path','.','--script','tests/avatar_presentation_ownership_runner.gd'],90,r'^AVATAR OWNERSHIP: 25 assertions, 2 failures$'),
 'native-fixed':(['bash','tools/godot.sh','--headless','--fixed-fps','60','--path','.','--script','tests/avatar_presentation_ownership_runner.gd'],90,r'^AVATAR OWNERSHIP: [1-9]\d* assertions, 0 failures$'),
 'generated26':([sys.executable,'tools/run_generated_consumer_tests.py'],2100,r'^GENERATED CONSUMER SUITES: 26 suites passed$'),
}
argv,cap,pattern=commands[phase]
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
status=subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True)
before=harness.source_inventory();(out/(phase+'-source-before.json')).write_text(json.dumps(before,indent=2)+'\n')
start=time.monotonic();result=harness.run_check({'argv':argv,'timeout_seconds':cap,'success_pattern':pattern},out/(phase+'.log'),root=ROOT)
after=harness.source_inventory();(out/(phase+'-source-after.json')).write_text(json.dumps(after,indent=2)+'\n')
receipt={'phase':phase,'scope':'Real original CLI with exact full prepared tracked/untracked SHA inventory including docs, no engine parallelism','head_before':head,'head_after':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'git_status_before':status,'git_status_after':subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True),'source_count':len(before),'source_stable':before==after,'source_differences':[p for p in sorted(before.keys()|after.keys())if before.get(p)!=after.get(p)],'check':result,'argv':argv,'timeout_seconds':cap,'log_sha256':hashlib.sha256((out/(phase+'.log')).read_bytes()).hexdigest(),'total_seconds_with_after_SHA':time.monotonic()-start}
receipt['git_stable']=receipt['head_before']==receipt['head_after'] and receipt['git_status_before']==receipt['git_status_after']
(out/(phase+'-receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
expected=result['exit_code']==1 if phase=='native-original' else result['status']=='passed'
raise SystemExit(0 if expected and receipt['source_stable'] and receipt['git_stable'] else 1)
