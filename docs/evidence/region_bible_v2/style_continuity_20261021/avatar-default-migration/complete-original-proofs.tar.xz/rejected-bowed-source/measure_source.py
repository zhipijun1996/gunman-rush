"""Read-only measurements of the immutable single imagegen return; writes JSON only."""
from pathlib import Path
from collections import Counter
from PIL import Image
import base64
import hashlib
import json

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
path = HERE / 'imagegen-original.png'
source = Image.open(path).convert('RGBA')
alpha = source.getchannel('A')
pixels = list(source.get_flattened_data())
bboxes = {}
for threshold in (1, 128, 240, 250, 253, 254, 255):
    box = alpha.point(lambda value: 255 if value >= threshold else 0).getbbox()
    bboxes[str(threshold)] = {'bbox': box, 'aspect': (box[2]-box[0])/(box[3]-box[1]) if box else None}
outline = json.loads((HERE/'frozen-spec.json').read_text())['native_outline']


def inside(x, y):
    crossings = 0
    for a, b in zip(outline, outline[1:] + outline[:1]):
        if (a[1] > y) != (b[1] > y) and x < (b[0]-a[0])*(y-a[1])/(b[1]-a[1])+a[0]:
            crossings += 1
    return crossings % 2 == 1


samples = []
for y in range(73):
    for x in range(195):
        if inside(x+.5, y+.5):
            samples.append(source.getpixel((min(source.width-1, int((x+.5)/195*source.width)),
                                            min(source.height-1, int((y+.5)/73*source.height)))))
references = []
for relative in ('assets/underworld_plains/terrain/source.png', 'assets/forest_bible_v2/native/bark_source_v2.png'):
    reference = Image.open(ROOT/relative).convert('RGBA')
    occupied = [pixel for pixel in reference.get_flattened_data() if pixel[3] > 0]
    references.append({'path': relative, 'size': reference.size, 'nontransparent_RGBA_colors': len(set(occupied)),
                       'nontransparent_alpha_counts': dict(Counter(pixel[3] for pixel in occupied))})
raw_response = json.loads((HERE/'raw-tool-response.json').read_text())
returned_png = base64.b64decode(raw_response['image_url'].split(',', 1)[1])
assert returned_png == path.read_bytes()
measurement = {
    'scope': 'Source readback only, no image pixels edited or repaired; no engine/GPU render',
    'original_source_bytes': path.stat().st_size,
    'original_source_SHA256': hashlib.sha256(path.read_bytes()).hexdigest(),
    'raw_tool_image_data_equals_original_PNG_bytes': True,
    'actual_source_size': source.size,
    'actual_RGBA_color_count': len(set(pixels)),
    'actual_RGB_color_count': len({pixel[:3] for pixel in pixels}),
    'alpha_value_count': len(Counter(pixel[3] for pixel in pixels)),
    'alpha_top_counts': Counter(pixel[3] for pixel in pixels).most_common(12),
    'alpha_threshold_bboxes': bboxes,
    'native_logical_dimensions': [195, 73],
    'source_size_and_logical_scale_are_distinct': True,
    'whole_canvas_nominal_native_point_sampling': {
        'is_only_a_measurement_not_a_saved_resized_image_or_GPU_claim': True,
        'expected_solid_samples': len(samples),
        'samples_with_alpha_under128': sum(pixel[3] < 128 for pixel in samples),
        'sampled_RGB_colors': len({pixel[:3] for pixel in samples}),
        'sampled_RGBA_colors': len(set(samples)),
        'sampled_alpha_top_counts': Counter(pixel[3] for pixel in samples).most_common(8),
    },
    'reference_measurements': references,
    'thresholds_are_diagnostics_not_new_project_acceptance_rules': True,
    'art_decision': 'STOP_SINGLE_CANDIDATE_NATIVE_STYLE_AND_WHOLE_SOLID_ALIGNMENT_GAP',
    'generated_variants_or_repairs': 0,
}
(HERE/'source-measurements.json').write_text(json.dumps(measurement, indent=2)+'\n')
print('Read-only source measurement complete; raw original unchanged.')
