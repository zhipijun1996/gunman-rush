import hashlib,json,re,subprocess
from pathlib import Path
ROOT=Path.cwd();OUT=ROOT/'build/region_bible_v2/avatar-ownership-independent-first';E=ROOT/'build/region_bible_v2/avatar-ownership-v15-repair-first';P=ROOT/'tests/avatar_presentation_ownership_runner.gd'
new=P.read_text();old=(E/'avatar.original.gd').read_text(); checks=[]
def ck(name,v,actual=None):
 checks.append({'name':name,'passed':bool(v),'actual':actual});assert v,name
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
ck('source_frozen_exact_sha',sha(P)=='7a865cda9d8b7bee216acceae8137beaa5bd421bb254ac06aaf29374f2c26ff8')
ck('old_source_exact_git_HEAD',subprocess.check_output(['git','show','HEAD:tests/avatar_presentation_ownership_runner.gd'])==(E/'avatar.original.gd').read_bytes())
old_call='check(app.start_debug_region(&"thorn_forest", 1, "avatar-ownership"), "Real Forest consumer starts")'
new_call='check(app.start_debug_region(&"thorn_forest", 1, "avatar-ownership", ThornForestRegionGenerator.DEPTH_VERSION, "forest-fruit-routes-v14"), "Real Forest consumer starts")'
old_guards=[s.strip() for s in old.splitlines() if s.lstrip().startswith('check(')]
new_guards=[s.strip() for s in new.splitlines() if s.lstrip().startswith('check(')]
for s in old_guards:ck('original_guard_preserved:'+s,s in new_guards if s!=old_call else new_call in new_guards)
ck('12_new_literal_guards',len(new_guards)-len(old_guards)==12,{'original_literal':len(old_guards),'current_literal':len(new_guards),'old_actual':25,'new_actual':37})
start=new.index('\t# Current default shares the formal Plains body.');end=new.index('\tcheck(await load("res://tests/audio_teardown.gd")',start)
restored=(new[:start]+new[end:]).replace('\t# Preserve the original appearance guards on their actual historical Stage.\n','').replace('\tcheck(app.stage is ThornForestRegionStage and app.stage.generated.manifest.layout_version == "forest-fruit-routes-v14", "Historical Forest appearance consumes an explicitly recorded real v14 Stage")\n','').replace(new_call,old_call)
ck('reverse_only_explicit_historical_args_and_additions_restores_old_bytes',restored==old)
ck('current_call_omits_both_version_pins','check(app.start_debug_region(&"thorn_forest", 1, "avatar-ownership-current"), ' in new)
ck('current_checks_actual_v15_and_empty_request','app.stage.generated.manifest.layout_version == "forest-bible-world-v15" and app._requested_forest_layout.is_empty()' in new)
ck('actual_body_type_Underworld','var forest_body := player.get_node_or_null("PixelPlainsActor") as UnderworldPlayer' in new)
ck('no_production_injection_or_generation_calls',not any(s in new for s in ['.generate(','set_script(','set_meta("avatar_presentation_owned"','add_child(forest_body','UnderworldPlayer.new()']))
for phase,expected,summary in [('native-original','failed','AVATAR OWNERSHIP: 25 assertions, 2 failures'),('native-fixed','passed','AVATAR OWNERSHIP: 37 assertions, 0 failures')]:
 r=json.loads((E/(phase+'-receipt.json')).read_bytes());before=json.loads((E/(phase+'-source-before.json')).read_bytes());after=json.loads((E/(phase+'-source-after.json')).read_bytes());log=(E/(phase+'.log')).read_text()
 ck(phase+':actual_status',r['check']['status']==expected)
 ck(phase+':actual_summary',summary in log)
 ck(phase+':log_hash',sha(E/(phase+'.log'))==r['log_sha256'])
 ck(phase+':full22984_inventory_equal',len(before)==22984 and before==after and r['source_stable'] and r['source_differences']==[])
 ck(phase+':git_before_after_equal',r['head_before']==r['head_after'] and r['git_status_before']==r['git_status_after'] and r['git_stable'])
 ck(phase+':original90_cap',r['timeout_seconds']==90)
 ck(phase+':actual_native_call',r['argv']==['bash','tools/godot.sh','--headless','--fixed-fps','60','--path','.','--script','tests/avatar_presentation_ownership_runner.gd'])
 ck(phase+':fixture_source_binding',before['tests/avatar_presentation_ownership_runner.gd']==sha(P if phase=='native-fixed' else E/'avatar.original.gd'))
 ck(phase+':audio_and_owner_release_completed','TEST AUDIO TEARDOWN:' in log and '"released":true' in log and 'Actual App owner releases before exit' not in log)
oldinv=json.loads((E/'native-original-source-before.json').read_bytes());newinv=json.loads((E/'native-fixed-source-before.json').read_bytes())
ck('only_source_delta_runner',sorted(p for p in oldinv.keys()|newinv.keys() if oldinv.get(p)!=newinv.get(p))==['tests/avatar_presentation_ownership_runner.gd'])
scope=json.loads((E/'original-26-scope.json').read_bytes());wrapper=ROOT/'tools/run_generated_consumer_tests.py'
ck('original26wrapper_unchanged',scope['sha256']==sha(wrapper) and wrapper.read_bytes()==subprocess.check_output(['git','show','HEAD:tools/run_generated_consumer_tests.py']))
ck('original26_90_2100_caps',len(scope['suites'])==26 and scope['native_parent_cap_seconds']==2100 and scope['import_cap_seconds']==90 and next(r[2] for r in scope['suites'] if r[0]=='tests/avatar_presentation_ownership_runner.gd')==90)
# Test-only real state perturbations. Never loaded until root engine lease GO.
insertion='\tcheck(is_instance_valid(forest_body) and forest_body.visible and not original.visible and visible_bodies(player) == 1, "Current Forest default is the sole shared Underworld body with hidden Courier anchor")'
mutants={
 'legacy_body_only':new.replace(insertion,'\tforest_body.hide()\n\toriginal.show()\n'+insertion),
 'double_visible_body':new.replace(insertion,'\toriginal.show()\n'+insertion),
 'explicit_current_pin':new.replace('app.start_debug_region(&"thorn_forest", 1, "avatar-ownership-current")','app.start_debug_region(&"thorn_forest", 1, "avatar-ownership-current", ThornForestRegionGenerator.DEPTH_VERSION, "forest-bible-world-v15")'),
}
for name,text in mutants.items():
 ck('mutant_has_one_bounded_injection:'+name,text!=new)
 (OUT/(name+'.gd')).write_text(text)
(OUT/'source-review.json').write_text(json.dumps({'verdict':'ACCEPT_SOURCE_ONLY_PENDING_INDEPENDENT_NATIVE_NEGATIVES','scope':'Only avatar test migration. No engine executed by reviewer yet.','source_sha256':sha(P),'checks':checks,'actual_producer_evidence':{'old':'25/2 actualFAILED retained','new':'37/0 actualPASS, full22984source stable'},'prepared_mutants':list(mutants),'reviewer':'/root/bible_test_workflow_independent_review'},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'source_checks':len(checks),'passed':True,'mutants_prepared_not_run':list(mutants)}))
