"""Reproduce this one original native80x64 source and review metadata.
No reference/golden pixels are read, resized or edited. The only rendered
source is the complete literal palette-index rows retained beside this file.
"""
from pathlib import Path
from PIL import Image
import json,hashlib
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[3]
NATIVE=ROOT/'assets/forest_bible_v2/native';NATIVE.mkdir(parents=True,exist_ok=True)
rows=(HERE/'root_shoulder.authored.rows').read_text().splitlines();palette=json.loads((HERE/'palette.json').read_text())['palette_RGBA']
assert len(rows)==64 and all(len(row)==80 for row in rows)
im=Image.new('RGBA',(80,64));im.putdata([tuple(palette[c])for row in rows for c in row]);im.save(NATIVE/'root_shoulder_v1.png')
assert hashlib.sha256((NATIVE/'root_shoulder_v1.png').read_bytes()).hexdigest()=='0d4a2e9db83cc50500d2c273a6a82a1803423f1cccbb0db34dfda7f9426f4f2a'
assert (HERE/'root_shoulder_v1.original.png').read_bytes()==(NATIVE/'root_shoulder_v1.png').read_bytes()
record=json.loads((HERE/'contract.authored.json').read_text());record['native_source_sha256']=hashlib.sha256((NATIVE/'root_shoulder_v1.png').read_bytes()).hexdigest();record['source_provenance']='assets/forest_bible_v2/source/native_root_shoulder_v1/provenance.json';(NATIVE/'root_shoulder_v1.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print(record['native_source_sha256'])
