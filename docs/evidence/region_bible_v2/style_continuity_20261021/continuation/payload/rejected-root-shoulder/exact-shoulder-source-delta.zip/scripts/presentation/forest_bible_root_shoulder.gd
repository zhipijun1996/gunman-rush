class_name ForestBibleRootShoulder
extends RefCounted
## ONE candidate internal wood-fibre sample, not a new terrain/outer contour.
## Runs only on the exact recorded V15 map2 hosts and their lower thorn seams.
## Original terrain, moss, thorn2, collision, RNG and gameplay stay authoritative.
## Deep numeric data uses the existing shared comparator; no epsilon/coercion.
## Texture filtering inherits the existing nearest setup; no filter writes here.
const SOURCE: Texture2D = preload("res://assets/forest_bible_v2/native/root_shoulder_v1.png")
const NATIVE_SIZE := Vector2i(80,64)
const WORLD := Rect2(700,350,160,128)
const WORLD_UNITS_PER_PIXEL: float = 2.0
const HOSTS: Array[Dictionary] = [
	{"id":"hollow__belly_roof","rect":[380,324,390,166]},
	{"id":"hollow__elbow_lower_lip","rect":[770,414,40,76]},
	{"id":"hollow__trunk_above_window","rect":[810,414,120,92]},
]
const SEAMS: Array[Dictionary] = [
	{"hazard_rect":[380,300,260,24],"segments":[{"support_id":"hollow__belly_roof","start":[380,324],"end":[640,324]}]},
	{"hazard_rect":[770,390,160,24],"segments":[{"support_id":"hollow__elbow_lower_lip","start":[770,414],"end":[810,414]},{"support_id":"hollow__trunk_above_window","start":[810,414],"end":[930,414]}]},
]

static func draw(canvas: Node2D, m: Dictionary) -> void:
	if m.get("layout_version") != "forest-bible-world-v15" or m.get("map_index") != 2: return
	if SOURCE.get_width() != NATIVE_SIZE.x or SOURCE.get_height() != NATIVE_SIZE.y: return
	var semantic := RandomStageGenerator.new()
	var solids: Array[Rect2] = []
	for expected: Dictionary in HOSTS:
		var host_matches: int = 0
		for row: Dictionary in m.get("platforms", []):
			if row.get("id") != expected.id: continue
			if row.get("structure_id") != "hollow" or row.get("one_way",true) != false: return
			if not semantic._same_data(row.get("rect"),expected.rect): return
			host_matches += 1
		if host_matches != 1: return
		solids.append(_rect(expected.rect))
	for expected: Dictionary in SEAMS:
		var seam_matches: int = 0
		for surface: Dictionary in m.get("thorn_surfaces", []):
			if surface.get("face") != "up" or not semantic._same_data(surface.get("hazard_rect"),expected.hazard_rect): continue
			if not semantic._same_data(surface.get("segments"),expected.segments): return
			seam_matches += 1
		if seam_matches != 1: return
	# The original source already lies8wu inside the real exposed boundary.
	# These three abutting crops additionally enforce the actual solid union;
	# source UVs remain1native pixel per2world units, with no tint or stretching.
	for solid: Rect2 in solids:
		var target: Rect2 = WORLD.intersection(solid)
		if not target.has_area(): continue
		var pixels := Rect2((target.position-WORLD.position)/WORLD_UNITS_PER_PIXEL,target.size/WORLD_UNITS_PER_PIXEL)
		canvas.draw_texture_rect_region(SOURCE,target,pixels)

static func _rect(a: Array) -> Rect2:
	return Rect2(float(a[0]),float(a[1]),float(a[2]),float(a[3]))
