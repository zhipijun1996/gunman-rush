extends SceneTree
func _initialize() -> void:
	var data: Dictionary=JSON.parse_string(FileAccess.get_file_as_string("res://build/forest_playable/progression/cross_region_manifest.json"))
	var tuning:=PlayerTuning.load_default()
	var equality:=RandomStageGenerator.new()
	print("FULL_REPLAY_VALID ",RunManifest.from_snapshot(data)!=null)
	for row: Dictionary in data.stages:
		var m: Dictionary=row.get("outputs",{}).get("generated_layout",{})
		if m.get("layout_version")!="forest-bible-world-v15":continue
		var surfaces: Array=ForestBibleThornSurfaces._surfaces(m)
		var fresh: Dictionary=ThornForestRegionV2V15.new()._candidate(str(m.seed),int(m.map_index))
		print("JSON_DIAG ",JSON.stringify({"map":m.map_index,"registry":ThornForestRegionGenerator.new().validate(m,tuning),"producer":ThornForestRegionV2V15.new().validate(m,tuning),"layout":ForestBibleV2Layout.validate(m),"thorn":ForestBibleThornSurfaces.validate(m),"language":ForestSceneLanguage.validate(m),"full_same":equality._same_data(m,fresh),"surfaces_variant_equal":surfaces==m.thorn_surfaces,"surfaces_same_data":equality._same_data(surfaces,m.thorn_surfaces),"index_types":[typeof(surfaces[0].danger_index),typeof(m.thorn_surfaces[0].danger_index)]}))
		for id: String in m.enemy_drops:
			var drop: Dictionary=m.enemy_drops[id]
			if drop.get("kind")=="none": print("NO_DROP ",JSON.stringify({"id":id,"row":drop,"raw_dict_equal":drop=={"kind":"none","amount":0},"same_data":equality._same_data(drop,{"kind":"none","amount":0}),"amount_type":typeof(drop.get("amount"))}))
	quit(0)
