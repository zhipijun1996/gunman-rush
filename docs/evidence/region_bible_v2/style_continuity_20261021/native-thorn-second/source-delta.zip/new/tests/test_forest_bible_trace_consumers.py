"""Finite admission/consumer controls. Source checks do not claim native execution."""
import copy
import hashlib
from pathlib import Path
import re
import subprocess
import sys
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tools'))
import run_forest_depth_enemies as enemies
import test_forest_bible_region_admission as fixture_module


class BibleTraceConsumerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        fixture_module.BibleAdmissionTests.setUpClass()
        cls.fixtures = fixture_module.BibleAdmissionTests()

    def fixture(self, index=0):
        return self.fixtures.fixture(index)

    def test_same_strict_reader_accepts_both_explicit_current_variants(self):
        for index in (0, 1):
            data = self.fixture(index)
            before = copy.deepcopy(data)
            enemies.strict_manifest_admission(data)
            self.assertEqual(data, before)

    def test_missing_reference_flags_and_changed_actual_body_reject(self):
        mutations = (
            lambda d: d.pop('bible_admission'),
            lambda d: d['bible_admission'].update(actual_validated=False),
            lambda d: d['bible_admission'].update(reference_validated=False),
            lambda d: d['bible_admission'].update(reference_manifest=copy.deepcopy(d['manifest'])),
            lambda d: d['manifest']['platforms'].pop(),
            lambda d: d['manifest'].update(candidate_overlay={'scope': 'historical_candidate'}),
        )
        for mutate in mutations:
            data = self.fixture()
            mutate(data)
            with self.subTest(mutate=mutate):
                with self.assertRaisesRegex(ValueError, 'Bible manifest admission rejected'):
                    enemies.strict_manifest_admission(data)

    def test_lift_and_crossbranch_cannot_bypass_strict_reader(self):
        for validate in (enemies.validate_lift_choice, enemies.validate_crossbranch):
            data = self.fixture()
            data.pop('bible_admission')
            with self.subTest(consumer=validate.__name__):
                with self.assertRaisesRegex(ValueError, 'Bible manifest admission rejected'):
                    validate(data)

    def test_historical_manifest_does_not_enter_new_reader(self):
        for layout in ('shared-tree-canopy-hunt-v10', 'forest-interwoven-canopy-v13', 'forest-fruit-routes-v14'):
            with patch('forest_bible_region_admission.validate_bible_admission', side_effect=AssertionError('old path changed')):
                enemies.strict_manifest_admission({'manifest': {'layout_version': layout}})

    def test_original_ecology_and_lift_strategies_stay_byte_identical(self):
        expected = {'forest_depth_ecology_trace.gd': 'ba4e4a24c43c9eaadbf1d48730200c205bf575267fe7ca0608064519183a4016',
                    'forest_depth_lift_trace.gd': 'd973cb63ddf29838dd168e9f39584ce290b3ef805805264309b05685337a5762'}
        for name, digest in expected.items():
            self.assertEqual(hashlib.sha256((ROOT / 'tests' / name).read_bytes()).hexdigest(), digest)

    def test_three_thin_traces_share_real_support_without_physics_override(self):
        allowed = {'canopy_layout', 'interwoven_layout', 'woven_layout', 'begin', 'observe_actual_projectile', '_process', 'admission_evidence'}
        for new, old in (('region_auto', 'depth_region'), ('ecology', 'depth_ecology'), ('lift', 'depth_lift')):
            source = (ROOT / 'tests' / f'forest_bible_{new}_trace.gd').read_text()
            self.assertTrue(source.startswith(f'extends "res://tests/forest_{old}_trace.gd"'))
            self.assertEqual(set(re.findall(r'^func (\w+)\(', source, re.M)), allowed)
            self.assertIn('BIBLE_SUPPORT.install(self)\n\tawait super.begin()\n\tBIBLE_SUPPORT.bind(self)', source)
            self.assertIn('BIBLE_SUPPORT.process_reader(self)\n\tsuper._process(delta)', source)
            self.assertIn('super.observe_actual_projectile(serial)', source)

    def test_conflicting_historical_cli_override_refuses_before_engine(self):
        for args in (['--scenario', 'expedition'], ['--scenario', 'root_entry', '--map', '2'],
                     ['--scenario', 'crossbranch', '--crossbranch-strategies', 'lifecycle']):
            result = subprocess.run([sys.executable, str(ROOT / 'tools/run_forest_depth_enemies.py'), *args,
                                     '--layout', 'forest-bible-world-v15'], capture_output=True, text=True, cwd=ROOT)
            self.assertEqual(result.returncode, 2)
            self.assertIn('Historical coordinate fixtures require their original explicit v10 layout', result.stderr)


if __name__ == '__main__':
    unittest.main()
