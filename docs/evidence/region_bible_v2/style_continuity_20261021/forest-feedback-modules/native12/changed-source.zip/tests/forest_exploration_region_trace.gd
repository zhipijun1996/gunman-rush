extends "res://tests/forest_depth_region_trace.gd"
## V16 consumes the actual new world through the original Router/Motor driver.
## Historical layouts, v15 Bible support and v14 references remain untouched.
const EXPLORATION_LAYOUT := "forest-branching-expedition-v16"
var _actual_validated := false
var _unexpected_modal_frames := 0
var _collision_before := Vector2.ZERO
var _reward_transactions: Array[Dictionary] = []
var _reward_before: Dictionary = {}
var _duplicate_neutral_before: Dictionary = {}
var _pointer_start := 0
var _modal_start := 0
var _reward_recorded := false
class ExplorationGroundPilot extends "res://tests/forest_depth_grove_combat_case.gd":
	func supports_layout(layout: String) -> bool:
		return layout == "forest-branching-expedition-v16"

class ExplorationAirPilot extends "res://tests/forest_depth_air_chain_case.gd":
	var descending_cast := false
	func drive(trace: Node, leg: Dictionary) -> void:
		if active_leg != int(trace.leg_index):
			descending_cast = false
			super.drive(trace,leg)
			if leg.has("action_start"):
				start = trace.point(leg.action_start)
				trace.controller.router.set_move_axis(clampf((start.x-trace.player.global_position.x)/12.0,-1.0,1.0))
			return
		var departure: Dictionary = leg.get("departure",{})
		var outside_drop: bool = departure.get("ground_required",true) == false and not leg.has("approach_steps")
		if not outside_drop:
			super.drive(trace,leg); return
		if trace.age > 400:
			trace.fail("v16_outside_drop_bounded_phase/"+str(trace.phase)); return
		if trace.phase == "align":
			trace.controller.router.set_move_axis(clampf((start.x-trace.player.global_position.x)/12.0,-1.0,1.0))
			trace.stable = trace.stable+1 if trace.at_destination(start,entry_support) and absf(trace.player.velocity.x)<1.0 else 0
			if trace.stable >= 13:
				trace.jump(false)
				trace.event("v16_grounded_outside_departure",{"geometry_instance":instance_data.id,"entry_support":entry_support,"method":"ordinary_walk_off_outside_edge"})
				trace.set_phase("v16_outside_drop")
			return
		if trace.phase == "v16_outside_drop":
			var outside: Vector2 = trace.point(departure.path[-1])
			trace.controller.router.set_move_axis(clampf((outside.x-trace.player.global_position.x)/12.0,-1.0,1.0))
			trace.jump(false)
			var mapped: String = str(instance_data.anchor_id_map.get(str(program[0].get("anchor","")),""))
			var target: Node2D = trace.stage.assembler.hook_targets.get(mapped)
			if not is_instance_valid(target): trace.fail("v16_outside_drop_target_missing"); return
			var half: Vector2 = (trace.player.get_node("CollisionShape2D") as CollisionShape2D).shape.get_rect().size*.5
			var below := target.global_position.y+half.y+2.0
			var rect: Array = trace.platform(entry_support).rect
			var outside_body: bool = trace.player.global_position.x-half.x > float(rect[0])+float(rect[2])
			if not trace.player.is_on_floor() and outside_body and trace.player.global_position.y >= below:
				descending_cast = true
				trace.event("v16_actual_descending_side_cast",{"geometry_instance":instance_data.id,"target":mapped,"target_position":trace.pair(target.global_position),"velocity":trace.pair(trace.player.velocity),"grounded":trace.player.is_on_floor(),"outside_body":outside_body,"threshold_y":below})
				_submit(trace)
			return
		if trace.phase == "air_chain_receive" and not descending_cast:
			trace.fail("v16_outside_drop_missing_actual_cast"); return
		super.drive(trace,leg)

func canopy_layout() -> bool:
	# Reuse ordinary sequence endpoint labels and the actual ground-combat
	# pilot. The old interwoven/woven special encounters remain ineligible.
	return manifest.get("layout_version") == EXPLORATION_LAYOUT

func begin() -> void:
	grove_combat_case = ExplorationGroundPilot.new()
	air_chain_case = ExplorationAirPilot.new()
	await super.begin()
	if not initialized or not failures.is_empty(): return
	if manifest.get("layout_version") != EXPLORATION_LAYOUT:
		fail("exploration_requires_actual_v16"); return
	_actual_validated = ThornForestRegionGenerator.new().validate(manifest, player.tuning)
	if not _actual_validated:
		fail("exploration_actual_manifest_validator_rejected"); return
	var expanded: Array[Dictionary] = []
	for leg: Dictionary in itinerary:
		if leg.kind == "airborne_chain":
			for index: int in leg.get("approach_steps",[]).size():
				var approach: Dictionary = leg.approach_steps[index].duplicate(true)
				approach.edge_id = leg.edge_id; approach.step_index = index; approach.approach = true
				expanded.append(approach)
		expanded.append(leg)
	itinerary = expanded
	_collision_before = (player.get_node("CollisionShape2D") as CollisionShape2D).shape.get_rect().size
	if _collision_before != Vector2(24,36): fail("exploration_actual_player_collision_changed")

func fail(reason: String) -> void:
	# Preserve the original failure condition, while exposing actual App
	# generation/assembly status instead of guessing from an empty Manifest.
	var diagnostic := {"kind":"v16_failure_diagnostic","tick":tick,"reason":reason,"requested_layout_pin":recorded_layout_version,"actual_manifest_layout":str(manifest.get("layout_version",""))}
	if is_instance_valid(app):
		diagnostic.app_status = str(app.get("_status"))
		var actual_stage := app.get("stage") as Node
		diagnostic.actual_stage_exists = is_instance_valid(actual_stage)
		if is_instance_valid(actual_stage):
			diagnostic.actual_stage_class = actual_stage.get_class()
			var actual_script := actual_stage.get_script() as Script
			diagnostic.actual_stage_script = actual_script.resource_path if actual_script != null else ""
			if actual_stage is GeneratedDemoStage:
				diagnostic.assembly_ok = (actual_stage as GeneratedDemoStage).assembly_ok
				var generated: Dictionary = (actual_stage as GeneratedDemoStage).generated
				diagnostic.generated_ok = generated.get("ok",false)
				diagnostic.generated_error = str(generated.get("error",""))
	events.append(diagnostic)
	super.fail(reason)

func _physics_process(delta: float) -> void:
	if initialized and not finished and not get_tree().paused and leg_index < itinerary.size() and str(itinerary[leg_index].get("kind","")) in ["short_hook_crossing","live_hook_crossing","live_pod_defeat"]:
		if not is_instance_valid(player) or not is_instance_valid(controller) or not app.lifetime.active:
			fail("actual_run_ended"); return
		tick += 1; age += 1; before_steps = player.motion_steps
		if tick > 18000: fail("route_tick_budget"); return
		if tick-leg_started > 1800: fail("edge_tick_budget/"+str(leg_index)+"/"+phase); return
		var leg: Dictionary = itinerary[leg_index]
		if bool(leg.get("claim_before_edge",false)) and not duplicate_checked:
			claim_local_id = str(leg.claim_id); drive_cache(); return
		if str(leg.kind) == "live_pod_defeat": _drive_pod_defeat(leg)
		elif str(leg.kind) == "live_hook_crossing" or str(leg.get("release_mode","")) == "hang_jump": _drive_exchange(leg)
		else: _drive_short_hook(leg)
		return
	super._physics_process(delta)

func _drive_short_hook(leg: Dictionary) -> void:
	var takeoff := point(leg.path[0])
	var goal := point(leg.landing)
	var anchor_id := str(leg.anchor_id)
	var target: Node2D = stage.assembler.hook_targets.get(anchor_id)
	if not is_instance_valid(target): fail("v16_short_hook_actual_target_missing"); return
	if phase == "align":
		controller.router.set_move_axis(clampf((takeoff.x-player.global_position.x)/12.0,-1.0,1.0))
		stable = stable+1 if at_destination(takeoff,str(leg.from_support_id)) and absf(player.velocity.x)<1.0 and player.recoil_burst_remaining<=0 else 0
		if stable >= 12:
			event("v16_short_hook_departure",{"edge_id":leg.edge_id,"from_support_id":leg.from_support_id,"target":anchor_id,"supports":supports()})
			jump(true); set_phase("v16_short_hook_launch")
		return
	if phase == "v16_short_hook_launch":
		controller.router.set_move_axis(0)
		if not player.is_on_floor() and age >= 1:
			var origin := player.global_position+Vector2(0,-6)
			var offset := target.global_position-origin
			if offset.length() > controller.traversal.definition.hook_range:
				fail("v16_short_hook_outside_actual_range"); return
			event("v16_short_hook_intent",{"edge_id":leg.edge_id,"target":anchor_id,"target_position":pair(target.global_position),"origin":pair(origin),"actual_range":controller.traversal.definition.hook_range})
			if hook(anchor_id): set_phase("v16_short_hook_contact")
		return
	if phase == "v16_short_hook_contact":
		controller.router.set_move_axis(clampf((goal.x-player.global_position.x)/12.0,-1.0,1.0))
		if controller.traversal.state in [&"hook_miss",&"hook_retract"]:
			fail("v16_short_hook_actual_target_missed"); return
		if controller.traversal.state == &"hook_kick": jump(false)
		if controller.traversal.state == &"free":
			var contacted := false
			for accepted: Dictionary in events:
				if int(accepted.get("leg",-1)) == leg_index and accepted.get("kind") == "hook_contact_kick" and accepted.get("target") == anchor_id: contacted = true
			if not contacted: fail("v16_short_hook_no_actual_contact"); return
			set_phase("v16_short_hook_receive")
		return
	controller.router.set_move_axis(clampf((goal.x-player.global_position.x)/12.0,-1.0,1.0))
	stable = stable+1 if at_destination(goal,str(leg.landing_support_id)) else 0
	if stable >= 12: complete_leg()


func _live_actor(leg: Dictionary) -> EnemyActor:
	var found: EnemyActor = null
	for index: int in stage.enemy_manifest.size():
		var row: Dictionary = stage.enemy_manifest[index]
		if str(row.id) != str(leg.encounter_id): continue
		if found != null or str(row.get("geometry_instance","")) != str(leg.geometry_instance) or str(row.get("authored_slot_id","")) != str(leg.authored_slot_id) or str(row.get("behavior_id","")) != "forest_swing_pod":
			fail("v16_live_pod_identity_mismatch"); return null
		found = stage.enemies[index].get_node("Actor") as EnemyActor
	if found == null: fail("v16_live_pod_actual_actor_missing")
	return found

func _pod_sample(actor: EnemyActor) -> Dictionary:
	return {"motor_instance":actor.motor.get_instance_id(),"position":pair(actor.motor.global_position),"velocity":pair(actor.motor.velocity),"health":actor.health.current,"terminal":actor.health.terminal,"damageable_active":actor.damageable.active,"collision_layer":actor.motor.collision_layer,"body_size":pair(actor.definition.collision_size),"behavior_id":String(actor.definition.behavior_id),"depth_state":actor.attack_behavior.call("depth_snapshot")}

func _hook_event(state: StringName) -> void:
	super._hook_event(state)
	if events.is_empty(): return
	var actual_target: Node2D = controller.traversal.hook_target
	events[-1].target_instance = actual_target.get_instance_id() if is_instance_valid(actual_target) else 0
	events[-1].kick_side = controller.traversal.kick_side
	events[-1].velocity = pair(player.velocity)
	for index: int in stage.enemy_manifest.size():
		var actor: EnemyActor = stage.enemies[index].get_node("Actor") as EnemyActor
		if actual_target == actor.motor:
			events[-1].target_actor_id = str(stage.enemy_manifest[index].id)
			events[-1].actual_pod = _pod_sample(actor) if actor.definition.behavior_id == &"forest_swing_pod" else {}

func _drive_exchange(leg: Dictionary) -> void:
	var live := str(leg.kind) == "live_hook_crossing"
	var actor: EnemyActor = _live_actor(leg) if live else null
	if finished: return
	var target: Node2D = actor.motor if live else stage.assembler.hook_targets.get(str(leg.anchor_id))
	if not is_instance_valid(target): fail("v16_exchange_actual_target_missing"); return
	if live and actor.health.terminal: fail("v16_live_pod_defeated_before_exchange"); return
	if not live and (not target is GrappleAnchor or not (target as GrappleAnchor).hang_enabled):
		fail("v16_fixed_exchange_requires_actual_hanging_fruit"); return
	var source := point(leg.path[0])
	var goal := point(leg.landing)
	if phase == "align":
		jump(false)
		controller.router.set_move_axis(clampf((source.x-player.global_position.x)/12.0,-1.0,1.0))
		stable = stable+1 if at_destination(source,str(leg.from_support_id)) and absf(player.velocity.x)<1.0 and player.recoil_burst_remaining<=0 else 0
		if stable < 12: return
		if live:
			var row: Dictionary = {}
			for candidate: Dictionary in stage.enemy_manifest:
				if str(candidate.id) == str(leg.encounter_id): row = candidate
			var home := point(row.position)
			var definition := actor.definition as ForestEnemyDefinition
			var favorable := target.global_position.x >= home.x+definition.patrol_half_width*.9 and target.global_position.y <= home.y-definition.swing_rise*.8 and actor.motor.velocity.x >= 0.0
			if not favorable:
				if age % 12 == 0: event("v16_live_phase_declined",{"encounter_id":str(leg.encounter_id),"actual_pod":_pod_sample(actor),"supports":supports()})
				return
		event("v16_exchange_departure",{"edge_id":leg.edge_id,"live":live,"target_instance":target.get_instance_id(),"supports":supports(),"actual_pod":_pod_sample(actor) if live else {}})
		jump(true); set_phase("v16_exchange_launch"); return
	if phase == "v16_exchange_launch":
		controller.router.set_move_axis(0)
		if player.is_on_floor() or age < 1: return
		var origin := player.global_position+Vector2(0,-6)
		var direction := target.global_position-origin
		if direction.length() > controller.traversal.definition.hook_range: fail("v16_exchange_outside_actual_range"); return
		event("v16_exchange_intent",{"edge_id":leg.edge_id,"live":live,"target_instance":target.get_instance_id(),"target_position":pair(target.global_position),"origin":pair(origin),"actual_range":controller.traversal.definition.hook_range,"encounter_id":str(leg.get("encounter_id","")),"actual_pod":_pod_sample(actor) if live else {}})
		request(&"grapple",direction.normalized()); jump(false); set_phase("v16_exchange_contact"); return
	if controller.traversal.state in [&"hook_miss",&"hook_retract"]: fail("v16_exchange_actual_hook_missed"); return
	if phase == "v16_exchange_contact":
		controller.router.set_move_axis(clampf((goal.x-player.global_position.x)/12.0,-1.0,1.0))
		if not live and controller.traversal.state == &"hook_hang":
			jump(false); event("v16_fixed_hang_observed",{"target":str(leg.anchor_id),"target_instance":target.get_instance_id(),"hook_tip":pair(controller.traversal.hook_tip)})
			set_phase("v16_exchange_hang_release"); return
		if live and controller.traversal.state == &"hook_kick": jump(false)
		if controller.traversal.state != &"free": return
		if not live: fail("v16_fixed_exchange_never_hung"); return
		var contact := false
		for accepted: Dictionary in events:
			if int(accepted.get("leg",-1)) == leg_index and accepted.get("kind") == "hook_contact_kick" and accepted.get("target_actor_id","") == str(leg.encounter_id): contact = true
		if not contact: fail("v16_live_exchange_no_actual_pod_contact"); return
		set_phase("v16_exchange_receive"); return
	if phase == "v16_exchange_hang_release":
		if controller.traversal.state != &"hook_hang": fail("v16_fixed_hang_lost_before_jump"); return
		event("v16_fixed_hang_jump_intent",{"target":str(leg.anchor_id),"target_instance":target.get_instance_id()})
		jump(true); set_phase("v16_exchange_receive"); return
	controller.router.set_move_axis(clampf((goal.x-player.global_position.x)/12.0,-1.0,1.0))
	if not live: release_jump_after_clearance(str(leg.landing_support_id))
	stable = stable+1 if at_destination(goal,str(leg.landing_support_id)) else 0
	if stable >= 12: complete_leg()

func _drive_pod_defeat(leg: Dictionary) -> void:
	var actor := _live_actor(leg)
	if finished or actor == null: return
	var bank := point(leg.path[0])
	controller.router.set_move_axis(clampf((bank.x-player.global_position.x)/12.0,-1.0,1.0)); jump(false)
	if tick-leg_started > 600: fail("v16_live_pod_defeat_600_frame_bound"); return
	if actor.health.terminal:
		var actual_drop: Dictionary = stage.region_state.drops.get(str(leg.encounter_id),{})
		if actual_drop.is_empty(): return
		stable = stable+1 if at_destination(bank,str(leg.landing_support_id)) and player.recoil_burst_remaining<=0 else 0
		if stable >= 12:
			event("v16_live_pod_actual_defeat_settlement",{"encounter_id":str(leg.encounter_id),"actual_pod":_pod_sample(actor),"settled_drop":actual_drop.duplicate(true),"manifest_drop":manifest.enemy_drops.get(str(leg.encounter_id),{}).duplicate(true),"hook_unavailable":not actor.damageable.active and actor.motor.collision_layer == 0})
			complete_leg()
		return
	stable = stable+1 if at_destination(bank,str(leg.from_support_id)) and player.recoil_burst_remaining<=0 else 0
	if stable < 12 or controller.shoot_ability.cooldown_remaining>0 or controller.shoot_ability.rounds_remaining>0 or controller.actor_resources.stamina.current<controller.shot_energy.shot_energy_cost: return
	var offset := actor.motor.global_position-player.global_position
	var ray := PhysicsRayQueryParameters2D.create(player.global_position,actor.motor.global_position,5,[player.get_rid()])
	var hit: Dictionary = player.get_world_2d().direct_space_state.intersect_ray(ray)
	if not hit.is_empty() and hit.get("collider") != actor.motor: return
	var unit := offset.normalized()
	for unused: int in 12: unit = unit.normalized()
	event("v16_live_pod_shot_intent",{"encounter_id":str(leg.encounter_id),"actual_pod":_pod_sample(actor),"supports":supports(),"aim":pair(unit)})
	request(&"shoot_release",unit); stable = 0

func drive_cache() -> void:
	if not cache_pending:
		_reward_before = _neutral_reader_snapshot()
		_pointer_start = pointer_events.size(); _modal_start = modal_frames.size()
	if cache_claimed and duplicate_tick < 0 and not app.reward_modal.opened:
		_duplicate_neutral_before = _neutral_reader_snapshot()
	super.drive_cache()
	if duplicate_checked and not _reward_recorded:
		var after := _neutral_reader_snapshot()
		for key: String in ["claimed","items","coins","notes"]:
			if _duplicate_neutral_before.get(key) != after.get(key):
				fail("v16_duplicate_reward_changed_resources"); return
		_reward_transactions.append({"claim_id":claim_local_id,"edge_id":str(itinerary[leg_index].edge_id),"leg":leg_index,"tick":tick,"before":_reward_before.duplicate(true),"after":after,"duplicate_before":_duplicate_neutral_before.duplicate(true),"duplicate_after":after,"pointer_events":pointer_events.slice(_pointer_start).duplicate(true),"modal_frames":modal_frames.slice(_modal_start).duplicate(true)})
		_reward_recorded = true

func complete_leg() -> void:
	var has_claim: bool = leg_index < itinerary.size() and bool(itinerary[leg_index].get("claim_before_edge",false))
	if has_claim and (not cache_claimed or not duplicate_checked or not _reward_recorded):
		fail("v16_claim_edge_completed_without_real_reward"); return
	super.complete_leg()
	if has_claim:
		cache_pending = false; cache_claimed = false; duplicate_checked = false; _reward_recorded = false
		duplicate_tick = -1; modal_age = 0; modal_button = null
		claim_before = {}; claim_after = {}; duplicate_before = {}; duplicate_after = {}

func observe() -> void:
	var before := frames.size()
	super.observe()
	if frames.size() == before: return
	var size := (player.get_node("CollisionShape2D") as CollisionShape2D).shape.get_rect().size
	frames[-1].body = [player.global_position.x-size.x*.5, player.global_position.y-size.y*.5, size.x, size.y]
	frames[-1].hook_start = pair(controller.traversal.hook_start)
	frames[-1].hook_tip = pair(controller.traversal.hook_tip)
	frames[-1].shot_energy_delay = controller.shot_energy._delay
	frames[-1].burst_remaining = player.recoil_burst_remaining
	frames[-1].burst_velocity = pair(player.recoil_velocity)
	for index: int in frames[-1].enemies.size():
		var row: Dictionary = stage.enemy_manifest[index]
		if str(row.get("behavior_id","")) != "forest_swing_pod": continue
		var actor: EnemyActor = stage.enemies[index].get_node("Actor") as EnemyActor
		frames[-1].enemies[index].merge(_pod_sample(actor))
		frames[-1].enemies[index].geometry_instance = str(row.get("geometry_instance",""))
		frames[-1].enemies[index].authored_slot_id = str(row.get("authored_slot_id",""))
	frames[-1].pending_air_grants = controller.received_resource_grants.map(func(grant: Dictionary) -> Dictionary: return {"amount":int(grant.amount),"session_id":int(grant.session_id)})

func snapshot() -> Dictionary:
	var data := super.snapshot()
	if data.is_empty(): return data
	data.grounded = player.is_on_floor()
	data.hook_used = controller.traversal.hook_used
	data.shot_energy_delay = controller.shot_energy._delay
	data.shot_economy = {"owner_id":player.get_instance_id(),"session_id":controller.session_id,"weapon_epoch":controller.shoot_ability.weapon_epoch,"hits":controller.shot_energy._hits.duplicate(true),"combat_packets":controller.combat_energy._packets.duplicate(true)}
	data.pending_air_grants = controller.received_resource_grants.map(func(grant: Dictionary) -> Dictionary: return {"amount":int(grant.amount),"session_id":int(grant.session_id)})
	data.notes = app.meta.snapshot().get("notes",0)
	data.coins = app.wallet.balance
	data.collision_size = pair((player.get_node("CollisionShape2D") as CollisionShape2D).shape.get_rect().size)
	return data

func _neutral_reader_snapshot() -> Dictionary:
	return {"claimed":stage.region_state.claimed.duplicate(true),"items":app.build.item_ids(),"coins":app.wallet.balance,"notes":app.meta.snapshot().get("notes",0),"position":pair(player.global_position),"motion_steps":player.motion_steps}

func _process(delta: float) -> void:
	if initialized and not finished and is_instance_valid(stage):
		var reader := stage.get("discoveries") as ForestBibleDiscoveries
		if cache_claimed and duplicate_tick >= 0 and is_instance_valid(reader) and reader.is_open():
			# Duplicate interaction may offer the co-located story Reader. Use
			# actual Escape input; never call a claim/close implementation hook.
			var before := _neutral_reader_snapshot()
			var was_paused := get_tree().paused
			for pressed: bool in [true,false]:
				var key := InputEventKey.new()
				key.physical_keycode = KEY_ESCAPE; key.keycode = KEY_ESCAPE; key.pressed = pressed
				get_viewport().push_input(key,true)
			var after := _neutral_reader_snapshot()
			event("v16_duplicate_cache_reader_dismissed",{"paused_before":was_paused,"reader_closed":not reader.is_open(),"paused_after":get_tree().paused,"keys":["Escape_press","Escape_release"],"before":before,"after":after})
			if not was_paused or reader.is_open() or get_tree().paused or before != after:
				fail("v16_duplicate_reader_not_neutral")
		if get_tree().paused and not app.reward_modal.opened:
			_unexpected_modal_frames += 1
			if _unexpected_modal_frames > 90: fail("v16_unexpected_modal_frame_budget")
		else: _unexpected_modal_frames = 0
	super._process(delta)

func admission_evidence() -> Dictionary:
	return {"schema":"forest-exploration-runtime-v16","actual_layout":str(manifest.get("layout_version","")),"actual_validated":_actual_validated,"requested_layout_pin":recorded_layout_version,"actual_requested_layout_cleared":is_instance_valid(app) and app._requested_forest_layout.is_empty(),"body_collision_before":pair(_collision_before),"body_collision_after":pair((player.get_node("CollisionShape2D") as CollisionShape2D).shape.get_rect().size) if is_instance_valid(player) else [],"world_source_sha256":FileAccess.get_sha256("res://scripts/generation/forest_exploration_world.gd"),"module_source_sha256":FileAccess.get_sha256("res://scripts/generation/forest_exploration_modules.gd"),"strategy":"original_18000_route_1800_edge_Router_Motor_ground_combat_no_injection","legacy_reference_used":false,"reward_transactions":_reward_transactions.duplicate(true)}
