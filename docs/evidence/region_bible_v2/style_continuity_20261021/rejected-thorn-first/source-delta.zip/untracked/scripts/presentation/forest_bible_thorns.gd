class_name ForestBibleThorns
extends RefCounted
## A visual covering rooted in explicitly bound real support seams.
## No collision, RNG, nearest-host search, hazard remapping or gameplay writes.
const PIXEL: float = 2.0
const INK: Color = Color("241f19")
const WOOD: Color = Color("493721")
const WOOD_FACE: Color = Color("745631")
const MOSS: Color = Color("536b45")
const MOSS_LIGHT: Color = Color("71824f")
const THORN_SHADOW: Color = Color("859076")
const THORN_TIP: Color = Color("d5dabe")
const BRAID_A: Array[int] = [-10,-8,-6,-4,-2,0,2,2,0,-2,-4,-6,-8,-10,-12,-12]
const BRAID_B: Array[int] = [-10,-12,-14,-16,-18,-20,-20,-18,-16,-14,-12,-10,-8,-6,-6,-8]
const PITCH: Array[int] = [14,18,16,20]

static func draw(canvas: Node2D, m: Dictionary) -> void:
	if m.get("layout_version") != "forest-bible-world-v15": return
	var hosts: Dictionary = {}
	for row: Dictionary in m.get("platforms", []):
		if row.has("rect"): hosts[str(row.get("id", ""))] = _rect(row.rect)
	for surface: Dictionary in m.get("thorn_surfaces", []):
		var face: String = str(surface.get("face", ""))
		if face not in ["up", "down", "left"]: continue
		var hazard: Rect2 = _rect(surface.hazard_rect)
		if not hazard.has_area(): continue
		for segment: Dictionary in surface.get("segments", []):
			var id: String = str(segment.get("support_id", ""))
			if not hosts.has(id): continue
			_draw_segment(canvas, _point(segment.start), _point(segment.end), hosts[id], hazard, face)

static func _draw_segment(canvas: Node2D, start: Vector2, end: Vector2, host: Rect2, hazard: Rect2, face: String) -> void:
	var tangent: Vector2 = Vector2.DOWN if face == "left" else Vector2.RIGHT
	var normal: Vector2 = Vector2.LEFT if face == "left" else Vector2.DOWN if face == "down" else Vector2.UP
	var length: float = (end-start).dot(tangent)
	if length < PIXEL or not host.has_area(): return
	var reach: float = start.x-hazard.position.x if face == "left" else hazard.end.y-start.y if face == "down" else start.y-hazard.position.y
	var inside: float = host.end.x-start.x if face == "left" else start.y-host.position.y if face == "down" else host.end.y-start.y
	if reach <= 0.0 or inside <= PIXEL: return
	# The source seam, not the full hazard thickness, determines external tips.
	var inner_limit: float = -minf(22.0, maxf(PIXEL, inside-4.0))
	var phase: int = floori((start.y if face == "left" else start.x)/PIXEL)
	var strand_a: PackedVector2Array = _strand(start, tangent, normal, length, phase, BRAID_A, inner_limit, reach)
	var strand_b: PackedVector2Array = _strand(start, tangent, normal, length, phase, BRAID_B, inner_limit, reach)
	_paint_strand(canvas, strand_b, WOOD)
	_paint_strand(canvas, strand_a, WOOD_FACE)
	# Short internal rootlets and isolated moss knots belong to the real host.
	for at: int in range(8, floori(length)-4, 32):
		var local := Vector2(float(at), maxf(inner_limit, -18.0))
		var first: Vector2 = start+tangent*local.x+normal*local.y
		var last: Vector2 = start+tangent*(local.x+6.0)+normal*maxf(inner_limit,-24.0)
		_rootlet(canvas, first, last, host)
		_moss(canvas, start+tangent*(local.x+2.0)+normal*maxf(inner_limit+2.0,-12.0), host)
	# Bent bark spines have only a few pale terminal pixels. Every spine pixel
	# is clipped to the original danger rectangle, never into safe outer space.
	var at: float = minf(4.0, length*0.5)
	var ordinal: int = _index(phase, PITCH.size())
	var last_at: float = -100.0
	while at <= length-2.0:
		_draw_spine(canvas, start, tangent, normal, at, reach, ordinal, host, hazard)
		last_at = at
		at += float(PITCH[_index(ordinal, PITCH.size())])
		ordinal += 1
	if length-2.0-last_at > 10.0:
		_draw_spine(canvas, start, tangent, normal, maxf(1.0,length-3.0), reach, ordinal, host, hazard)

static func _strand(start: Vector2, tangent: Vector2, normal: Vector2, length: float, phase: int, pattern: Array[int], inner_limit: float, reach: float) -> PackedVector2Array:
	var result := PackedVector2Array()
	var previous := Vector2.ZERO
	for step: int in range(ceili(maxf(0.0,length-6.0)/PIXEL)+1):
		var u: float = minf(length-3.0, 3.0+step*PIXEL)
		var v: float = clampf(float(pattern[_index(phase+step,pattern.size())]),inner_limit,minf(2.0,reach-3.0))
		var point: Vector2 = (start+tangent*u+normal*v).snapped(Vector2.ONE*PIXEL)
		if not result.is_empty():
			# Cardinal staircase edges keep the declared2wu native clusters.
			var corner := Vector2(point.x,previous.y) if tangent == Vector2.RIGHT else Vector2(previous.x,point.y)
			if corner != previous: result.append(corner)
		if result.is_empty() or result[-1] != point: result.append(point)
		previous = point
	return result

static func _paint_strand(canvas: Node2D, points: PackedVector2Array, face: Color) -> void:
	if points.size() < 2: return
	canvas.draw_polyline(points, INK, 6.0, false)
	canvas.draw_polyline(points, WOOD, 4.0, false)
	canvas.draw_polyline(points, face, 2.0, false)

static func _rootlet(canvas: Node2D, first: Vector2, last: Vector2, host: Rect2) -> void:
	var steps: int = maxi(1,ceili(first.distance_to(last)/PIXEL))
	for step: int in steps+1:
		var center: Vector2 = first.lerp(last,float(step)/steps).snapped(Vector2.ONE*PIXEL)
		_pixel(canvas,center,WOOD,host)

static func _moss(canvas: Node2D, center: Vector2, host: Rect2) -> void:
	_pixel(canvas,center,MOSS,host)
	_pixel(canvas,center+Vector2(2,0),MOSS,host)
	_pixel(canvas,center+Vector2(0,-2),MOSS_LIGHT,host)

static func _draw_spine(canvas: Node2D, seam: Vector2, tangent: Vector2, normal: Vector2, at: float, reach: float, ordinal: int, host: Rect2, hazard: Rect2) -> void:
	var lean: float = -4.0 if _index(ordinal,3) == 0 else 4.0 if _index(ordinal,3) == 1 else 2.0
	var tip_depth: float = maxf(PIXEL,reach-(2.0 if _index(ordinal,3) == 1 and reach > 8.0 else 0.0))
	# A blunt woody neck reaches into the actual host, joining the braid. It
	# creates no needle-like mark on the safe exterior of the platform.
	for depth: int in range(-8,1,2):
		var center: Vector2 = seam+tangent*at+normal*float(depth)
		_pixel(canvas,center,WOOD_FACE,host)
	for row: int in range(ceili(tip_depth/PIXEL)):
		var depth: float = minf(tip_depth-1.0,float(row)*PIXEL+1.0)
		var amount: float = depth/tip_depth
		var u: float = at+lean*amount*amount
		var half: int = 2 if amount < 0.35 else 1 if amount < 0.72 else 0
		var color: Color = WOOD_FACE if amount < 0.55 else THORN_SHADOW if amount < 0.78 else THORN_TIP
		for cross: int in range(-half,half+1):
			var center: Vector2 = seam+tangent*(u+float(cross)*PIXEL)+normal*depth
			_pixel(canvas,center,color,hazard)
	# The last two native pixels establish the actual dangerous outer extent.
	var tip: Vector2 = seam+tangent*(at+lean)+normal*(tip_depth-1.0)
	_pixel(canvas,tip,THORN_TIP,hazard)

static func _pixel(canvas: Node2D, center: Vector2, color: Color, clip: Rect2) -> void:
	var pixel := Rect2(center.snapped(Vector2.ONE*PIXEL)-Vector2.ONE,Vector2.ONE*PIXEL)
	var visible: Rect2 = pixel.intersection(clip)
	if visible.has_area(): canvas.draw_rect(visible,color)

static func _index(value: int, size: int) -> int:
	return ((value%size)+size)%size

static func _point(raw: Array) -> Vector2:
	return Vector2(float(raw[0]),float(raw[1]))

static func _rect(raw: Array) -> Rect2:
	return Rect2(float(raw[0]),float(raw[1]),float(raw[2]),float(raw[3]))
