class_name ForestBibleThorns
extends RefCounted
## Second candidate: rooted, open branching growth, never a closed braid.
## All coordinates come from bound seams; no collision, RNG or gameplay writes.
const PIXEL: float = 2.0
const INK: Color = Color("241f19")
const WOOD: Color = Color("493721")
const WOOD_FACE: Color = Color("745631")
const MOSS: Color = Color("536b45")
const THORN_SHADOW: Color = Color("859076")
const THORN_TIP: Color = Color("d5dabe")
# Unequal authored lengths, sampled in WORLD coordinates across support joins.
# Only one stem: the long phrase never closes into a second parallel lattice.
const STEM_X: Array[int] = [0,42,110,146,230,284,382,428,500,566]
const STEM_Y: Array[int] = [-14,-18,-12,-20,-16,-8,-14,-20,-12,-14]
const SPINE_X: Array[int] = [8,30,62,80,114,142,160,196,224,240,274,306,324,360,384,406,438,456,492,520,538,572,598]
const SPINE_DEPTH: Array[float] = [0.48,0.84,0.64,1.0,0.4,0.72,0.56,0.92,0.6,0.42,0.8,0.52,1.0,0.64,0.44,0.86,0.58,0.74,0.46,0.96,0.62,0.4,0.78]
const SPINE_LEAN: Array[int] = [-4,6,2,-6,4,8,-2,-4,6,-2,4,-8,2,6,-4,4,-6,2,8,-4,4,-2,-6]
const SPINE_PERIOD: int = 626

static func draw(canvas: Node2D, m: Dictionary) -> void:
	if m.get("layout_version") != "forest-bible-world-v15": return
	var hosts: Dictionary = {}
	var hollow_solids: Array[Rect2] = []
	var hollow_ids: Dictionary = {}
	for row: Dictionary in m.get("platforms", []):
		if not row.has("rect") or bool(row.get("one_way",false)): continue
		hosts[str(row.get("id", ""))] = _rect(row.rect)
		if row.get("structure_id") == "hollow":
			hollow_solids.append(_rect(row.rect))
			hollow_ids[str(row.id)] = true
	var rooted_segments: Array[Dictionary] = []
	for surface: Dictionary in m.get("thorn_surfaces", []):
		var face: String = str(surface.get("face", ""))
		if face not in ["up", "down", "left"]: continue
		var hazard: Rect2 = _rect(surface.hazard_rect)
		if not hazard.has_area(): continue
		for segment: Dictionary in surface.get("segments", []):
			var id: String = str(segment.get("support_id", ""))
			if not hosts.has(id): continue
			var first: Vector2 = _point(segment.start)
			var last: Vector2 = _point(segment.end)
			var root_hosts: Array[Rect2] = [hosts[id]]
			if hollow_ids.has(id): root_hosts = hollow_solids
			_draw_segment(canvas, first, last, hosts[id], hazard, face,root_hosts)
			if hollow_ids.has(id) and face != "left":
				rooted_segments.append({"first":first,"last":last,"host":hosts[id],"face":face})
	_draw_bare_connections(canvas,rooted_segments,hollow_solids)

static func _draw_segment(canvas: Node2D, first: Vector2, last: Vector2, host: Rect2, hazard: Rect2, face: String, solids: Array[Rect2]) -> void:
	var tangent: Vector2 = Vector2.DOWN if face == "left" else Vector2.RIGHT
	var normal: Vector2 = Vector2.LEFT if face == "left" else Vector2.DOWN if face == "down" else Vector2.UP
	var length: float = (last-first).dot(tangent)
	var reach: float = first.x-hazard.position.x if face == "left" else hazard.end.y-first.y if face == "down" else first.y-hazard.position.y
	var inside: float = host.end.x-first.x if face == "left" else first.y-host.position.y if face == "down" else host.end.y-first.y
	if length < PIXEL or reach <= 0.0 or inside <= PIXEL: return
	var inner: float = minf(22.0,maxf(PIXEL,inside-4.0))
	var axis: float = first.y if face == "left" else first.x
	var previous: Vector2 = first+normal*maxf(-inner,_stem_depth(axis))
	for step: int in range(1,ceili(length/PIXEL)+1):
		var u: float = minf(length,float(step)*PIXEL)
		var point: Vector2 = first+tangent*u+normal*maxf(-inner,_stem_depth(axis+u))
		_wood_line(canvas,previous,point,solids)
		previous = point
	# Absolute attachments survive splitting one seam into several real hosts.
	var first_cycle: int = floori((axis-32.0)/float(SPINE_PERIOD))
	var last_cycle: int = floori((axis+length+32.0)/float(SPINE_PERIOD))
	for cycle: int in range(first_cycle,last_cycle+1):
		for index: int in SPINE_X.size():
			var world_at: float = float(cycle*SPINE_PERIOD+SPINE_X[index])
			var at: float = world_at-axis
			if at < 1.0 or at >= length-1.0: continue
			_spine(canvas,first,tangent,normal,at,reach,inner,index,world_at,host,hazard)
			# A small rooted side shoot breaks silhouette density without a net.
			if index in [3,10,18]:
				var root: Vector2 = first+tangent*at+normal*maxf(-inner,_stem_depth(world_at))
				var branch: Vector2 = root-tangent*10.0-normal*6.0
				_wood_line(canvas,root,branch,solids)
				_pixel(canvas,branch,MOSS,host)

static func _stem_depth(axis: float) -> float:
	var phase: float = fposmod(axis,float(STEM_X[-1]))
	for i: int in STEM_X.size()-1:
		if phase <= float(STEM_X[i+1]):
			var amount: float = (phase-float(STEM_X[i]))/float(STEM_X[i+1]-STEM_X[i])
			return snappedf(lerpf(float(STEM_Y[i]),float(STEM_Y[i+1]),amount),PIXEL)
	return -14.0

static func _spine(canvas: Node2D, seam: Vector2, tangent: Vector2, normal: Vector2, at: float, reach: float, inner: float, index: int, axis: float, host: Rect2, hazard: Rect2) -> void:
	var lean: float = float(SPINE_LEAN[index])
	var root_depth: float = maxf(-inner,_stem_depth(axis))
	var root: Vector2 = seam+tangent*at+normal*root_depth
	var collar: Vector2 = seam+tangent*(at+lean*0.25)-normal*2.0
	var solids: Array[Rect2] = [host]
	_wood_line(canvas,root,collar,solids)
	var depth: float = maxf(2.0,reach*SPINE_DEPTH[index])
	for row: int in range(ceili(depth/PIXEL)):
		var v: float = minf(depth-1.0,float(row)*PIXEL+1.0)
		var amount: float = v/depth
		var u: float = at+lean*(0.25+0.75*amount*amount)
		var half: int = 1 if amount < 0.45 and reach > 6.0 else 0
		var color: Color = WOOD if amount < 0.58 else WOOD_FACE if amount < 0.8 else THORN_SHADOW
		if amount > 0.85 and SPINE_DEPTH[index] >= 0.7: color = THORN_TIP
		for cross: int in range(-half,half+1):
			_pixel(canvas,seam+tangent*(u+float(cross)*PIXEL)+normal*v,color,hazard)
	# A few long curved tips show the original external extent; shorter shoots
	# stay woody/duller rather than painting a uniform pale fence at the bound.
	if SPINE_DEPTH[index] >= 0.7:
		_pixel(canvas,seam+tangent*(at+lean)+normal*(depth-1.0),THORN_TIP,hazard)

static func _draw_bare_connections(canvas: Node2D, segments: Array[Dictionary], solids: Array[Rect2]) -> void:
	for a: Dictionary in segments:
		for b: Dictionary in segments:
			if a == b or a.face != b.face: continue
			var end: Vector2 = a.last
			var begin: Vector2 = b.first
			var gap: Vector2 = begin-end
			if gap.x < 0.0 or gap.x > 160.0 or absf(gap.y) > 96.0: continue
			if gap.length() < PIXEL: continue
			# Never link across an intervening thorn segment, nor infer a host.
			var interrupted: bool = false
			for c: Dictionary in segments:
				if c.face == a.face and c.first.x > end.x and c.first.x < begin.x:
					interrupted = true; break
			if interrupted: continue
			var sign_y: float = 1.0 if a.face == "down" else -1.0
			# Overlap the bound stems inside each segment. A pixel centered on
			# the bare x=lip edge would straddle the real empty corner below it.
			var inset_a: float = minf(4.0,maxf(0.0,(end.x-float(a.first.x))*0.5))
			var inset_b: float = minf(4.0,maxf(0.0,(float(b.last.x)-begin.x)*0.5))
			var root_a: Vector2 = end+Vector2(-inset_a,sign_y*_stem_depth(end.x-inset_a))
			var root_b: Vector2 = begin+Vector2(inset_b,sign_y*_stem_depth(begin.x+inset_b))
			var path: Array[Vector2] = [root_a,root_b]
			if not is_zero_approx(gap.y):
				# A real lip must contain the entire internal turn. Try its two
				# inward offsets; accept only a complete solid-contained path.
				path = [root_a,Vector2(end.x+12.0,root_a.y),Vector2(end.x+12.0,root_b.y),root_b]
				if not _path_inside(path,solids):
					path = [root_a,Vector2(end.x-12.0,root_a.y),Vector2(end.x-12.0,root_b.y),root_b]
			if not _path_inside(path,solids): continue
			for i: int in path.size()-1: _wood_line(canvas,path[i],path[i+1],solids)

static func _path_inside(path: Array[Vector2], solids: Array[Rect2]) -> bool:
	for i: int in path.size()-1:
		var steps: int = maxi(1,ceili(path[i].distance_to(path[i+1])/PIXEL))
		for step: int in range(steps+1):
			var center: Vector2 = path[i].lerp(path[i+1],float(step)/steps).snapped(Vector2.ONE*PIXEL)
			for offset: Vector2 in [Vector2.ZERO,Vector2(2,0),Vector2(-2,0),Vector2(0,2),Vector2(0,-2)]:
				if not _contained(center+offset,solids): return false
	return true

static func _wood_line(canvas: Node2D, first: Vector2, last: Vector2, solids: Array[Rect2]) -> void:
	var steps: int = maxi(1,ceili(first.distance_to(last)/PIXEL))
	for step: int in range(steps+1):
		var center: Vector2 = first.lerp(last,float(step)/steps).snapped(Vector2.ONE*PIXEL)
		for offset: Vector2 in [Vector2(2,0),Vector2(-2,0),Vector2(0,2),Vector2(0,-2)]:
			_union_pixel(canvas,center+offset,INK,solids)
		_union_pixel(canvas,center,WOOD,solids)
		# Broken facets, rather than a continuous gold outline.
		if posmod(floori(center.x/PIXEL)+floori(center.y/PIXEL),17) < 3:
			_union_pixel(canvas,center,WOOD_FACE,solids)

static func _contained(center: Vector2, solids: Array[Rect2]) -> bool:
	var pixel := Rect2(center.snapped(Vector2.ONE*PIXEL)-Vector2.ONE,Vector2.ONE*PIXEL)
	for solid: Rect2 in solids:
		if solid.encloses(pixel): return true
	# A native pixel may straddle two abutting real solids. Subtract their
	# union exactly, rather than rejecting that valid seam or painting a gap.
	var uncovered: Array[Rect2] = [pixel]
	for solid: Rect2 in solids:
		var remaining: Array[Rect2] = []
		for piece: Rect2 in uncovered:
			var cut: Rect2 = piece.intersection(solid)
			if not cut.has_area():
				remaining.append(piece); continue
			for part: Rect2 in [
				Rect2(piece.position,Vector2(piece.size.x,cut.position.y-piece.position.y)),
				Rect2(Vector2(piece.position.x,cut.end.y),Vector2(piece.size.x,piece.end.y-cut.end.y)),
				Rect2(Vector2(piece.position.x,cut.position.y),Vector2(cut.position.x-piece.position.x,cut.size.y)),
				Rect2(Vector2(cut.end.x,cut.position.y),Vector2(piece.end.x-cut.end.x,cut.size.y))]:
				if part.has_area(): remaining.append(part)
		uncovered = remaining
		if uncovered.is_empty(): return true
	return false

static func _union_pixel(canvas: Node2D, center: Vector2, color: Color, solids: Array[Rect2]) -> void:
	if _contained(center,solids):
		canvas.draw_rect(Rect2(center.snapped(Vector2.ONE*PIXEL)-Vector2.ONE,Vector2.ONE*PIXEL),color)

static func _pixel(canvas: Node2D, center: Vector2, color: Color, clip: Rect2) -> void:
	var pixel := Rect2(center.snapped(Vector2.ONE*PIXEL)-Vector2.ONE,Vector2.ONE*PIXEL)
	var visible: Rect2 = pixel.intersection(clip)
	if visible.has_area(): canvas.draw_rect(visible,color)

static func _point(raw: Array) -> Vector2:
	return Vector2(float(raw[0]),float(raw[1]))

static func _rect(raw: Array) -> Rect2:
	return Rect2(float(raw[0]),float(raw[1]),float(raw[2]),float(raw[3]))
