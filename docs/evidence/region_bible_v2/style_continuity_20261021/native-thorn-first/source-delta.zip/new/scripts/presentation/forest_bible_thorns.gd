class_name ForestBibleThorns
extends RefCounted
## Authored native sprites only. No procedural stem, needles, physics or RNG.
const ATLAS: Texture2D = preload("res://assets/forest_bible_v2/native/thorn_briar_atlas_v1.png")
# Byte-equivalent region data is embedded so exported builds need no JSON filter.
const REGIONS: Dictionary = {
	"up12_a": {"root_anchor_y_by_x":[17,17,17,17,17,17,17,16,15,15,16,17,17,17,17,17,17,17,17,17,17,17,16,16,17,17,17,17,17,17,17,17],"atlas_rect":[0,0,32,20],"outer_rect":[0,0,32,12],"root_rect":[0,12,32,8],"port":[0,17],"face":"up","seam_native":12,"size":[32,20]},
	"up12_b": {"root_anchor_y_by_x":[17,17,17,17,17,17,17,17,17,17,17,17,17,17,17,17,17,17,17,17,17,17,16,17,17,17,17,17,17,17,17,17],"atlas_rect":[32,0,32,20],"outer_rect":[0,0,32,12],"root_rect":[0,12,32,8],"port":[0,17],"face":"up","seam_native":12,"size":[32,20]},
	"down10_a": {"root_anchor_y_by_x":[3,3,3,3,3,3,4,5,6,6,3,3,3,3,3,3,3,3,3,4,4,5,5,3,3,3,3,3,3,3,3,3],"atlas_rect":[64,0,32,18],"outer_rect":[0,8,32,10],"root_rect":[0,0,32,8],"port":[0,3],"face":"down","seam_native":8,"size":[32,18]},
	"down8_a": {"root_anchor_y_by_x":[3,3,3,3,3,3,4,5,6,6,3,3,3,3,3,3,3,3,3,4,4,5,5,3,3,3,3,3,3,3,3,3],"atlas_rect":[96,0,32,16],"outer_rect":[0,8,32,8],"root_rect":[0,0,32,8],"port":[0,3],"face":"down","seam_native":8,"size":[32,16]},
	"down10_b": {"root_anchor_y_by_x":[3,3,3,3,3,3,3,3,3,3,3,3,3,4,4,3,3,3,3,3,3,3,2,3,3,3,3,3,3,3,3,3],"atlas_rect":[0,32,32,18],"outer_rect":[0,8,32,10],"root_rect":[0,0,32,8],"port":[0,3],"face":"down","seam_native":8,"size":[32,18]},
	"down8_b": {"root_anchor_y_by_x":[3,3,3,3,3,3,3,3,3,3,3,3,3,4,4,3,3,3,3,3,3,3,2,3,3,3,3,3,3,3,3,3],"atlas_rect":[32,32,32,16],"outer_rect":[0,8,32,8],"root_rect":[0,0,32,8],"port":[0,3],"face":"down","seam_native":8,"size":[32,16]},
	"left20": {"root_anchor_y_by_x":[],"atlas_rect":[64,32,28,26],"outer_rect":[0,0,20,26],"root_rect":[20,0,8,26],"port":[23,0],"face":"left","seam_native":20,"size":[28,26]},
	"bare_round": {"root_anchor_y_by_x":[],"atlas_rect":[96,32,12,12],"outer_rect":[0,0,0,0],"root_rect":[0,0,12,12],"port":[0,3],"face":"bare","seam_native":0,"size":[12,12]},
	"bare_short": {"root_anchor_y_by_x":[],"atlas_rect":[0,64,16,8],"outer_rect":[0,0,0,0],"root_rect":[0,0,16,8],"port":[0,4],"face":"bare","seam_native":0,"size":[16,8]},
	"bare_vertical": {"root_anchor_y_by_x":[],"atlas_rect":[32,64,8,16],"outer_rect":[0,0,0,0],"root_rect":[0,0,8,16],"port":[3,0],"face":"bare","seam_native":0,"size":[8,16]},
}
const PIXEL: float = 2.0
const TILE_WIDTH: float = 64.0
const VARIANTS: Array[int] = [0,1,1,0,0,1,0,1,1,1,0]

static func draw(canvas: Node2D, m: Dictionary) -> void:
	if m.get("layout_version") != "forest-bible-world-v15": return
	var hosts: Dictionary = {}
	var hollow: Array[Rect2] = []
	var hollow_ids: Dictionary = {}
	for row: Dictionary in m.get("platforms", []):
		if bool(row.get("one_way",false)) or not row.has("rect"): continue
		hosts[str(row.id)] = _rect(row.rect)
		if row.get("structure_id") == "hollow":
			hollow.append(_rect(row.rect)); hollow_ids[str(row.id)] = true
	var joins: Array[Dictionary] = []
	for surface: Dictionary in m.get("thorn_surfaces", []):
		var face: String = str(surface.get("face", ""))
		if face not in ["up","down","left"]: continue
		var hazard: Rect2 = _rect(surface.hazard_rect)
		var segments: Array = surface.get("segments", [])
		if segments.is_empty() or not hazard.has_area(): continue
		var solids: Array[Rect2] = []
		var valid: bool = true
		for segment: Dictionary in segments:
			var id: String = str(segment.support_id)
			if not hosts.has(id): valid = false; break
			solids.append(hosts[id])
		if not valid: continue
		var seam: Vector2 = _point(segments[0].start)
		var reach: float = seam.x-hazard.position.x if face == "left" else hazard.end.y-seam.y if face == "down" else seam.y-hazard.position.y
		var depth: int = roundi(reach/PIXEL)
		if not is_equal_approx(reach,float(depth)*PIXEL): continue
		if face == "left":
			if depth != 20 or not is_equal_approx(hazard.size.y,52.0): continue
			_stamp(canvas,"left20",Vector2(seam.x-40.0,hazard.position.y),hazard,solids)
			continue
		if (face == "up" and depth != 12) or (face == "down" and depth not in [8,10]): continue
		var family: String = ("up" if face == "up" else "down")+str(depth)
		# One sprite run for the actual hazard union: shared support boundaries
		# do not restart phase, emit another cap, or duplicate external thorns.
		var origin_y: float = seam.y-reach if face == "up" else seam.y-16.0
		for index: int in range(ceili(hazard.size.x/TILE_WIDTH)):
			var x: float = hazard.position.x+float(index)*TILE_WIDTH
			var name: String = _variant_name(family,x,hazard.end.x-x)
			_stamp(canvas,name,Vector2(x,origin_y),hazard,solids)
		for segment: Dictionary in segments:
			if hollow_ids.has(str(segment.support_id)):
				joins.append({"first":_point(segment.start),"last":_point(segment.end),"face":face,
					"family":family,"run_left":hazard.position.x,"run_right":hazard.end.x,"origin_y":origin_y})
	_draw_connections(canvas,joins,hollow)

static func _variant_name(family: String, x: float, remaining: float) -> String:
	# A's complete pale heads fit the actual2/3/16/19/30px tail widths.
	var variant: int = 0 if remaining < TILE_WIDTH else VARIANTS[posmod(floori(x/TILE_WIDTH),VARIANTS.size())]
	return family+("_a" if variant == 0 else "_b")

static func _stamp(canvas: Node2D, name: String, origin: Vector2, hazard: Rect2, solids: Array[Rect2]) -> void:
	var region: Dictionary = REGIONS[name]
	_blit(canvas,region,origin,_rect(region.outer_rect),hazard)
	var root: Rect2 = _rect(region.root_rect)
	for solid: Rect2 in solids: _blit(canvas,region,origin,root,solid)

static func _blit(canvas: Node2D, region: Dictionary, origin: Vector2, native: Rect2, clip: Rect2) -> void:
	if not native.has_area(): return
	var target := Rect2(origin+native.position*PIXEL,native.size*PIXEL)
	var visible: Rect2 = target.intersection(clip)
	if not visible.has_area(): return
	var source := Rect2(_point(region.atlas_rect)+native.position+(visible.position-target.position)/PIXEL,visible.size/PIXEL)
	canvas.draw_texture_rect_region(ATLAS,visible,source)

static func _root_anchor(row: Dictionary, at_end: bool) -> Vector2:
	var x: float = float(row.last.x)-4.0 if at_end else float(row.first.x)+4.0
	var tile: int = floori((x-float(row.run_left))/TILE_WIDTH)
	var tile_x: float = float(row.run_left)+float(tile)*TILE_WIDTH
	var name: String = _variant_name(str(row.family),tile_x,float(row.run_right)-tile_x)
	var region: Dictionary = REGIONS[name]
	var column: int = clampi(floori((x-tile_x)/PIXEL),0,31)
	return Vector2(x,float(row.origin_y)+float(region.root_anchor_y_by_x[column])*PIXEL)

static func _draw_connections(canvas: Node2D, joins: Array[Dictionary], solids: Array[Rect2]) -> void:
	for a: Dictionary in joins:
		for b: Dictionary in joins:
			if a == b or a.face != b.face: continue
			var gap: Vector2 = b.first-a.last
			if gap.x < 0.0 or gap.x > 160.0 or absf(gap.y) > 96.0 or gap.length() < PIXEL: continue
			var interrupted: bool = false
			for c: Dictionary in joins:
				if c.face == a.face and c.first.x > a.last.x and c.first.x < b.first.x:
					interrupted = true; break
			if interrupted: continue
			var first: Vector2 = _root_anchor(a,true)
			var last: Vector2 = _root_anchor(b,false)
			if is_zero_approx(gap.y):
				_bare_span(canvas,first,last,solids,false)
				continue
			# Only the real lip's inside can contain this bare turn. Nothing
			# white is introduced and no nearest support is inferred.
			var bend_x: float = float(a.last.x)+12.0
			if not _covered(Rect2(Vector2(bend_x-2.0,minf(first.y,last.y)),Vector2(4.0,absf(last.y-first.y))),solids):
				bend_x = float(a.last.x)-12.0
			if not _covered(Rect2(Vector2(bend_x-2.0,minf(first.y,last.y)),Vector2(4.0,absf(last.y-first.y))),solids): continue
			_bare_span(canvas,first,Vector2(bend_x,first.y),solids,false)
			_bare_span(canvas,Vector2(bend_x,first.y),Vector2(bend_x,last.y),solids,true)
			_bare_span(canvas,Vector2(bend_x,last.y),last,solids,false)
			_round(canvas,Vector2(bend_x-16.0,first.y-6.0),solids,false)
			_round(canvas,Vector2(bend_x-16.0,last.y-18.0),solids,true)

static func _bare_span(canvas: Node2D, first: Vector2, last: Vector2, solids: Array[Rect2], vertical: bool) -> void:
	if first.distance_to(last) < PIXEL: return
	var a: Vector2 = first
	var b: Vector2 = last
	if (a.y > b.y if vertical else a.x > b.x):
		a = last; b = first
	var length: float = b.y-a.y if vertical else b.x-a.x
	var count: int = maxi(1,ceili(length/24.0))
	var region: Dictionary = REGIONS["bare_vertical" if vertical else "bare_short"]
	for i: int in count:
		var t: float = float(i)/float(count)
		var point: Vector2 = a.lerp(b,t).snapped(Vector2.ONE*PIXEL)
		var origin: Vector2 = point-Vector2(6,0) if vertical else point-Vector2(0,8)
		var span := Rect2(Vector2(a.x-16.0,a.y) if vertical else Vector2(a.x,a.y-24.0),Vector2(32.0,length) if vertical else Vector2(length,48.0))
		for solid: Rect2 in solids: _blit(canvas,region,origin,_rect(region.root_rect),solid.intersection(span))

static func _round(canvas: Node2D, origin: Vector2, solids: Array[Rect2], flip_y: bool) -> void:
	var region: Dictionary = REGIONS.bare_round
	var atlas_at: Vector2 = _point(region.atlas_rect)
	# Mirroring ONLY a bare corner preserves the authored outline; down-facing
	# hazardous sprites above have their own local-lit native source rows.
	for y: int in 12:
		for x: int in 12:
			var target := Rect2(origin+Vector2(x,11-y if flip_y else y)*PIXEL,Vector2.ONE*PIXEL)
			if _covered(target,solids): canvas.draw_texture_rect_region(ATLAS,target,Rect2(atlas_at+Vector2(x,y),Vector2.ONE))

static func _covered(pixel: Rect2, solids: Array[Rect2]) -> bool:
	for solid: Rect2 in solids:
		if solid.encloses(pixel): return true
	var uncovered: Array[Rect2] = [pixel]
	for solid: Rect2 in solids:
		var remaining: Array[Rect2] = []
		for piece: Rect2 in uncovered:
			var cut: Rect2 = piece.intersection(solid)
			if not cut.has_area(): remaining.append(piece); continue
			for part: Rect2 in [Rect2(piece.position,Vector2(piece.size.x,cut.position.y-piece.position.y)),Rect2(Vector2(piece.position.x,cut.end.y),Vector2(piece.size.x,piece.end.y-cut.end.y)),Rect2(Vector2(piece.position.x,cut.position.y),Vector2(cut.position.x-piece.position.x,cut.size.y)),Rect2(Vector2(cut.end.x,cut.position.y),Vector2(piece.end.x-cut.end.x,cut.size.y))]:
				if part.has_area(): remaining.append(part)
		uncovered = remaining
		if uncovered.is_empty(): return true
	return false

static func _point(raw: Array) -> Vector2:
	return Vector2(float(raw[0]),float(raw[1]))

static func _rect(raw: Array) -> Rect2:
	return Rect2(float(raw[0]),float(raw[1]),float(raw[2]),float(raw[3]))
