import sys,json,re,subprocess,time
from pathlib import Path
ROOT=Path('/workspace/gunman-rush');sys.path.insert(0,str(ROOT/'tools'));import harness
folder=ROOT/'build/plains_revision_01/native-r3-02';folder.mkdir(parents=True,exist_ok=False)
source=harness.git_metadata();results=[]
checks=[('parse',['bash','tools/godot.sh','--headless','--audio-driver','Dummy','--path','.','--editor','--quit'],90,None),('revision',['bash','tools/godot.sh','--headless','--audio-driver','Dummy','--fixed-fps','60','--path','.','--script','tests/plains_revision_01_runner.gd','--','--output='+str(folder/'runtime.json')],180,r'^PLAINS REVISION 01: 323 checks, 0 failures$'),('native',['python3','tools/run_integration_four_tests.py','--case','enemy-feedback-native'],360,r'^ENEMY_FEEDBACK_01 checks=[1-9]\d* failures=0$'),('muzzle',['bash','tools/godot.sh','--headless','--audio-driver','Dummy','--fixed-fps','60','--path','.','--script','tests/plains_revision_01_muzzle.gd'],180,r'^PLAINS REVISION MUZZLE: checks=167; failures=0; cases=20$')]
for name,argv,budget,marker in checks:
    spec={'argv':argv,'timeout_seconds':budget}
    spec['success_pattern']=marker or r'^Godot Engine v'
    result=harness.run_check(spec,folder/(name+'.log'),ROOT)
    results.append(dict(name=name,**result));print(name,result,flush=True)
    if result['status']!='passed':break
stable=source==harness.git_metadata()
(folder/'receipt.json').write_text(json.dumps(dict(source=source,source_stable=stable,checks=results),indent=2)+'\n')
raise SystemExit(0 if len(results)==len(checks) and all(r['status']=='passed' for r in results) and stable else 1)
