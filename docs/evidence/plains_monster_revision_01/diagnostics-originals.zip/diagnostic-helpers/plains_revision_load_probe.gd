extends SceneTree
func _initialize() -> void:
    run.call_deferred()
func run() -> void:
    var held: Resource = load(OS.get_cmdline_user_args()[0])
    print("PROBE LOAD ",OS.get_cmdline_user_args()[0]," refs=",held.get_reference_count())
    held = null
    await process_frame
    await process_frame
    quit()
