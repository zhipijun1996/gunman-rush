## v8: restored strict persistent-corpse assertions from 0d5b72c following the
## latest user rejection of exploded disappearance and custom death sound.
extends SceneTree
## Real DemoApp default start_plains / generated spawn / damage / drop / rebuild.
## Each target uses one explicitly recorded initial player Motor positioning on
## existing safe terrain. Subsequent movement and shooting use InputRouter.
## No enemy, AI, HP, collider, damage, reward, manifest or energy is altered.
const TARGETS: Array[StringName] = [&"plains_charger", &"plains_diver"]
var checks := 0
var failures: Array[String] = []
var inventory: Array[Dictionary] = []
var results: Array[Dictionary] = []
var events: Array[Dictionary] = []
var shots: Array[Dictionary] = []
var trace: Array[Dictionary] = []
var app: DemoApp
var original_manifest := ""
var ready_receipts: Array[Dictionary] = []
var remains_teardown: Array[WeakRef] = []

func _initialize() -> void:
	run.call_deferred()

func check(ok: bool, label: String) -> void:
	checks += 1
	if not ok:
		failures.append(label)
		printerr("FAIL: ", label)

func stage_ready(phase: String) -> bool:
	var started := Time.get_ticks_msec()
	var frames := 0
	while Time.get_ticks_msec() - started < 60000 and frames < 3600:
		if not app._stage_pending and is_instance_valid(app.stage) and app.stage is PlainsRegionStage and (app.stage as PlainsRegionStage).assembly_ok and app._can_interact():
			ready_receipts.append({"phase": phase, "frames": frames, "milliseconds": Time.get_ticks_msec() - started, "assembly_ok": true, "stage_pending": false})
			return true
		await physics_frame
		await process_frame
		frames += 1
	ready_receipts.append({"phase": phase, "frames": frames, "milliseconds": Time.get_ticks_msec() - started, "assembly_ok": false, "stage_pending": app._stage_pending})
	return false

func ticks(count: int, phase: String) -> void:
	for _frame: int in count:
		await physics_frame
		await process_frame
		if is_instance_valid(app.controller):
			trace.append({"phase": phase, "tick": Engine.get_physics_frames(), "player_position": app.player.position, "HP": app.controller.actor_resources.health.current, "energy": app.controller.actor_resources.stamina.current, "actor_epoch": app.lifetime.actor_epoch, "drop_count": app.region_state.drops.size() if app.region_state != null else -1})

func clear_terrain_line(from: Vector2, to: Vector2) -> bool:
	var space := app.player.get_world_2d().direct_space_state
	for y_offset: float in [-3.0, 0.0, 3.0]:
		var query := PhysicsRayQueryParameters2D.create(from + Vector2(0, y_offset), to + Vector2(0, y_offset), 1, [app.player.get_rid()])
		if not space.intersect_ray(query).is_empty():
			return false
	return true

func find_initial_fixture(stable_id: StringName) -> Dictionary:
	var stage := app.stage as PlainsRegionStage
	var space := app.player.get_world_2d().direct_space_state
	for index: int in stage.enemies.size():
		var motor := stage.enemies[index]
		var actor := motor.get_node("Actor") as EnemyActor
		if actor.definition.stable_id != stable_id or actor.health.terminal:
			continue
		for x_offset: float in [-160.0, 160.0, -220.0, 220.0, -110.0, 110.0, -280.0, 280.0]:
			var x := motor.global_position.x + x_offset
			var ray := PhysicsRayQueryParameters2D.create(Vector2(x, motor.global_position.y - 60), Vector2(x, motor.global_position.y + 280), 1, [app.player.get_rid()])
			var ground := space.intersect_ray(ray)
			if ground.is_empty() or (ground.normal as Vector2).dot(Vector2.UP) < .7:
				continue
			var location := (ground.position as Vector2) - Vector2(0, 18)
			if not app.segment.is_safe(location) or not clear_terrain_line(location, motor.global_position):
				continue
			var retreat_side := signf(x_offset)
			var supported := true
			for travel: float in [24.0, 48.0, 72.0, 96.0]:
				if not app.segment.is_safe(location + Vector2(retreat_side * travel, 0)):
					supported = false
			if not supported:
				continue
			var isolated := true
			for other: EnemyMotor in stage.enemies:
				if other != motor and other.global_position.distance_to(location) < 85:
					isolated = false
			if isolated:
				return {"index": index, "id": str(stage.enemy_manifest[index].id), "stable_id": str(stable_id), "location": location, "target_initial": motor.global_position, "positioning": "one initial player.motor.reset_at on existing SegmentRespawn.is_safe terrain; not natural traversal"}
	return {}

func fire_at_actual_target(motor: EnemyMotor, fixture_location: Vector2) -> bool:
	var actor := motor.get_node("Actor") as EnemyActor
	for attempt: int in 12:
		if actor.health.terminal:
			return true
		if not app._can_interact():
			return false
		# Legitimate movement returns from recoil toward the recorded supported
		# starting point. Never reset the body or regenerate resources here.
		for _frame: int in 120:
			var offset := fixture_location.x - app.player.global_position.x
			app.controller.router.set_move_axis(signf(offset) if absf(offset) > 8 else 0)
			if absf(offset) <= 8 and app.player.is_on_floor() and app.controller.shoot_ability.cooldown_remaining <= 0 and app.controller.shot_energy.can_fire():
				break
			await ticks(1, "natural_recoil_recovery")
			if not app._can_interact():
				return false
		app.controller.router.set_move_axis(0)
		var distance := app.player.global_position.distance_to(motor.global_position)
		var predicted := motor.global_position + motor.velocity * minf(.20, distance / app.player.tuning.projectile_speed)
		var direction := (predicted - app.player.global_position).normalized()
		app.controller.router.aim_direction = direction
		app.controller.router.request_action(&"shoot_release", direction)
		await ticks(32, "actual_router_shot_%s" % attempt)
	app.controller.router.set_move_axis(0)
	return actor.health.terminal

func verify_target(stable_id: StringName) -> void:
	var fixture := find_initial_fixture(stable_id)
	check(not fixture.is_empty(), "actual generated %s has a safe supported shooting fixture" % stable_id)
	if fixture.is_empty():
		results.append({"stable_id": str(stable_id), "status": "UNVERIFIED", "reason": "No safe supported unobstructed initial player position in this actual map; no fixture enemy injected"})
		return
	var stage := app.stage as PlainsRegionStage
	var motor := stage.enemies[int(fixture.index)]
	var actor := motor.get_node("Actor") as EnemyActor
	var art := motor.get_node("Presentation") as UnderworldEnemy
	check(art != null and art.feedback_sample != null, "default formal installer owns selected shared component for " + str(stable_id))
	if art == null or art.feedback_sample == null:
		return
	var initial_hp := actor.health.current
	var before_events := events.size()
	var before_shots := shots.size()
	var enemy_id := str(fixture.id)
	check(not app.region_state.drops.has(enemy_id), "actual live generated identity has no settled drop before shooting")
	actor.damageable.damaged.connect(func(context: Dictionary) -> void:
		events.append({"enemy_id": enemy_id, "tick": Engine.get_physics_frames(), "event_id": str(context.get("event_id", "")), "context": context.duplicate(), "HP": actor.health.current}))
	var player_hp := app.controller.actor_resources.health.current
	var player_energy := app.controller.actor_resources.stamina.current
	app.player.reset_at(fixture.location)
	app.controller.router.clear("enemy_feedback_01_initial_position_fixture")
	check(app.controller.actor_resources.health.current == player_hp and app.controller.actor_resources.stamina.current == player_energy, "initial positioning preserves real HP and energy")
	await ticks(4, "initial_position_fixture")
	check(app.player.is_on_floor(), "initial fixture reaches actual Motor-supported floor")
	var killed := await fire_at_actual_target(motor, fixture.location)
	check(killed and actor.health.terminal, "actual formal Router projectiles kill generated " + str(stable_id))
	check(shots.size() > before_shots and events.size() - before_events == ceili(initial_hp), "actual accepted projectile contexts account for original enemy HP")
	if not killed:
		results.append({"stable_id": str(stable_id), "id": enemy_id, "status": "UNVERIFIED", "fixture": fixture, "reason": "Bounded actual shooting did not kill target", "remaining_HP": actor.health.current})
		return
	check(art.feedback_sample.accepted_hit_count == ceili(initial_hp) - 1 and art.feedback_sample.accepted_death_count == 1, "actual formal consumer performs one death and each nonlethal hurt")
	check(art.feedback_particles.emitted_bursts == ceili(initial_hp) and art.feedback_sample.impact_serial == ceili(initial_hp), "actual default formal projectiles emit exactly one pixel burst per accepted HP receipt including death")
	check(art.feedback_remains.active and not art.feedback_remains.restored and art.feedback_remains.accepted_starts == 1 and art.feedback_remains.get_parent() == stage, "actual generated enemy has one accepted corpse owned by its real stage")
	await ticks(3, "formal_drop_settlement")
	check(app.region_state.drops.has(enemy_id), "DemoApp itself settles actual generated terminal identity")
	if not app.region_state.drops.has(enemy_id):
		return
	var drop: Dictionary = app.region_state.drops[enemy_id].duplicate(true)
	var drops_before := JSON.stringify(app.region_state.drops)
	var duplicate_count := stage.pickups.filter(func(row: Dictionary) -> bool: return str(row.id) == "drop_" + enemy_id).size()
	check(duplicate_count == (0 if drop.kind == "none" else 1), "formal terminal drop has exactly one pickup instance or configured none")
	if events.size() > before_events:
		check(not actor.damageable.receive_damage(events.back().context), "replayed actual projectile context cannot settle another lethal hit")
	await ticks(45, "formal_duplicate_ticks")
	check(JSON.stringify(app.region_state.drops) == drops_before, "repeated official damage settlement ticks preserve exact drop receipt")
	check(stage.pickups.filter(func(row: Dictionary) -> bool: return str(row.id) == "drop_" + enemy_id).size() == duplicate_count, "repeated ticks and replay never add another pickup")
	check(art.feedback_sample.flash_strength() == 0 and art.feedback_particles.active_bursts() == 0 and art.feedback_particles.emitted_bursts == ceili(initial_hp), "actual formal terminal replay adds no pixel burst and all impact effects expire")
	await ticks(130, "formal_persistent_corpse_over_two_seconds")
	check(art._death >= .65 and not art.visible and art.feedback_remains.active and art.feedback_remains.visible and art.feedback_remains.is_visible_in_tree(), "actual generated corpse remains visible for over two seconds after inherited parent fade")
	check(art.feedback_remains.frame_index == 7 and art.feedback_remains.source == art.feedback_frames.texture(7), "actual generated accepted corpse persists on authored rest frame 7")
	check(art.feedback_remains.accepted_starts == 1 and JSON.stringify(app.region_state.drops) == drops_before, "persistent corpse and repeated formal settlement preserve one death and exact drop receipt")
	results.append({"stable_id": str(stable_id), "id": enemy_id, "status": "verified", "fixture": fixture, "initial_HP": initial_hp, "projectile_contexts": events.size() - before_events, "shots": shots.size() - before_shots, "drop": drop, "pickup_instances": duplicate_count, "hurt_count": art.feedback_sample.accepted_hit_count, "death_count": art.feedback_sample.accepted_death_count, "remains_age": art.feedback_remains.age, "remains_phase": str(art.feedback_remains.phase), "remains_accepted_starts": art.feedback_remains.accepted_starts})

func verify_actual_reload() -> void:
	var old_stage: WeakRef = weakref(app.stage)
	var drops_before := JSON.stringify(app.region_state.drops)
	var audio := app.get_tree().get_first_node_in_group(&"game_audio") as GameAudio
	var defeat_cues := int(audio.played.get(&"enemy_defeat", 0))
	var old_epoch := app.lifetime.actor_epoch
	var previous_remains: Array[WeakRef] = []
	for child: Node in app.stage.get_children():
		if child is EnemyFeedback01Remains:
			previous_remains.append(weakref(child))
	app._stage_pending = true
	app.controller.router.clear("stage_transition")
	app.call_deferred("_load_stage")
	var rebuilt := await stage_ready("actual_same_map_reload")
	check(rebuilt, "formal same-map _load_stage completes actual asynchronous assembly")
	if not rebuilt:
		return
	await ticks(3, "rebuilt_stage_ready")
	check(old_stage.get_ref() == null, "actual reload frees previous formal stage")
	check(previous_remains.all(func(reference: WeakRef) -> bool: return reference.get_ref() == null), "actual stage rebuild releases every prior stage sibling corpse")
	check(app.lifetime.actor_epoch > old_epoch, "actual reload cancels prior actor epoch")
	check(JSON.stringify(app.region_state.drops) == drops_before, "actual reload preserves drop receipt byte representation")
	check(int(audio.played.get(&"enemy_defeat", 0)) == defeat_cues, "actual saved dead actors produce no second defeat audio")
	var stage := app.stage as PlainsRegionStage
	check(JSON.stringify(stage.generated.manifest) == original_manifest, "actual reload uses unchanged generated Manifest")
	for result: Dictionary in results:
		if result.status != "verified":
			continue
		var found := false
		for index: int in stage.enemies.size():
			if str(stage.enemy_manifest[index].id) != str(result.id):
				continue
			found = true
			var motor := stage.enemies[index]
			var actor := motor.get_node("Actor") as EnemyActor
			var art := motor.get_node("Presentation") as UnderworldEnemy
			check(actor.health.terminal and not motor.visible, "official saved terminal actor stays dead and hidden after reload")
			check(art != null and art.feedback_sample != null and art.feedback_sample.restored_terminal and not art.feedback_sample.death_active and art.feedback_sample.accepted_death_count == 0 and art.feedback_sample.accepted_hit_count == 0, "actual restored corpse never starts new hurt or death performance")
			check(art.feedback_particles.emitted_bursts == 0 and art.feedback_particles.active_bursts() == 0 and art.feedback_sample.flash_strength() == 0, "official reload of dead actor emits no pixel particles or body flash")
			check(art.feedback_remains.active and art.feedback_remains.restored and art.feedback_remains.settled and art.feedback_remains.accepted_starts == 0, "official dead snapshot reconstructs static remains without replaying death motion")
			check(art.feedback_remains.frame_index == 7 and art.feedback_remains.source == art.feedback_frames.texture(7), "official dead reload directly reconstructs authored final frame without new death animation")
			check(art.feedback_remains.get_parent() == stage and art.feedback_remains.visible and art.feedback_remains.is_visible_in_tree(), "official restored corpse stays visible despite hidden saved EnemyMotor")
			var expected := 0 if result.drop.kind == "none" else 1
			check(stage.pickups.filter(func(row: Dictionary) -> bool: return str(row.id) == "drop_" + str(result.id)).size() == expected, "official rebuild restores one existing drop instance")
		check(found, "same generated enemy identity restored for " + str(result.stable_id))

func run() -> void:
	app = DemoApp.new()
	app.meta_persistence_enabled = false
	root.add_child(app)
	check(app.start_plains("enemy-feedback-01-formal"), "actual default start_plains accepts task seed")
	var ready := await stage_ready("default_start_plains")
	check(ready, "actual stage readiness and assembly observed before any fixture")
	if ready:
		app.player.get_node("KeyboardMouseAdapter").process_mode = Node.PROCESS_MODE_DISABLED
		app.controller.shoot_ability.shot_fired.connect(func(direction: Vector2, id: int) -> void:
			shots.append({"id": id, "tick": Engine.get_physics_frames(), "direction": direction, "muzzle": app.controller.shoot_ability.last_muzzle, "player": app.player.position}))
		var stage := app.stage as PlainsRegionStage
		original_manifest = JSON.stringify(stage.generated.manifest)
		for index: int in stage.enemies.size():
			var actor := stage.enemies[index].get_node("Actor") as EnemyActor
			inventory.append({"id": stage.enemy_manifest[index].id, "stable_id": str(actor.definition.stable_id), "behavior": str(actor.definition.behavior_id), "position": stage.enemies[index].position, "presentation": stage.enemies[index].get_node("Presentation").get_class()})
		for stable_id: StringName in TARGETS:
			await verify_target(stable_id)
		check(JSON.stringify((app.stage as PlainsRegionStage).generated.manifest) == original_manifest, "initial fixture and real combat never mutate generated Manifest")
		await verify_actual_reload()
		if is_instance_valid(app.stage):
			for child: Node in app.stage.get_children():
				if child is EnemyFeedback01Remains:
					remains_teardown.append(weakref(child))
	app.abandon_run()
	check(await load("res://tests/audio_teardown.gd").drain_world(app), "formal consumer teardown observes bounded actual audio release")
	app.free()
	for _frame: int in 4:
		await process_frame
	check(remains_teardown.all(func(reference: WeakRef) -> bool: return reference.get_ref() == null), "abandon and full DemoApp unload release all remaining corpse siblings")
	DirAccess.make_dir_recursive_absolute("res://build/enemy_feedback_01/v8")
	var output := {"feedback_revision": "dedicated_species_frames_and_persistent_corpse_v8", "task": "ENEMY-FEEDBACK-01", "checks": checks, "failures": failures, "ready": ready_receipts, "inventory": inventory, "targets": results, "shots": shots, "accepted_events": events, "trace": trace, "scope": "real default DemoApp/start_plains generated actors, Router/projectile damage, official drop ledger and same-map rebuild; explicitly positioned player fixtures, not natural traversal", "not_verified": ["full natural traversal", "GPU visual quality", "user acceptance", "physical device"]}
	var file := FileAccess.open("res://build/enemy_feedback_01/v8/formal_runtime.json", FileAccess.WRITE)
	file.store_string(JSON.stringify(output, "\t"))
	file.close()
	print("ENEMY_FEEDBACK_01_FORMAL checks=%d failures=%d" % [checks, failures.size()])
	quit(0 if failures.is_empty() else 1)
