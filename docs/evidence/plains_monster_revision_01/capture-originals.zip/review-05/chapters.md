# ENEMY-ALL-02 actual capture

Initial arena fixtures; normal-speed AI/InputRouter/projectiles. Human visual approval pending.

| Case | Species / chain | Movie process-frame seconds | Accepted enemy hits | Coverage gaps |
| --- | --- | --- | --- | --- |
| 1 | patrol_drone / underworld | 0.02–10.57 | 3 | none recorded |
| 2 | plains_charger / underworld | 10.62–22.33 | 3 | none recorded |
| 3 | plains_diver / underworld | 22.38–33.48 | 3 | none recorded |
| 4 | plains_hopper / underworld | 33.53–44.05 | 3 | none recorded |
| 5 | plains_sentry / underworld | 44.10–54.73 | 3 | none recorded |
| 6 | plains_fan_sentry / underworld | 54.78–65.43 | 3 | none recorded |
| 7 | plains_root_bell / underworld | 65.48–76.08 | 3 | none recorded |
