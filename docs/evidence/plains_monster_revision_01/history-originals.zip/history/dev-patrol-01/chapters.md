# ENEMY-ALL-02 actual capture

Initial arena fixtures; normal-speed AI/InputRouter/projectiles. Human visual approval pending.

| Case | Species / chain | Movie process-frame seconds | Accepted enemy hits | Coverage gaps |
| --- | --- | --- | --- | --- |
| 1 | patrol_drone / underworld | 0.02–10.57 | 3 | none recorded |
