# ENEMY-ALL-02 actual capture

Initial arena fixtures; normal-speed AI/InputRouter/projectiles. Human visual approval pending.

| Case | Species / chain | Movie process-frame seconds | Accepted enemy hits | Coverage gaps |
| --- | --- | --- | --- | --- |
| 1 | patrol_drone / underworld | 0.02–10.57 | 3 | none recorded |
| 2 | plains_charger / underworld | 10.62–22.30 | 3 | none recorded |
| 3 | plains_diver / underworld | 22.35–33.45 | 3 | none recorded |
| 4 | plains_hopper / underworld | 33.50–44.02 | 3 | none recorded |
| 5 | plains_sentry / underworld | 44.07–54.70 | 3 | none recorded |
| 6 | plains_fan_sentry / underworld | 54.75–65.40 | 3 | none recorded |
| 7 | plains_root_bell / underworld | 65.45–76.05 | 3 | none recorded |
