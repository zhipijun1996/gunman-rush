from pathlib import Path
import json,hashlib,zipfile
R=Path('/workspace/gunman-rush');T=Path('/tmp/gunman-forest-v18');OUT=T/'iterations-04.zip'
roots={
 'primary-all33':R/'build/region_bible_v2/forest-places-feedback/cb3d46ea94f14451af290ae459644b2b',
 'primary-all33-outer':R/'build/verification/harness/20261022T043156.273366Z',
 'app-golden04':T/'app-golden04',
 'app-fallen05':R/'build/region_bible_v2/app-fallen05',
 'library16':R/'build/region_bible_v2/forest-library-feedback/d4c1dfd72b3a4c9592b68d83bd9e716c',
 'library16-outer':R/'build/verification/harness/20261022T045955.531526Z',
 'journey05':R/'build/region_bible_v2/journey05',
}
files={}
for prefix,base in roots.items():
 if not base.is_dir():raise RuntimeError('missing '+str(base))
 for p in sorted(base.rglob('*')):
  if p.is_symlink():raise RuntimeError('symlink '+str(p))
  if p.is_file():files[prefix+'/'+p.relative_to(base).as_posix()]=p
for p in sorted(Path('/tmp').glob('forest-v18-*')):
 if p.is_file() and any(tag in p.name for tag in ('review33','audit33','review04','05','browser-')):files['independent/'+p.name]=p
for name in ('run-app-golden04.py','run-fallen05.py','run-journey05.py','primary-all33-post-termination-observer.json','archive04.py'):
 files['coordinator/'+name]=T/name
rows=[]
with zipfile.ZipFile(OUT,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for name,p in sorted(files.items()):
  data=p.read_bytes();z.writestr(name,data);rows.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
with zipfile.ZipFile(OUT) as z:
 assert len(z.infolist())==len(rows)
 for row in rows:
  data=z.read(row['path']);assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
index={'archive':OUT.name,'archive_bytes':OUT.stat().st_size,'archive_sha256':hashlib.sha256(OUT.read_bytes()).hexdigest(),'verification':'all full members read back and bytes/SHA matched; originals retained','members':rows}
(T/'iterations-04-index.json').write_text(json.dumps(index,indent=2)+'\n');print(json.dumps({k:v for k,v in index.items() if k!='members'}),len(rows))
