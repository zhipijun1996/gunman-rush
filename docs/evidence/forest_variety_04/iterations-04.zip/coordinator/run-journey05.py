from pathlib import Path
import sys,os,time,json,contextlib,hashlib
R=Path('/workspace/gunman-rush');O=R/'build/region_bible_v2/journey05';O.mkdir(exist_ok=False)
os.environ.update(GUNMAN_TOOLCHAIN_ROOT='/workspace/toolchains',OMP_NUM_THREADS='1',LP_NUM_THREADS='1');os.chdir(R);sys.path.insert(0,str(R/'tools'))
from run_tests import run_engine
from forest_bible_world_sources import inventory
from run_forest_exploration_contract import archive_sources,changed_sources,git
from run_forest_places_feedback import jobs_for_suite,validate_report
before=inventory(R);head=git('rev-parse','HEAD').decode().strip();(O/'source-before.json').write_text(json.dumps(before,sort_keys=True));saved=archive_sources(O/'source-snapshot-before',before,changed_sources());(O/'source-bytes-before.json').write_text(json.dumps({'baseline_head':head,'files':saved}));start=time.monotonic();r={'scope':'affected_fresh_formal_spawn_routes_only_not_full_core_or_CI','baseline_head':head,'exit_code':1,'checks':[],'native_cap_seconds':240,'whole_cap_seconds':600,'fixed_fps':60}
try:
 for name,script,extra,marker,cap in jobs_for_suite('core'):
  if name not in ('map1_normal','map2_normal'):continue
  p=O/(name+'.json');log=O/(name+'.log');args=['--headless','--path','.','--fixed-fps','60','--script',script,'--',*extra,'--output='+str(p)];t=time.monotonic();row={'id':name,'argv':['bash','tools/godot.sh',*args],'passed':False};r['checks'].append(row)
  with log.open('w') as f,contextlib.redirect_stdout(f):out=run_engine(args,min(cap,600-(time.monotonic()-start)))
  import re
  if len(re.findall(marker,out,re.M))!=1:raise RuntimeError('missing/nonunique native marker')
  validate_report(json.loads(p.read_text()),name,script,extra);row.update(passed=True,exit_code=0,seconds=time.monotonic()-t,report_sha256=hashlib.sha256(p.read_bytes()).hexdigest());(O/'receipt.json').write_text(json.dumps(r,indent=2))
 r['exit_code']=0
except Exception as e:r['error']=repr(e)
finally:
 after=inventory(R);(O/'source-after.json').write_text(json.dumps(after,sort_keys=True));r['source_stable']=before==after and head==git('rev-parse','HEAD').decode().strip()
 if not r['source_stable']:r['exit_code']=1
 r['seconds']=time.monotonic()-start;(O/'receipt.json').write_text(json.dumps(r,indent=2));print(json.dumps(r),flush=True)
