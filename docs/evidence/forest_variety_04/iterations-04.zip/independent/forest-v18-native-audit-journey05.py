import json,hashlib,subprocess
from pathlib import Path
R=Path('/workspace/gunman-rush/build/region_bible_v2/journey05');BASE='e594d3ff54daaf9d8f5e30f3190890737ce39a1e'
before=json.loads((R/'source-before.json').read_text());after=json.loads((R/'source-after.json').read_text());stored=json.loads((R/'source-bytes-before.json').read_text());assert stored['baseline_head']==BASE and before==after
for n,e in stored['files'].items():
 raw=(R/e['path']).read_bytes();assert len(raw)==e['bytes'] and hashlib.sha256(raw).hexdigest()==e['sha256']==before[n]
unchanged=sorted(set(before)-set(stored['files']));p=subprocess.Popen(['git','cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,cwd='/workspace/gunman-rush')
for n in unchanged:
 p.stdin.write((BASE+':'+n+'\n').encode());p.stdin.flush();h=p.stdout.readline().split();assert len(h)==3 and h[1]==b'blob';raw=p.stdout.read(int(h[2]));assert p.stdout.read(1)==b'\n';assert hashlib.sha256(raw).hexdigest()==before[n],n
p.stdin.close();p.wait();assert p.returncode==0
lib=Path('/workspace/gunman-rush/build/region_bible_v2/forest-library-feedback/d4c1dfd72b3a4c9592b68d83bd9e716c');assert before==json.loads((lib/'source-before.json').read_text())
s=Path('/tmp/forest-v18-native-audit11.py').read_text();exec(s[s.index('def intersection('):s.index('rows=[]')])
r=json.loads((R/'receipt.json').read_text());assert r['exit_code']==0 and r['source_stable'] is True and [c['id'] for c in r['checks']]==['map1_normal','map2_normal'];rows=[]
for c in r['checks']:
 raw=(R/(c['id']+'.json')).read_bytes();assert hashlib.sha256(raw).hexdigest()==c['report_sha256'];d=json.loads(raw);m=d['manifest'];fs=d['frames'];it=d['itinerary'];cs=d['completed'];ps={p['id']:p['rect'] for p in m['platforms']};fm={f['tick']:f for f in fs}
 assert d['passed'] is True and d['failures']==[] and d['scope']=='formal_spawn_actual_App_Router_Motor_no_position_or_resource_injection'
 assert 'fixture' not in d and 'initial_fixture_spawn_override' not in d and d['initial']['position']==m['spawn'] and d['manual_motor_step'] is False and d['midroute_injection'] is False and d['resource_override'] is False
 assert d['map_index']==int(c['id'][3]) and d['route']=='places_normal_journey' and d['seed']==f'forest-places-{d["map_index"]-1:02d}' and m['seed']==f'{d["seed"]}/thorn_forest/map_{d["map_index"]}' and m['layout_version']==d['layout']=='forest-exploration-places-v18'
 assert d['initial']['hook_enabled'] is True and d['initial']['double_enabled'] is False and d['initial']['wall_enabled'] is False
 assert expected_itinerary(m,d['route'])==it and len(cs)==len(it)>0 and len(fs)>0
 assert [f['tick'] for f in fs]==list(range(1,len(fs)+1)) and all(type(f['motor_steps']) is int and f['motor_steps']==1 and f['body'][2:]==[24,36] for f in fs)
 for i,e in enumerate(cs):
  assert e['leg']==i and e['edge_id']==it[i]['edge_id'] and all(full(fm[t],ps) for t in range(e['tick']-11,e['tick']+1))
 for e,leg in zip(cs,it):
  f=fm[e['tick']];target=leg['landing'];assert abs(f['position'][0]-target[0])<=7 and abs(f['position'][1]-target[1])<=2
  if leg.get('support_id'):assert all(leg['support_id'] in full(fm[t],ps) for t in range(e['tick']-11,e['tick']+1))
 assert any(e['edge_id'].startswith('places_fallen__') for e in it) and any(e['edge_id'].startswith('places_z__') for e in it)
 areas={a['id']:a['position'] for a in m['areas']};goal=areas[m['route_goals'][d['route']]];final=d['final']['position'];assert abs(final[0]-goal[0])<=7 and abs(final[1]-goal[1])<=2 and full(fs[-1],ps)
 doors=[]
 for i,leg in enumerate(it):
  if leg['edge_id'] not in ('places_z__crown_onward','places_backbranch__east_onward'):continue
  samples=[f for f in fs if f['leg']==i];doors.append(dict(edge=leg['edge_id'],frames=len(samples),x_first_last=[samples[0]['position'][0],samples[-1]['position'][0]],y_range=[min(f['position'][1] for f in samples),max(f['position'][1] for f in samples)]))
 rows.append(dict(id=c['id'],frames=len(fs),legs=len(cs),all_fullfoot12=True,formal_initial_no_fixture=True,HP_min=min(f['health'] for f in fs),HP_end=d['final']['health'],static_danger_contacts=sum(intersection(f['body'],a) for f in fs for a in m['dangers']),doors=doors,contains_new_places=True,final_goal=m['route_goals'][d['route']]))
out=dict(scope='independent affected formal-route recorded-fact audit only; not full core20/full80/CI/ART/FUN/timing',source_paths=len(before),changed_bytes_verified=len(stored['files']),unchanged_baseline_blobs_verified=len(unchanged),equal_library_runtime_inventory=True,source_stable=True,seconds=r['seconds'],rows=rows)
Path('/tmp/forest-v18-native-audit-journey05.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
