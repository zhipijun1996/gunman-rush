import ast, asyncio, argparse, re, sys, types, hashlib, json
from pathlib import Path
from unittest.mock import patch
import csv,io
p=Path('/workspace/gunman-rush/tools/verify_forest_browser.py')
source=p.read_text(); tree=ast.parse(source)
selected=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name in ('main','validate_assembled_layout','norm','locate_original')]
record=[]
async def verify(*args): record.append(args)
ns=dict(argparse=argparse,asyncio=asyncio,re=re,Path=Path,urlparse=__import__('urllib.parse',fromlist=['urlparse']).urlparse,__doc__='isolated pure Python review',verify=verify,subprocess=__import__('subprocess'),os=__import__('os'),csv=csv,io=io)
exec(compile(ast.Module(body=selected,type_ignores=[]),str(p),'exec'),ns)
base=['verify','http://localhost/','--output-dir','/tmp/never-created-browser-review','--expected-commit','a'*40,'--expected-build-id','b'*12]
results={}
for label,extra,expected in [('default',[],0),('candidate_missing_exact', ['--forest-places'],2),('candidate_wrong15',['--forest-places','--expected-forest-version','thorn-forest-region-v2','--expected-forest-layout','forest-bible-world-v15'],2),('candidate_missing_version',['--forest-places','--expected-forest-layout','forest-exploration-places-v18'],2),('candidate_exact18',['--forest-places','--expected-forest-version','thorn-forest-region-v2','--expected-forest-layout','forest-exploration-places-v18'],0)]:
 try:
  with patch.object(sys,'argv',base+extra): ns['main']()
  status=0
 except SystemExit as e: status=e.code
 assert status==expected,(label,status)
 results[label]={'exit':status,'arguments':list(record[-1][4:]) if status==0 else None}
for label,event,valid in [('real18',{'event':'region_assembled','layout_version':'forest-exploration-places-v18'},True),('old15',{'event':'region_assembled','layout_version':'forest-bible-world-v15'},False),('menuonly',{'event':'debug_entry','layout_version':'forest-exploration-places-v18'},False)]:
 try: ns['validate_assembled_layout'](event,'forest-exploration-places-v18'); got=True
 except AssertionError: got=False
 assert got==valid; results[label]={'accepted':got}
# OCR subprocess is synthetic TSV, not browser proof. Ensure the whole candidate label is demanded.
for label,words,valid in [('default_words',['THORN_FOREST','MAP','1'],False),('candidate_words',['FOREST','PLACES','MAP','1'],True),('wrong_map',['FOREST','PLACES','MAP','2'],False)]:
 tsv='text\tleft\ttop\twidth\theight\n'+''.join(f'{word}\t{i*20}\t10\t18\t12\n' for i,word in enumerate(words))
 with patch.object(ns['subprocess'],'run',return_value=types.SimpleNamespace(stdout=tsv)):
  try: ns['locate_original'](Path('/tmp/synthetic-not-image.png'),'FOREST PLACES MAP 1'); got=True
  except ValueError: got=False
 assert got==valid; results['OCR_'+label]={'accepted':got}
verify_node=next(n for n in tree.body if isinstance(n,ast.AsyncFunctionDef) and n.name=='verify')
cases_expr=next(n.value for n in ast.walk(verify_node) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='cases' for t in n.targets))
for flag in (False,True):
 result=eval(compile(ast.Expression(cases_expr),str(p),'eval'),{'forest_places':flag})
 assert result==((('thorn_forest',1),('thorn_forest',2)) if flag else (('plains',1),('plains',2),('thorn_forest',1),('thorn_forest',2)))
 results['cases_'+str(flag)]=result
results['source_sha256']=hashlib.sha256(p.read_bytes()).hexdigest()
Path('/tmp/forest-v18-browser-option-review.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
