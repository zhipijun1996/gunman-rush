import ast,asyncio,hashlib,json
from pathlib import Path
p=Path('/workspace/gunman-rush/tools/verify_forest_browser.py'); tree=ast.parse(p.read_text()); node=next(n for n in tree.body if isinstance(n,ast.AsyncFunctionDef) and n.name=='verify'); ns={'Path':Path}; exec(compile(ast.Module(body=[node],type_ignores=[]),str(p),'exec'),ns)
class ReachedFolder(Exception): pass
class Folder:
 def __init__(self): self.calls=0
 def mkdir(self,**kwargs): self.calls+=1; raise ReachedFolder()
rows=[]
for label,version,layout,expected in [('missing_both',None,None,'ValueError'),('wrong15','thorn-forest-region-v2','forest-bible-world-v15','ValueError'),('missing_version',None,'forest-exploration-places-v18','ValueError'),('wrong_v1','thorn-forest-region-v1','forest-exploration-places-v18','ValueError'),('exact18','thorn-forest-region-v2','forest-exploration-places-v18','ReachedFolder')]:
 f=Folder()
 try: asyncio.run(ns['verify']('http://unused',f,'a'*40,'b'*12,version,layout,False,True)); outcome='unexpected_success'
 except (ValueError,ReachedFolder) as e: outcome=type(e).__name__
 assert outcome==expected,(label,outcome)
 assert f.calls==(1 if expected=='ReachedFolder' else 0)
 rows.append({'label':label,'outcome':outcome,'folder_calls':f.calls})
report={'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'scope':'isolated direct API guard test, no folder writes/browser/engine','rows':rows}
Path('/tmp/forest-v18-browser-api-review.json').write_text(json.dumps(report,indent=2)+'\n'); print(json.dumps(report,indent=2))
