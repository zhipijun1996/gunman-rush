import json,hashlib,subprocess,math
from pathlib import Path
R=Path('/workspace/gunman-rush/build/region_bible_v2/forest-library-feedback/d4c1dfd72b3a4c9592b68d83bd9e716c');BASE='e594d3ff54daaf9d8f5e30f3190890737ce39a1e'
before=json.loads((R/'source-before.json').read_text());after=json.loads((R/'source-after.json').read_text());stored=json.loads((R/'source-bytes-before.json').read_text());assert stored['baseline_head']==BASE and before==after
for n,e in stored['files'].items():
 raw=(R/e['path']).read_bytes();assert len(raw)==e['bytes'] and hashlib.sha256(raw).hexdigest()==e['sha256']==before[n]
unchanged=sorted(set(before)-set(stored['files']));p=subprocess.Popen(['git','cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,cwd='/workspace/gunman-rush')
for n in unchanged:
 p.stdin.write((BASE+':'+n+'\n').encode());p.stdin.flush();h=p.stdout.readline().split();assert len(h)==3 and h[1]==b'blob';raw=p.stdout.read(int(h[2]));assert p.stdout.read(1)==b'\n';assert hashlib.sha256(raw).hexdigest()==before[n],n
p.stdin.close();p.wait();assert p.returncode==0
s=Path('/tmp/forest-v18-native-audit11.py').read_text();exec(s[s.index('def intersection('):s.index('rows=[]')])
receipt=json.loads((R/'receipt.json').read_text());assert receipt['exit_code']==0 and receipt['source_stable'] is True and len(receipt['checks'])==receipt['expected_job_count']==16
expected=['import','world','union']+[f'local_{k}_{v}_{r}' for v in [0,1] for k,r in [('z','reward_return'),('fallen','reward_return'),('back','main'),('back','retry')]]+['map1_z_reward','map2_fallen_reward','map2_back_reward','map1_z_failure','map2_z_failure']
assert [c['id'] for c in receipt['checks']]==expected==receipt['expected_job_ids']
rows=[]
for c in receipt['checks']:
 assert c['passed'] is True
 if not c.get('report'):assert c['id']=='import';continue
 raw=(R/c['report']).read_bytes();assert hashlib.sha256(raw).hexdigest()==c['report_sha256'];d=json.loads(raw)
 if c['id'] in ['world','union']:
  assert d['failures']==[];rows.append(dict(id=c['id'],assertions=d['assertions'],expansion_pairs=[(a['module_id'],a['variant']) for a in d.get('expansion_rows',[])]));continue
 fs=d['frames'];m=d['manifest'];assert fs and d['passed'] is True and d['manual_motor_step'] is False and d['midroute_injection'] is False and d['resource_override'] is False
 assert all(type(f['motor_steps']) is int and f['motor_steps']==1 for f in fs)
 assert [f['tick'] for f in fs]==list(range(1,len(fs)+1))
 if c['id'].startswith('local_'):
  _,name,v,route=c['id'].split('_',3);assert d['layout']=={'fallen':'fallen_trunk_two_faces','z':'z_descending_return','back':'backbranch_fruit_reversal'}.get(name,d['layout'])
  assert m['id']==d['layout'] and d['place_variant']==m['variant']==int(v) and d['route']==route and d['initial_fixture_spawn_override'] is True and d['reached'] is True
  if name=='fallen':assert m['version']=='forest-exploration-fallen-trunk-v18.3'
  ps={a['id']:a['rect'] for a in m['platforms']};fmap={f['tick']:f for f in fs}
  def localfoot(f,sid):
   x,y=f['position'];p=ps[sid];return f['grounded'] and x-12>=p[0]-.1 and x+12<=p[0]+p[2]+.1 and abs(y+18-p[1])<1
  steps=m['routes']['main'].get('steps',[])
  es=[e for e in d['events'] if e['kind']=='actual_ordinary_leg_complete']
  if m['routes']['main']['kind']=='ordinary_sequence':
   assert len(es)==len(steps)>0 and [e['step'] for e in es]==list(range(len(steps)))
   for e,step in zip(es,steps):
    assert e['stable_frames']>=12 and all(localfoot(fmap[t],step['support_id']) for t in range(e['tick']-12,e['tick']))
   air=[]
  else:
   assert [a['action'] for a in m['action_program']]==['H','R']
   air=[{k:e[k] for k in ('kind','tick','target','serial','direction') if k in e} for e in d['events'] if e['kind'] in ['hook_contact_kick','hook_kick','shot_fired']]
   assert [e['kind'] for e in air]==['hook_contact_kick','hook_kick','shot_fired'] and air[0]['target']==air[1]['target']==m['action_program'][0]['anchor'] and air[2]['serial']>0
   assert all(f['grounded'] and f['crown_support'] and localfoot(f,m['goal_support_id']) for f in fs[-12:])
  rows.append(dict(id=c['id'],frames=len(fs),version=m['version'],ordinary_steps=len(steps),all_fullfoot12_inferred_24x36=True,air_events=air,HP_min=min(f['health'] for f in fs),danger_contacts=d['danger_contacts']));continue
 assert d['map_index']==int(c['id'][3]) and d['route']=={'map1_z_reward':'places_z_reward_trial','map2_fallen_reward':'places_fallen_reward_trial','map2_back_reward':'places_backbranch_reward_trial','map1_z_failure':'places_z_failure_recovery_trial','map2_z_failure':'places_z_failure_recovery_trial'}[c['id']]
 assert d['layout']==m['layout_version']=='forest-exploration-places-v18' and d['seed']==f'forest-places-{d["map_index"]-1:02d}' and m['seed']==f'{d["seed"]}/thorn_forest/map_{d["map_index"]}'
 assert d['scope']=='initial_fixture_spawn_only_actual_App_no_midroute_or_resource_injection' and d['initial_fixture_spawn_override'] is True
 fixture=d['fixture'];areas={a['id']:a['position'] for a in m['areas']};required='places_z__failure' if c['id'].endswith('failure') else 'C'
 assert fixture['area']==required and fixture['motion_steps_before_override']==0 and fixture['resource_or_health_override'] is False and fixture['actual_fixture_spawn']==d['initial']['position']==areas[required] and fixture['original_formal_spawn']==m['spawn']
 assert d['initial']['hook_enabled'] is True and d['initial']['double_enabled'] is False and d['initial']['wall_enabled'] is False
 assert d['itinerary']==expected_itinerary(m,d['route']) and len(d['completed'])==len(d['itinerary'])>0
 ps={p['id']:p['rect'] for p in m['platforms']};fmap={f['tick']:f for f in fs}
 assert all(f['body'][2:]==[24,36] and abs(f['body'][0]+12-f['position'][0])<1e-7 and abs(f['body'][1]+18-f['position'][1])<1e-7 for f in fs)
 for i,e in enumerate(d['completed']):
  assert e['leg']==i and e['edge_id']==d['itinerary'][i]['edge_id'] and all(full(fmap[t],ps) for t in range(e['tick']-11,e['tick']+1))
 for e,leg in zip(d['completed'],d['itinerary']):
  f=fmap[e['tick']];target=leg['landing'];assert abs(f['position'][0]-target[0])<=7 and abs(f['position'][1]-target[1])<=2
  if leg.get('support_id'):assert all(leg['support_id'] in full(fmap[t],ps) for t in range(e['tick']-11,e['tick']+1))
 goal=areas[m['route_goals'][d['route']]];final=d['final']['position'];assert abs(final[0]-goal[0])<=7 and abs(final[1]-goal[1])<=2 and full(fs[-1],ps)
 tx=[]
 for t in d['reward_transactions']:
  reward=next(r for r in m['rewards'] if r['id']==t['claim_id']);assert reward['approach_route']==d['route'];delta=[t['after']['coins']-t['before']['coins'],t['after']['notes']-t['before']['notes']];allowed=[[r['amount'],0] if r['kind']=='coin' else [0,r['amount']] for r in reward['resources']];assert delta in allowed and t['duplicate_before']==t['duplicate_after'] and t['before']['items']==t['after']['items']
  claim=f'thorn_forest/map_{d["map_index"]}/{t["claim_id"]}';assert not t['before']['claimed'].get(claim,False) and t['after']['claimed'][claim] is True
  assert len(d['modal_frames'])>=5 and all(f['paused'] for f in d['modal_frames']) and len({f['motion_steps'] for f in d['modal_frames']})==1
  press,release=d['pointer_events'];assert press['kind']=='mouse_button_press' and release['kind']=='mouse_button_release' and press['button_text']==release['button_text'] and press['position']==release['position']
  tx.append(dict(claim=t['claim_id'],tick=t['tick'],delta=delta,duplicate_unchanged=True))
 assert len(tx)==(0 if c['id'].endswith('failure') else 1)
 recovery=[]
 if c['id'].endswith('failure'):
  names=['places_recovery_actual_grounded_departure','places_recovery_in_range_hook_intent','places_recovery_actual_fixed_hang_observed','places_recovery_fixed_hang_jump_intent','places_recovery_actual_crown_shoulder_clear','places_recovery_actual_crown_arrival'];ev=[next(e for e in d['events'] if e['kind']==n) for n in names];start,cast,hang,kick,shoulder,arrive=ev
  assert start['tick']<cast['tick']<hang['tick']<kick['tick']<shoulder['tick']<arrive['tick']
  assert len({e['target_instance'] for e in [start,cast,hang,kick,arrive]})==1 and hang['actual_hook_target_instance']==hang['target_instance']
  assert cast['distance']<=cast['actual_hook_range']==231 and cast['body_and_cast_corridor_clear'] is True and kick['previous_key_release_tick']==hang['tick']
  req=[(r['tick'],r['held']) for r in d['requests'] if r['kind']=='actual_keyboard_space'];assert all(a in req for a in [(start['tick'],True),(hang['tick'],False),(kick['tick'],True)])
  assert any(e['kind']=='jumped' and start['tick']<=e['tick']<cast['tick'] for e in d['events'])
  assert any(e['kind']=='jumped' and e['tick']==kick['tick'] for e in d['events']) and any(e['kind']=='hook_kick' and e['tick']==kick['tick'] and e['target']==start['anchor_id'] for e in d['events'])
  assert all(full(fmap[t],ps) for t in range(arrive['tick']-11,arrive['tick']+1))
  recovery=[dict(kind=e['kind'],tick=e['tick']) for e in ev]
 rows.append(dict(id=c['id'],route=d['route'],fixture=required,frames=len(fs),legs=len(d['completed']),actual_body24x36=True,all_completed_fullfoot12=True,HP_min=min(f['health'] for f in fs),HP_end=d['final']['health'],static_danger_contacts=sum(intersection(f['body'],a) for f in fs for a in m['dangers']),transactions=tx,recovery=recovery))
out={'scope':'independent production-source and recorded-native facts; wrapper author does not independently sign wrapper','source_paths':len(before),'changed_bytes_verified':len(stored['files']),'unchanged_baseline_blobs_verified':len(unchanged),'source_stable':True,'receipt_exit':receipt['exit_code'],'seconds':receipt['seconds'],'rows':rows}
Path('/tmp/forest-v18-native-audit-library05.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
