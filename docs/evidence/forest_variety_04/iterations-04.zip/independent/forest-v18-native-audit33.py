import json,hashlib,subprocess
from pathlib import Path
R=Path('/workspace/gunman-rush/build/region_bible_v2/forest-places-feedback/cb3d46ea94f14451af290ae459644b2b');BASE='e594d3ff54daaf9d8f5e30f3190890737ce39a1e'
before=json.loads((R/'source-before.json').read_text());stored=json.loads((R/'source-bytes-before.json').read_text())['files'];external=json.loads(Path('/tmp/gunman-forest-v18/primary-all33-post-termination-observer.json').read_text());assert external['runtime_source_after']==before
for n,entry in stored.items():
 if n not in before:continue
 assert hashlib.sha256((R/entry['path']).read_bytes()).hexdigest()==before[n]
unchanged=[n for n in before if n not in stored];p=subprocess.Popen(['git','cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE)
for n in unchanged:
 p.stdin.write((BASE+':'+n+'\n').encode());p.stdin.flush();h=p.stdout.readline().split();assert len(h)==3 and h[1]==b'blob';b=p.stdout.read(int(h[2]));assert p.stdout.read(1)==b'\n';assert hashlib.sha256(b).hexdigest()==before[n],n
p.stdin.close();p.wait();assert p.returncode==0
# Reuse this independent audit's geometric helpers, not the production wrapper.
s=Path('/tmp/forest-v18-native-audit11.py').read_text();exec(s[s.index('def intersection('):s.index('rows=[]')])
receipt=json.loads((R/'receipt.json').read_text());rows=[]
for check in receipt['checks']:
 if not check.get('passed') or not check.get('report'):continue
 data_path=R/check['report'];assert hashlib.sha256(data_path.read_bytes()).hexdigest()==check['report_sha256'];d=json.loads(data_path.read_text())
 if check['id'].startswith('local_'):
  assert all(type(f['motor_steps']) is int and f['motor_steps']==1 for f in d['frames'])
  if d['manifest']['routes']['main']['kind']=='airborne_chain':
   events=[{k:e[k] for k in ('kind','tick','target','serial','direction') if k in e} for e in d['events'] if e['kind'] in ('hook_contact_kick','hook_kick','shot_fired')]
   rows.append(dict(id=check['id'],scope='local_air_input_only',frames=len(d['frames']),events=events))
  continue
 if not check['id'].startswith('map'):continue
 fs=d['frames'];m=d['manifest'];it=d['itinerary'];cs=d['completed'];platforms={p['id']:p['rect'] for p in m['platforms']};fm={f['tick']:f for f in fs}
 assert expected_itinerary(m,d['route'])==it
 assert len(cs)==len(it)>0
 assert all(type(f['motor_steps']) is int and f['motor_steps']==1 and f['body'][2:]==[24,36] for f in fs)
 for c in cs:
  assert c['edge_id']==it[c['leg']]['edge_id'];assert all(full(fm[t],platforms) for t in range(c['tick']-11,c['tick']+1))
 hazards=[(f['tick'],i) for f in fs for i,danger in enumerate(m['dangers']) if intersection(f['body'],danger)]
 tx=[{'id':t['claim_id'],'tick':t['tick'],'delta':[t['after']['coins']-t['before']['coins'],t['after']['notes']-t['before']['notes']],'duplicate_unchanged':t['duplicate_before']==t['duplicate_after']} for t in d['reward_transactions']]
 doors=[]
 for i,leg in enumerate(it):
  if leg['edge_id'] not in ('places_z__crown_onward','places_backbranch__east_onward'):continue
  samples=[f for f in fs if f['leg']==i]
  doors.append({'edge':leg['edge_id'],'frames':len(samples),'x_first_last':[samples[0]['position'][0],samples[-1]['position'][0]],'y_range':[min(f['position'][1] for f in samples),max(f['position'][1] for f in samples)]})
 rows.append(dict(id=check['id'],scope=d['scope'],frames=len(fs),completed=len(cs),all_fullfoot12=True,health_min=min(f['health'] for f in fs),health_final=d['final']['health'],static_hazard_contacts=hazards,transactions=tx,actual_door_crossings=doors))
out={'scope':'independent production/native-record fact audit only; no Godot, no self-signing wrapper; original33overall remains timeout/FAIL','source_paths':len(before),'stored_changed_files':len(stored),'baseline_files_verified':len(unchanged),'external_source_inventory_equal':True,'original_source_stable':receipt.get('source_stable'),'original_exit_code':receipt['exit_code'],'passed_checks':sum(c['passed'] for c in receipt['checks']),'rows':rows,'unexecuted':['map2_back_reward','map1_z_failure','map2_z_failure'],'timed_out':'map2_fallen_reward'}
Path('/tmp/forest-v18-native-audit33.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
