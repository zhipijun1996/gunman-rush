extends SceneTree
func _initialize() -> void: run.call_deferred()
func run() -> void:
 var app := DemoApp.new()
 app.meta_persistence_enabled=false
 root.add_child(app)
 var start: int=Time.get_ticks_usec()
 var ok: bool=app.start_debug_region(&"thorn_forest",1,"plains-ef9b74c58ef7a04256941ca06caddbe1",ThornForestRegionGenerator.DEPTH_VERSION,"forest-exploration-places-v18")
 print("APP_PERF start_debug_us=",Time.get_ticks_usec()-start," ok=",ok)
 for unused: int in 12: await physics_frame
 var assembled: bool=is_instance_valid(app.stage) and app.stage.assembly_ok
 print("APP_PERF actual_assembly_us=",Time.get_ticks_usec()-start," assembled=",assembled)
 await preload("res://tests/audio_teardown.gd").drain_world(app)
 app.free()
 quit(0 if ok and assembled else 1)
