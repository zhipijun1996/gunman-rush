from pathlib import Path
from PIL import Image
import json,hashlib,subprocess
R=Path('/workspace/gunman-rush');G=Path('/tmp/gunman-forest-v18/gpu-border09');rec=json.loads((G/'receipt.json').read_text());BASE=rec['baseline_head'];inventories={};countmeta={}
assert rec['exit_code']==0 and len(rec['passes'])==2
for state in ['before','after']:
 d=G/state;b=json.loads((d/'source-before.json').read_text());a=json.loads((d/'source-after.json').read_text());assert a==b;inventories[state]=b;meta=json.loads((d/'source-bytes-before.json').read_text());assert meta['baseline_head']==BASE
 for n,e in meta['files'].items():
  raw=(d/e['path']).read_bytes();assert len(raw)==e['bytes'] and hashlib.sha256(raw).hexdigest()==b[n]==e['sha256']
 countmeta[state]=len(meta['files'])
 p=subprocess.Popen(['git','cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,cwd=R)
 for n in sorted(set(b)-set(meta['files'])):
  p.stdin.write((BASE+':'+n+'\n').encode());p.stdin.flush();h=p.stdout.readline().split();assert len(h)==3 and h[1]==b'blob';raw=p.stdout.read(int(h[2]));assert p.stdout.read(1)==b'\n';assert hashlib.sha256(raw).hexdigest()==b[n],n
 p.stdin.close();p.wait();assert p.returncode==0
 matrix=json.loads((d/'matrix/result_gpu.json').read_text());assert matrix['gpu'] is True and matrix['cases']==5 and matrix['checks']==239910 and matrix['failures']==[]
 cap=json.loads((d/'capture.json').read_text());assert cap['failures']==[] and len(cap['rows'])==6
 for passed in rec['passes']:assert passed['source_stable'] is True and passed['exit_code']==0
changes=sorted(n for n in set(inventories['before'])|set(inventories['after']) if inventories['before'].get(n)!=inventories['after'].get(n));assert changes==['scripts/art/plains_terrain_borders.gd']
old=subprocess.check_output(['git','show',BASE+':scripts/art/plains_terrain_borders.gd'],cwd=R);assert hashlib.sha256(old).hexdigest()==inventories['before'][changes[0]]
for n in ['tests/underworld_plains/test_underworld_terrain.gd','scripts/underworld_plains/underworld_terrain.gd','scripts/underworld_plains/underworld_terrain.gdshader']:
 raw=subprocess.check_output(['git','show',BASE+':'+n],cwd=R);assert hashlib.sha256(raw).hexdigest()==inventories['before'][n]==inventories['after'][n]
comparisons=[]
for e in rec['comparisons']:
 n=e['image'];b=(G/'before'/n).read_bytes();a=(G/'after'/n).read_bytes();bs=hashlib.sha256(b).hexdigest();ass=hashlib.sha256(a).hexdigest();assert bs==e['before_sha256']==ass==e['after_sha256'];bi=Image.open(G/'before'/n).convert('RGBA');ai=Image.open(G/'after'/n).convert('RGBA');assert bi.size==ai.size and bi.tobytes()==ai.tobytes();comparisons.append({'image':n,'same_RGBA':True,'same_PNG_sha256':bs})
assert len(comparisons)==11
looked=['plains_map1_reference.png','map1_thorn_mouth.png','map2_thorn_elbow.png','matrix/golden_2.png']
out={'scope':'independent source closure + actual8 PNG views + offline11 RGBA pair checks; limited style-source rebind only','baseline':BASE,'source_paths':len(inventories['before']),'changed_snapshot_files_each':countmeta,'sole_before_after_difference':changes,'before_border_sha256':inventories['before'][changes[0]],'after_border_sha256':inventories['after'][changes[0]],'source_stable_both':True,'baseline_native_matrix_guards_and_renderer_unchanged':True,'native_matrix_each':{'cases':5,'checks':239910,'failures':[]},'actually_viewed_pairs':looked,'comparisons':comparisons,'decision':'ALLOW explicit versioned style-v4 rebind for equivalent boundary optimization only; do not sign v18 art or browser timeout'}
Path('/tmp/forest-v18-gpu-border09-independent.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k!='comparisons'},indent=2))
