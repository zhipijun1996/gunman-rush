from pathlib import Path
import json,hashlib,subprocess,random,math
R=Path('/workspace/gunman-rush');E=R/'build/region_bible_v2/border-equivalence08';before=json.loads((E/'source-before.json').read_text());after=json.loads((E/'source-after.json').read_text());meta=json.loads((E/'source-bytes-before.json').read_text());assert before==after
for n,e in meta['files'].items():assert hashlib.sha256((E/e['path']).read_bytes()).hexdigest()==before[n]==e['sha256']
old=subprocess.check_output(['git','show',meta['baseline_head']+':scripts/art/plains_terrain_borders.gd'],cwd=R);oracle=(E/'source-snapshot-before/tests/underworld_plains/terrain_borders_reference.gd').read_bytes();assert oracle==old.replace(b'class_name PlainsTerrainBorders',b'class_name TerrainBordersReference',1)
d=json.loads((E/'equivalence.json').read_text());receipt=json.loads((E/'receipt.json').read_text());assert receipt['exit_code']==0 and d['failures']==[] and d['worlds'] is True and d['assertions']==receipt['assertions']==sum(r['solids']+1 for r in d['rows'])+2
# Finite real arithmetic broad-phase property; not a substitute for Godot float/byte equivalence.
def occ(p,v,rs):
 return any((p[0]>r[0] and p[0]<=r[0]+r[2] if v[0]<0 else p[0]>=r[0] and p[0]<r[0]+r[2]) and (p[1]>r[1] and p[1]<=r[1]+r[3] if v[1]<0 else p[1]>=r[1] and p[1]<r[1]+r[3]) for r in rs)
def near(r,rs):return [o for o in rs if not(o[0]>r[0]+r[2] or o[0]+o[2]<r[0] or o[1]>r[1]+r[3] or o[1]+o[3]<r[1])]
rng=random.Random(60881);queries=0
for trial in range(80):
 rs=[tuple(rng.randint(-120,120)/8 for _ in range(2))+tuple(rng.randint(1,120)/8 for _ in range(2)) for _ in range(8)]
 rs += [(0,0,32,32),(32,0,32,32),(32,32,32,32)]
 for r in rs:
  for vertical,axis,lo,hi in [(True,r[0],r[1],r[1]+r[3]),(True,r[0]+r[2],r[1],r[1]+r[3]),(False,r[1],r[0],r[0]+r[2]),(False,r[1]+r[3],r[0],r[0]+r[2])]:
   cuts=sorted([lo,hi]+[v for o in rs for v in ([o[1],o[1]+o[3]] if vertical else [o[0],o[0]+o[2]]) if lo<v<hi]);values=cuts+[(a+b)/2 for a,b in zip(cuts,cuts[1:]) if a<b]
   for t in values:
    p=(axis,t) if vertical else (t,axis)
    for v in [(-1,0),(1,0),(0,-1),(0,1),(-1,-1),(1,-1),(-1,1),(1,1)]:
     assert occ(p,v,rs)==occ(p,v,near(r,rs));queries+=1
r=(0,0,32,32);touch=(32,0,32,32);assert occ((32,16),(1,0),[r,touch]) and not occ((32,16),(1,0),[r])
far=(999,11,40,12);globalcuts=sorted([0,60,far[1],far[1]+far[3]]);assert globalcuts==[0,11,23,60]
result={'scope':'independent read-only source proof and completed native-record audit; no engine/browser/art pass','oracle_exact_baseline_rename_only':True,'baseline':meta['baseline_head'],'source_before_after_equal':True,'stored_changed_file_hashes_verified':len(meta['files']),'native_assertions':d['assertions'],'native_cases':len(d['rows']),'native_failures':d['failures'],'native_worlds':d['rows'][-2:],'python_boundary_occupancy_queries':queries,'closed_touch_counterexample':{'point':[32,16],'direction':[1,0],'dropping_touching_solid_wrongly_exposes_right_face':True},'far_cut_counterexample':{'target':[0,0,40,60],'far_solid':far,'global_side_cuts':globalcuts},'limitations':['NaN/Inf fallback statically reviewed but absent native fixtures','final-geometry expected branch shares unchanged current merge/pieces composers; oracle freezes border plan only','style v3 bindings must be versioned/rebound explicitly after actual cross-region GPU','browser timeout fix not yet proven by these border timings']}
Path('/tmp/forest-v18-border08-independent.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
