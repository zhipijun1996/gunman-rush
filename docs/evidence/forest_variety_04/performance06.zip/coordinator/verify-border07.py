from pathlib import Path
import os,sys,json,time,contextlib
R=Path('/workspace/gunman-rush');O=R/'build/region_bible_v2/border-equivalence07';O.mkdir(exist_ok=False);os.chdir(R);sys.path.insert(0,str(R/'tools'));os.environ.update(GUNMAN_TOOLCHAIN_ROOT='/workspace/toolchains',OMP_NUM_THREADS='1',LP_NUM_THREADS='1')
from run_tests import run_engine
from forest_bible_world_sources import inventory
from run_forest_exploration_contract import archive_sources,changed_sources,git
with (O/'import.log').open('w') as log,contextlib.redirect_stdout(log):run_engine(['--headless','--path','.','--editor','--quit'],90)
before=inventory();head=git('rev-parse','HEAD').decode().strip();(O/'source-before.json').write_text(json.dumps(before,sort_keys=True));files=archive_sources(O/'source-snapshot-before',before,changed_sources());(O/'source-bytes-before.json').write_text(json.dumps({'baseline_head':head,'files':files}));t=time.monotonic();r={'exit_code':1,'scope':'full_ordered_reference_equivalence_and_affected_native_terrain_checks_not_gameplay_or_ART'}
try:
 for label,args,cap in [('equivalence',['--headless','--path','.','--fixed-fps','60','--script','tests/underworld_plains/test_terrain_border_equivalence.gd','--','--world','--output='+str(O/'equivalence.json')],240),('terrain',['--headless','--path','.','--script','tests/underworld_plains/test_underworld_terrain.gd'],120)]:
  with (O/(label+'.log')).open('w') as log,contextlib.redirect_stdout(log):run_engine(args,cap)
 data=json.loads((O/'equivalence.json').read_text());assert data['assertions']>0 and data['failures']==[] and data['worlds'] is True
 r.update(exit_code=0,assertions=data['assertions'])
except Exception as e:r['error']=repr(e)
after=inventory();(O/'source-after.json').write_text(json.dumps(after,sort_keys=True));r['source_stable']=before==after and head==git('rev-parse','HEAD').decode().strip()
if not r['source_stable']:r['exit_code']=1
r['seconds']=time.monotonic()-t;(O/'receipt.json').write_text(json.dumps(r,indent=2));print(json.dumps(r),flush=True)
