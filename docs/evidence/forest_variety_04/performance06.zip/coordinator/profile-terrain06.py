from pathlib import Path
import sys,os,json,contextlib,time,shutil
P=Path('/workspace/gunman-rush');R=Path('/tmp/gunman-forest-v18/runtime');O=Path('/tmp/gunman-forest-v18/perf06');O.mkdir(exist_ok=False);sys.path.insert(0,str(P/'tools'));from forest_bible_world_sources import inventory
src=inventory(P);old=inventory(R)
for name in set(old)-set(src):(R/name).unlink()
for name,h in src.items():
 if old.get(name)!=h:
  (R/name).parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(P/name,R/name)
f=R/'scripts/underworld_plains/underworld_terrain.gd';s=f.read_text();s=s.replace('var node := UnderworldTerrain.new()','var perf_started: int = Time.get_ticks_usec()\n\tvar node := UnderworldTerrain.new()');s=s.replace('node.union_edges = plan.edges','print("TERRAIN_PERF plan_us=",Time.get_ticks_usec()-perf_started," solids=",solids.size()," pieces=",plan.pieces.size()," edges=",plan.edges.size())\n\tperf_started=Time.get_ticks_usec()\n\tnode.union_edges = plan.edges');s=s.replace('# Sum disjoint canonical pieces:','print("TERRAIN_PERF corners_us=",Time.get_ticks_usec()-perf_started)\n\tperf_started=Time.get_ticks_usec()\n\t# Sum disjoint canonical pieces:');s=s.replace('# Subtract those exact full cells','print("TERRAIN_PERF tilemap_us=",Time.get_ticks_usec()-perf_started)\n\tperf_started=Time.get_ticks_usec()\n\t# Subtract those exact full cells');s=s.replace('var texture := load(spec.source_texture)','print("TERRAIN_PERF boundary_us=",Time.get_ticks_usec()-perf_started," boundary=",node.boundary_pieces.size())\n\tperf_started=Time.get_ticks_usec()\n\tvar texture := load(spec.source_texture)');s=s.replace('\treturn node\n','\tprint("TERRAIN_PERF shader_setup_us=",Time.get_ticks_usec()-perf_started," nodes=",node.get_child_count())\n\treturn node\n',1);f.write_text(s)
script=R/'tests/perf_app_tmp.gd';script.write_text('''extends SceneTree
func _initialize() -> void: run.call_deferred()
func run() -> void:
 var app := DemoApp.new()
 app.meta_persistence_enabled=false
 root.add_child(app)
 var start: int=Time.get_ticks_usec()
 var ok: bool=app.start_debug_region(&"thorn_forest",1,"plains-ef9b74c58ef7a04256941ca06caddbe1",ThornForestRegionGenerator.DEPTH_VERSION,"forest-exploration-places-v18")
 print("APP_PERF start_debug_us=",Time.get_ticks_usec()-start," ok=",ok)
 await preload("res://tests/audio_teardown.gd").drain_world(app)
 app.free()
 quit(0 if ok else 1)
''')
os.chdir(R);os.environ.update(GUNMAN_TOOLCHAIN_ROOT='/workspace/toolchains',OMP_NUM_THREADS='1',LP_NUM_THREADS='1');sys.path.insert(0,str(R/'tools'));from run_tests import run_engine
with (O/'import.log').open('w') as log,contextlib.redirect_stdout(log):run_engine(['--headless','--path','.','--editor','--quit'],90)
before=inventory(R);(O/'source-before.json').write_text(json.dumps(before,sort_keys=True));shutil.copyfile(f,O/'underworld_terrain.instrumented.gd');shutil.copyfile(script,O/'perf_app_tmp.gd');t=time.monotonic();r={'scope':'isolated_profile_instrumented_timing_not_production_or_traversal','exit_code':1}
try:
 with (O/'native.log').open('w') as log,contextlib.redirect_stdout(log):out=run_engine(['--headless','--path','.','--fixed-fps','60','--script','tests/perf_app_tmp.gd'],240)
 r['exit_code']=0
except Exception as e:r['error']=repr(e)
after=inventory(R);(O/'source-after.json').write_text(json.dumps(after,sort_keys=True));r.update(source_stable=before==after,seconds=time.monotonic()-t);(O/'receipt.json').write_text(json.dumps(r,indent=2));print(json.dumps(r),flush=True)
