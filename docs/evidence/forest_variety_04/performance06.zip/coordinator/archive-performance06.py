from pathlib import Path
import json,hashlib,shutil,zipfile
R=Path('/workspace/gunman-rush');T=Path('/tmp/gunman-forest-v18');out=R/'docs/evidence/forest_variety_04';base=json.loads((R/'build/region_bible_v2/web-prototype06/source-before.json').read_text())
for label in ('perf06','perf07','perf08'):
 folder=T/label;before=json.loads((folder/'source-before.json').read_text());special={'scripts/underworld_plains/underworld_terrain.gd':folder/'underworld_terrain.instrumented.gd','tests/perf_app_tmp.gd':folder/'perf_app_tmp.gd','tests/perf_app_tmp.gd.uid':folder/'perf_app_tmp.gd.uid'};files={}
 for name,h in before.items():
  if base.get(name)==h:continue
  candidates=[special.get(name),R/name,R/'build/region_bible_v2/border-equivalence07/source-snapshot-before'/name,R/'build/region_bible_v2/border-equivalence08/source-snapshot-before'/name]
  p=next((p for p in candidates if p is not None and p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()==h),None)
  if p is None:raise RuntimeError('missing exact profile bytes '+label+'/'+name)
  target=folder/'source-snapshot-before'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target);files[name]={'path':str(target.relative_to(folder)),'sha256':h,'bytes':target.stat().st_size}
 (folder/'source-bytes-before.json').write_text(json.dumps({'baseline_head':'a6e7cfb4c9b50b22a4a643afcb98fbe7550d5d64','files':files,'method':'External exact-byte reconstruction closure; original profiling receipt/logs unchanged'},indent=2)+'\n')
roots={'web-success06':R/'build/region_bible_v2/web-prototype06','browser-failed06':R/'build/region_bible_v2/browser-candidate06','perf06':T/'perf06','perf07':T/'perf07','perf08':T/'perf08','border-failed07':R/'build/region_bible_v2/border-equivalence07','border08':R/'build/region_bible_v2/border-equivalence08','gpu-border09':T/'gpu-border09'};files={}
for label,folder in roots.items():
 for p in sorted(folder.rglob('*')):
  if p.is_file():assert not p.is_symlink();files[label+'/'+p.relative_to(folder).as_posix()]=p
for name in ('profile-terrain06.py','profile-terrain07.py','profile-terrain08.py','verify-border07.py','verify-border08.py','gpu-border09.py','archive-performance06.py'):files['coordinator/'+name]=T/name
for p in Path('/tmp').glob('forest-v18-*'):
 if p.is_file() and ('border08-independent' in p.name or 'gpu-border09-independent' in p.name):files['independent/'+p.name]=p
for name in ('browser-candidate06.console.log','style-v3-drift07.json','underworld-wrapper08.log'):files['observations/'+name]=R/'build/region_bible_v2'/name
files['observations/preserved-web06-core-index.json']=R/'build/region_bible_v2/preserved-web06/preservation.json'
a=out/'performance06.zip';rows=[]
with zipfile.ZipFile(a,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for name,p in sorted(files.items()):
  data=p.read_bytes();z.writestr(name,data);rows.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
with zipfile.ZipFile(a) as z:
 for row in rows:
  data=z.read(row['path']);assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
(out/'performance06-index.json').write_text(json.dumps({'archive':a.name,'archive_bytes':a.stat().st_size,'archive_sha256':hashlib.sha256(a.read_bytes()).hexdigest(),'verification':'All full members read back against original lengths/SHA; originals retained','members':rows},indent=2)+'\n')
for src,dst in [(T/'gpu-border09/receipt.json','gpu-border09-receipt.json'),(R/'build/region_bible_v2/border-equivalence08/receipt.json','border08-receipt.json'),(R/'build/region_bible_v2/web-prototype06/receipt.json','web06-receipt.json'),(R/'build/region_bible_v2/browser-candidate06/report.json','browser-failed06-report.json'),(Path('/tmp/forest-v18-border08-independent.md'),'border08-independent.md'),(Path('/tmp/forest-v18-gpu-border09-independent.md'),'gpu-border09-independent.md')]:shutil.copyfile(src,out/dst)
print('performance archive',a.stat().st_size,'members',len(rows))
