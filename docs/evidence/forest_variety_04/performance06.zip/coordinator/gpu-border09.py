from pathlib import Path
import sys,os,json,shutil,subprocess,contextlib,time,hashlib
P=Path('/workspace/gunman-rush');R=Path('/tmp/gunman-forest-v18/runtime');O=Path('/tmp/gunman-forest-v18/gpu-border09');O.mkdir(exist_ok=False);sys.path.insert(0,str(P/'tools'));from forest_bible_world_sources import inventory
u=R/'tests/perf_app_tmp.gd.uid'
if u.exists():shutil.copyfile(u,Path('/tmp/gunman-forest-v18/perf08')/u.name)
primary=inventory(P);old=inventory(R)
for name in set(old)-set(primary):(R/name).unlink()
for name,h in primary.items():
 if old.get(name)!=h:(R/name).parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(P/name,R/name)
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=P,text=True).strip();old_border=subprocess.check_output(['git','show',base+':scripts/art/plains_terrain_borders.gd'],cwd=P);new_border=(P/'scripts/art/plains_terrain_borders.gd').read_bytes()
changed=set(subprocess.check_output(['git','diff','--name-only',base],cwd=P,text=True).splitlines())|set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=P,text=True).splitlines());changed={n for n in changed if n in primary}
os.chdir(R);os.environ.update(GUNMAN_TOOLCHAIN_ROOT='/workspace/toolchains',LIBGL_ALWAYS_SOFTWARE='1',OMP_NUM_THREADS='1',LP_NUM_THREADS='1');sys.path.insert(0,str(R/'tools'));from run_tests import run_engine
start=time.monotonic();summary={'scope':'actual_shared_Plains_Forest_static_composition_and_GPU_matrix_before_after_only','baseline_head':base,'exit_code':1,'passes':[]}
x=subprocess.Popen(['/workspace/gunman-rush/build/forest_revision04/display-final-W6/runtime/usr/bin/Xvfb','-displayfd','1','-screen','0','1280x720x24','-nolisten','tcp','-ac'],stdout=subprocess.PIPE,stderr=(O/'display.log').open('w'));os.environ['DISPLAY']=':'+x.stdout.readline().decode().strip()
try:
 for label,source in [('before',old_border),('after',new_border)]:
  out=O/label;out.mkdir();(R/'scripts/art/plains_terrain_borders.gd').write_bytes(source)
  with (out/'import.log').open('w') as log,contextlib.redirect_stdout(log):run_engine(['--headless','--path','.','--editor','--quit'],min(90,600-(time.monotonic()-start)))
  before=inventory(R);(out/'source-before.json').write_text(json.dumps(before,sort_keys=True));files={}
  for name in sorted(changed):
   target=out/'source-snapshot-before'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/name,target);files[name]={'path':str(target.relative_to(out)),'bytes':target.stat().st_size,'sha256':hashlib.sha256(target.read_bytes()).hexdigest()};assert files[name]['sha256']==before[name]
  (out/'source-bytes-before.json').write_text(json.dumps({'baseline_head':base,'files':files}));t=time.monotonic()
  with (out/'app.log').open('w') as log,contextlib.redirect_stdout(log):result=run_engine(['--path','.','--rendering-method','gl_compatibility','--audio-driver','Dummy','--fixed-fps','60','--script','tests/forest_bible_golden_runner.gd','--','--output='+str(out),'--compare-plains','--thorn-only'],min(120,600-(time.monotonic()-start)))
  assert 'FOREST BIBLE GOLDEN: 6 images / 0 failures' in result
  with (out/'matrix.log').open('w') as log,contextlib.redirect_stdout(log):result=run_engine(['--path','.','--rendering-method','gl_compatibility','--audio-driver','Dummy','--fixed-fps','60','--script','tests/underworld_plains/test_underworld_terrain.gd','--','--gpu'],min(120,600-(time.monotonic()-start)))
  assert '"failures":[]' in result
  shutil.copytree(R/'build/underworld_plains/terrain',out/'matrix')
  after=inventory(R);(out/'source-after.json').write_text(json.dumps(after,sort_keys=True));assert before==after
  summary['passes'].append({'label':label,'exit_code':0,'source_stable':True,'seconds':time.monotonic()-t})
 from PIL import Image
 comparisons=[]
 for a in sorted((O/'before').rglob('*.png')):
  name=a.relative_to(O/'before');b=O/'after'/name;assert b.is_file();ia=Image.open(a).convert('RGBA');ib=Image.open(b).convert('RGBA');assert ia.size==ib.size;aa=ia.tobytes();bb=ib.tobytes();diff=sum(aa[i:i+4]!=bb[i:i+4] for i in range(0,len(aa),4));comparisons.append({'image':str(name),'different_pixels':diff,'before_sha256':hashlib.sha256(a.read_bytes()).hexdigest(),'after_sha256':hashlib.sha256(b.read_bytes()).hexdigest()})
 summary['comparisons']=comparisons;assert len(comparisons)==11
 summary['exit_code']=0 if all(c['different_pixels']==0 for c in comparisons) else 1
except Exception as e:summary['error']=repr(e)
finally:
 x.terminate();x.wait(timeout=5);summary['seconds']=time.monotonic()-start;(O/'receipt.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary),flush=True)
