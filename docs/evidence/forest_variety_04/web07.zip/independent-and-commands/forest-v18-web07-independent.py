from pathlib import Path
import json,zipfile,hashlib,subprocess
R=Path('/workspace/gunman-rush');W=R/'build/region_bible_v2/web-prototype07';sha=lambda b:hashlib.sha256(b).hexdigest();receipt=json.loads((W/'receipt.json').read_text());p=json.loads((W/'package.json').read_text());assert receipt['exit_code']==0 and receipt['source_stable'] is True and all(c['exit_code']==0 for c in receipt['commands']);assert p['build_info']==receipt['build_info'];commit=receipt['source_commit'];assert commit=='263afd4fbdd535df6b4e80b1f4b584a05b55c7ea'
before=json.loads((W/'source-before.json').read_text());after=json.loads((W/'source-after.json').read_text());assert before==after
proc=subprocess.Popen(['git','cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,cwd=R)
for n,h in before.items():
 proc.stdin.write((commit+':'+n+'\n').encode());proc.stdin.flush();head=proc.stdout.readline().split();assert len(head)==3 and head[1]==b'blob';raw=proc.stdout.read(int(head[2]));assert proc.stdout.read(1)==b'\n';assert sha(raw)==h,n
proc.stdin.close();proc.wait();assert proc.returncode==0
archive=R/p['path'];assert archive.stat().st_size==p['bytes'] and sha(archive.read_bytes())==p['sha256'];files=p['files'];assert len({f['path'] for f in files})==len(files)==375
with zipfile.ZipFile(archive) as z:
 assert set(z.namelist())-{f['path'] for f in files}=={'README-试玩.txt'} and len(z.namelist())==376
 readme=z.read('README-试玩.txt');readme_hash=sha(readme);assert commit.encode() in readme and receipt['build_info']['build_id'].encode() in readme
 for f in files:
  raw=z.read(f['path']);assert len(raw)==f['bytes'] and sha(raw)==f['sha256']
 pack=z.read(receipt['build_info']['pack']);assert sha(pack)==receipt['pack_sha256'] and len(pack)==receipt['build_info']['pack_bytes']==141811380
 bundleinfo=json.loads(z.read('build-info.json'));assert bundleinfo==receipt['build_info']
old=R/'build/region_bible_v2/browser-candidate06/report.json';saved=R/'docs/evidence/forest_variety_04/browser-failed06-report.json';assert old.read_bytes()==saved.read_bytes();failed=json.loads(old.read_text());assert failed['status']=='failed' and 'Timeout 30000ms' in failed['failure']
pre={'scope':'independent local package/source closure readback, pending separate completed browser review','source_commit':commit,'build_id':receipt['build_info']['build_id'],'runtime_paths_verified_against_commit':len(before),'source_stable':True,'package_path':p['path'],'package_bytes':p['bytes'],'package_sha256':p['sha256'],'manifest_payload_members_read_back':len(files),'all_zip_members_read_back':len(files)+1,'extra_documentation_member':{'path':'README-试玩.txt','sha256':readme_hash},'PCK_bytes':len(pack),'PCK_sha256':sha(pack),'FAIL06_original_and_archived_equal':True,'FAIL06_report_sha256':sha(old.read_bytes())}
Path('/tmp/forest-v18-web07-package-independent.json').write_text(json.dumps(pre,indent=2)+'\n');print(json.dumps(pre,indent=2))
B=R/'build/region_bible_v2/browser-candidate07';report_path=B/'report.json';d=json.loads(report_path.read_text());assert d['status']=='passed' and d['errors']==[] and d['forest_places_candidate'] is True and d['expected_forest_layout']=='forest-exploration-places-v18' and d['expected_forest_version']=='thorn-forest-region-v2';assert d['source_commit']==d['expected_commit']==commit and d['build_id']==d['expected_build_id']==receipt['build_info']['build_id'] and d['pack_sha256']==receipt['pack_sha256']
expected=[f'{device}-thorn_forest-map{m}' for device in ['touch','mouse'] for m in [1,2]];assert [i['case'] for i in d['identities']]==expected and len(d['checks'])==12 and len(d['events'])==8
cases=[]
for item in d['identities']:
 case=item['case'];identity=item['identity'];assert identity=={'source_commit':commit,'build_id':receipt['build_info']['build_id'],'pack':receipt['build_info']['pack'],'pack_sha256':receipt['pack_sha256'],'pack_bytes':receipt['build_info']['pack_bytes']}
 device=case.split('-')[0];m=int(case[-1]);es=[e for e in d['events'] if e['device']==device and e['map_index']==m];assert [e['event'] for e in es]==['debug_entry','region_assembled'];entry,assembled=es;assert entry['natural_progression'] is False and entry['region']=='thorn_forest' and assembled['debug_entry'] is True and assembled['content_version']=='thorn-forest-region-v2' and assembled['layout_version']=='forest-exploration-places-v18' and assembled['abilities']==['grapple'] and assembled['seed']==f'{entry["seed"]}/thorn_forest/map_{m}' and len(assembled['manifest_hash'])==64
 boss='rootbell_guardian_v2' if m==1 else 'thorn_queen_canopy';assert assembled['boss_definition']==f'res://resources/bosses/{boss}.tres' and assembled['boss_scene']==f'res://scenes/bosses/{boss}.tscn'
 checks=[c for c in d['checks'] if c.startswith(case+':')];assert len(checks)==3 and any('pause and resume' in c for c in checks)
 for name in ['entry','pause-0','resumed']:assert (B/f'{case}-{name}.png').is_file()
 heading=json.loads((B/f'{case}-entry-actual-heading-receipt.json').read_text());assert heading['status']=='passed' and heading['match_count']==1 and heading['expected']==f'THORN FOREST {m}/2'
 cases.append({'case':case,'actual_layout':assembled['layout_version'],'manifest_hash':assembled['manifest_hash'],'actual_seed':assembled['seed'],'pause_resume_recorded':True,'complete_heading_OCR':True,'PCK_identity_equal':True})
looked=['touch-thorn_forest-map1-entry.png','touch-thorn_forest-map2-entry.png','mouse-thorn_forest-map1-resumed.png','mouse-thorn_forest-map2-resumed.png','touch-thorn_forest-map1-pause-0.png','mouse-thorn_forest-map2-pause-0.png']
out={**pre,'scope':'independent final local Web prototype delivery readback and completed actual GUI records; no engine/browser by reviewer','browser_status':'passed','browser_report_sha256':sha(report_path.read_bytes()),'browser_errors':d['errors'],'browser_cases':cases,'browser_checks':len(d['checks']),'actually_viewed_original_PNGs':{name:sha((B/name).read_bytes()) for name in looked},'limits':['explicit candidate debug entry only, not default forest15 replacement','no final art or whole-region FUN approval','no complete browser route/reward/Boss/next-region proof','emulated DOM touch, physical devices unverified','8–12/15–20 minute human timing unverified','local ZIP only, no new public deployment'],'FAIL06_retained':True}
Path('/tmp/forest-v18-web07-independent.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'browser_status':out['browser_status'],'cases':len(cases),'checks':len(d['checks']),'actually_viewed':len(looked),'report_sha256':out['browser_report_sha256']},indent=2))
