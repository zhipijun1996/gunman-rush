from pathlib import Path
import os,sys,subprocess,json,time,hashlib
R=Path('/workspace/gunman-rush');os.chdir(R);sys.path.insert(0,str(R/'tools'))
from forest_bible_world_sources import inventory
O=R/'build/region_bible_v2/web-prototype07';O.mkdir(exist_ok=False)
os.environ.update(GUNMAN_TOOLCHAIN_ROOT='/workspace/toolchains',OMP_NUM_THREADS='1',LP_NUM_THREADS='1')
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();before=inventory();expected=json.loads((R/'build/region_bible_v2/border-equivalence08/source-before.json').read_text()); delta={p for p in before.keys()|expected.keys() if before.get(p)!=expected.get(p)}; assert delta=={'tests/test_region_bible.py','tests/test_region_creative_direction.py'},str(delta); (O/'validated-source-delta.json').write_text(json.dumps({'baseline':'border-equivalence08/source-before.json','changed_only':sorted(delta),'scope':'same gameplay assets and GDScript; two explicit version tests covered by fresh six-check harness 20261022T055129.880429Z'},indent=2))
(O/'source-before.json').write_text(json.dumps(before,sort_keys=True));start=time.monotonic();receipt={'scope':'local_Web_prototype_only_not_published_or_full_region','source_commit':head,'commands':[],'exit_code':1}
try:
 for label,args,cap in [('build',['python3','tools/build.py','web'],360),('licenses',['python3','tools/style_exploration_delivery.py','licenses','--commit',head],60),('bundle',['python3','tools/style_exploration_delivery.py','check-bundle','--commit',head],60),('web-closure',['python3','tools/check_web_bundle.py','build/web'],120)]:
  t=time.monotonic()
  with (O/(label+'.log')).open('w') as f:r=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,timeout=cap)
  receipt['commands'].append({'argv':args,'exit_code':r.returncode,'seconds':time.monotonic()-t,'log':label+'.log'})
  if r.returncode:raise RuntimeError(label+' failed')
 info=json.loads((R/'build/web/build-info.json').read_text());assert info['source_commit']==head
 pack=R/'build/web'/info['pack'];digest=hashlib.sha256(pack.read_bytes()).hexdigest();assert digest[:12]==info['build_id'] and pack.stat().st_size==info['pack_bytes']
 receipt.update(exit_code=0,build_info=info,pack_sha256=digest)
except Exception as e:receipt['error']=repr(e)
finally:
 after=inventory();(O/'source-after.json').write_text(json.dumps(after,sort_keys=True));receipt['source_stable']=before==after and head==subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
 if not receipt['source_stable']:receipt['exit_code']=1
 receipt['seconds']=time.monotonic()-start;(O/'receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt),flush=True)
