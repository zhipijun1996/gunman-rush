extends SceneTree
## Offline Godot-only derivation of an upscaled AI study, never native AI output.
## No repaint, blur, topology edits, new crop recipe, or automatic visual approval.
const ROOT := "res://assets/forest_bible_v2/source/ai_bark_v18/"
const NATIVE := "res://assets/forest_bible_v2/native/"
const SHARED := "res://assets/underworld_plains/terrain/"
const SIZE := Vector2i(176,144)
var failures: Array[String] = []
var assertions := 0
var receipt: Dictionary = {"scope":"one offline derivative; actual GPU, art, FUN and device unverified","raw_return_is_native":false,"generation_model":"not_exposed","license":"unknown","outputs_written":false}

func _initialize() -> void:
	_run.call_deferred()

func _check(ok: bool, reason: String) -> bool:
	assertions += 1
	if not ok: failures.append(reason)
	return ok

func _load_rgba(path: String) -> Image:
	var image := Image.load_from_file(path)
	if not _check(image!=null and not image.is_empty(),"image_missing:"+path): return null
	if image.is_compressed():
		if not _check(image.decompress()==OK,"cannot_decompress:"+path): return null
	image.convert(Image.FORMAT_RGBA8)
	return image

func _run() -> void:
	var spec: Variant = JSON.parse_string(FileAccess.get_file_as_string(ROOT+"derivation-spec.json"))
	if not _check(spec is Dictionary,"missing_derivation_spec"): _finish(); return
	for path: String in spec.references:
		_check(FileAccess.get_sha256("res://"+path)==str(spec.references[path]),"reference_drift:"+path)
	_check(FileAccess.get_sha256(ROOT+"tool-output.original.png")==str(spec.raw_original_sha256),"raw_tool_output_drift")
	var raw := _load_rgba(ROOT+"tool-output.original.png")
	var v2 := _load_rgba(NATIVE+"bark_source_v2.png")
	var original := _load_rgba(SHARED+"source.png")
	var original_atlas := _load_rgba(SHARED+"terrain.png")
	var v2_atlas := _load_rgba(NATIVE+"bark_atlas47_v2.png")
	if raw==null or v2==null or original==null or original_atlas==null or v2_atlas==null:
		_finish(); return
	receipt.raw_return_size = [raw.get_width(),raw.get_height()]
	_check(v2.get_size()==SIZE and original.get_size()==SIZE,"existing_source_size")
	_check(raw.get_width()%SIZE.x==0 and raw.get_height()%SIZE.y==0,"raw_size_not_integral_native_scale")
	var scale_x := raw.get_width()/float(SIZE.x)
	var scale_y := raw.get_height()/float(SIZE.y)
	_check(scale_x==scale_y and scale_x>=1,"raw_nonuniform_or_invalid_scale")
	var recipe: Variant = JSON.parse_string(FileAccess.get_file_as_string(SHARED+"terrain_build.json"))
	if not _check(recipe is Dictionary and recipe.get("source_regions",{}).size()==47,"actual_original_47_recipe_missing") or not failures.is_empty():
		_finish(); return
	_check(_assemble(original,recipe).get_data()==original_atlas.get_data(),"unchanged_recipe_does_not_rebuild_shared_atlas_exactly")
	_check(_assemble(v2,recipe).get_data()==v2_atlas.get_data(),"unchanged_recipe_does_not_rebuild_retained_v2_atlas_exactly")
	var raw_data := raw.get_data()
	var base_data := v2.get_data()
	var sampled_data := PackedByteArray()
	sampled_data.resize(SIZE.x*SIZE.y*4)
	var derived_data := sampled_data.duplicate()
	var missing: Array = []
	var opaque_samples := 0
	for y: int in SIZE.y:
		for x: int in SIZE.x:
			# Sample the centre of the existing 8x8 (or other integral) cell,
			# not an interpolated/averaged colour or a shifted whole image.
			var sx := int((float(x)+0.5)*float(scale_x))
			var sy := int((float(y)+0.5)*float(scale_y))
			var src := (sy*raw.get_width()+sx)*4
			var dst := (y*SIZE.x+x)*4
			for c: int in 4:
				sampled_data[dst+c] = raw_data[src+c]
				derived_data[dst+c] = raw_data[src+c]
			# Preserve A byte-for-byte; RGB remains exactly the sampled tool
			# output. Missing RGB beneath old opaque pixels is a layout fail,
			# not permission to invent a patch or silently paint black there.
			derived_data[dst+3] = base_data[dst+3]
			if base_data[dst+3]>0:
				opaque_samples += 1
				if sampled_data[dst+3]==0: missing.append([x,y])
	var sampled := Image.create_from_data(SIZE.x,SIZE.y,false,Image.FORMAT_RGBA8,sampled_data)
	_check(sampled.save_png(ROOT+"cell-centre-study.derived.png")==OK,"cannot_save_diagnostic_study")
	receipt.sample_method = "integral-scale cell-centre nearest RGB; unchanged existing v2 alpha"
	receipt.scale = [scale_x,scale_y]
	receipt.original_nonzero_alpha_samples = opaque_samples
	receipt.missing_generated_rgb_under_original_alpha = missing
	_check(missing.is_empty(),"generated_layout_leaves_original_solid_texels_without_RGB")
	var derived := Image.create_from_data(SIZE.x,SIZE.y,false,Image.FORMAT_RGBA8,derived_data)
	var atlas := _assemble(derived,recipe)
	_check(_alpha(derived)==_alpha(v2),"source_alpha_changed")
	_check(_alpha(atlas)==_alpha(v2_atlas),"atlas_alpha_changed")
	if failures.is_empty():
		_check(derived.save_png(NATIVE+"bark_source_v18.png")==OK,"source_output_write_failed")
		_check(atlas.save_png(NATIVE+"bark_atlas47_v18.png")==OK,"atlas_output_write_failed")
		if failures.is_empty():
			receipt.outputs_written = true
			receipt.source_sha256 = FileAccess.get_sha256(NATIVE+"bark_source_v18.png")
			receipt.atlas_sha256 = FileAccess.get_sha256(NATIVE+"bark_atlas47_v18.png")
	_finish()

func _assemble(source: Image, recipe: Dictionary) -> Image:
	var atlas := Image.create(128,96,false,Image.FORMAT_RGBA8)
	atlas.fill(Color.TRANSPARENT)
	for mask: String in recipe.source_regions:
		var cell: Array = recipe.mask_to_atlas[mask]
		for part: Dictionary in recipe.source_regions[mask]:
			var s: Array = part.source
			var d: Array = part.destination
			var rect := Rect2i(int(s[0]),int(s[1]),int(s[2])-int(s[0]),int(s[3])-int(s[1]))
			var piece := source.get_region(rect)
			if bool(part.horizontal_flip): piece.flip_x()
			_check(piece.get_size()==Vector2i(int(d[2])-int(d[0]),int(d[3])-int(d[1])),"original_recipe_piece_size:"+mask)
			atlas.blit_rect(piece,Rect2i(Vector2i.ZERO,piece.get_size()),Vector2i(int(cell[0])*16+int(d[0]),int(cell[1])*16+int(d[1])))
	return atlas

func _alpha(image: Image) -> PackedByteArray:
	var rgba := image.get_data()
	var alpha := PackedByteArray()
	for i: int in range(3,rgba.size(),4): alpha.append(rgba[i])
	return alpha

func _finish() -> void:
	receipt.assertions = assertions
	receipt.failures = failures
	receipt.passed = failures.is_empty()
	FileAccess.open(ROOT+"derivation-receipt.json",FileAccess.WRITE).store_string(JSON.stringify(receipt,"\t"))
	print("FOREST AI BARK DERIVE: %s assertions, %s failures" % [assertions,failures.size()])
	quit(0 if failures.is_empty() else 1)
