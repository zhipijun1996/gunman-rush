class_name ForestBibleTerrainMaterial
extends RefCounted
## Forest material extension of the same 47-tile / exact-boundary family.
## Owns no geometry, collision, masks, neighbors, or shader implementation.
# The full13-mother brown v3 candidate was rejected in actual composition.
# Keep the established moss/edge clusters while refining local bark separately.
const SOURCE: Texture2D = preload("res://assets/forest_bible_v2/native/bark_source_v2.png")
const ATLAS: Texture2D = preload("res://assets/forest_bible_v2/native/bark_atlas47_v2.png")

static func install_on(terrain: UnderworldTerrain, candidate: bool = false) -> bool:
	if not is_instance_valid(terrain) or not is_instance_valid(terrain.core_layer): return false
	var source: Texture2D = SOURCE
	var texture: Texture2D = ATLAS
	if candidate:
		# An explicit v18-only trial; default/historical consumers retain v2.
		# A missing or mask-incompatible candidate is rejected, not hidden by
		# a fallback. The offline derivation retains tool output and recipe.
		var source_path := "res://assets/forest_bible_v2/native/bark_source_v18.png"
		var atlas_path := "res://assets/forest_bible_v2/native/bark_atlas47_v18.png"
		if not ResourceLoader.exists(source_path,"Texture2D") or not ResourceLoader.exists(atlas_path,"Texture2D"): return false
		source = load(source_path) as Texture2D
		texture = load(atlas_path) as Texture2D
		if source==null or texture==null: return false
	if source.get_size() != Vector2(176, 144) or texture.get_size() != Vector2(128, 96): return false
	if candidate and (not _same_alpha(source,SOURCE) or not _same_alpha(texture,ATLAS)): return false
	var original: TileSet = terrain.core_layer.tile_set
	if original == null or original.tile_size != Vector2i(16, 16): return false
	if not original.has_source(0) or not original.get_source(0) is TileSetAtlasSource: return false
	# Validate every adapter consumer before changing either material path.
	var adapters: Array[ColorRect] = []
	for child: Node in terrain.get_children():
		if not child is ColorRect: continue
		var quad := child as ColorRect
		if not quad.material is ShaderMaterial: return false
		var material := quad.material as ShaderMaterial
		if material.shader != UnderworldTerrain.SHADER: return false
		if material.get_shader_parameter("source_size") != Vector2(176, 144): return false
		adapters.append(quad)
	var tiles: TileSet = original.duplicate(true) as TileSet
	var atlas: TileSetAtlasSource = tiles.get_source(0) as TileSetAtlasSource
	atlas.texture = texture
	terrain.core_layer.tile_set = tiles
	for quad: ColorRect in adapters:
		var material: ShaderMaterial = quad.material.duplicate() as ShaderMaterial
		material.set_shader_parameter("source_pixels", source)
		quad.material = material
	return true

static func _same_alpha(first: Texture2D, second: Texture2D) -> bool:
	var a := first.get_image()
	var b := second.get_image()
	if a==null or b==null or a.get_size()!=b.get_size(): return false
	if a.is_compressed() and a.decompress()!=OK: return false
	if b.is_compressed() and b.decompress()!=OK: return false
	a.convert(Image.FORMAT_RGBA8)
	b.convert(Image.FORMAT_RGBA8)
	var left := a.get_data()
	var right := b.get_data()
	if left.size()!=right.size(): return false
	for i: int in range(3,left.size(),4):
		if left[i]!=right[i]: return false
	return true
