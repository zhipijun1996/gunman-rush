import json,zipfile,subprocess,hashlib,math
from pathlib import Path
R=Path('/tmp/gunman-forest-v18/round11'); O=Path('/tmp/forest-v18-native-audit11.json'); BASE='e594d3ff54daaf9d8f5e30f3190890737ce39a1e'
before=json.loads((R/'source-before.json').read_text());after=json.loads((R/'source-after.json').read_text()); closure=json.loads((R/'source-closure.json').read_text()); z=zipfile.ZipFile(R/'changed-source.zip')
errors=[]; assert before==after
changed=set(closure['changed_paths']); assert changed==set(z.namelist())
for n in changed:
 assert hashlib.sha256(z.read(n)).hexdigest()==before[n],n
# Independently hash every unchanged recorded runtime source from its exact Git baseline blob.
paths=[n for n in before if n not in changed]
p=subprocess.Popen(['git','cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE)
for n in paths:
 p.stdin.write((BASE+':'+n+'\n').encode());p.stdin.flush(); h=p.stdout.readline().split();assert len(h)==3 and h[1]==b'blob',(n,h)
 b=p.stdout.read(int(h[2]));assert p.stdout.read(1)==b'\n';assert hashlib.sha256(b).hexdigest()==before[n],n
p.stdin.close();p.wait();assert p.returncode==0

def intersection(a,b):
 return a[0]<b[0]+b[2]-1e-8 and b[0]<a[0]+a[2]-1e-8 and a[1]<b[1]+b[3]-1e-8 and b[1]<a[1]+a[3]-1e-8

def full(f,platforms):
 x,y,w,h=f['body']
 if not f['grounded']:return []
 return [s for s in f['supports'] if s in platforms and x>=platforms[s][0]-.1 and x+w<=platforms[s][0]+platforms[s][2]+.1 and abs(y+h-platforms[s][1])<1]

def expected_itinerary(m,r):
 out=[];edges={e['id']:e for e in m['connections']}
 for eid in m['routes'][r]:
  e=edges[eid]
  if e['kind']=='ordinary_sequence':
   for i,s in enumerate(e['steps']):
    s=s.copy();s.update(edge_id=eid,step_index=i)
    if i==0:
     for k in ['claim_before_edge','claim_area','claim_id']:
      if k in e:s[k]=e[k]
    out.append(s)
   out.append(dict(kind='walk',edge_id=eid,landing=e['path'][-1],step_index=len(e['steps']),b=e['b']))
  else:
   q=e.copy();q['edge_id']=eid;q['landing']=e.get('landing',e['path'][-1]);out.append(q)
   for i,s in enumerate(e.get('post_landing_steps',[])):
    s=s.copy();s.update(edge_id=eid,step_index=i,post_landing=True);out.append(s)
   if e['kind']=='hollow_recovery':out.append(dict(kind='walk',edge_id=eid,landing=e['path'][-1],post_recovery_align=True))
 return out
rows=[]
for name in ['map1-main','map1-reward','map1-outer','map2-main','map1-windows','map2-windows']:
 d=json.loads((R/(name+'.json')).read_text());m=d['manifest'];fs=d['frames'];it=d['itinerary'];cs=d['completed']; pfs={p['id']:p['rect'] for p in m['platforms']}; fm={f['tick']:f for f in fs};
 assert expected_itinerary(m,d['route'])==it,name+' unfaithful itinerary'
 assert d['manual_motor_step'] is False and d['midroute_injection'] is False and d['resource_override'] is False
 assert d['initial_fixture_spawn_override'] is True and d['fixture']['motion_steps_before_override']==0 and d['fixture']['area']=='C'
 assert d['initial']['double_enabled'] is False and d['initial']['wall_enabled'] is False and d['initial']['hook_enabled'] is True
 assert all(f['motor_steps']==1 for f in fs),name+' multimotor'
 assert all(f['body'][2:]==[24.0,36.0] for f in fs)
 assert all(abs(f['body'][0]+12-f['position'][0])<1e-8 and abs(f['body'][1]+18-f['position'][1])<1e-8 for f in fs)
 completed_bad=[];hold_bad=[]
 for i,c in enumerate(cs):
  assert c['leg']==i and c['edge_id']==it[i]['edge_id']
  f=fm.get(c['tick']);
  if not f or not full(f,pfs):completed_bad.append(i)
  window=[fm[t] for t in range(c['tick']-11,c['tick']+1) if t in fm]
  if len(window)!=12 or not all(full(f,pfs) for f in window):hold_bad.append(i)
 assert not completed_bad,(name,completed_bad)
 # Some source legs deliberately accept non-12-frame cavity/corridor transitions; report rather than assume.
 hazard_contacts=[];swept=[]
 for j,f in enumerate(fs):
  for di,danger in enumerate(m['dangers']):
   if intersection(f['body'],danger):hazard_contacts.append([f['tick'],di])
  if j:
   a=fs[j-1]['body'];b=f['body'];h=[min(a[0],b[0]),min(a[1],b[1]),max(a[0]+a[2],b[0]+b[2])-min(a[0],b[0]),max(a[1]+a[3],b[1]+b[3])-min(a[1],b[1])]
   for di,danger in enumerate(m['dangers']):
    if intersection(h,danger):swept.append([f['tick'],di])
 events=[e for e in d['events'] if e['kind']=='committed_damage']
 goals={a['id']:a['position'] for a in m['areas']};g=m['route_goals'][d['route']];final=d['final']['position'];goal_ok=abs(final[0]-goals[g][0])<=7 and abs(final[1]-goals[g][1])<=2 and bool(full(fs[-1],pfs))
 if d['passed']:assert len(cs)==len(it) and len(it)>0 and goal_ok
 tr=d['reward_transactions'];trs=[]
 for t in tr:
  delta=[t['after']['coins']-t['before']['coins'],t['after']['notes']-t['before']['notes']]
  assert delta in [[4,0],[0,1]] and t['duplicate_before']==t['duplicate_after']
  trs.append(dict(claim=t['claim_id'],tick=t['tick'],delta=delta,duplicate_unchanged=True))
 rows.append(dict(name=name,passed=d['passed'],frames=len(fs),ticks=[fs[0]['tick'],fs[-1]['tick']],itinerary=len(it),completed=len(cs),body=[24,36],all_motor_one=True,completed_fullfoot_invalid=completed_bad,completed_without_fullfoot12=hold_bad,goal=g,goal_ok=goal_ok,health_range=[min(f['health'] for f in fs),max(f['health'] for f in fs)],health_end=d['final']['health'],damage_events=events,static_danger_frame_contacts=hazard_contacts,static_swept_AABB_candidates=swept,reward_transactions=trs,modal_frames=len(d['modal_frames']),pointer_events=d['pointer_events'],failures=d['failures']))
result=dict(scope='offline independent source closure and exact native JSON analysis; no new Godot execution',source_paths=len(before),changed_paths=len(changed),baseline_paths_verified=len(paths),source_stable=True,rows=rows)
O.write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
