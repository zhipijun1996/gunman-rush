LAYOUT = 'forest-exploration-places-v18'
FORMAL_SCOPE = 'formal_spawn_actual_App_Router_Motor_no_position_or_resource_injection'
FIXTURE_SCOPE = 'initial_fixture_spawn_only_actual_App_no_midroute_or_resource_injection'
LOCAL_SCOPE = 'single_place_real_input_not_formal_map_or_FUN'


def _require(condition, reason):
    if not condition:
        raise ValueError(reason)


def _point(value):
    import math
    return (isinstance(value, list) and len(value) == 2
            and all(type(n) in (int, float) and math.isfinite(n) for n in value))


def _close(a, b, x=0.1, y=0.1):
    return _point(a) and _point(b) and abs(a[0]-b[0]) <= x and abs(a[1]-b[1]) <= y


def _full_support(frame, platforms):
    if frame.get('grounded') is not True:
        return False
    x, y, width, height = frame['body']
    return any(s in platforms and x >= platforms[s][0]-.1
               and x+width <= platforms[s][0]+platforms[s][2]+.1
               and abs(y+height-platforms[s][1]) < 1
               for s in frame.get('supports', []))


def _expand_itinerary(manifest, route):
    """Rebuild the actual Bible reader expansion, including its terminal walks."""
    edges = {edge['id']: edge for edge in manifest['connections']}
    _require(len(edges) == len(manifest['connections']), 'Duplicate world edge IDs')
    route_ids = manifest['routes'][route]
    _require(isinstance(route_ids, list) and route_ids, 'Empty requested world route')
    result = []
    for edge_id in route_ids:
        edge = edges[edge_id]
        if edge['kind'] == 'ordinary_sequence':
            _require(isinstance(edge['steps'], list) and edge['steps'], 'Empty ordinary edge')
            for index, authored in enumerate(edge['steps']):
                step = dict(authored, edge_id=edge_id, step_index=index)
                if index == 0:
                    step.update({key: edge[key] for key in ('claim_before_edge', 'claim_area', 'claim_id') if key in edge})
                result.append(step)
            result.append(dict(kind='walk', edge_id=edge_id, landing=edge['path'][-1],
                               step_index=len(edge['steps']), b=edge['b']))
        else:
            result.append(dict(edge, edge_id=edge_id, landing=edge.get('landing', edge['path'][-1])))
            result.extend(dict(step, edge_id=edge_id, step_index=index, post_landing=True)
                          for index, step in enumerate(edge.get('post_landing_steps', [])))
            if edge['kind'] == 'hollow_recovery':
                result.append(dict(kind='walk', edge_id=edge_id, landing=edge['path'][-1], post_recovery_align=True))
    return result


def _validate_reward(data, itinerary, choice_index):
    claims = {leg['claim_id'] for leg in itinerary if leg.get('claim_before_edge') is True}
    transactions = data['reward_transactions']
    _require(isinstance(transactions, list) and len(transactions) == len(claims)
             and {row['claim_id'] for row in transactions} == claims, 'Missing or duplicate actual reward transaction')
    rewards = {row['id']: row for row in data['manifest']['rewards']}
    for row in transactions:
        reward = rewards[row['claim_id']]
        selected = reward['resources'][choice_index]
        _require(selected['kind'] in ('coin', 'note') and type(selected['amount']) is int
                 and selected['amount'] > 0, 'Invalid actual OR resource choice')
        before, after = row['before'], row['after']
        for state in (before, after):
            _require(all(type(state[key]) is int and state[key] >= 0 for key in ('coins', 'notes')),
                     'Invalid actual reward balances')
        expected = (selected['amount'], 0) if selected['kind'] == 'coin' else (0, selected['amount'])
        _require((after['coins']-before['coins'], after['notes']-before['notes']) == expected,
                 'Reward did not settle the requested OR choice')
        claim_key = f"thorn_forest/map_{data['map_index']}/{row['claim_id']}"
        _require(not before['claimed'].get(claim_key, False)
                 and after['claimed'] == dict(before['claimed'], **{claim_key: True})
                 and before['items'] == after['items'], 'Reward claim state/items do not match actual OR settlement')
        _require(row['duplicate_before'] == after == row['duplicate_after'], 'Duplicate reward changed the full wallet')
        _require(type(row['tick']) is int and 1 <= row['tick'] <= data['frames'][-1]['tick'], 'Reward tick outside actual trace')
    if claims:
        modal = data['modal_frames']
        _require(len(modal) >= 5 and all(f['paused'] is True for f in modal)
                 and len({f['motion_steps'] for f in modal}) == 1, 'Actual paused reward modal proof missing')
        pointer = data['pointer_events']
        _require(len(pointer) == 2 and [e['kind'] for e in pointer] == ['mouse_button_press', 'mouse_button_release'],
                 'Actual reward pointer choice missing')
        _require(pointer[0]['position'] == pointer[1]['position'] and pointer[0]['button_text'] == pointer[1]['button_text'],
                 'Reward pointer did not click the same choice')
        for event in pointer:
            x, y, width, height = event['rect']
            _require(_point(event['position']) and x <= event['position'][0] <= x+width
                     and y <= event['position'][1] <= y+height, 'Reward pointer outside the choice button')


def validate_report(data, name, script, extra):
    """Reject partial/misbound native evidence; this does not evaluate FUN/art."""
    try:
        _validate_report(data, name, script, extra)
    except (KeyError, IndexError, TypeError) as error:
        raise ValueError('Malformed native report: '+str(error)) from error


def _validate_report(data, name, script, extra):
    _require(isinstance(data, dict), 'Native report must be an object')
    if name in ('world', 'union'):
        _require(data.get('failures') == [] and type(data.get('assertions')) is int
                 and data['assertions'] > 0, 'Missing or failed nonempty native assertions')
        if name == 'world':
            samples = data['samples']
            expected = {(m, f'forest-places-{i:02d}') for m in (1, 2) for i in range(10)}
            _require(len(samples) == 20 and {(s['map_index'], s['root_seed']) for s in samples} == expected,
                     'Actual 20-world structure/replay corpus missing')
            for sample in samples:
                _require(type(sample['map_index']) is int and sample['seed'] == f"{sample['root_seed']}/thorn_forest/map_{sample['map_index']}"
                         and type(sample['variant']) is int and sample['variant'] in (0, 1), 'World sample identity mismatch')
        else:
            _require(len(data['rows']) == 2 and {r['variant'] for r in data['rows']} == {0, 1}
                     and all(r['internal_edges'] == [] and type(r['solid_count']) is int and r['solid_count'] > 0
                             and type(r['edge_count']) is int and r['edge_count'] > 0 for r in data['rows']),
                     'Both nonempty real contour variants missing')
        return
    options = dict(arg[2:].split('=', 1) for arg in extra)
    route = options['route']
    frames = data['frames']
    _require(data.get('passed') is True and data.get('audio_released') is True
             and data.get('route') == route and isinstance(frames, list) and frames,
             'Missing, failed or wrong native route')
    _require(data.get('manual_motor_step') is False and data.get('midroute_injection') is False
             and data.get('resource_override') is False, 'Native pose/Motor/resource injection')
    _require(all(type(f.get('motor_steps')) is int and f['motor_steps'] == 1
                 and type(f.get('tick')) is int and f['tick'] == index+1 and _point(f.get('position'))
                 for index, f in enumerate(frames)), 'Actual contiguous single-Motor frames missing')
    manifest = data['manifest']
    if name.startswith('local_'):
        variant = int(options['place-variant'])
        _require(data['scope'] == LOCAL_SCOPE and data['layout'] == 'seven_bough_reveal'
                 and type(data['place_variant']) is int and data['place_variant'] == variant == manifest['variant']
                 and data.get('initial_fixture_spawn_override') is True and data.get('reached') is True
                 and data.get('failure') == '' and data.get('danger_contacts') == [], 'Local fixture identity or outcome mismatch')
        selected = manifest['routes'][route]
        _require(selected == manifest['routes']['main'] and selected['steps'], 'Local requested itinerary was replaced or empty')
        completed = [e for e in data['events'] if e.get('kind') == 'actual_ordinary_leg_complete']
        _require(len(completed) == len(selected['steps'])
                 and [e['step'] for e in completed] == list(range(len(selected['steps'])))
                 and all(e['stable_frames'] >= 12 for e in completed), 'Actual complete place itinerary missing')
        _require(_close(frames[0]['position'], manifest['spawn'], 1, 2)
                 and _close(completed[-1]['position'], manifest['goal'], 7, 2), 'Local departure/final goal mismatch')
        return
    map_index, seed = int(options['map']), options['seed']
    fixture = script == 'tests/forest_places_fixture_runner.gd'
    _require(script in ('tests/forest_places_fixture_runner.gd', 'tests/forest_places_motor_runner.gd'), 'Unexpected App evidence consumer')
    _require(data['scope'] == (FIXTURE_SCOPE if fixture else FORMAL_SCOPE) and data['layout'] == LAYOUT
             and manifest['layout_version'] == LAYOUT and data['seed'] == seed
             and type(data['map_index']) is int and data['map_index'] == map_index == manifest['map_index']
             and manifest['seed'] == f'{seed}/thorn_forest/map_{map_index}' and data.get('failures') == [], 'App layout/map/seed/scope mismatch')
    areas = {a['id']: a['position'] for a in manifest['areas']}
    initial = data['initial']
    _require(initial['hook_enabled'] is True and initial['double_enabled'] is False and initial['wall_enabled'] is False,
             'Initial capability snapshot is not S2-H')
    if fixture:
        info = data['fixture']
        area = options.get('fixture-area', 'C')
        _require(data.get('initial_fixture_spawn_override') is True and info['initial_fixture_spawn_override'] is True
                 and info['area'] == area and type(info['motion_steps_before_override']) is int
                 and info['motion_steps_before_override'] == 0 and info['resource_or_health_override'] is False
                 and _close(info['original_formal_spawn'], manifest['spawn'], 1, 2)
                 and _close(info['actual_fixture_spawn'], areas[area])
                 and _close(initial['position'], areas[area], 1, 2), 'Undeclared or late initial fixture spawn')
    else:
        _require(data.get('initial_fixture_spawn_override', False) is False and not data.get('fixture')
                 and _close(initial['position'], manifest['spawn'], 1, 2), 'Formal route secretly used a local fixture pose')
    itinerary = _expand_itinerary(manifest, route)
    completed = data['completed']
    _require(data['itinerary'] == itinerary and len(completed) == len(itinerary), 'Actual complete exact App itinerary missing')
    platforms = {p['id']: p['rect'] for p in manifest['platforms']}
    for frame in frames:
        body = frame['body']
        _require(isinstance(body, list) and len(body) == 4 and body[2:] == [24, 36]
                 and _close([body[0]+12, body[1]+18], frame['position']), 'Actual player body observation missing')
    for index, event in enumerate(completed):
        tick = event['tick']
        _require(type(tick) is int and 12 <= tick <= len(frames) and event['leg'] == index
                 and event['edge_id'] == itinerary[index]['edge_id']
                 and (index == 0 or tick > completed[index-1]['tick'])
                 and all(_full_support(f, platforms) for f in frames[tick-12:tick]), 'Actual full-foot completion proof missing')
    goal = areas[manifest['route_goals'][route]]
    _require(_close(data['final']['position'], goal, 7, 2)
             and _close(frames[-1]['position'], data['final']['position']), 'Actual final route goal missing')
    _validate_reward(data, itinerary, int(options.get('reward-index', 0)))
    if name.endswith('_reward'):
        _require('places_seven_backside_cache' in {r['claim_id'] for r in data['reward_transactions']},
                 'Requested reward route did not claim its actual cache')


