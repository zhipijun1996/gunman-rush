def _validate_local_air(data, selected):
    """Validate the intended native airborne program, not a fabricated walk log."""
    import math
    manifest, frames, events = data['manifest'], data['frames'], data['events']
    program = selected['action_program']
    _require(program == manifest['action_program'] and program
             and any(a['action'] == 'H' for a in program) and any(a['action'] == 'R' for a in program),
             'Actual nonempty H/R program missing')
    _require(not any(e.get('kind') == 'actual_ordinary_leg_complete' for e in events),
             'Ordinary completion events cannot prove an airborne program')
    contacts = [e for e in events if e.get('kind') == 'hook_contact_kick']
    shots = [e for e in events if e.get('kind') == 'shot_fired']
    _require(len(contacts) == sum(a['action'] == 'H' for a in program)
             and len(shots) == sum(a['action'] == 'R' for a in program), 'Actual H contacts or R shots missing/duplicated')
    _require(all(type(e['serial']) is int and e['serial'] > 0 for e in shots)
             and len({e['serial'] for e in shots}) == len(shots), 'Actual shot identity missing/duplicated')
    cursor, first_cast = 0, None
    for action in program:
        if action['action'] == 'H':
            actual = next((e for e in contacts if e['tick'] > cursor), None)
            _require(actual is not None and actual['target'] == action['anchor']
                     and actual.get('hook_used_at_event') is True, 'H contacted the wrong or absent real target')
            casts = [e for e in events if e.get('kind') == 'hook_cast' and cursor <= e['tick'] <= actual['tick']]
            pulls = [e for e in events if e.get('kind') == 'hook_pull' and cursor <= e['tick'] <= actual['tick']
                     and e.get('target') == action['anchor']]
            kicks = [e for e in events if e.get('kind') == 'hook_kick' and e['tick'] >= actual['tick']
                     and e.get('target') == action['anchor'] and e.get('hook_used_at_event') is False]
            _require(len(casts) == 1 and len(pulls) == 1 and kicks
                     and casts[0]['tick'] <= pulls[0]['tick'] <= actual['tick'] <= kicks[0]['tick'],
                     'Actual H cast/pull/contact/kick sequence missing')
            _require(any(r.get('kind') == 'grapple' and r.get('queued') is True
                         and cursor <= r['tick'] <= casts[0]['tick'] for r in data['requests']),
                     'Accepted H did not follow a real queued Router request')
            first_cast = casts[0]['tick'] if first_cast is None else first_cast
            cursor = kicks[0]['tick']
        elif action['action'] == 'R':
            actual = next((e for e in shots if e['tick'] > cursor), None)
            direction = action['direction']
            _require(_point(direction) and math.hypot(*direction) > 0, 'Invalid authored R direction')
            length = math.hypot(*direction)
            direction = [n/length for n in direction]
            _require(actual is not None and _close(actual['direction'], direction, .0001, .0001),
                     'Actual R shot direction/order mismatches the program')
            _require(any(r.get('kind') == 'shoot_release' and r.get('queued') is True
                         and cursor <= r['tick'] <= actual['tick']
                         and _close(r['direction'], direction, .0001, .0001) for r in data['requests']),
                     'Actual R shot has no matching queued Router request')
            cursor = actual['tick']
        else:
            _require(False, 'Unsupported airborne action')
    _require(type(frames[-1].get('program_index')) is int and frames[-1]['program_index'] == len(program),
             'Airborne action program did not finish')
    if manifest.get('chain_contract', {}).get('continuous_airborne') is True:
        _require(all(f['grounded'] is False for f in frames if first_cast <= f['tick'] <= cursor),
                 'Continuous airborne program landed before the last action')
    support_id = manifest['goal_support_id']
    goal_port = manifest['ports'][selected['to_port']]
    _require(support_id == 'crown' == goal_port['support_id']
             and _close(goal_port['position'], manifest['goal']), 'Airborne goal is not its actual crown receiving port')
    supports = {p['id']: p['rect'] for p in manifest['platforms']}
    _require(len(frames) >= 12, 'Actual airborne receiving observation missing')
    for frame in frames[-12:]:
        x, y = frame['position']
        sample = dict(frame, body=[x-12, y-18, 24, 36], supports=['crown'])
        _require(frame.get('crown_support') is True and _full_support(sample, supports, 'crown'),
                 'Actual final twelve full-foot crown frames missing')


