# Forest v18 topology candidate — current integration

Owned implementation: `scripts/generation/forest_exploration_network.gd` and `thorn_forest_region_v2_v18.gd`. Old v15 producer/default is retained. This report supersedes the initial optional-annex draft.

## Actual progression

The formal route retains old spawn/tutorial, actual selected camp→C route, C's real old right-step/optional elbow relay, new double-window, and seven-shaped reveal. Seven's true far foot continues to authored places; its near/failure western window still returns through the old backbranch/Weaver mouth to camp.

A joint-map stream uses the root seed (the actual `/thorn_forest/map_N` suffix is removed), chooses Z→fallen or fallen→Z, and inverts that choice for map2. Map2 first adds the backlook fruit branch. These are actual changed directed connections and physical placement sequences, not variant labels. Local depth/spacing variants do not count as new mechanisms.

The complete Boss factory sector, gate, practice frame and approach are rebuilt beyond the actual last exit. There is no forced reward gate or branch completion requirement.

## Physical seams

For each next authored place, read previous port support rect and raw entrance support rect. Position the new support's west edge 80wu east of the previous support's east edge, match actual standing heights, walk to previous east-24, ordinary jump 144wu to entrance west+40, then walk the actual entrance port. No support-filling generator or short-platform ladder is used.

Map2 fruit uses the author's real western-retry lip `west_entry[-424,94]`, not the entry platform behind its cache underside. `west_to_entry` is the actual walk→94wu jump→walk suffix through the existing side opening. Factory v18.4 further clears the low retry opening; its new union needs fresh proof.

## Real decisions and rewards

- Seven: upper crown to far root, optional inward cache 4coin OR1note, or near/west return to camp.
- Z: same observation pocket offers safe outer drop, inward left/right fold, or an additional outward/back thorn cache trip. Actual world cache is 6coin OR2note.
- Fallen: exposed fractured upper trunk versus sheltered interior and thorn cache; both leave through the low far heel. Actual world cache is 4coin OR1note. Missed fractures and inner gaps have authored actual exits.
- Map2 backbranch: resource-free ordinary forward route versus actual forward H + diagonal R landing behind on the higher branch; cache return goes to observed entry before onward. Actual world cache is 5coin OR2note. The actual low-root retry closes a cycle.

World resource claims use actual cache areas and mark only the first real returning edge for settlement. A factory card alone awards nothing.

## Z low-catch escape

Actual low port is not silently merged with the 224wu-higher exit. Route `places_z_failure_recovery_trial` walks the raw failure→failure_out route (496→416), then real `places_z_failure_align` back to failure496, followed by `places_z_fixed_hang_recovery` to the actual crown and all subsequent stages/Boss.

That edge has `places_fixed_hang_recovery=true`, real source/landing support IDs, actual anchor ID `places_z__z_exit_fruit`, and a source-derived path/landing. The world explicitly sets this existing rooted fruit's `hang_enabled=true`; the authored host remains unchanged. A real-input pilot must hold J until actual range231 is reached, aim H through x432..544 clear gap, observe that actual target hanging, release/press J and land with full feet on crown. No new catch floor is generated. Native verification is pending and owned by root.

## Honest limits

This is a candidate of chained choice places with real splits, rejoins and loops. It is not a fully woven region topology. The richer map1 rooted/map2 canopy identity is incremental. Native passing evidence for the earlier one-seven golden does not certify the new Z/fallen/fruit sequence or changed unions. New world input routes, all OR settlements, recovery, final Boss entry and shared-renderer GPU composition require fresh root runs.

Normal8–12min and thorough15–20min are human play targets, not measured or certified results. No coordinate length, automated tick total, module count, stream hash or successful traversal is used as FUN/timing proof. `production_pool=false`, `human_timing=unverified`, and region completion remains false.

## Round12 real-world output correction

Root's actual App traversal exposed two missed interfaces: Z crown672 was west of the eastern living root, and backbranch lower_return576 was west of its far tree. A broad support rect spanning both sides did not prove either horizontal walk. Existing local routes ended on the near shore; world continuation incorrectly assumed the full support was open.

The module authors changed real collision: Z18.7 has a96wu side window and `crown_onward` to true onward896; backbranch18.5 has a96wu eastern window and `east_onward` from near576 to far784. Network normal/reward/inner/recovery chains explicitly consume those source actions before generating the next module/Boss. The local backbranch retry loop stays on the near side. New unions require fresh world/native/GPU proof; old round12 failures are retained. The actual Z fixed-hang J/H/J recovery reached crown with12-frame full-foot evidence in round12, but then encountered the old Boss continuation wall, so it did not prove final completion.

Process correction: every world output must name the physically facing shore and include an actual authored final action to it. Source support identity and its overall bounding rectangle are insufficient evidence of continuous walkability.
