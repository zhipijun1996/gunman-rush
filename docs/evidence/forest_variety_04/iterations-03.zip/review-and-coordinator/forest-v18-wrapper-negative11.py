"""Read-only production audit: inject fake engine results into the exact round11 wrapper in /tmp.
No Godot, no project writes, no production modules imported.
"""
import sys,types,runpy,json,copy,tempfile,contextlib,io
from pathlib import Path
ROOT=Path('/tmp/forest-v18-wrapper-negative11');ROOT.mkdir(exist_ok=True)
source=Path('/tmp/forest-v18-round11-source/tools/run_forest_places_feedback.py')
for name in ['forest_bible_world_sources','run_forest_exploration_contract','run_tests']:
 sys.modules[name]=types.ModuleType(name)
sys.modules['forest_bible_world_sources'].inventory=lambda:{'fixture-only':'unchanged'}
c=sys.modules['run_forest_exploration_contract'];c.archive_sources=lambda *a:{};c.changed_sources=lambda:[];c.git=lambda *a:b'e594d3ff54daaf9d8f5e30f3190890737ce39a1e\n';c.save=lambda p,d:Path(p).write_text(json.dumps(d))
sys.modules['run_tests'].run_engine=lambda *a:''
ns=runpy.run_path(str(source),run_name='audit_wrapper');ns['main'].__globals__['ROOT']=ROOT
r=Path('/tmp/gunman-forest-v18/round11');local=json.loads(Path('/tmp/gunman-forest-v18/round06/v0-main.json').read_text());actual=json.loads((r/'map1-main.json').read_text());results=[]
for case in ['wrong_identity_real_nonempty','empty_itinerary','missing_reward_transaction','formal_uses_fixture_pose']:
 out=ROOT/'build'/case
 def engine(args,cap):
  if '--editor' in args:return ''
  s=args[args.index('--script')+1]
  target=next((a[len('--output=res://'):] for a in args if a.startswith('--output=res://')),None)
  if 'world_runner' in s:data=json.loads((r/'world.json').read_text());mark='FOREST PLACES WORLD: 165 assertions, 0 failures'
  elif 'union_runner' in s:data=json.loads((r/'union.json').read_text());mark='FOREST PLACES UNION: 2361 assertions, 0 failures'
  elif 'menu_runner' in s:return 'FOREST PLACES MENU: 1 assertions, 0 failures\n'
  elif 'exploration_place_runner' in s:data=local;mark='FOREST PLACE: PASS / copied_actual_local_main'
  else:
   data=copy.deepcopy(actual)
   # Keep real body frames and reports as the starting point. Each malformed case
   # changes only fields that the wrapper should bind, not native physics.
   if case=='empty_itinerary':data['completed']=[];data['itinerary']=[]
   if case=='missing_reward_transaction':data['reward_transactions']=[]
   if case=='formal_uses_fixture_pose':data['initial_fixture_spawn_override']=True
   mark='FOREST PLACES FIXTURE: PASS / copied_actual_route' if 'fixture_runner' in s else 'FOREST PLACES MOTOR: PASS / copied_actual_route'
  if target: (ROOT/target).write_text(json.dumps(data))
  return mark+'\n'
 ns['main'].__globals__['run_engine']=engine
 stdout=io.StringIO()
 with contextlib.redirect_stdout(stdout):code=ns['main'](['--output-dir',str(out)])
 receipt=json.loads((out/'receipt.json').read_text())
 results.append({'case':case,'wrapper_exit':code,'checks':len(receipt['checks']),'unexpected_acceptance':code==0,'stdout':stdout.getvalue().strip()})
 # These are synthetic duplicate copies, not evidence from engine. Retain tiny
 # receipt only; omit large copies whose bytes already exist in round11.
 for p in out.glob('*.json'):
  if p.name not in ['receipt.json','source-before.json','source-after.json','source-bytes-before.json']:p.unlink()
report={'scope':'exact round11 wrapper with mocked engine; NO Godot execution, NO production/source mutations; counterexample to report validator only','results':results}
Path('/tmp/forest-v18-wrapper-negative11.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
