from pathlib import Path
import sys,json,time,contextlib,os,subprocess,hashlib,zipfile
ROOT=Path('/tmp/gunman-forest-v18/runtime'); BASE=Path('/workspace/gunman-rush')
os.environ['GUNMAN_TOOLCHAIN_ROOT']='/workspace/toolchains';os.environ['OMP_NUM_THREADS']='1';os.environ['LP_NUM_THREADS']='1'
os.chdir(ROOT);sys.path.insert(0,str(ROOT/'tools'))
from run_tests import run_engine
from forest_bible_world_sources import inventory
out=Path('/tmp/gunman-forest-v18/round12');out.mkdir(exist_ok=False)
t=time.monotonic();r={'scope':'expanded_forest_actual_App_fixtures_local_native_not_FUN_or_human_time','baseline':'e594d3ff54daaf9d8f5e30f3190890737ce39a1e','import_cap':90,'native_cap':240,'whole_cap':600,'fixed_fps':60,'checks':[],'exit_code':1}
try:
 with (out/'import.log').open('w') as log,contextlib.redirect_stdout(log):run_engine(['--headless','--path','.','--editor','--quit'],90)
 before=inventory(ROOT);(out/'source-before.json').write_text(json.dumps(before,sort_keys=True))
 blobs={}
 for row in subprocess.check_output(['git','ls-tree','-r','-z',r['baseline']],cwd=BASE).split(b'\0'):
  if row:
   meta,path=row.split(b'\t',1);blobs[path.decode()]=meta.split()[2].decode()
 changed=[]
 with zipfile.ZipFile(out/'changed-source.zip','x',zipfile.ZIP_DEFLATED) as z:
  for path,sha in before.items():
   data=(ROOT/path).read_bytes();assert hashlib.sha256(data).hexdigest()==sha
   oid=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
   if blobs.get(path)!=oid:z.writestr(path,data);changed.append(path)
 (out/'source-closure.json').write_text(json.dumps({'baseline':r['baseline'],'source_paths':len(before),'changed_paths':changed,'unchanged':'exact baseline Git blobs','changed_bytes':'changed-source.zip'},indent=2))
 cases=[('world','tests/forest_places_world_runner.gd',[]),('union','tests/forest_places_union_runner.gd',[])]
 for mi in (1,2):
  seed='forest-places-00' if mi==1 else 'forest-places-01'
  for label,route,area in [('main','places_main_trial','C'),('z_failure','places_z_failure_recovery_trial','places_z__failure')]:
   cases.append((f'map{mi}_{label}','tests/forest_places_fixture_runner.gd',[f'--map={mi}','--seed='+seed,'--route='+route,'--fixture-area='+area]))
 for mi,label,route in [(1,'z_cache','places_z_reward_trial'),(2,'fallen_cache','places_fallen_reward_trial'),(2,'back_cache','places_backbranch_reward_trial')]:
  cases.append((f'map{mi}_{label}','tests/forest_places_fixture_runner.gd',[f'--map={mi}','--seed='+('forest-places-00' if mi==1 else 'forest-places-01'),'--route='+route,'--reward-index=1']))
 for name,script,extra in cases:
   row={'id':name,'passed':False};r['checks'].append(row)
   try:
    with (out/(name+'.log')).open('w') as log,contextlib.redirect_stdout(log):
     text=run_engine(['--headless','--fixed-fps','60','--path','.','--script',script,'--',*extra,'--output='+str(out/(name+'.json'))],min(240,600-(time.monotonic()-t)))
    data=json.loads((out/(name+'.json')).read_text());
    from run_forest_places_feedback import validate_report
    validate_report(data,name,script,extra)
    row.update(passed=(data.get('failures')==[] and (data.get('passed') is True or data.get('assertions',0)>0)),frames=len(data.get('frames',[])),failures=data.get('failures'))
   except Exception as e:row['error']=str(e)
   print(json.dumps(row),flush=True)
 after=inventory(ROOT);(out/'source-after.json').write_text(json.dumps(after,sort_keys=True));r['source_stable']=before==after
 r['exit_code']=0 if r['source_stable'] and all(x['passed'] for x in r['checks']) else 1
except Exception as e:r['error']=str(e)
r['seconds']=time.monotonic()-t;(out/'receipt.json').write_text(json.dumps(r,indent=2));print(json.dumps(r),flush=True)
