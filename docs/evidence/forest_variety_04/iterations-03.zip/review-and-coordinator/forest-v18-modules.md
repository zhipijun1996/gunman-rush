# v18 first place: seven_bough_reveal

Source: scripts/generation/forest_exploration_places.gd. Factory VERSION forest-exploration-places-v18.1. Bible SHA a7bad8323af64a7be0577132e5d988a6e1b781d9e1ac1639d37f9d65935194e3. This is candidate geometry, no Godot/motor/GPU run by the author. The Z/L/fallen-trunk entries are proposed cards only; build rejects them.

The authored tree forks across two real gaps, then bends down into a roof over a side-facing hollow. The ordinary upper route uses two full-held jumps. Optional fruits assist the same actual boughs without creating an ability gate. Crown onward is distinct from cache and lower return. Going around the far root nose reveals the hollow from its back, then a rooted 48wu thorn patch precedes the cache. The lower mouth exits to a different world destination. Both real low support feet need world connectivity; no local return to high entry is claimed.

The two structural variants belong to this one place, not two new fun mechanics. v0: first branch up48 then crown down32; v1: first branch down32 then crown up48. The second variant shifts the whole crown/root/hollow relation, deepens the far bay and cache, and changes actual gap approach/discovery order. Runtime seed diversity still requires regional module/topology differences, not just choosing these variants.

Important native counterexamples: the initial entry walk-off may leave through the low return, but should not reach the covered cache. The first bough fall lands on the real hollow roof; an early outer-bark approach is a legitimate alternative, not a reason to add a visited-counter gate. Check all two-jump phrases and the same-support cache thorn crossing without releasing jump early. The far bay is one-way, actual bark around its left mouth is solid; a driver must wait for natural falling past the root nose, never place the actor through the wall. The left/right lower feet have a 128wu real gap, reverse ordinary jump target separation176wu. Full body and all underside union pieces must be included in sweep review.

Ports v0: entry[-240,-18], crown/onward[672,-34], cache/reward[448,430], lower_return/return[-32,590], failure[960,590].
Ports v1: entry[-240,-18], crown/onward[576,-34], cache/reward[352,494], lower_return/return[-32,654], failure[960,654].

Every route is ordinary_sequence with explicit steps: main(entry→crown), outer(entry→lower_return), reward(entry→cache), returning(cache→lower_return), reward_return(entry→cache→lower_return), failure_to_return(failure→lower_return). The world owns real OR reward transactions; the factory does not award resources. No shot, physics, tuning or health overrides.

Root profile pieces are connected below the named standing surface, not an exposed upper staircase. Whether this actual silhouette expresses a natural root in the shared Underworld renderer is unverified until GPU review; metadata is not art acceptance. No new asset family and no BGM added.
