class_name ForestExplorationBark
extends RefCounted
## One v18 interior-material candidate. Shared terrain owns every outer pixel;
## these broken wood-fibre clusters stay eight wu inside actual solid union.
## Authored code/palette, no sampled prop, new texture, geometry or random stream.
const PIXEL := 2.0
const INSET := 8.0
const SHADES: Array[Color] = [Color("242a20"), Color("151f19"), Color("343b29"), Color("293423")]
static var _cached_hash := ""
static var _cached_marks: Array[Dictionary] = []

static func draw(canvas: Node2D, m: Dictionary) -> void:
	if m.get("layout_version") != "forest-exploration-places-v18": return
	var key := str(m.get("manifest_hash", ""))
	if key.is_empty(): return
	if key != _cached_hash:
		_cached_marks = _compile(m)
		_cached_hash = key
	for mark: Dictionary in _cached_marks:
		canvas.draw_rect(mark.rect, SHADES[int(mark.shade)])

static func _compile(m: Dictionary) -> Array[Dictionary]:
	var groups: Dictionary = {}
	for row: Dictionary in m.get("platforms", []):
		if bool(row.get("one_way", false)): continue
		var structure := str(row.get("structure_id", ""))
		if not structure.begins_with("places_"): continue
		if str(row.get("scene_kind", "")) not in ["root_earth", "living_bough", "hollow_bark"]: continue
		# Join the source primitive's bands before painting. A 16wu collision
		# slice is never a new grain origin or an outlined decoration tile.
		var family := structure+":"+str(row.get("surface_role", "")).get_slice("__", 0)
		if not groups.has(family): groups[family] = []
		var a: Array = row.rect
		groups[family].append(Rect2(float(a[0]),float(a[1]),float(a[2]),float(a[3])))
	var marks: Array[Dictionary] = []
	var keys: Array = groups.keys()
	keys.sort()
	for family: String in keys:
		var solids: Array = groups[family]
		var bounds: Rect2 = solids[0]
		for solid: Rect2 in solids: bounds = bounds.merge(solid)
		var upright := bounds.size.y > bounds.size.x*1.25
		var across := bounds.size.x if upright else bounds.size.y
		var along := bounds.size.y if upright else bounds.size.x
		for band: int in range(ceili(across/28.0)):
			for part: int in range(ceili(along/44.0)):
				if (part+band*2)%5 == 0: continue
				var u := float(part)*44.0+float(band%3)*8.0
				var v := float(band)*28.0+12.0+float(part%2)*4.0
				# Short, stepped fibre clusters: broad shadow, broken middle,
				# one two-wu light facet. No continuous bright standing line.
				var facets: Array = [[0,0,26,4,0],[2,4,16,4,1],[6,-2,14,2,2],[18,2,10,2,3],[-4,2,4,2,1]]
				for facet: Array in facets:
					var p := Vector2(u+float(facet[0]),v+float(facet[1]))
					var size := Vector2(float(facet[2]),float(facet[3]))
					if upright:
						p = Vector2(p.y,p.x)
						size = Vector2(size.y,size.x)
					var rect := Rect2((bounds.position+p).snapped(Vector2.ONE*PIXEL),size)
					# Test the full footprint plus margin against exact rectangles;
					# centre/corner tests alone could bridge a thin hole or seam.
					if _covered(rect.grow(INSET),solids):
						marks.append({"rect":rect,"shade":int(facet[4])})
	return marks

static func _covered(rect: Rect2, solids: Array) -> bool:
	var remaining: Array[Rect2] = [rect]
	for solid: Rect2 in solids:
		var next: Array[Rect2] = []
		for piece: Rect2 in remaining:
			var cut := piece.intersection(solid)
			if not cut.has_area():
				next.append(piece)
				continue
			if cut.position.y>piece.position.y:
				next.append(Rect2(piece.position,Vector2(piece.size.x,cut.position.y-piece.position.y)))
			if cut.end.y<piece.end.y:
				next.append(Rect2(Vector2(piece.position.x,cut.end.y),Vector2(piece.size.x,piece.end.y-cut.end.y)))
			if cut.position.x>piece.position.x:
				next.append(Rect2(Vector2(piece.position.x,cut.position.y),Vector2(cut.position.x-piece.position.x,cut.size.y)))
			if cut.end.x<piece.end.x:
				next.append(Rect2(Vector2(cut.end.x,cut.position.y),Vector2(piece.end.x-cut.end.x,cut.size.y)))
		remaining = next
		if remaining.is_empty(): return true
	return false
