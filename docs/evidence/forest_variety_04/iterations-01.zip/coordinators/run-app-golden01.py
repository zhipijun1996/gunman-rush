from pathlib import Path
import sys,os,time,contextlib,json,subprocess
R=Path('/tmp/gunman-forest-v18/runtime');O=Path('/tmp/gunman-forest-v18/app-golden01');O.mkdir(exist_ok=False)
os.environ.update(GUNMAN_TOOLCHAIN_ROOT='/workspace/toolchains',LIBGL_ALWAYS_SOFTWARE='1',OMP_NUM_THREADS='1',LP_NUM_THREADS='1');os.chdir(R);sys.path.insert(0,str(R/'tools'))
from run_tests import run_engine
from forest_bible_world_sources import inventory
before=inventory(R);(O/'source-before.json').write_text(json.dumps(before,sort_keys=True));t=time.monotonic();r={'exit_code':1,'scope':'actual_App_static_UI_composition_no_traversal_or_device'}
x=None
try:
 x=subprocess.Popen(['/workspace/gunman-rush/build/forest_revision04/display-final-W6/runtime/usr/bin/Xvfb','-displayfd','1','-screen','0','1280x720x24','-nolisten','tcp','-ac'],stdout=subprocess.PIPE,stderr=(O/'xvfb.log').open('w'))
 os.environ['DISPLAY']=':'+x.stdout.readline().decode().strip()
 with (O/'native.log').open('w') as log,contextlib.redirect_stdout(log):
  text=run_engine(['--path','.','--rendering-method','gl_compatibility','--audio-driver','Dummy','--fixed-fps','60','--script','tests/forest_places_golden_runner.gd','--','--output='+str(O)],240)
 r['exit_code']=0 if 'FOREST PLACES GOLDEN: 16 images / 0 failures' in text else 1
except Exception as e:r['error']=str(e)
finally:
 if x is not None:x.terminate();x.wait(timeout=5)
 after=inventory(R);(O/'source-after.json').write_text(json.dumps(after,sort_keys=True));r['source_stable']=before==after
 if not r['source_stable']:r['exit_code']=1
 r['seconds']=time.monotonic()-t;(O/'receipt.json').write_text(json.dumps(r,indent=2));print(json.dumps(r),flush=True)
