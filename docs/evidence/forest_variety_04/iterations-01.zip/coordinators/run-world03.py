from pathlib import Path
import sys,json,time,contextlib,os,subprocess,hashlib,zipfile
ROOT=Path('/tmp/gunman-forest-v18/runtime'); BASE=Path('/workspace/gunman-rush')
os.environ['GUNMAN_TOOLCHAIN_ROOT']='/workspace/toolchains';os.environ['OMP_NUM_THREADS']='1';os.environ['LP_NUM_THREADS']='1'
os.chdir(ROOT);sys.path.insert(0,str(ROOT/'tools'))
from run_tests import run_engine
from forest_bible_world_sources import inventory
out=Path('/tmp/gunman-forest-v18/round03');out.mkdir(exist_ok=False)
t=time.monotonic();r={'scope':'new_seven_place_isolated_input_only','baseline':'e594d3ff54daaf9d8f5e30f3190890737ce39a1e','import_cap':90,'native_cap':240,'whole_cap':600,'fixed_fps':60,'checks':[],'exit_code':1}
try:
 with (out/'import.log').open('w') as log,contextlib.redirect_stdout(log):run_engine(['--headless','--path','.','--editor','--quit'],90)
 before=inventory(ROOT);(out/'source-before.json').write_text(json.dumps(before,sort_keys=True))
 blobs={}
 for row in subprocess.check_output(['git','ls-tree','-r','-z',r['baseline']],cwd=BASE).split(b'\0'):
  if row:
   meta,path=row.split(b'\t',1);blobs[path.decode()]=meta.split()[2].decode()
 changed=[]
 with zipfile.ZipFile(out/'changed-source.zip','x',zipfile.ZIP_DEFLATED) as z:
  for path,sha in before.items():
   data=(ROOT/path).read_bytes();assert hashlib.sha256(data).hexdigest()==sha
   oid=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
   if blobs.get(path)!=oid:z.writestr(path,data);changed.append(path)
 (out/'source-closure.json').write_text(json.dumps({'baseline':r['baseline'],'source_paths':len(before),'changed_paths':changed,'unchanged':'exact baseline Git blobs','changed_bytes':'changed-source.zip'},indent=2))
 for name,script,extra in [
  ('world','tests/forest_places_world_runner.gd',[]),
  ('map1-main','tests/forest_places_fixture_runner.gd',['--map=1','--seed=forest-places-00','--route=places_main_trial']),
  ('map1-reward','tests/forest_places_fixture_runner.gd',['--map=1','--seed=forest-places-00','--route=places_reward_trial']),
  ('map2-main','tests/forest_places_fixture_runner.gd',['--map=2','--seed=forest-places-00','--route=places_main_trial'])]:
   row={'id':name,'passed':False};r['checks'].append(row)
   try:
    with (out/(name+'.log')).open('w') as log,contextlib.redirect_stdout(log):
     text=run_engine(['--headless','--fixed-fps','60','--path','.','--script',script,'--',*extra,'--output='+str(out/(name+'.json'))],min(240,600-(time.monotonic()-t)))
    data=json.loads((out/(name+'.json')).read_text());row.update(passed=(data.get('failures')==[] and (data.get('passed') is True or data.get('assertions',0)>0)),frames=len(data.get('frames',[])),failures=data.get('failures'))
   except Exception as e:row['error']=str(e)
   print(json.dumps(row),flush=True)
 after=inventory(ROOT);(out/'source-after.json').write_text(json.dumps(after,sort_keys=True));r['source_stable']=before==after
 r['exit_code']=0 if r['source_stable'] and all(x['passed'] for x in r['checks']) else 1
except Exception as e:r['error']=str(e)
r['seconds']=time.monotonic()-t;(out/'receipt.json').write_text(json.dumps(r,indent=2));print(json.dumps(r),flush=True)
