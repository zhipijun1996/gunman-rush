# Forest v18 topology proposal — 2026-10-22

Scope: source review and implementation design only. No Godot, no new physical/art/time acceptance. Original v15 producer must remain replayable. New v18 may relocate whole proven structures and the Boss sector; preserving good design does not require every old coordinate to be immutable in a new version.

Bible: docs/creative_direction/bibles/2-thorn_forest_region_bible_v2.md, SHA a7bad8323af64a7be0577132e5d988a6e1b781d9e1ac1639d37f9d65935194e3. Relevant §§1–6, 7, 10, 13. Shared Underworld16px/32wu and true host thorn rules retained. S2-H/J/R only, no BGM or core changes.

## Design decision

The old Boss remains physically reachable very soon if new content is only an optional annex. V18 should move the actual Boss sector beyond a new connected set of places. Do not add collection gates or require clearing every optional branch. Normal progression crosses three memorable places with real alternatives; rich loops leave/rejoin those places. The 8–12 /15–20 minute figures are user targets to measure in normal human play, not native-driver seconds, walking distance or compulsory waits.

Map1: root/hollow loop. Retain the old root-bay lesson and old good tree challenge, add a stable mid-lesson observation as already prototyped, then let old F05/backbranch and camp become the entry/return shores of the new giant-root loop. The new 7/reveal place supplies one upper onward route and a lower return/cache journey. A double-window trunk connects upper continuation and inward lower return, then a living-pod court / fixed alternative gives the third place before the Guardian court. Routes cross at remembered root shores; all rewards are optional.

Map2: crown crossing. Retain the old hollow/cavity/spiral grammar, but primary continuation leaves the actual C cavity exit toward a new upper 7/reveal branch and two-tree living-target crossing; reverse-side descent reaches an old E/R courtyard at a different height. A high outward continuation reaches the relocated Queen sector. This is not Map1 repeated at a new tint: dominant movement is across exposed crown gaps, while Map1 returns through a trunk and around its root.

## Actual existing interfaces

Coordinates below are observed in round11 manifests for seed forest-depth-hollow-00. Derive from actual row rectangles/areas at runtime: cavity direction and map can change C height. They are not universal constants.

| Interface | Actual support/standing position | Useful direction |
| --- | --- | --- |
| Old formal spawn | root_spiral__entry [-2420,1900,300,60], spawn[-2200,1882] | keep teaching root bay; old spiral remains optional |
| Root lesson | interwoven_lesson_bough [-1830,1850,200,24], point[-1780,1832] | easy horizontal singleH before next high phrase |
| Root camp | hollow__outer_root [950,900,350,40], camp[1230,882] | remembered safe choice / return |
| Old high hollow E | hollow__outer_crown [930,576,270,24], E[980,558] | Map1 first outward view; old Boss can be removed past its east lip |
| Old C | hollow__cavity_exit x930..1200, top300 or390; C[1030,282 or372] | Map2 upper continuation; derive Y from actual support |
| F05 upper shore | bible_backbranch__entry [1840,1000,220,24], point[2020,982] | Map1 higher entrance into a new outlying tree; actual H seam required |
| F05 lower recovery | bible_backbranch__recovery [1640,1320,610,40], point[2220,1302] | low return can connect laterally without a tall ladder |
| Weaver lower shore | bible_weaver_lower [1550,1200,180,24], point[1630,1182] | actual old return to root fork/camp; full player and live-web phase matter |
| Root network fork | bible_root_step1 [1160,1200,160,24], point[1240,1182] | existing version chooses real D or R physical exit, not just a route label |

## New 7 module interface

Module author reports seven_bough_reveal v0: entry[-240,-18], crown/onward[672,-34], cache[416,270], lower_return[-32,430]; main two ordinary jumps via a broad transfer root, optional far-end drop then reverse underneath to cache and lower return. Variant1 changes the first transfer to a descent/rise, crown west112, lower_return down64. Always consume actual ports, not those nominal values. Neither variant is physically verified yet.

Map1 candidate placement: origin[2672,820] makes entry[2432,802], crown[3344,786], lower_return[2640,1250]. Lower return is only52 above the existing F05 recovery standing height1302, so a lateral broad rooted connection can close a loop. Avoid originY1320: it places the lower return450 below F05 and invites another pointless recovery ladder. Entry from old F05 upper shore is a real H/hang-jump seam, not a legal assumption of a180wu jump. A fixed fruit west of the new solid entry can allow approach and jump over its edge, but its host/ray/body must be observed; attaching a fruit immediately under a roof then jumping straight into it is a known failure.

Double-window continuation candidate: origin[3650,786] for old complete hollow. Its entry body x3430..3730 top804 overlaps the seven crown x3216..3472 top804 by72, giving an actual shared shore rather than a fake same-support string. The root/hollow output lower ports remain different destinations. This placement is only a seam hypothesis, not art-ready: the old410wu rectangular roof must not be copied as v17 did; remake the organic roof from the same cavity/host source before integration. Upper old HR proof remains limited to its original collision, so any new roof/host needs fresh actual proof.

Map2 candidate placement: derive exitY=actualC.y, origin[1640,exitY+18]. Nominal entry[1400,exitY] is a200wu gap to the end of old C body x1200; use a valid ordinary takeoff/receiver pair with full-foot margin or an actual single-H seam, not a direct200+ travel assertion. Crown approximately[2312,exitY-16], lower_return[1608,exitY+448] drops toward the remembered E/R layer. Use that low outlet to reconnect west, while the normal onward route continues right/up across a living court. Exact low landing must avoid old solid sump and F05 blocks.

## Real random topology

Randomness should select among authored, physically bounded macro assemblies rather than shuffle route labels. Use a new stream namespace/version, preserve old streams. At least two states per map:

- Map1 A: upper7 shore enters high double-window; lower window returns inward to F05/camp. Cache is in the backside root pocket. Normal Boss continuation is upper tree -> living court.
- Map1 B: 7 lower outlet enters lower double-window / inside-tree approach; upper7 shore is the faster outward living-court route. One real connecting mouth/root body differs and rewards move with actual host, giving a different first discovery and loop crossing.
- Map2 A: crown7 -> moving-pod crossing -> far tree -> Boss; lower7 returns to E.
- Map2 B: old C -> fixed inside-tree crossing -> far tree -> Boss, with7 crown accessible from the far side and living pod route the higher reward shortcut. Real mouth facing/bridge presence must change; neither state can be made by renaming same platforms.

A topology state is a complete authored assembly with physically verified entry/exit/recovery states. Do not move one rect1wu to satisfy a support-signature assertion. Mandatory technical guards should compare sorted unique physical support rect/one_way arrays and canonical target coordinates, actual directed graph reachability to three separately bound destinations and module-combination identity; these are necessary, not FUN acceptance. Record sample20 seeds, pairwise topology+support changes, old/default15 reproducibility and rejected corrupt manifests.

## Rebuild Boss sector safely

Use the real factory to regenerate at a new prep instead of recursively guessing all nested coordinates. Actual arena/platform members are identified by m.boss_geometry.platforms[*].id and anchors by m.boss_geometry.hook_anchors[*].id, not prefixes.

Observed map1 ids: boss_entry, guardian_canopy_roof, boss_floor, counter_branch, guardian_branch_left, guardian_branch_right; hooks inner_left,return_left,inner_right,return_right.
Observed map2 ids: floor,central_rib,right_rib,right_bank,canopy,canopy_entry; hooks A,B,low_recovery. Queen geometry has receiver_fields, motion_paths and high_field and must be regenerated from queen_canopy_from_prep, not just top-level boss_arena moved.

1. Snapshot/retain old sector provenance. Remove exactly the old factory bodies/hooks from the new18 manifest. Remove old boss_approach and crown_approach_ring_0 separately. Preserve all other old tree modules.
2. Replace areas prep/gate_ready/boss, and old crown_prep or cavity_prep, crown_approach, arena_entry relations. For each existing route, replace the old prep edge with the explicit selected new macro itinerary. Never leave old route references dangling, auto-shortest-path-promote experimental edges, or rename the entire new journey into a fake walk edge.
3. Build the last broad approach at actual final shore. m.boss_approach_origin is the external prep passed to ForestBossArenaFactory.from_prep(prep,1) or queen_canopy_from_prep(prep). Replace boss_contract and boss_geometry with full result, boss_arena/root_supports, append true factory platforms/hooks; preserve boss_content contract for map2.
4. Rebuild vine_gate/key target and gate approach from actual final support, with an observable valid H contact. Do not leave a gate at old x1456 after relocating its target.
5. Rebuild map1 training_bells and bible_practice_bell_frame at the final real approach, or deliberately retire this practice only in18 with rationale. Do not leave a bough host pointing at moved boss_approach. Preserve training intent.
6. Recompute scene membership, actual fruit hosts/stem roots, world bounds, topology signature and canonical manifest hash. Do not rerun historical ForestBibleThornSurfaces.install on already-converted v15 hazard data; explicitly add any new true host thorn surfaces.
7. Register18 in actual generator, assembler fruit/host paths, ForestBiblePresentation/Thorns, generator._boss_paths approved map2 layout list and explicit dev-menu layout. Keep CURRENT_DEPTH_LAYOUT15 until verified. No claim of current Boss binding if these lists were not updated.

## Evidence reuse and next implementation order

Round11 old formal-spawn annex/L paths prove the original v15 prefix, first rest prototype, old root mouths and the particular v17 seams only. They do not prove the proposed18 seam, relocated Boss, live reverse weaver, new random assembly, fun or human timing. Old crown/window complete translations are good starting dimensions, but adjacent new bodies invalidate any assumption of unchanged input rays.

Implement one7+real old neighbor+return shore+reward transaction, capture normal camera, real Motor and cheap alternative, then independent art/mechanism review. Only after that acceptance expand another assembly. Phase1 can legitimately deliver a complete connected golden and a map blueprint while full8–12/15–20 remains unverified; do not declare the whole region achieved from that slice. After actual extension, measure normal-speed sessions: first non-speedrun route to Boss, optional one-reward loop and thorough exploration. Record decisions, repeated walking, failure/retry, combat, help/pause time separately; never pad traversal or mandatory enemy health to hit a duration.
