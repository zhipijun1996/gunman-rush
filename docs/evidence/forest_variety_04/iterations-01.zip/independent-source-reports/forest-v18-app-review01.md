# Forest v18 首个 actualApp 静态构图独审

2026-10-22，reviewer `/root/forest_v18_review`。只读、没有启动 Godot或修改生产。

**结论：首个 seven 场所允许继续真实通行与动态镜头验证；静态轮廓/共享像素接入获有限接受，完整联合黄金与整区艺术仍 REWORK/UNVERIFIED。** 双窗邻接仍有独立的大矩形母形问题，不能拿 seven 的改善给整个新世界签艺术通过。

## 实际观看范围及身份

已通过 `view_image` 逐张打开 app-golden01 以下12张原尺寸1280×720 GPU图：两map各 seven cache/crown/lower_return、prep，以及double_window entry/crown。没有看另外4张 C/seven entry，不把整目录16图成功等同全部已看。

图源 `/tmp/gunman-forest-v18/app-golden01/`，receipt：actual_App_static_UI_composition_no_traversal_or_device、source_stable=true、exit0、21.811s。实际 runner 通过 DemoApp.start_debug_region 加载，随后明确暂停、把玩家定位到对应area、snap相机、重绘。它有正式 Stage、UnderworldPlayer、HUD和真实对象绘制，但其 pose **是 staged fixture，不是玩家自然走到这里**。

Seed为 `forest-places-00`，layout `forest-exploration-places-v18`。两map实际manifest：

- map1 `49a33a7fd65a5bf35b1a33dc61ee620297b2f22e68eb9b445a16e799be65bd50`
- map2 `9ce276fab40e325750e301665981507e01b63065dccf595c69c0f7806df71345`

对应 round08 完整 source closure：baseline e594d3ff54daaf9d8f5e30f3190890737ce39a1e，3698paths。`forest_exploration_places.gd` VERSION18.4、SHA `77b4f543fe7fc3a75a9bef72bcb835d2cd40962d74530f89c8782050775ebea1`；golden runner SHA `6b3828ad8401372efcfd8ae52e6ed717f3504ddfbfe2cb78aa19c2749aa910cf`；network SHA `2c6158a50c195c75fc7007725b2be0459b1c53e2fd5d777240134776466c2e4a`。均从round08 changed-source.zip核字节，不以之后工作树变更代签。

| PNG | SHA256 |
| --- | --- |
| map1_places_seven__cache.png | 958a74ed6b09dbee3a29789b2c0687246fbcac738f7473700cd3956015b3d56f |
| map1_places_seven__crown.png | 053982f7f706948f7a7867790ed6d280d955b5c68a0ef5ac6d352daca0adf7cf |
| map1_places_seven__lower_return.png | 7d4d43b6ef85dd85e406a7a0bd10320b5710e49087b4e97fa282b27e69b6297e |
| map1_prep.png | b7c2677a80d814d2a2556125e8eb9d21f2f68ab8dadceedc9a271f52844b1931 |
| map1_places_double_window__entry.png | 841434123a5d92ebe04c1faee9d5ae3a0ebf2207a32024415f0e10e34a9b054c |
| map1_places_double_window__crown.png | 14b1e507d7da227556919d16f7b14c5a79575e1193cea4b43bec0f04bb0ccf70 |
| map2_places_seven__cache.png | 674679e8082f73547aabbd5db450caa2ca79186af03b39b89800d26f5ed89495 |
| map2_places_seven__crown.png | f46e514b946e7a9910884166023cdfdfcb9d0003bb8532bcc5fcc97c2d76c515 |
| map2_places_seven__lower_return.png | 1c1cf5fcf8267aca71f3f6ab2e426488ca8dede99c3bf2218c006c86e731b192 |
| map2_prep.png | 48fe00847c264bb58ba5e1516d3bd42ddadc0b2cd75d777934b58b6d191a7cdb |
| map2_places_double_window__entry.png | d779939cc8b9f44a0f1017ead7f4012a991c14d4fcef2e0d3510460109b35ac2 |
| map2_places_double_window__crown.png | 401ea4c679862c8963ee22f14ed1ff9e7337dd64e56085122314b8927dcf6fca |

未看影片、未听音轨、无实体设备；未独立重跑原生输入。引擎输出和实际像素是不同范围。

## 首场所已成立的静态改善

- seven 的cache仍有连续C形根壁、拱顶、凹入立足面，真实App中没有退回两片悬台。人物/暖箱/白刺与暗根基本分开，箱子确实进入正式对象绘制。
- crown 的两枝通过不同曲肋汇入主根，保留开阔前向负空间；不是规则短平台梯。shared像素尺寸、背景对比、角色家族维持一致。
- 上轮实体内部横线在这次所看的crown/cache/root像素中已不可见。round08 union日志2361assert/0fail和world165assert/0fail提供相关技术背景，但仅限各自检查。round07真实2401assert/644fail继续保留；不是把旧失败改标通过。
- App右侧实际one-way边缘是与原家族一致的绿枝，未出现locallab的米白编辑线。前报告白线只属于那个lab消费者，不能据其签正式失败；本次也不签所有one-way消费者已统一。
- 静态主角附近没有HUD覆盖唯一立足面；左上HUD与右上menu占据固定区域，仍保留大部分通行视野。不能从静态足下清楚推断跳跃顶点、下落初见和最坏相位均清楚。

因此可以继续首场所的实际输入/世界邻接，不需因旧lab白线阻断它，也不应为此先重跑整套CI。

## 仍存在的问题与边界

### APP01 — 双窗邻接继续使用巨矩形L梁/方柱（ART_REWORK）

两map的double_window entry图里，上方约x376..1035/y170..340仍是长平梁+直角竖柱，顶缘的两三块阶梯像在矩形上削角；人物脚下约x376..733/y479是一片独立厚平岛。crown图上半左侧同体横梁+方柱主导轮廓，下部又是窄柱/细枝。

这仍然是首轮 v17 被指出的那类机械框架，不因隔壁 seven 变自然就成立。它可以保留旧窗口/动作语义作为重设输入，但若作为新版实际主路，应单独从树体/洞口负空间推导自然实体。不要把seven整个C形复制过去当第二场所，双窗应有自己可读的上下孔关系与树干朝向。

这是相邻母形的艺术返工，不据此否定seven本身的有限轮廓接受；两者的通行证据也分别记录。

### APP02 — lower_return的近/远岸关系还需要运动证明

seven lower_return两图里，人物右边约x665..807有粗根贯通到上部cache；下方连续的支撑面在粗根两侧形成不同岸。源明确把near/far ports分开，这比仅因为同support字符串便声称可通行正确。

静图中右侧prep方向可望见果实/铃，但粗根确实隔着身体；它让return的拓扑关系无法由一张图读完。需要实际输入分别从奖后远口、普通早退近口到对应真实目的地，观察玩家是否能理解为何不能直接穿根。本审查不从静图判软锁，也绝不因wide floor看起来连续就签返回成立。

### APP03 — 材料表达与局部白刺仍可精修

大形已改善，内部仍偏细碎深蓝黑岩土，外皮/树洞木质面缺方向差别；绿苔均匀覆盖四向边缘，主根的木质承重感弱于背景。cache刺面有真实根面承载、白尖可辨，但当前只是很短的棕色突起补丁，缠绕生长关系仍较少。后续沿同16px/47tile家族修内外边材、主干方向与贴根藤体，不另换画风、不画假站面，也不需要立即给所有平台填满荆棘。

这不阻断当前局部通行修复；它意味着整体森林美术还不能定稿。

### APP04 — 两map的局部构图尚不能回答地图身份丰富度

本次map1/2的seven crown/cache主体几乎相同，lower_return也相近。prep后方Boss侧确有不同形体/生态，不能因此说两图完全一样；但一个相同家族的局部两变体也不足以证明“树腹回环/树冠跨越”的全图差别。实际新宏观拓扑、更多场所、合理时长都维持未完成。world20sample/165assert不是这些体验结论。

### APP05 — staged可见不能代替实际奖励、危险与路线

cache图里主角和闭箱重叠，符合显式定位在领奖点的fixture；它不证明角色会被箱子实体卡住，也不证明已领奖。prep图显示真实竖铜轨/门与圈形目标，完整配对/射线及战斗入口仍须真实输入。round08 receipt中map1-main/reward/outer、map2-main均失败；该事实压过任何静态摆拍成功，本报告不签可通行。

## 当前允许与不允许的声明

允许：seven首场所的实体轮廓和实际共享像素接入有实质改善；本次所看App视角未再出现内部线；可以继续实际通行和动态构图验证。

不允许：完整黄金艺术ACCEPT、双窗邻接艺术通过、世界出返/奖励二选一通过、Boss入口已真实可达、整区模块库/宏观随机/8–12或15–20分钟达标、用户/设备认可、公开新包交付。

下一步应优先修正真实输入/邻接并保留失败，再看同源动态镜头，不必为同一静态七形反复做没有新问题的截图轮次。双窗和新场所按各自空间语义继续联合设计，避免以不断扩写验收报告代替实际模块开发。
