from pathlib import Path
import json,hashlib,subprocess
R=Path('/workspace/gunman-rush');old='docs/creative_direction/bibles/style-continuity-20261021-v3.json';new='docs/creative_direction/bibles/style-continuity-20261022-v4.json';sha=lambda b:hashlib.sha256(b).hexdigest();a=json.loads((R/old).read_text());b=json.loads((R/new).read_text())
assert (R/old).read_bytes()==subprocess.check_output(['git','show','HEAD:'+old],cwd=R)
assert sha((R/old).read_bytes())=='95549bd9844de117b011edf4fd98a0ef8945ad7cbc33c113f3b4762faad7626f'
assert b['version']=='4' and b['supersedes']['path']==old and b['supersedes']['sha256']==sha((R/old).read_bytes())
assert {k:v for k,v in a.items() if k not in ['version','runtime_reference','revision_impact','supersedes']}=={k:v for k,v in b.items() if k not in ['version','runtime_reference','revision_impact','supersedes']}
assert {k:v for k,v in a['runtime_reference'].items() if k!='references'}=={k:v for k,v in b['runtime_reference'].items() if k!='references'}
ars=a['runtime_reference']['references'];brs=b['runtime_reference']['references'];assert len(ars)==len(brs)==16;changed=[]
for x,y in zip(ars,brs):
 assert x['role']==y['role'] and x['path']==y['path'];assert sha((R/y['path']).read_bytes())==y['sha256']
 if x!=y:changed.append({'old':x,'new':y})
assert len(changed)==1 and changed[0]['old']['role']=='boundary_sides' and changed[0]['old']['sha256']=='240098cce12d435c902cb85c114dd302415f0d639f848fa89769c90581f8391d' and changed[0]['new']['sha256']=='e1f710bfe7f125bf64245406db0b07d70def3a3ee591309cfb53196cb45f2d34'
regpath='docs/creative_direction/bibles/registry.json';reg=json.loads((R/regpath).read_text());oldreg=json.loads(subprocess.check_output(['git','show','HEAD:'+regpath],cwd=R));assert reg['shared_style_authority']=={'path':new,'sha256':sha((R/new).read_bytes())};assert {k:v for k,v in reg.items() if k!='shared_style_authority'}=={k:v for k,v in oldreg.items() if k!='shared_style_authority'}
skills=['animation-vfx','art-director','game-quality-gate','region-creative-director','region-generator','visual-director'];pointers=['AGENTS.md']+[f'.agents/skills/{s}/SKILL.md' for s in skills]
for p in pointers:
 previous=subprocess.check_output(['git','show','HEAD:'+p],cwd=R);assert (R/p).read_bytes()==previous.replace(b'style-continuity-20261021-v3.json',b'style-continuity-20261022-v4.json'),p
for p in ['docs/creative_direction/thorn_forest.json','docs/creative_direction/windchime_plains.json']:
 assert (R/p).read_bytes()==subprocess.check_output(['git','show','HEAD:'+p],cwd=R)
for row in reg['regions']:
 # The whole registry region payload is unchanged. Preserve original registered Bible bytes too.
 for key,value in row.items():
  if isinstance(value,dict) and isinstance(value.get('path'),str) and value['path'].endswith('.md') and (R/value['path']).is_file():
   assert (R/value['path']).read_bytes()==subprocess.check_output(['git','show','HEAD:'+value['path']],cwd=R)
impact=b['revision_impact'];assert impact['unchanged_all_other_reference_bytes'] is True and 'unverified' in impact['validation_status'] and 'ART_REWORK' in impact['validation_status']
for p in [impact['scoped_evidence'],impact['independent_review']]:assert (R/p).is_file()
index=json.loads((R/impact['scoped_evidence']).read_text());archive=(R/impact['scoped_evidence']).parent/index['archive'];assert archive.stat().st_size==index['archive_bytes'] and sha(archive.read_bytes())==index['archive_sha256']
out={'scope':'independent read-only actual document/registry/ref/pointer check, not engine/browser/new ART','v3_byte_identical_to_HEAD':True,'v3_sha256':sha((R/old).read_bytes()),'v4_sha256':sha((R/new).read_bytes()),'registry_exact_rebind':True,'registered_region_records_unchanged':True,'references_total':16,'changed_references':changed,'other15_actual_reference_hashes_match':True,'quotes_dimensions_global_style_unchanged':True,'seven_current_pointer_files_only_replace_v3_v4':pointers,'creative_direction_documents_unchanged':True,'evidence_links_and_archive_hash_valid':True,'decision':'CONFIRM limited explicit style-v4 rebind matches prior allowance; browser/native further receipts remain separate'}
Path('/tmp/forest-v18-style-v4-rebind-review.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
