from pathlib import Path
import json,hashlib,subprocess,sys,copy,ast
R=Path('/workspace/gunman-rush');sys.path.insert(0,str(R/'tools'));import region_creative_direction as creative
sha=lambda b:hashlib.sha256(b).hexdigest();impact=json.loads((R/'docs/creative_direction/bibles/style-continuity-rebind-v4.json').read_text());rows=[]
for change in impact['changes']:
 region=change['region_id'];oldref=change['before_direction'];newref=change['after_direction'];oldraw=(R/oldref['path']).read_bytes();newraw=(R/newref['path']).read_bytes();old=json.loads(oldraw);new=json.loads(newraw)
 assert sha(oldraw)==oldref['sha256'] and sha(newraw)==newref['sha256'];assert oldraw==subprocess.check_output(['git','show','HEAD:'+newref['path']],cwd=R)
 allow={'version','region_bible','authority_sources','historical_direction'};assert {k:v for k,v in old.items() if k not in allow}=={k:v for k,v in new.items() if k not in allow}
 assert old['region_bible']==oldref['region_bible'] and new['region_bible']==newref['region_bible'] and new['version']=='creative-v8'
 actual,bound=creative.load_direction(newref['path'],region_id=region,root=R);assert actual==new and bound['sha256']==newref['sha256']
 try:creative.validate_bible_binding(old['region_bible'],region_id=region,root=R);raise AssertionError('old full binding accepted')
 except ValueError as e:old_error=str(e)
 try:creative.load_direction(oldref['path'],region_id=region,root=R);raise AssertionError('archived current accepted as new current')
 except ValueError as e:archived_error=str(e)
 rejects=[]
 for version in [2,3]:
  p=f'docs/creative_direction/bibles/style-continuity-20261021-v{version}.json';stale=copy.deepcopy(new['region_bible']);stale.update(supplemental_authority_path=p,supplemental_authority_sha256=sha((R/p).read_bytes()))
  try:creative.validate_bible_binding(stale,region_id=region,root=R);raise AssertionError('stale style accepted')
  except ValueError as e:rejects.append({'style':version,'error':str(e)})
 rows.append({'region':region,'archive_sha256':sha(oldraw),'new_sha256':sha(newraw),'changed_fields':sorted(k for k in set(old)|set(new) if old.get(k)!=new.get(k)),'outside_four_fields_identical':True,'actual_load_direction':'accepted creative-v8','old_full_binding_rejected':old_error,'old_archived_direction_rejected':archived_error,'old_style_rejections':rejects})
# Confirm old source-level loader guard remains literal/exact, not auto-overwriting refs.
assert (R/'tools/region_creative_direction.py').read_bytes()==subprocess.check_output(['git','show','HEAD:tools/region_creative_direction.py'],cwd=R)
tests=[]
for path,changed_names in [('tests/test_region_bible.py',{'test_actual_player_body_closure_is_required_and_superseded_binding_refused'}),('tests/test_region_creative_direction.py',{'test_plan_preserves_selected_direction_in_each_task'})]:
 now=(R/path).read_text();prev=subprocess.check_output(['git','show','HEAD:'+path],cwd=R,text=True)
 def methods(s):return {n.name:ast.dump(n,include_attributes=False) for n in ast.walk(ast.parse(s)) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
 a,b=methods(prev),methods(now);assert a.keys()==b.keys();changed={n for n in a if a[n]!=b[n]}
 tests.append({'path':path,'changed_methods':sorted(changed),'all_other_methods_AST_identical':True})
 if 'bible' in path:
  assert changed=={'test_actual_player_body_closure_is_required_and_superseded_binding_refused'}
  assert 'stale_v3' in now and "'version'],'4'" in now and "style-continuity-20261021-v2.json" in now
 else: assert now==prev.replace("'creative-v7'","'creative-v8'")
harness=[]
for id in ['20261022T054736.439436Z','20261022T055129.880429Z']:
 d=json.loads((R/'build/verification/harness'/id/'report.json').read_text());harness.append({'id':id,'status':d['status'],'checks':[{k:c.get(k) for k in ['id','status','exit_code']} for c in d['checks']]})
assert harness[0]['status']=='failed' and harness[1]['status']=='passed' and len(harness[1]['checks'])==6
prior=Path('/tmp/forest-v18-style-v4-rebind-review.md');out={'scope':'bounded corrective read-only followup; actual production loader calls, no engine/browser','prior_report_preserved':{'path':str(prior),'sha256':sha(prior.read_bytes()),'contains_incorrect_loader_conclusion':True},'correction':'Registry rebinding alone does not override stored direction bindings. load_direction calls validate_bible_binding and rejects old style/registry refs. Earlier conclusion was wrong. Original failed harness remains failed.','rows':rows,'loader_source_unchanged':True,'test_diff_scope':tests,'harness_receipts':harness}
Path('/tmp/forest-v18-style-v4-followup-review.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
