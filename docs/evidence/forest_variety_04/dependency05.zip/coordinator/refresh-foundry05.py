from pathlib import Path
import sys,os,json,subprocess,time,hashlib,zipfile
R=Path('/workspace/gunman-rush');os.chdir(R);sys.path.insert(0,str(R/'tools'));from forest_bible_world_sources import inventory
O=R/'build/region_bible_v2/foundry-refresh05';O.mkdir(exist_ok=False);os.environ.update(GUNMAN_TOOLCHAIN_ROOT='/workspace/toolchains',OMP_NUM_THREADS='1',LP_NUM_THREADS='1')
before=inventory();(O/'source-before.json').write_text(json.dumps(before,sort_keys=True));rows=[]
with zipfile.ZipFile(O/'old-foundry.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
 for p in sorted((R/'resources/foundry').rglob('*')):
  if p.is_file():
   name=p.relative_to(R).as_posix();data=p.read_bytes();z.writestr(name,data);rows.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
with zipfile.ZipFile(O/'old-foundry.zip') as z:
 for r in rows:
  data=z.read(r['path']);assert len(data)==r['bytes'] and hashlib.sha256(data).hexdigest()==r['sha256']
(O/'old-foundry-index.json').write_text(json.dumps(rows,indent=2));start=time.monotonic();r={'exit_code':1,'commands':[],'scope':'refresh_existing_development_pool_and_export_stamp_with_original_validator_no_guard_change'}
try:
 for label,args,cap in [('refresh',['python3','tools/foundry.py','build','--count','24','--promote'],1050),('stamp',['bash','tools/godot.sh','--headless','--path','.','--script','tools/foundry_export_stamp.gd'],30)]:
  t=time.monotonic()
  with (O/(label+'.log')).open('w') as f:c=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,timeout=cap)
  r['commands'].append({'argv':args,'exit_code':c.returncode,'seconds':time.monotonic()-t})
  if c.returncode:raise RuntimeError(label+' failed')
 batch=json.loads((R/'resources/foundry/batch.json').read_text());assert len(batch['accepted'])==36 and len(batch['itineraries'])==18
 r.update(exit_code=0,basis=batch['basis'],accepted=36,itineraries=18)
except Exception as e:r['error']=repr(e)
finally:
 after=inventory();(O/'source-after.json').write_text(json.dumps(after,sort_keys=True));changes=sorted(k for k in set(before)|set(after) if before.get(k)!=after.get(k));r['changed_paths']=changes;r['only_expected_development_JSON']=all(k.startswith('resources/foundry/') and k.endswith('.json') for k in changes)
 if not r['only_expected_development_JSON']:r['exit_code']=1
 r['seconds']=time.monotonic()-start;(O/'receipt.json').write_text(json.dumps(r,indent=2));print(json.dumps(r),flush=True)
