"""V18 finite development feedback: actual places, canonical contour and App routes.

This proves selected technical paths only. Art, meaningful library size, generated
map identity, FUN and devices remain independent; this is never a release gate.
"""
import argparse
import contextlib
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import time

from forest_bible_world_sources import inventory
from run_forest_exploration_contract import archive_sources, changed_sources, git, save
from run_tests import run_engine

ROOT = Path(__file__).resolve().parents[1]


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir', required=True, type=Path)
    args = parser.parse_args(argv)
    output = args.output_dir.absolute()
    if (not output.is_relative_to(ROOT / 'build') or output.exists() or '..' in output.parts
            or any(p.is_symlink() for p in [output, *output.parents] if p.is_relative_to(ROOT))):
        parser.error('Use a fresh ordinary directory under build/')
    output.mkdir(parents=True)
    started = time.monotonic()
    receipt = {'scope': __doc__, 'import_cap_seconds': 90, 'native_cap_seconds': 240,
               'whole_cap_seconds': 600, 'fixed_fps': 60, 'workers': 1, 'checks': [], 'exit_code': 1}
    before = None
    try:
        receipt['baseline_head'] = git('rev-parse', 'HEAD').decode().strip()
        before = inventory()
        save(output / 'source-before.json', before)
        archived = archive_sources(output / 'source-snapshot-before', before, changed_sources())
        save(output / 'source-bytes-before.json', {'baseline_head': receipt['baseline_head'], 'files': archived})
        jobs = [('import', None, [], '', 90),
                ('world', 'tests/forest_places_world_runner.gd', [], r'^FOREST PLACES WORLD: [1-9]\d* assertions, 0 failures$', 240),
                ('menu', 'tests/forest_places_menu_runner.gd', [], r'^FOREST PLACES MENU: [1-9]\d* assertions, 0 failures$', 240)]
        jobs.insert(2, ('union', 'tests/forest_places_union_runner.gd', [], r'^FOREST PLACES UNION: [1-9]\d* assertions, 0 failures$', 240))
        for index in (0, 1):
            for route in ('main', 'reward_return', 'failure_west_return', 'near_west_return'):
                jobs.append((f'local_{index}_{route}', 'tests/forest_exploration_place_runner.gd',
                             [f'--place-variant={index}', '--route='+route], r'^FOREST PLACE: PASS /', 240))
        for map_index in (1, 2):
            for label, route, fixture in (('normal', 'places_normal_journey', False),
                                          ('reward', 'places_reward_trial', True),
                                          ('return', 'places_outer_trial', True),
                                          ('windows', 'places_window_loop', True)):
                script = 'tests/forest_places_fixture_runner.gd' if fixture else 'tests/forest_places_motor_runner.gd'
                marker = r'^FOREST PLACES FIXTURE: PASS /' if fixture else r'^FOREST PLACES MOTOR: PASS /'
                jobs.append((f'map{map_index}_{label}', script,
                             [f'--map={map_index}', '--seed='+('forest-places-00' if map_index == 1 else 'forest-places-01'), '--route='+route,
                              *(['--reward-index=1'] if map_index == 2 and label == 'reward' else [])], marker, 240))
        for name, script, extra, marker, cap in jobs:
            remaining = 600 - (time.monotonic() - started)
            if remaining <= 0:
                raise TimeoutError('Original 600 second whole feedback budget exceeded')
            native_report = output / (name + '.json')
            log = output / (name + '.log')
            arguments = ['--headless', '--path', '.']
            if script:
                arguments += ['--fixed-fps', '60', '--script', script]
                if name != 'menu':
                    arguments += ['--', *extra, '--output=res://' + native_report.relative_to(ROOT).as_posix()]
            else:
                arguments += ['--editor', '--quit']
            row = {'id': name, 'argv': ['bash', 'tools/godot.sh', *arguments], 'passed': False,
                   'timeout_seconds': min(cap, remaining), 'log': log.name}
            receipt['checks'].append(row)
            t = time.monotonic()
            try:
                with log.open('w') as stream, contextlib.redirect_stdout(stream), contextlib.redirect_stderr(stream):
                    text = run_engine(arguments, min(cap, remaining))
                if marker and len(re.findall(marker, text, re.M)) != 1:
                    raise RuntimeError('Missing or nonunique native completion marker')
                if script and name != 'menu':
                    data = json.loads(native_report.read_text())
                    if name in ('world', 'union'):
                        if (data.get('failures') != [] or type(data.get('assertions')) is not int
                                or data['assertions'] <= 0):
                            raise RuntimeError('Missing or failed nonempty native assertions')
                        if name == 'world' and len(data.get('samples', [])) != 20:
                            raise RuntimeError('Actual 20-world structure/replay corpus missing')
                        if name == 'union' and len(data.get('rows', [])) != 2:
                            raise RuntimeError('Both real contour variants missing')
                    elif name.startswith('local_'):
                        if (data.get('passed') is not True or data.get('failure') != ''
                                or data.get('danger_contacts') != [] or not data.get('frames')
                                or any(f.get('motor_steps') != 1 for f in data['frames'])
                                or data.get('midroute_injection') is not False
                                or data.get('resource_override') is not False):
                            raise RuntimeError('Actual local single-Motor route failed or missing')
                        completed = [e for e in data.get('events', []) if e.get('kind') == 'actual_ordinary_leg_complete']
                        if len(completed) != len(data['manifest']['routes']['main']['steps']):
                            raise RuntimeError('Actual complete place itinerary missing')
                    elif (data.get('failures') != [] or data.get('passed') is not True or not data.get('frames')
                          or len(data.get('completed', [])) != len(data.get('itinerary', []))
                          or any(f.get('motor_steps') != 1 for f in data['frames'])
                          or data.get('midroute_injection') is not False or data.get('resource_override') is not False):
                        raise RuntimeError('Actual complete App single-Motor path proof missing')
                    row['report'] = native_report.name
                    row['report_sha256'] = hashlib.sha256(native_report.read_bytes()).hexdigest()
                row.update(passed=True, exit_code=0)
            except (OSError, ValueError, RuntimeError, subprocess.SubprocessError) as error:
                row.update(exit_code=1, error=repr(error))
                raise
            finally:
                row['seconds'] = round(time.monotonic() - t, 3)
                if log.is_file(): row['log_sha256'] = hashlib.sha256(log.read_bytes()).hexdigest()
                save(output / 'receipt.json', receipt)
        receipt['exit_code'] = 0
    except (OSError, ValueError, RuntimeError, subprocess.SubprocessError) as error:
        receipt.update(exit_code=1, error=repr(error))
    finally:
        after = inventory()
        save(output / 'source-after.json', after)
        receipt['source_stable'] = before is not None and before == after and receipt.get('baseline_head') == git('rev-parse', 'HEAD').decode().strip()
        if not receipt['source_stable']: receipt['exit_code'] = 1
        receipt['seconds'] = round(time.monotonic() - started, 3)
        save(output / 'receipt.json', receipt)
    print(('PASS' if receipt['exit_code'] == 0 else 'FAIL') + ': forest places development feedback')
    return receipt['exit_code']


if __name__ == '__main__':
    sys.exit(main())
