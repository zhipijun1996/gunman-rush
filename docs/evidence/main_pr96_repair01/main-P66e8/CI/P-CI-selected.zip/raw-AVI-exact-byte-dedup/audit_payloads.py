from pathlib import Path
import json,hashlib,shutil
B=Path('build/forest_revision04');O=B/'raw-AVI-exact-byte-dedup-P';expected={}
folders=['main-movies-M9757','main-movies-N1447','ci-efficiency-movie-map2-K4306','main-movies-P66e8']
for folder in folders:
 for rp in (B/folder).rglob('receipt.json'):
  d=json.loads(rp.read_text())
  for r in d.get('runs',[]):
   m=r.get('movie')
   if m and m.get('sha256'):
    p=Path(m['argv'][-1]);name=str(p.relative_to(Path.cwd()))
    expected[name]={'sha256':m['sha256'],'bytes':m['bytes'],'source_receipt':str(rp)}
for r in json.loads((B/'ci-efficiency-N-followup/N-native-AVI-reference-index.json').read_text()):
 expected.setdefault(r['path'],{'sha256':r['sha256'],'bytes':r['bytes'],'source_receipt':str(B/'ci-efficiency-N-followup/N-native-AVI-reference-index.json')})
rows=[]
for folder in folders:
 for p in sorted((B/folder).rglob('*.avi')):
  e=expected[str(p)];s=p.stat()
  with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
  assert h==e['sha256'] and s.st_size==e['bytes']
  rows.append({'path':str(p),**e,'actual_sha256':h,'dev':s.st_dev,'inode':s.st_ino,'nlink':s.st_nlink,'mtime_ns_after':s.st_mtime_ns,'allocated':s.st_blocks*512})
assert len(rows)==7
report={'status':'PASS_PAYLOAD_AND_PATH_AUDIT','initial_helper_status':'REWORK_AFTER_LINKING: metadata-only assertion incorrectly expected distinct original mtimes to survive shared inodes. Do not claim unchanged mtimes.','all7_payloads_sizes_equal_prior_source_specific_receipts':True,'all7_paths_retained':True,'no_source_identity_rebinding':True,'timestamp_scope':'Filesystem mtimes unified on aliases; original execution UTC/source/guard/film receipts remain unchanged. Distinct source-specific actual executions were already complete before dedup.','rows':rows,'unique_inodes_after':len({(r['dev'],r['inode'])for r in rows}),'free_after':shutil.disk_usage('.').free}
(O/'final-payload-audit.json').write_text(json.dumps(report,indent=2)+'\n')
print({k:report[k]for k in ['status','all7_payloads_sizes_equal_prior_source_specific_receipts','unique_inodes_after','free_after']})
