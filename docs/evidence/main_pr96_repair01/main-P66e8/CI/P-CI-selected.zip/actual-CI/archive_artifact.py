"""Archive actual P artifact bytes; transport URLs are read only from stdin."""
import sys,json,urllib.request,hashlib,zlib,zipfile,io,pathlib,datetime
OUT=pathlib.Path(__file__).parent
cfg=json.loads(sys.stdin.readline())
api=cfg['artifact'];name=api['name'];keep=bool(cfg.get('keep_zip'))
assert api['workflow_run']['id']==39452164092
assert api['workflow_run']['head_sha']=='66e8b912854d6d4cccadb45b9c348a618689f5a1'
h=hashlib.sha256();crc=0;size=0;selected=[];members=[];bytes_selected=0
target=OUT/(name+'.zip')
receipt={'head':api['workflow_run']['head_sha'],'run_id':api['workflow_run']['id'],'run_attempt':1,'artifact_id':api['id'],'name':name,'status':'started','zip_retained':keep,'downloaded_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
rp=OUT/(name+'-download-receipt.json')
rp.write_text(json.dumps(receipt,indent=2)+'\n')
try:
 buf=target.open('xb') if keep else io.BytesIO()
 with urllib.request.urlopen(cfg['url'],timeout=45) as r:
  while b:=r.read(1024*1024):
   size+=len(b);h.update(b);crc=zlib.crc32(b,crc);buf.write(b)
 if keep:buf.close();source=target
 else:buf.seek(0);source=buf
 assert size==api['size_in_bytes'], 'artifact size differs from actual API'
 assert 'sha256:'+h.hexdigest()==api['digest'], 'artifact SHA differs from actual API digest'
 with zipfile.ZipFile(source) as z:
  for i in z.infolist():
   members.append({'name':i.filename,'bytes':i.file_size,'compressed_bytes':i.compress_size,'crc32':format(i.CRC,'08x')})
   if i.is_dir():continue
   select=(i.filename.endswith(('report.json','receipt.json','runtime.json','sourceguard.json','source-guard.json'))
    or i.filename.endswith('forest-depth-region.log')
    or ('forest-depth-region/' in i.filename and i.filename.endswith(('native.log','check.log')))
    or ('serial' in name and ('audio-lifecycle/' in i.filename or 'wood-platform' in i.filename) and i.filename.endswith(('.json','.log','.png')))
    or name.startswith('harness-phase-proof-')
    or (name=='harness-web' and i.filename.endswith(('underworld-damage-feedback.log','check.log'))))
   if name=='harness-gameplay-parallel':
    parts=pathlib.PurePosixPath(i.filename).parts
    select=(len(parts)==4 and parts[:2]==('verification','harness') and parts[-1]=='report.json') or ('forest-depth-region/' in i.filename and i.filename.endswith(('receipt.json','native.log','check.log','sourceguard.json','source-guard.json'))) or i.filename.endswith('forest-depth-region.log')
   crc_actual=0;chosen=io.BytesIO() if select and not keep else None
   with z.open(i) as f:
    while b:=f.read(1024*1024):
     crc_actual=zlib.crc32(b,crc_actual)
     if chosen is not None:chosen.write(b)
   assert crc_actual==i.CRC, 'member CRC mismatch'
   if chosen is not None:
    rel=pathlib.PurePosixPath(i.filename);assert not rel.is_absolute() and '..' not in rel.parts
    dest=OUT/('artifact-'+name)/str(rel);dest.parent.mkdir(parents=True,exist_ok=True)
    with dest.open('xb') as f:f.write(chosen.getbuffer())
    selected.append(i.filename);bytes_selected+=i.file_size
 receipt.update(status='passed',bytes=size,sha256=h.hexdigest(),crc32=format(crc,'08x'),API_digest_matches=True,all_member_CRC_passed=True,selected_bytes=bytes_selected,selected_members=selected)
except Exception as exc:
 receipt.update(status='failed',error_type=type(exc).__name__,bytes_received=size,selected_bytes=bytes_selected,selected_members=selected)
 rp.write_text(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps({k:v for k,v in receipt.items() if k!='selected_members'}));sys.exit(1)
rp.write_text(json.dumps(receipt,indent=2)+'\n')
(OUT/(name+'-members.json')).write_text(json.dumps(members,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k!='selected_members'}))
