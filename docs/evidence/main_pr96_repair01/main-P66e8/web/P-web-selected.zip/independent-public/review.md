# P 正式CI包与公网有限独审

`ACCEPT_SCOPED`，P=`66e8b912854d6d4cccadb45b9c348a618689f5a1`，审查者`/root/p_movie_review`。这是新地区Bible改造前技术基线，不签新美术成果。

实际唯一Web artifact12279384244/run39452164092/attempt1绑定完整ZIP SHA。原三25/40/8项全true、原300秒各自通过；六源码SHA等于P，source/served双端闭合。独立完整重读ZIP、CI PCK及新公网PCK：PCK141171460B，SHA`3eaeaccb67dd8810b5c84a53dd9b1c8b4533903426e88d8a4206968290702d74`。正式六许可/来源sidecar逐项与公网、CI、P源码完整SHA和长度一致。

新official helper按实际tools/build.py合同通过metadata/build_report/fullPCK/6sidecar。原underworld consumer请求隔离实验style-licenses/index.json而404的整次失败保留，未追认。新fullbytes9.623秒，原forest20项/8context451.533秒在480内，selector56.160秒在120内；各退出0，source闭合。

逐张实际打开闭合、弹出和Escape闭合三张1280×720原图：状态正确，“外观 · 原版信使”“外观 · 围巾旅人”“外观 · 修钟少女”字形完整可辨；后两项灰色锁定且未选择。字体metadata没有替代像素审查。

raw selector console仍有一条generic404（未知URL/原因）；classified errors/failed_requests为空不等于所有错误为零。Q旧偶发H失败原因仍未知，P成功不倒签旧失败已修。全森林/HUD、完整音画、自然流程、Boss战、实体设备/FUN和最终用户审美均未签。原movie证据未动。
