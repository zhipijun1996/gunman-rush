import json,pathlib,hashlib,subprocess,concurrent.futures,io
from PIL import Image
R=pathlib.Path('/workspace/gunman-rush'); O=R/'build/forest_revision04/P-movie-independent'; B=R/'build/forest_revision04/main-movie-derivatives-P66e8'
P='66e8b912854d6d4cccadb45b9c348a618689f5a1'
def sha(p):
 with open(p,'rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def probe(p):
 a=['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(p)]
 x=subprocess.run(a,capture_output=True,check=True);return {'argv':a,'exit_code':x.returncode,'stderr':x.stderr.decode(),'data':json.loads(x.stdout)}
s=json.loads((B/'summary.json').read_text());wpath=R/s['native_wrapper_receipt'];w=json.loads(wpath.read_text())
res={'source_commit':P,'execution_head':P,'verdict':'PENDING_PIXEL_NARRATIVE','independent':True,'viewed_pngs':[],'png_audit':[],'maps':[],'errors':[],'source_closure':{'derivative_source_stable':s['source_stable'],'wrapper_source_stable':w['source_stable'],'wrapper_hash_equal':sha(wpath)==s['native_wrapper_receipt_sha256'],'derivative_before_after_equal':s['source_before']==s['source_after'],'wrapper_before_after_equal':w['source_before']==w['source_after']}}
for m in s['maps']:
 idx=json.loads((B/f"map{m['map']}/event-frame-index.json").read_text()); cp=R/m['capture'];cap=json.loads(cp.read_text());nr=json.loads((R/m['native_receipt']).read_text());run=nr['runs'][0]
 item={'map':m['map'],'seed':m['seed'],'route':m['route'],'execution_head':m['execution_head'],'native_receipt':m['native_receipt'],'native_receipt_hash_equal':sha(R/m['native_receipt'])==m['native_receipt_sha256'],'capture_hash_equal':sha(cp)==m['capture_sha256'],'source_stable':nr['source_stable'],'native_exit':run['exit_code'],'native_errors':run['errors'],'movie_errors':run['movie']['errors'],'software_render_threads':run['software_render_threads'],'completed_legs':len(cap['completed_legs']),'physics_frames':len(cap['frames']),'capture_failures':cap['failures'],'actual_stage_version':cap['actual_stage_version'],'manifest_layout_version':cap['manifest'].get('layout_version'),'manual_motor_step':cap['manual_motor_step'],'position_or_resource_injection':cap['position_or_resource_injection'],'boss_fight_covered':cap['boss_fight_covered'],'avi_frames':m['video_frames'],'outer_seconds':w['maps'][m['map']-1].get('seconds'),'source_before_after_equal':nr['source_before']==nr['source_after']}
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:
  paths=[R/m['avi'],R/m['mp4']]; hs=list(ex.map(sha,paths));ps=list(ex.map(probe,paths))
 for k,h,p in zip(['avi','mp4'],hs,ps):
  item[k]={'path':m[k],'sha256':h,'hash_equal':h==m[k+'_sha256'],'bytes':(R/m[k]).stat().st_size,'probe':p}
  (O/f"map{m['map']}-{k}-ffprobe.json").write_text(json.dumps(p,indent=2)+'\n')
 inds=[f['avi_frame_index_zero_based'] for f in idx['frames']]
 command=['ffmpeg','-hide_banner','-loglevel','error','-threads','1','-filter_threads','1','-i',str(R/m['avi']),'-map','0:v:0','-vf','select='+ '+'.join('eq(n\\,%d)'%n for n in inds),'-fps_mode','vfr','-pix_fmt','rgb24','-f','rawvideo','-threads','1','pipe:1']
 dec=subprocess.run(command,capture_output=True,check=True);sz=1280*720*3;assert len(dec.stdout)==sz*len(inds)
 item['decode_command']=command;item['decode_exit']=dec.returncode;item['decode_stderr']=dec.stderr.decode();item['direct_avi_rgb_equal_all_16']=True
 for j,f in enumerate(idx['frames']):
  p=R/f['png'];im=Image.open(p).convert('RGB');h=sha(p);eq=im.size==(1280,720) and im.tobytes()==dec.stdout[j*sz:(j+1)*sz]
  row={**{k:f[k] for k in ['png','avi_frame_index_zero_based','event_presentation_frame','avi_frame_offset_from_event','movie_time_seconds','event_fields']},'sha256':h,'metadata_hash_equal':h==f['sha256'],'viewed':True,'dimensions':list(im.size),'direct_avi_rgb_exact':eq}
  res['viewed_pngs'].append(f['png']);res['png_audit'].append(row);item['direct_avi_rgb_equal_all_16'] &=eq
  if not eq or h!=f['sha256']:res['errors'].append(f['png'])
 item['camera_trace_available']=False
 item['camera_trace_limit']='Capture frame records contain motor position but no camera center/zoom. No invented numerical camera trajectory.'
 res['maps'].append(item)
res['source_closure']['current_head']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();res['source_closure']['current_git_status']=subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True)
res['observed_count']=len(res['viewed_pngs']);(O/'audit.json').write_text(json.dumps(res,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'errors':res['errors'],'count':res['observed_count'],'source_closure':res['source_closure'],'map_results':[{k:m[k] for k in ['map','completed_legs','physics_frames','native_exit','native_errors','movie_errors','manifest_layout_version','direct_avi_rgb_equal_all_16']} for m in res['maps']]}))
