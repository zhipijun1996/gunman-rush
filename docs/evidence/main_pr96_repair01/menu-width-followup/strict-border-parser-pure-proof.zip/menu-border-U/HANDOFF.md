Scoped screenshot parser fix, base U e4b2132dd30bf8ca176a28eb79d1b32a65bb59e3

The real complete ACTIONS button has border RGB130,155,119, global palette rank84. The old top16 excluded that border. Only _studio_button_boxes changes: derive color candidates from observed exact horizontal+vertical runs, then retain original complete4edge/bounds/OCR/ambiguity checks. No coordinate/text/state fallback, browser budgets, production or original three consumers changed.

Pure suite:8/8 pass13.159s. Exact same suite with original helper:7 pass, real complete U case fails16.578s, proving regression coverage. OriginalM clipping remains rejected; actual duplicate buttons, each missingedge, Lshape, incomplete/suffix/substring/duplicate OCR remain rejected. First failed duplicate-fixture authoring run preserved in unit-r1.log; the testcanvas was too short for existing relative-size guard, corrected without detector changes.

See handoff.json and AST-preservation.json for full source/provenance/SHA. New testfixtures are byte-identical original M/U screenshots, not reconstructions. Initial current-U parse result/ROI TSV retained under first-real-U*. New helper geometry5.065s/current total6.797s, versus original recorded U geometry8.266s; single sample only. Native/browser were not run here. Source frozen; CPU window released. Root owns original3 live browser replay and commits.
