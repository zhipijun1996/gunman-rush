Weapon popup pure screenshot repair, W5a4d0da86fb217415aeb80c7c2a618ec2565b35b

Actual W navigation passed; original first browser failed57.607s with only223 marker. Original screenshot has15 full items. The old x45 scans flat green background; the actual unselected circle RGB differs from green by only14 total, failing old>25/gray assumptions. Only popup pixel discovery changes.

The new pure helper derives a complete panel from observed exact fill/background+four-border edges, finds actual round radio silhouettes including selected/unselected variants, requires one column with exactly15 actual components and original spacing inequalities, returns their actual centers. No fixednew coordinates, inferred absent rows, DOM/state injection or keyboardselection. Existing Action border/label/readiness/selection/6 original browser CLIs unchanged.

15tests pass15.161s: original8 AST-preserved plus7 actualpopup/negativecontrols; see unit-r2.log. W rawPNG pure parse approx0.5s. A first isolated standalone probe missed actualHUDscanstart197 vs paneltop192; r1 source/failure kept, gate corrected with actual asynchelper/HUD screenshot-I/O unit integration (no browser, no actualclick claim). Original failed browser artifacts unchanged.

Full source/fixture provenance/SHA and exact bounded scope in handoff.json/AST-preservation.json. Source frozen, pure process exited. Root owns independent review/commit/original3browser replay; no live browser/native executed here.
