P mobile TITLE-only screenshot navigation repair

Original P source09f09f99d8d3c2a6a1e3ff6edd4a3147814e4b58 firstbrowser failed201.741s: desktop nav/5mouse screenshots exist but finalbusinessreport absent; mobile originalwhole-frame3xpsm11 missed visibleTITLE across5attempts before ActionStudio. No browser/native was launched here.

Only a full-frame StudioMenuLabelMissing allows the same original screenshot to enter TITLE-only completefill4boundary OCR. Full-frame ambiguity stays fatal. Actual small-title right edge has no coloredstroke pixel, but completefill boundary is visible. All4 actual innerfill/outer-nonfill edges required, not touching screenshot bounds. Innerpixels fixed6xNEAREST/psm7 yield complete original English phrase via unchanged parser and actual uniquecenter509.5,262. No spellingwhitelist/coordinate/state fallback.

21puretests pass26.099s: original15AST unchanged plus6 bounded real/negative cases. Missingedges retain allactualtitle glyphs, imageclipping, duplicatefullbuttons, partialtext and realALL extra suffix all reject. Originalborder/Actions/popup/6CLI unchanged. Failedoriginal/2xoutline/LANCZOS probes and timingvariable erratum retained. Exactpaths/sourceSHA/provenance in handoff.json and AST-preservation.json.

Owned4sourcepaths frozen. Rootdocs changes belong to root. PureCPU processes all exited. Root owns indie/commit/Qexport/original3; mobile Action/picker/gameplay is not signed by this parser proof.
