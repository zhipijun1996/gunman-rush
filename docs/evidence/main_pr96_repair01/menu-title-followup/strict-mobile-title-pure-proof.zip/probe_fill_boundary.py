import sys,time,json,subprocess,os
from pathlib import Path
import numpy as np
from PIL import Image
sys.path.insert(0,'tools');import studio_gui_pointer as h
out=Path('build/forest_revision04/mobile-title-P');im=Image.open('build/forest_revision04/popup-P09f0-three/browser-cwd/build/studio-navigation/1792497154666907100/title-0.png').convert('RGB');t=time.monotonic();rgb=np.asarray(im,dtype=np.uint32);a=(rgb[:,:,0]<<16)|(rgb[:,:,1]<<8)|rgb[:,:,2]
def colors(lines,n):
 result=set()
 for line in lines:
  starts=np.r_[0,np.flatnonzero(line[1:]!=line[:-1])+1];ends=np.r_[starts[1:],line.size];result.update(line[starts[(ends-starts)>=n]].tolist())
 return result
def components(mask):
 pixels={(int(x),int(y))for y,x in np.argwhere(mask)}
 while pixels:
  seed=pixels.pop();q=[seed];part=[]
  while q:
   x,y=q.pop();part.append((x,y))
   for p in [(x-1,y),(x+1,y),(x,y-1),(x,y+1)]:
    if p in pixels:pixels.remove(p);q.append(p)
  xs,ys=zip(*part);yield(min(xs),min(ys),max(xs)+1,max(ys)+1),part
boxes=set()
for color in colors(a,80)&colors(a.T,20):
 for (l,t,r,b),part in components(a==color):
  w,hh=r-l,b-t
  if not(80<=w<=im.width*.9 and 20<=hh<=im.height*.15 and 2<=w/hh<=24 and len(part)/(w*hh)>.6 and l>0 and t>0 and r<im.width and b<im.height):continue
  xs=slice(l+w//4,r-w//4);ys=slice(t+hh//4,b-hh//4)
  inside=[a[t,xs],a[b-1,xs],a[ys,l],a[ys,r-1]];outside=[a[t-1,xs],a[b,xs],a[ys,l-1],a[ys,r]]
  if all(np.mean(v==color)>=.8 for v in inside) and all(np.mean(v!=color)>=.8 for v in outside):boxes.add((l-1,t-1,r+1,b+1))
rows=[]
for i,b in enumerate(sorted(boxes)):
 roi=im.crop(b).convert('L');roi=roi.resize((roi.width*6,roi.height*6),Image.Resampling.LANCZOS);p=out/f'fill-roi-{i}.png';roi.save(p);res=subprocess.run(['tesseract',str(p),'stdout','--psm','7','tsv'],capture_output=True,text=True,check=True,timeout=10,env={**os.environ,'OMP_THREAD_LIMIT':'1'});(out/f'fill-roi-{i}.tsv').write_text(res.stdout);row={'box':b}
 try:row['local_point']=h._studio_label_box(res.stdout,'DEVELOPMENT DEMOS / ALL ENTRIES',6)
 except AssertionError as e:row['error']=str(e)
 rows.append(row)
result={'scope':'Pure original P PNG fill rectangle all4visible boundary proposal, original exact parser; no source edit/browser','seconds':time.monotonic()-t,'boxes':rows};(out/'probe-fill-original-P.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
