Local Web K selected evidence

Exact source 8f803e2f04b17db3ed725df9071669fe78cadeea. Original build → original20/8 GUI480 → separate selector120. The supplemental pixels require independent review; technical success does not establish CJK or whole UI approval.

Includes all raw metadata/reports/console/events/input traces/logs/OCR TSV plus sixteen full entry/resumed and three selector screenshots, copied byte for byte. Full PCK/WASM excluded; full SHA identities and before/after bundle/source inventories included. Omitted navigation/derived OCR PNGs indexed separately. Actual original caps and exit status remain in raw outer receipts. No extra combined outer timer. Local service only; no public-main/device/natural-route claim.
