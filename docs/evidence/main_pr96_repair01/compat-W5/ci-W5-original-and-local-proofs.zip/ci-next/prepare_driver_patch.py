from pathlib import Path
import difflib,json,hashlib
out=Path('build/forest_revision04/ci-next/candidates')
paths=['tests/plains_region_trace.gd','tests/level_formal_trace.gd'];patch=[];rows=[]
for path in paths:
 a=Path(path).read_text();s=a
 if path.endswith('/plains_region_trace.gd'):
  marker='func deep_trial(id: String) -> bool:'
  helper='''func open_backside_shortcut(_edge: Dictionary) -> bool:
	# Legacy assembled fixtures retain their original proximity interaction.
	# The live formal App overrides this actuator for its attack-only latch.
	controller.router.request_action(&"interact")
	await tick(3)
	if is_trace_cancelled(): return false
	return region_state.opened.has(_edge.id)

'''
  s=s.replace(marker,helper+marker,1)
  s=s.replace('''				controller.router.request_action(&"interact")
				await tick(3)
				if is_trace_cancelled(): return false
				check.call(region_state.opened.has(shortcut.id),"reward return opens actual nearby upper-side hatch through input")''','''				await open_backside_shortcut(shortcut)
				if is_trace_cancelled(): return false
				check.call(region_state.opened.has(shortcut.id),"reward return opens actual nearby upper-side hatch through input")''',1)
 else:
  s=s.replace('''	# Production shortcut opening must go through nearby input interaction.''','''	# Production shortcut opening must go through its actual nearby actuator.''',1)
  s=s.replace('''		controller.router.request_action(&"interact")
		await tick(3)
		if is_trace_cancelled(): return false
		if not region_state.opened.has(edge.id):''','''		await open_backside_shortcut(edge)
		if is_trace_cancelled(): return false
		if not region_state.opened.has(edge.id):''',1)
  marker='func walk_edge(edge: Dictionary, forward: bool) -> bool:'
  helper='''func open_backside_shortcut(edge: Dictionary) -> bool:
	# Only a real installed attack latch selects the current contract. The
	# historical fixture actuator remains in the base driver unchanged.
	var latch: Node2D = null
	for candidate: Node2D in stage.attack_shortcuts:
		if str(candidate.shortcut_id) == str(edge.id):latch = candidate;break
	if latch == null:return await super.open_backside_shortcut(edge)
	var control: Vector2 = latch.upper_control
	var actor: Vector2 = latch.to_local(motor.global_position)
	if actor.distance_to(control)>90.0 or actor.y>control.y+24.0:return false
	critical_traversal += 1
	controller.router.set_move_axis(0)
	# Observe the original weapon cooldown/resource policy before submitting
	# one Router shot. This stays inside the unchanged total route budget.
	var ready := false
	for unused: int in 30:
		if controller.shoot_ability.cooldown_remaining<=0 and controller.shoot_ability.rounds_remaining==0 and controller.shot_energy.can_fire():ready=true;break
		await tick()
		if is_trace_cancelled():break
	var before_serial: int = controller.shoot_ability._shot_serial
	if ready and not is_trace_cancelled():
		actor = latch.to_local(motor.global_position)
		if actor.distance_to(control)>90.0 or actor.y>control.y+24.0:ready=false
		else:ready=controller.router.request_action(&"shoot_release",(latch.to_global(latch.bell_position)-motor.global_position).normalized())
	if ready:
		for unused: int in 30:
			await tick()
			if is_trace_cancelled() or region_state.opened.has(edge.id):break
	critical_traversal -= 1
	if is_trace_cancelled():return false
	var opened: bool = ready and controller.shoot_ability._shot_serial>before_serial and latch.is_open and region_state.opened.has(edge.id) and stage.shortcut_shapes[str(edge.id)].disabled
	policy_observations.append({"tick":trace_ticks,"kind":"actual_backside_attack","shortcut":str(edge.id),"actor_position":SNAPSHOT.pair(motor.global_position),"before_shot_serial":before_serial,"after_shot_serial":controller.shoot_ability._shot_serial,"opened":opened})
	return opened

'''
  s=s.replace(marker,helper+marker,1)
 if path.endswith('/plains_region_trace.gd'):
  s=s.replace('if not region_state.opened.has(shortcut.id): return false','if not shortcut_opened or not region_state.opened.has(shortcut.id): return false',1)
 else:
  s=s.replace('await open_backside_shortcut(edge)\n','var shortcut_opened: bool = await open_backside_shortcut(edge)\n',1)
  s=s.replace('if not region_state.opened.has(edge.id):\n\t\t\trecord_check','if not shortcut_opened or not region_state.opened.has(edge.id):\n\t\t\trecord_check',1)
 assert s!=a,path
 (out/Path(path).name).write_text(s)
 patch.extend(difflib.unified_diff(a.splitlines(True),s.splitlines(True),fromfile='a/'+path,tofile='b/'+path))
 rows.append({'path':path,'before_sha256':hashlib.sha256(a.encode()).hexdigest(),'candidate_sha256':hashlib.sha256(s.encode()).hexdigest()})
Path('build/forest_revision04/ci-next/driver-proposal.patch').write_text(''.join(patch));Path('build/forest_revision04/ci-next/driver-proposal.json').write_text(json.dumps(rows,indent=2)+'\n')
print('Prepared two driver candidates; source unchanged.')
