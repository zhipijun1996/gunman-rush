from pathlib import Path
import difflib,json,hashlib
out=Path('build/forest_revision04/ci-next/candidates');out.mkdir(parents=True,exist_ok=True)
paths=['tests/underworld_plains/'+name for name in ['test_underworld_r3_objects.gd','test_underworld_formal.gd','test_underworld_r3_boss_lifecycle.gd','test_underworld_identity_population.gd','capture_scenery_windows.gd','capture_underworld_r3_boss_fight.gd','capture_revision3_projectile_windows.gd']]+['tests/plains_pressure_boss_runner.gd']
patch=[];inventory=[]
for path in paths:
 a=Path(path).read_text();s=a;name=Path(path).name
 if name!='plains_pressure_boss_runner.gd':
  s=s.replace('app.director.stage_index=2','app.director.stage_index=2;app.director.region_map_index=2').replace('app.director.stage_index = 2','app.director.stage_index = 2;app.director.region_map_index = 2')
 identity='stage.map_index == map_index and app.director.region_map_index == map_index and str(stage.generated.manifest.seed) == PlainsRegionCampaign.seed_for(app.director.seed,map_index) and str(stage.generated.manifest.manifest_hash).length() == 64'
 if name in ['test_underworld_r3_objects.gd','test_underworld_formal.gd','test_underworld_identity_population.gd']:
  stage_line=next(l for l in s.splitlines() if 'var stage' in l and 'app.stage as PlainsRegionStage' in l);indent=stage_line[:len(stage_line)-len(stage_line.lstrip())]
  s=s.replace(stage_line,stage_line+'\n'+indent+'check('+identity+',"actual formal map, derived seed and hash match the requested consumer")\n'+indent+'var actual_hash := str(stage.generated.manifest.manifest_hash)\n'+indent+'check(not map_hashes.has(actual_hash),"requested formal map owns a distinct actual Manifest hash")\n'+indent+'map_hashes[actual_hash] = true',1)
  marker='func formal_consumers() -> void:' if name=='test_underworld_r3_objects.gd' else 'func run() -> void:'
  s=s.replace(marker,marker+'\n\tvar map_hashes: Dictionary = {}',1)
 elif name=='test_underworld_r3_boss_lifecycle.gd':
  s=s.replace('var encounter:WindkeeperEncounter','var encounter:WindkeeperEncounter\nvar map_hashes: Dictionary = {}')
  marker='\tencounter=app.stage.boss.get_node("Encounter") as WindkeeperEncounter'
  s=s.replace(marker,'\tvar stage := app.stage as PlainsRegionStage\n\tcheck('+identity+',"actual Boss fixture map, derived seed and hash match the requested consumer")\n\tvar actual_hash := str(stage.generated.manifest.manifest_hash)\n\tcheck(not map_hashes.has(3-map_index) or map_hashes[3-map_index] != actual_hash,"mini and main fixtures own distinct actual Manifest hashes")\n\tmap_hashes[map_index] = actual_hash\n'+marker,1)
 elif name=='capture_scenery_windows.gd':
  marker='\tif stage == null or not stage.assembly_ok: push_error("Real formal stage failed"); quit(1); return'
  s=s.replace(marker,marker+'\n\tif not ('+identity+'): push_error("Requested scenery map identity mismatch"); quit(1); return')
  s=s.replace('"map":map_index,"grounded_landmark_rays"','"map":map_index,"actual_map_index":stage.map_index,"manifest_seed":stage.generated.manifest.seed,"manifest_hash":stage.generated.manifest.manifest_hash,"grounded_landmark_rays"')
 elif name=='capture_underworld_r3_boss_fight.gd':
  s=s.replace('\tif map_index==2:\n','\tvar first_map_hash := str((app.stage as PlainsRegionStage).generated.manifest.manifest_hash)\n\tif map_index==2:\n',1)
  marker='\tvar stage:=app.stage as PlainsRegionStage'
  s=s.replace(marker,marker+'\n\tif not ('+identity+'): failure.append("actual fight map identity differs from requested formal map")\n\tif map_index==2 and str(stage.generated.manifest.manifest_hash)==first_map_hash: failure.append("actual main fight reused mini map Manifest hash")',1)
  s=s.replace('{"map":map_index,"failures":failure','{"map":map_index,"actual_map_index":stage.map_index,"manifest_seed":stage.generated.manifest.seed,"manifest_hash":stage.generated.manifest.manifest_hash,"failures":failure')
 elif name=='capture_revision3_projectile_windows.gd':
  s=s.replace('loaded.map_index == expected_map and loaded.is_node_ready()','loaded.map_index == expected_map and app.director.region_map_index == expected_map and str(loaded.generated.manifest.seed) == PlainsRegionCampaign.seed_for(app.director.seed,expected_map) and str(loaded.generated.manifest.manifest_hash).length() == 64 and loaded.is_node_ready()')
  s=s.replace('"map_index":app.director.stage_index,"manifest_hash"','"map_index":app.director.stage_index,"actual_map_index":stage.map_index,"manifest_seed":stage.generated.manifest.seed,"manifest_hash"')
 else:
  s=s.replace('\t\tcurrent_background.queue_free()','\t\t# Borrow the required App owner only for this historical renderer inspection.\n\t\t# Return it before the ordinary Run -> Home lifecycle resumes.')
  marker='\tcheck(JSON.stringify(stage.generated.manifest)==manifest_before,"new current-default inspection preserves the complete formal gameplay Manifest")\n\tapp.abandon_run()'
  s=s.replace(marker,marker.replace('\n\tapp.abandon_run()','\n\tbackground.queue_free()\n\tapp.add_child(current_background)\n\tcheck(app.get_node("PixelPlainsParallax")==current_background,"historical renderer fixture returns the exact required default owner")\n\tapp.abandon_run()\n\tfor attempt: int in 8:\n\t\tif app.director.state==DemoRunDirector.State.HOME and is_instance_valid(app.home_scene):break\n\t\tawait process_frame\n\tcheck(app.director.state==DemoRunDirector.State.HOME and current_background.visible,"actual Run exit restores the default Home background owner")'))
 assert s!=a,path
 oldchecks=[l.strip() for l in a.splitlines() if l.lstrip().startswith('check(')]
 assert all(l in [x.strip() for x in s.splitlines()] for l in oldchecks),path
 (out/name).write_text(s)
 patch.extend(difflib.unified_diff(a.splitlines(True),s.splitlines(True),fromfile='a/'+path,tofile='b/'+path))
 inventory.append({'path':path,'before_sha256':hashlib.sha256(a.encode()).hexdigest(),'candidate_sha256':hashlib.sha256(s.encode()).hexdigest(),'original_check_call_sites_preserved':len(oldchecks),'scope':'current actual formal consumer; historical immutable evidence and resource pins unchanged'})
Path('build/forest_revision04/ci-next/map-fixtures-proposal.patch').write_text(''.join(patch))
Path('build/forest_revision04/ci-next/map-fixtures-proposal.json').write_text(json.dumps(inventory,indent=2)+'\n')
print('Prepared',len(inventory),'test-only candidates; no source files changed.')
