from pathlib import Path
import hashlib,difflib,json
p=Path('tests/underworld_plains/capture_underworld_r3_boss_fight.gd');a=p.read_text()
old='\t\tif not settlement.first_claim or not settlement.repeat_claim_rejected or settlement.completed_biomes!=1 or not settlement.returned_home:failure.append("actual main Gold does not settle once and return home")'
new='''		settlement["gold_instances"]=app.build.count_item(selected)
		if not settlement.first_claim or not settlement.repeat_claim_rejected or settlement.gold_instances!=1:failure.append("actual main Gold does not settle exactly once")
		# Current two-region play continues through a separate core reward. These
		# are real production modal callbacks after the uninterrupted Boss battle.
		settlement["core_choice_open"]=app.progression_modal.opened and app.campaign.phase==RunCampaignProgression.Phase.ABILITY_CHOICE
		settlement["gold_does_not_grant_hook"]=not app.controller.traversal.hook_enabled
		if not settlement.core_choice_open or not settlement.gold_does_not_grant_hook or settlement.returned_home or settlement.completed_biomes!=0:failure.append("actual Gold must open the separate current core reward without ending the run")
		var previous_region_token := app.lifetime.token()
		var previous_stage_epoch := app.lifetime.stage_epoch
		var continuing_player_id := app.player.get_instance_id()
		app.progression_modal.ability_selected.emit(&"grapple")
		settlement["grapple_granted_once"]=app.controller.traversal.hook_enabled and app.campaign.abilities==[&"grapple"]
		settlement["region_choice_open"]=app.progression_modal.opened and app.campaign.phase==RunCampaignProgression.Phase.REGION_CHOICE
		var selected_core_snapshot := app.director.manifest.canonical_json()
		app.progression_modal.ability_selected.emit(&"grapple")
		settlement["duplicate_core_has_no_effect"]=app.campaign.abilities==[&"grapple"] and app.director.manifest.canonical_json()==selected_core_snapshot
		if not settlement.grapple_granted_once or not settlement.region_choice_open or not settlement.duplicate_core_has_no_effect:failure.append("actual core modal must grant grapple once and open region selection")
		app.progression_modal.region_selected.emit(&"thorn_forest")
		await frames(8)
		settlement["forest_entered"]=app.stage is ThornForestRegionStage and app.stage.assembly_ok and app.stage.map_index==1 and app.active_region_id==&"thorn_forest" and app.campaign.phase==RunCampaignProgression.Phase.PLAYING
		settlement["forest_version"]=str(app.stage.generated.manifest.version) if app.stage is ThornForestRegionStage else ""
		settlement["forest_layout"]=str(app.stage.generated.manifest.layout_version) if app.stage is ThornForestRegionStage else ""
		settlement["same_player_with_grapple"]=app.player.get_instance_id()==continuing_player_id and app.controller.traversal.hook_enabled and app.campaign.abilities==[&"grapple"] and app.build.count_item(selected)==1
		settlement["previous_region_token_rejected"]=not app.lifetime.accepts(previous_region_token) and app.lifetime.stage_epoch>previous_stage_epoch
		if not settlement.forest_entered or settlement.forest_version!="thorn-forest-region-v2" or settlement.forest_layout!="forest-fruit-routes-v14" or not settlement.same_player_with_grapple or not settlement.previous_region_token_rejected:failure.append("actual post-Boss region selection must assemble the default forest with retained Gold, one grapple and a fresh stage token")'''
assert old in a
b=a.replace(old,new,1)
out=Path('build/forest_revision04/ci-next');(out/'candidates/capture_underworld_r3_boss_fight_campaign.gd').write_text(b);(out/'boss-campaign-proposal.patch').write_text(''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='a/'+str(p),tofile='b/'+str(p))));(out/'boss-campaign-before.json').write_text(json.dumps({'path':str(p),'before_sha256':hashlib.sha256(a.encode()).hexdigest(),'candidate_sha256':hashlib.sha256(b.encode()).hexdigest()},indent=2)+'\n');print('Boss campaign candidate prepared; source unchanged during full policy.')
