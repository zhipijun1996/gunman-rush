import ast, json, hashlib, os, subprocess, sys, time
from pathlib import Path
from functools import partial
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from threading import Thread
ROOT=Path('/workspace/gunman-rush');OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'tools'))
import harness
from run_forest_depth_region import inventory
from verify_ci_artifact_browser import inventory as web_inventory
Q='4aec8b56743d1a14d1b44ba43d795e56811d7615'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
original=ROOT/'tools/verify_action_budget_browser.py';raw=original.read_text();(OUT/'original-Q-verify_action_budget_browser.py').write_bytes(original.read_bytes());tree=ast.parse(raw)
for node in tree.body:
 if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name)and t.id=='ROOT' for t in node.targets):node.value=ast.parse("Path('/workspace/gunman-rush')",mode='eval').body
main=next(n for n in tree.body if isinstance(n,ast.AsyncFunctionDef)and n.name=='main')
log=next(n for n in ast.walk(main)if isinstance(n,ast.FunctionDef)and n.name=='log')
for node in ast.walk(log):
 if isinstance(node,ast.Try)and node.body and isinstance(node.body[0],ast.Expr)and isinstance(node.body[0].value,ast.Call)and isinstance(node.body[0].value.func,ast.Attribute)and node.body[0].value.func.attr=='append':
  node.body += ast.parse("with (OUT/'diagnostic-events.jsonl').open('a') as diagnostic_stream:\n diagnostic_stream.write(json.dumps({'received_monotonic':time.monotonic(),'event':events[-1]},ensure_ascii=False)+'\\n')").body
block=next(n for n in main.body if isinstance(n,ast.AsyncWith))
except_body=ast.parse("""(OUT/'diagnostic-failure.json').write_text(json.dumps({'type':type(diagnostic_exc).__name__,'error':str(diagnostic_exc),'received_monotonic':time.monotonic()},indent=2)+'\\n')
try:
 if 'page' in locals() and not page.is_closed():
  await page.screenshot(path=str(OUT/'diagnostic-failure.png'))
except Exception as screenshot_exc:
 (OUT/'diagnostic-screenshot-error.json').write_text(json.dumps({'type':type(screenshot_exc).__name__,'error':str(screenshot_exc)},indent=2)+'\\n')
raise
""").body
final_body=ast.parse("(OUT/'diagnostic-finally.json').write_text(json.dumps({'events':events,'checks':checks,'browser_errors':errors,'scope':'Passive observer, original actions/assertions/caps unchanged; not original-three acceptance'},ensure_ascii=False,indent=2)+'\\n')").body
block.body=[ast.Try(body=block.body,handlers=[ast.ExceptHandler(type=ast.Name(id='BaseException',ctx=ast.Load()),name='diagnostic_exc',body=except_body)],orelse=[],finalbody=final_body)]
ast.fix_missing_locations(tree);driver=OUT/'observe_verify_action_budget_browser.py';driver.write_text(ast.unparse(tree)+'\n')
base=ast.parse(raw);new=ast.parse(driver.read_text())
asserts=lambda x:[ast.dump(n)for n in ast.walk(x)if isinstance(n,ast.Assert)]
assert asserts(base)==asserts(new)
def business_calls(x):
 return [ast.dump(n)for n in ast.walk(x)if isinstance(n,ast.Call)and isinstance(n.func,ast.Attribute)and (n.func.attr in ('press','down','up','click','move','tap','wait_for_timeout','wait_for_function','send','goto')or n.func.attr=='new_context')]
assert business_calls(base)==business_calls(new)
awaits=lambda x:[ast.dump(n)for n in ast.walk(x)if isinstance(n,ast.Await)]
# Wrapping a block changes ast.walk breadth-first order. Compare the concrete
# ordered statements via a depth-first visitor, excluding only failure screenshot.
def ordered(x,predicate):
 out=[]
 class V(ast.NodeVisitor):
  def generic_visit(self,node):
   if predicate(node):out.append(ast.dump(node))
   super().generic_visit(node)
 V().visit(x);return out
old_await=ordered(base,lambda n:isinstance(n,ast.Await));new_await=ordered(new,lambda n:isinstance(n,ast.Await))
assert len(new_await)==len(old_await)+1
assert [n for n in new_await if "diagnostic-failure.png"not in n]==old_await
proof={'original_script_sha256':sha(original),'observer_script_sha256':sha(driver),'same_all_assertions':True,'same_all_input_wait_navigation_calls':True,'same_ordered_awaits_except_one_failure_screenshot':True,'ROOT_explicit_repo':str(ROOT),'extra_total_timeout':None,'browser_cap_seconds':300,'changes':['Explicit copied-script ROOT','Immediate JSONL append for each accepted actual console event','Exception screenshot before context cleanup, preserve originalraise','Finally full actual events/checks/errors dump']}
(OUT/'AST-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
(OUT/'observer.diff').write_text(subprocess.run(['diff','-u',str(OUT/'original-Q-verify_action_budget_browser.py'),str(driver)],capture_output=True,text=True).stdout)
def state():
 return {'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'git_status':subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True),'inventory':inventory()}
record={'scope':'One original-action observer-only run; not original3 acceptance','execution_head':Q,'AST_proof':proof,'source_before':state(),'bundle_before':web_inventory(ROOT/'build/web'),'driver_sha256_before':sha(driver)}
assert record['source_before']['head']==Q and not record['source_before']['git_status']
info=json.loads((ROOT/'build/web/build-info.json').read_text());record['build_info']=info;record['full_PCK_sha256']=sha(ROOT/'build/web'/info['pack']);assert info['source_commit']==Q and record['full_PCK_sha256']=='442163f492173fa0aa52f24a21a6e9b0ac7d92d579eb34bdd8f67bce8de5d216'
class Quiet(SimpleHTTPRequestHandler):
 def log_message(self,*a):pass
server=ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(ROOT/'build/web')));Thread(target=server.serve_forever,daemon=True).start()
url=f'http://127.0.0.1:{server.server_port}/';cwd=OUT/'browser-cwd';cwd.mkdir(exist_ok=False);cmd=[sys.executable,str(driver),url];record.update(url=url,argv=cmd,cwd=str(cwd),status='running');(OUT/'receipt.json').write_text(json.dumps(record,indent=2)+'\n');started=time.monotonic()
try:
 result=harness.run_check({'argv':cmd,'timeout_seconds':300,'success_pattern':'"failed": \\[\\]'},OUT/'observer.log',root=cwd,env={**os.environ,'PYTHONPATH':str(ROOT/'tools')})
 record.update(result=result,elapsed_seconds=time.monotonic()-started)
finally:
 server.shutdown();server.server_close();record.update(source_after=state(),bundle_after=web_inventory(ROOT/'build/web'),driver_sha256_after=sha(driver));record.update(source_stable=record['source_before']==record['source_after'],bundle_stable=record['bundle_before']==record['bundle_after'],driver_stable=record['driver_sha256_before']==record['driver_sha256_after']);record['status']='observer_passed_not_original3' if record.get('result',{}).get('status')=='passed' else 'observer_failed_original_preserved';(OUT/'receipt.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:record[k]for k in ['status','result','elapsed_seconds','source_stable','bundle_stable','driver_stable']},indent=2))
