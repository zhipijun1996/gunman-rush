Mobile ACTIONS inner OCR fix on original observerQ

Raw actual844x390 PNG came from singleQ4aec observer, which strictlyFAILED165.775s afterdesktopupwardHsuccess andmobileTITLEsuccess; desktophad1falseslowtimecheck. Do not relabeloldQoriginalorobserver asPASS.

Original border extraction did find completeACTIONS, but wholeborder6xLANCZOS OCRmissed. Fixedruntime fallback is only missinglabel→actualclosedinnerfill of an ALREADYcompletecolored4edge candidate→8xLANCZOSpsm7→unchanged completebilingual Englishrightclause parser. Firstpassambiguity staysfatal; missingcolorededge never entersinnerfallback. No inferredletters/spellingwhitelist/point/state fallback. Pixelglyphpoint286.1875,163 derives actual8xwordbbox266.5,159.75..305.875,166.25. Failedpurevariants all kept; no runtimeparametersearch.

25puretests pass39.314s, old21AST unchanged, newactualmobilepositive/fourmissingcolorededges/duplicate/partial-suffix controls. OriginalMclipping and all oldborder/TITLE/popup tests stillpass. Source4ownedpaths frozen; parent owns separateclock/docs changes. Allpure processes exit; no browser/native run for thisfix. FullsourceSHA/provenance in handoff.json and AST-preservation.json.
