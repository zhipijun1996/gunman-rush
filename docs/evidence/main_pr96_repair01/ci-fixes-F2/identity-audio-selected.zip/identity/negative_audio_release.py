import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/"tools"))
from run_tests import run_engine
try:
    run_engine(["--headless","--audio-driver","Dummy","--path",".","--script","tests/underworld_plains/test_underworld_identity_population.gd","--","--retain-owned-audio"],240)
except Exception as error:
    print("ORIGINAL STRICT WRAPPER REFUSED:",repr(error),flush=True)
    raise SystemExit(1)
raise SystemExit(0)
