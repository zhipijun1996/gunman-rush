from pathlib import Path
import numpy as np,json
from PIL import Image
OUT=Path(__file__).resolve().parent
source=Path('/workspace/gunman-rush/build/forest_revision04/mobile-Sf18f-three/browser-cwd/build/weapon_feel/popup_failure.png');image=Image.open(source).convert('RGB');rgb=np.asarray(image,dtype=np.uint32);a=(rgb[:,:,0]<<16)|(rgb[:,:,1]<<8)|rgb[:,:,2]
panel=json.loads((OUT/'actual-S-probe.json').read_text())['panel_candidates'][0];left,top,right,bottom=panel['bounds'];col_left,col_right=104,113
# These candidate columns come from all14 actually found round component boxes,
# not a fixed coordinate in the proposed production helper.
ys=slice(top+(bottom-top)//4,bottom-(bottom-top)//4);xs=slice(left+(right-left)//4,right-(right-left)//4);bg=(27<<16)|(38<<8)|37
coverage={'inside':[float(np.mean(x==bg))for x in[a[top,xs],a[bottom-1,xs],a[ys,left],a[ys,right-1]]],'outside':[float(np.mean(x!=bg))for x in[a[top-1,xs],a[bottom,xs],a[ys,left-1],a[ys,right]]]}
strip=a[top:bottom,col_left:col_right];reference=a[top:bottom,col_right];mask=strip!=reference[:,None]
pixels={(int(x),int(y))for y,x in np.argwhere(mask)};components=[]
while pixels:
 seed=pixels.pop();q=[seed];part=[]
 while q:
  x,y=q.pop();part.append((x,y))
  for p in[(x-1,y),(x+1,y),(x,y-1),(x,y+1)]:
   if p in pixels:pixels.remove(p);q.append(p)
 xx,yy=zip(*part);l,t,r,b=min(xx),min(yy),max(xx)+1,max(yy)+1;w,h=r-l,b-t;m=np.zeros((h,w),bool)
 for x,y in part:m[y-t,x-l]=True
 valid=(6*(390/720)<=min(w,h)and max(w,h)<=24*(390/720)and .85<=w/h<=1.18 and .65<=m.mean() and (m.mean()<.95 or (len(part)<=int(np.ceil(.95*w*h)) and all(int(np.sum(rgb[top+t+py,col_left+l+px]))>int(np.sum(rgb[top+t+h//2,col_left+l+w//2])) for px,py in [(w//2,0),(w//2,h-1),(0,h//2),(w-1,h//2)]))) and np.mean(m==m[:,::-1])>=.9 and np.mean(m==m[::-1,:])>=.9 and not any(m[y,x]for x,y in[(0,0),(w-1,0),(0,h-1),(w-1,h-1)])and m[h//2,:].all()and m[:,w//2].all())
 components.append({'box':[col_left+l,top+t,col_left+r,top+b],'valid_round':bool(valid),'density':float(m.mean()),'hsym':float(np.mean(m==m[:,::-1])),'vsym':float(np.mean(m==m[::-1,:])),'mask':[''.join('#'if v else'.'for v in row)for row in m]})
rows=sorted((c['box'][1]+c['box'][3]-1)/2 for c in components if c['valid_round']);result={'scope':'Ignored pure prototype only. Columns derived from14 actual components in actual-S-probe','panel_four_fill_boundaries':coverage,'round_components':components,'actual_round_rows':rows,'count':len(rows)};(OUT/'strip-proof-quantized.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k!='round_components'},indent=2));print('first',components[0]if components else None)
