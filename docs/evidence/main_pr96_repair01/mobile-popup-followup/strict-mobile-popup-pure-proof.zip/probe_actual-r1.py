from pathlib import Path
from collections import Counter
import hashlib,json,sys,asyncio,time
import numpy as np
from PIL import Image
ROOT=Path('/workspace/gunman-rush');sys.path.insert(0,str(ROOT/'tools'));import studio_gui_pointer as h
OUT=Path(__file__).resolve().parent;source=ROOT/'build/forest_revision04/mobile-Sf18f-three/browser-cwd/build/weapon_feel/popup_failure.png';image=Image.open(source).convert('RGB');rgb=np.asarray(image,dtype=np.uint32);a=(rgb[:,:,0]<<16)|(rgb[:,:,1]<<8)|rgb[:,:,2]
class Page:
 viewport_size={'width':844,'height':390}
 async def screenshot(self):return source.read_bytes()
scale,pad,_=h.geometry(Page());row=asyncio.run(h.weapon_row_y(Page()));start_y=round(row+18*scale)
r={'scope':'Pure originalS screenshot, no native/browser/source change','source':str(source),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'geometry_scale':scale,'pad':pad,'actual_HUD_weapon_row':row,'original_scan_start':start_y,'panel_candidates':[]}
try:r['original_result']=h._weapon_popup_from_pixels(image,scale,start_y)
except AssertionError as e:r['original_error']=str(e)
def components(mask):
 pixels={(int(x),int(y))for y,x in np.argwhere(mask)}
 while pixels:
  seed=pixels.pop();q=[seed];part=[]
  while q:
   x,y=q.pop();part.append((x,y))
   for p in [(x-1,y),(x+1,y),(x,y-1),(x,y+1)]:
    if p in pixels:pixels.remove(p);q.append(p)
  xs,ys=zip(*part);yield(min(xs),min(ys),max(xs)+1,max(ys)+1),part
colors=set()
for col in a.T:
 st=np.r_[0,np.flatnonzero(col[1:]!=col[:-1])+1];en=np.r_[st[1:],col.size];colors.update(col[st[(en-st)>300*scale]].tolist())
for color in sorted(colors):
 for (l,t,rr,b),pts in components(a==color):
  w,hh=rr-l,b-t
  if not(b>start_y and hh>300*scale and 80*scale<=w<image.width*.9 and len(pts)/(w*hh)>.5):continue
  xs=slice(l+w//4,rr-w//4);ys=slice(t+hh//4,b-hh//4);edges=[a[t-1,xs],a[b,xs],a[ys,l-1],a[ys,rr]];border=Counter(int(v)for edge in edges for v in edge).most_common(1)[0][0]
  item={'fill_rgb':tuple((color>>s)&255 for s in(16,8,0)),'bounds':[l,t,rr,b],'density':len(pts)/(w*hh),'border_rgb':tuple((border>>s)&255 for s in(16,8,0)),'four_border_coverage':[float(np.mean(edge==border))for edge in edges],'components':[]}
  crop=a[t:b,l:rr]
  for (x,y,ex,ey),part in components(crop!=color):
   mw,mh=ex-x,ey-y
   if not(6*scale<=min(mw,mh) and max(mw,mh)<=24*scale and .85<=mw/mh<=1.18):continue
   mask=np.zeros((mh,mw),dtype=bool)
   for px,py in part:mask[py-y,px-x]=True
   item['components'].append({'bounds':[l+x,t+y,l+ex,t+ey],'density':float(mask.mean()),'horizontal_symmetry':float(np.mean(mask==mask[:,::-1])),'vertical_symmetry':float(np.mean(mask==mask[::-1,:])),'corners':[bool(mask[py,px])for px,py in((0,0),(mw-1,0),(0,mh-1),(mw-1,mh-1))],'central_cross':[bool(mask[mh//2,:].all()),bool(mask[:,mw//2].all())],'mask':[''.join('#'if v else'.'for v in row)for row in mask]})
  r['panel_candidates'].append(item)
(OUT/'actual-S-probe.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items()if k!='panel_candidates'},indent=2))
for p in r['panel_candidates']:
 print('panel', {k:v for k,v in p.items()if k!='components'})
 print('leftcomponents',[{k:v for k,v in c.items()if k!='mask'} for c in p['components']if c['bounds'][0]<125])
