"""Tiny pure draft controls only; no browser/native/production writes."""
from pathlib import Path
import importlib.util,json,time
from PIL import Image,ImageDraw
OUT=Path(__file__).resolve().parent;ROOT=Path('/workspace/gunman-rush')
spec=importlib.util.spec_from_file_location('mobile_popup_draft',OUT/'helper-draft-S.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
raw=Image.open(ROOT/'build/forest_revision04/mobile-Sf18f-three/browser-cwd/build/weapon_feel/popup_failure.png').convert('RGB');observed=json.loads((OUT/'full-draft-S-result.json').read_text());boxes=observed['marker_boxes'];rows=[]
def reject(name,image,scale=390/720,start=106):
 t=time.monotonic()
 try:
  value=h._weapon_popup_from_pixels(image,scale,start);rows.append({'case':name,'rejected':False,'unexpected_result':value})
 except AssertionError as error:rows.append({'case':name,'rejected':True,'error':str(error),'seconds':time.monotonic()-t})
for index in [0,7]:
 image=raw.copy();l,t,r,b=boxes[index]
 for y in range(t,b):ImageDraw.Draw(image).line((l,y,r-1,y),fill=image.getpixel((r,y)))
 reject('erase_selected'if index==0 else'erase_middle',image)
image=raw.copy()
for l,t,r,b in boxes:
 for y in range(t,b):ImageDraw.Draw(image).line((l,y,r-1,y),fill=image.getpixel((r,y)))
reject('erase_all_radio_keep_all_text',image)
image=raw.copy();image.paste(raw.crop((94,102,231,355)),(340,102));reject('duplicate_complete_popup',image)
reject('crop_bottom',raw.crop((0,0,844,340)));reject('crop_right',raw.crop((0,0,225,390)))
for style in ['solid_square','flat_chamfered_square']:
 image=raw.copy();draw=ImageDraw.Draw(image)
 for l,t,r,b in boxes:
  for y in range(t,b):draw.line((l,y,r-1,y),fill=image.getpixel((r,y)))
  size=min(r-l,b-t);draw.rectangle((l,t,l+size-1,t+size-1),fill=(100,100,100))
  if style=='flat_chamfered_square':
   for x,y in[(l,t),(l+size-1,t),(l,t+size-1),(l+size-1,t+size-1)]:draw.point((x,y),fill=image.getpixel((r,y)))
 reject(style,image)
# One desktop positive is an exact old fixture, not a resized mobile image.
t=time.monotonic();desktop=h._weapon_popup_from_pixels(Image.open(ROOT/'tests/fixtures/studio_gui_pointer/popup_W_green.png'),1,197)
result={'scope':'Ignored draft pure-only controls; not replacement for old25 fullsuite or browser','negative_controls':rows,'desktop_original_positive_count':len(desktop['rows']),'desktop_seconds':time.monotonic()-t}
(OUT/'draft-controls.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2));assert all(r['rejected']for r in rows)
