"""Explicitly triggered W9 final-source Foundry regeneration. Never auto-starts."""
from pathlib import Path
import argparse,datetime,hashlib,importlib.util,json,os,re,shutil,signal,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[2];BASE=Path(__file__).resolve().parent

def write(name,value):
    (BASE/name).write_text(json.dumps(value,indent=2)+'\n')
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()
def inventory():
    sys.path.insert(0,str(ROOT/'tools'))
    from level_formal import source_files
    files=source_files(('tools/foundry.py','tools/foundry_validate.gd','tools/foundry_export_stamp.gd','tools/run_tests.py','scripts/generation/foundry_catalog.gd'))
    for name in git('ls-files','tools','tests').splitlines():
        p=ROOT/name
        if p.suffix in ['.py','.gd','.json','.uid'] and p.is_file():files[name]=hashlib.sha256(p.read_bytes()).hexdigest()
    return files

def descendants(pid):
    rows=subprocess.check_output(['ps','-eo','pid=,ppid='],text=True).splitlines();children={}
    for row in rows:
        child,parent=map(int,row.split());children.setdefault(parent,[]).append(child)
    found=[];todo=[pid]
    while todo:
        p=todo.pop();found.append(p);todo.extend(children.get(p,[]))
    return found

def run(name,argv,timeout,marker):
    started=time.monotonic();log=BASE/(name+'.log');record={'argv':argv,'timeout_seconds':timeout,'log':str(log.relative_to(ROOT)),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    with log.open('wb') as output:
        p=subprocess.Popen(argv,cwd=ROOT,stdout=output,stderr=subprocess.STDOUT,start_new_session=True)
        try:code=p.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            # Native run_engine children own sessions; terminate only this owned tree.
            owned=descendants(p.pid)
            for pid in reversed(owned):
                try:os.kill(pid,signal.SIGTERM)
                except ProcessLookupError:pass
            try:p.wait(timeout=2)
            except subprocess.TimeoutExpired:
                for pid in reversed(owned):
                    try:os.kill(pid,signal.SIGKILL)
                    except ProcessLookupError:pass
                p.wait(timeout=5)
            record.update(exit_code=p.returncode,timed_out=True,elapsed_seconds=time.monotonic()-started);write(name+'.json',record);raise
    text=log.read_text();record.update(exit_code=code,timed_out=False,elapsed_seconds=time.monotonic()-started)
    matches=re.findall(marker,text,re.M);record['completion_markers']=matches;write(name+'.json',record)
    assert code==0,name+' exited '+str(code)
    assert matches,name+' lacks original completion marker'
    assert not re.search(r'^\s*(?:ERROR:|SCRIPT ERROR:|Parse Error:|SHADER ERROR:)|ObjectDB.*leaked|resources? still in use at exit',text,re.M),name+' emitted native errors/leaks'
    return record

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--source-commit',required=True);args=parser.parse_args()
    expected=git('rev-parse',args.source_commit);assert git('rev-parse','HEAD')==expected,'Root-supplied final source must be current HEAD'
    prefixes=('scripts/','scenes/','resources/','config/','shaders/','assets/','tests/','tools/')
    changes=git('diff','--name-only','HEAD').splitlines()+git('ls-files','--others','--exclude-standard').splitlines()
    assert not [p for p in changes if p.startswith(prefixes) or p in ['project.godot','export_presets.cfg']],'Unfrozen runtime/driver source'
    old=json.loads((BASE/'baseline_inventory.json').read_text())
    for row in old['files']:
        assert hashlib.sha256((ROOT/row['path']).read_bytes()).hexdigest()==row['sha256'],'Current Foundry no longer matches c77f baseline'
    assert shutil.disk_usage(ROOT).free>512*1024**2,'Insufficient space for original proof and preserved raw cache'
    # An existing marker means this proof attempt already ran; never silently retry.
    with (BASE/'attempt_started.json').open('x') as marker:json.dump({'source_commit':expected,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()},marker,indent=2)
    if (ROOT/'build/foundry').exists():shutil.copytree(ROOT/'build/foundry',BASE/'prior_build_foundry_cache')
    before=inventory();write('source_before.json',before)
    try:
        build=run('build36_18',[sys.executable,'tools/foundry.py','build','--count','24','--profiles','base','double_jump','air_chain','--promote'],1000,r'^Validated 36 development phrases; 18 continuous itineraries\. Fun: awaiting playtest\.$')
        stamp=run('export_stamp',['bash','tools/godot.sh','--headless','--path','.','--script','tools/foundry_export_stamp.gd'],90,r'^FOUNDRY EXPORT BASIS: ([a-f0-9]{64})$')
        spec=importlib.util.spec_from_file_location('w9_comparison',BASE/'compare.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);result=m.compare(ROOT/'resources/foundry');assert result['status']=='passed','Original frame/semantic comparison failed'
        assert result['after_basis']==stamp['completion_markers'][0]
        after=inventory();write('source_after.json',after)
        assert {p:h for p,h in before.items() if not p.startswith('resources/foundry/')}=={p:h for p,h in after.items() if not p.startswith('resources/foundry/')},'Source changed beyond expected Foundry outputs'
        expected_paths={x['path'] for x in old['files']};actual=set(git('diff','--name-only','HEAD','--','resources/foundry').splitlines());assert actual==expected_paths,'Unexpected Foundry output set'
        resources=[{'path':p,'sha256':hashlib.sha256((ROOT/p).read_bytes()).hexdigest()} for p in sorted(actual)];write('generated_resource_manifest.json',resources)
        shutil.copytree(ROOT/'build/foundry',BASE/'validated_build_foundry_cache')
        write('handoff-summary.json',{'status':'passed','source_commit':expected,'commands':[build,stamp],'comparison':'build/foundry_final_W9/comparison.json','baseline':'build/foundry_final_W9/baseline_inventory.json','native_counts':{'phrases':36,'itineraries':18,'replays':54,'frames':56113},'source_stable_except_expected56_Foundry_outputs':True,'resource_manifest':'build/foundry_final_W9/generated_resource_manifest.json','before_basis':result['before_basis'],'after_basis':result['after_basis'],'scope':'Original native validation and exact c77f actions/axis/position/shots/repair/routeIDs; only explicit source basis and direct derived hashes differ. No globalCI, browser, device or aesthetic admission.'})
        print('W9 FOUNDRY: original36/18; exact54/56113; source-stable; expected56 outputs; passed',flush=True)
    except Exception as exc:
        write('failed_attempt.json',{'status':'REWORK','source_commit':expected,'error':repr(exc),'raw_logs_preserved':True});raise
if __name__=='__main__':main()
