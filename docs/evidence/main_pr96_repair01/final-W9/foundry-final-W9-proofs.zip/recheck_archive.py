"""Read-only offline replay comparison; restores original c77f bytes from Git, never starts Godot."""
from pathlib import Path
import argparse,hashlib,importlib.util,json,subprocess,tempfile,zipfile
parser=argparse.ArgumentParser();parser.add_argument('--repo',type=Path,required=True);parser.add_argument('--archive',type=Path,required=True);args=parser.parse_args()
with tempfile.TemporaryDirectory(prefix='foundry-w9-recheck-') as folder:
    root=Path(folder)
    with zipfile.ZipFile(args.archive) as z:
        for info in z.infolist():
            p=Path(info.filename);assert not p.is_absolute() and '..' not in p.parts and not info.is_dir()
            target=root/p;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(z.read(info))
    inv=json.loads((root/'baseline_inventory.json').read_text())
    for row in inv['files']:
        rel=Path(row['path']).relative_to('resources/foundry');assert '..' not in rel.parts
        data=subprocess.check_output(['git','show',inv['baseline_commit']+':'+row['path']],cwd=args.repo)
        assert hashlib.sha256(data).hexdigest()==row['sha256']
        p=root/'baseline_c77f'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
    spec=importlib.util.spec_from_file_location('archived_w9_comparison',root/'compare.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    result=m.compare(root/'after_foundry');assert result['status']=='passed'
    print(json.dumps({'status':'passed','scope':'archived actual new54 replay bytes vs original56 Git blobs at c77f; no Godot','phrases':36,'itineraries':18,'replays':54,'frames':56113,'baseline_commit':inv['baseline_commit'],'after_basis':result['after_basis'],'differences':result['differences']},indent=2))
