H2 push Web 实际终态 cancelled；没有完整 harness report.json。下表时间来自原控制台 Running→passed 墙钟区间，包含进程外守门/收集开销，不能称原 subprocess duration_seconds。

Job 07:30:19→07:50:37，总1218秒；checkout241秒(07:30:21→07:34:22)；harness前总289秒；原harness step 07:35:08→07:50:34为926秒。40项完成跨度合876.116秒；最后 forest-fruit-contract 于07:50:08.229启动、未完成即取消。原20分钟cap未改。

web-build完整边界99.733秒；原child log包括Godot import/421资产reimport及export，但没有各子阶段墙钟时间戳，因此不能再拆出精确import/export秒数。

PR Web完整report对照：总697.402秒；已实际执行35检查进程时长合219.221秒，控制台跨度合664.976秒，相差445.755秒。例world进程0.092秒/跨度12.584秒；web-build进程90.345秒/跨度104.898秒。不能拿PR实测进程时长替填push缺失report。harness.py在每check前后执行完整source guard(336/342附近)，尚无函数级计时证明全部差额归其一。

| 集合 | 数量 | ID/状态 |
|---|---:|---|
| Web | 41 | 40 passed，1 started/incomplete |
| core gameplay+art并集 | 120 | 计划范围，非完成声明 |
| 两者交集 | 38 | Web已完成37；包含26非serial+12原native串行(其中fruit未完成) |
| Web独有 | 3 | web-cache, web-build, web-bundle |
| core独有 | 82 | 完整ID差集见web-vs-core-check-coverage.json |

12个共同native原ID/argv均属于core serial lane、同Linux/Godot4.7.2/原--release计划：underworld-raw-export, underworld-player-animation, underworld-mechanisms, underworld-home, underworld-ui, underworld-damage-feedback, underworld-projectile-vfx, underworld-world-objects, underworld-continuous-bosses, forest-camera-stability, forest-hazard-records, forest-fruit-contract。当前core日志下载仍404 BlobNotFound，不能证明其中任一已经在core执行/通过；待真实终态原日志再补。

push已完成：共同core检查墙钟跨度746.562秒(其中11个native268.648秒、26个非serial477.914秒)；Web独有3检查129.554秒。这里只列现行manifest/真实耗时，不提出扩大cap或删check。

| check | push observed wall seconds | status |
|---|---:|---|
| docs | 14.635 | passed |
| world | 14.225 | passed |
| world-design-tests | 14.320 | passed |
| structure | 14.279 | passed |
| harness-tests | 21.148 | passed |
| quality-drills | 14.281 | passed |
| quality-tests | 14.989 | passed |
| quality | 15.825 | passed |
| web-cache | 14.386 | passed |
| production-loop-tests | 61.000 | passed |
| terrain-tile-tests | 14.222 | passed |
| consumer-coverage-tests | 14.286 | passed |
| capture-tests | 14.252 | passed |
| level-design-contracts | 31.248 | passed |
| mechanism-comparisons | 14.224 | passed |
| level-design-analysis | 14.682 | passed |
| level-design-routing | 16.506 | passed |
| level-design-golden-tests | 15.002 | passed |
| level-region-context | 14.623 | passed |
| level-experience | 19.685 | passed |
| level-formal-receipts | 17.559 | passed |
| visual-director-tests | 34.289 | passed |
| web-resource-contract-tests | 14.667 | passed |
| runtime-raw-export-tests | 14.221 | passed |
| creative-direction | 14.159 | passed |
| creative-direction-tests | 15.326 | passed |
| underworld-home-guard-tests | 14.261 | passed |
| web-build | 99.733 | passed |
| web-bundle | 15.435 | passed |
| underworld-raw-export | 14.398 | passed |
| underworld-player-animation | 15.284 | passed |
| underworld-mechanisms | 29.048 | passed |
| underworld-home | 20.836 | passed |
| underworld-ui | 27.569 | passed |
| underworld-damage-feedback | 18.909 | passed |
| underworld-projectile-vfx | 19.082 | passed |
| underworld-world-objects | 28.341 | passed |
| underworld-continuous-bosses | 56.850 | passed |
| forest-camera-stability | 21.153 | passed |
| forest-hazard-records | 17.178 | passed |
| forest-fruit-contract | incomplete | started, no completion |
