extends SceneTree
## Fresh decoder must still accept actual pre-retirement current snapshots.
func _initialize() -> void:
	var source:Dictionary=JSON.parse_string(FileAccess.get_file_as_string("res://build/legacy_eight_retirement/before_apps.json"))
	var failures:Array[String]=[]
	var checks:=0
	for row:Dictionary in source.apps:
		if not row.has("manifest"):continue
		checks+=1
		var accepted:=RunManifest.from_snapshot(row.manifest)!=null
		if accepted!=row.compatible:failures.append(row.id)
	FileAccess.open("res://build/legacy_eight_retirement/prior_decoder.json",FileAccess.WRITE).store_string(JSON.stringify({"checks":checks,"failures":failures},"\t")+"\n")
	print("LEGACY RETIRE PRIOR DECODER: %d cases / %d failures"%[checks,failures.size()])
	quit(1 if not failures.is_empty() else 0)
