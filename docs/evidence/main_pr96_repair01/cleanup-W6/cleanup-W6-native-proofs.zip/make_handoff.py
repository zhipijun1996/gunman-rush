from pathlib import Path
import ast,hashlib,json,re,subprocess,sys
ROOT=Path.cwd();BASE=ROOT/'build/legacy_eight_retirement'
sys.path.insert(0,'tools');from level_formal import source_files
current=source_files();start=json.loads((BASE/'r2_final_source_inventory.json').read_text());assert current==start,'R2 sources changed during final native group'
(BASE/'r2_final_source_after.json').write_text(json.dumps(current,indent=2)+'\n')
r1=json.loads((BASE/'r1_source_inventory.json').read_text());prefixes=('scripts/','scenes/','resources/','config/','shaders/','assets/')
assert {p:h for p,h in r1.items() if p.startswith(prefixes)}=={p:h for p,h in current.items() if p.startswith(prefixes)}
retirement=json.loads((BASE/'applied_manifest.json').read_text());assert len(retirement)==55
for row in retirement:
    p=ROOT/row['path'];assert (hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None)==row['after_sha256']
resources=[]
for old in sorted((BASE/'before_foundry').rglob('*')):
    if old.is_file():
        p=ROOT/'resources/foundry'/old.relative_to(BASE/'before_foundry')
        resources.append({'path':p.relative_to(ROOT).as_posix(),'before_sha256':hashlib.sha256(old.read_bytes()).hexdigest(),'after_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'before_bytes':old.stat().st_size,'after_bytes':p.stat().st_size})
assert len(resources)==56
(BASE/'foundry_resource_manifest.json').write_text(json.dumps(resources,indent=2)+'\n')
initial=json.loads((BASE/'validation_initial_with_rework.json').read_text());final=json.loads((BASE/'validation_final.json').read_text());assert all(row['exit_code']==0 for row in final)
foundry=[r for r in initial if r['name'] in ['foundry36_18','foundry_stamp']];assert all(r['exit_code']==0 for r in foundry)
log=(BASE/'generated26_final.log').read_text();module=ast.parse((ROOT/'tools/run_generated_consumer_tests.py').read_text());suites=ast.literal_eval(next(n.value for n in module.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='SUITES' for t in n.targets)))
markers=[]
for script,pattern,timeout in suites:
    match=re.search('^'+pattern+'$',log,re.M);assert match,script
    markers.append({'suite':script,'completion':match.group(0),'original_timeout_seconds':timeout})
assert len(markers)==26 and 'GENERATED CONSUMER SUITES: 26 suites passed' in log
logs=[BASE/'after_import.log',BASE/'after_worlds.log',BASE/'after_apps.log',BASE/'prior_decoder.log',BASE/'foundry36_18.log',BASE/'foundry_stamp.log']+[BASE/(r['name']+'.log') for r in final]
logs+=list((BASE/'styles').glob('*.log'))+list((BASE/'world0').glob('*.log'))+list((BASE/'world1').glob('*.log'))
bad=[]
for p in logs:
    if re.search(r'^\s*(?:ERROR:|SCRIPT ERROR:|Parse Error:|SHADER ERROR:)|ObjectDB.*leaked|resources? still in use at exit',p.read_text(),re.M):bad.append(str(p.relative_to(ROOT)))
assert not bad,bad
comparisons={name:json.loads((BASE/(name+'_comparison.json')).read_text()) for name in ['worlds','apps','foundry']};assert all(v['passed'] and not v['differences'] for v in comparisons.values())
summary={
 'task':'MAIN-PR96-REPAIR-01 / explicitly authorized old-eight retirement',
 'base_commit':'54eacfd811fe538d79d374393f10754f1efdc94b',
 'phase':'Final R2 source frozen; no source commit made by this agent',
 'source_stability':{'r2_start_inventory':'build/legacy_eight_retirement/r2_final_source_inventory.json','r2_after_inventory':'build/legacy_eight_retirement/r2_final_source_after.json','exact_equal':True,'runtime_prefixes_unchanged_between_R1_data_proofs_and_R2':True,'strict_logs_scanned':len(logs),'strict_unexpected_errors_or_leaks':bad},
 'retirement':{'paths':55,'deleted_files':30,'net_bytes_removed':sum(r['before_bytes']-r['after_bytes'] for r in retirement),'exact_paths':[r['path'] for r in retirement],'manifest':'build/legacy_eight_retirement/applied_manifest.json','diff':'build/legacy_eight_retirement/applied_retirement.diff','producer_scripts_deleted':4,'exclusive_configs_deleted':2,'pure_feature_suites_deleted':7,'auxiliary_feature_test_scripts_deleted':2,'old_browser_CLIs_deleted':2,'old_generated_wrapper_suites':33,'retirement_wrapper_suites':26,'count_scope':'33 historical suites remain historical; 7 feature-exclusive suites retired by user request; final26 is a fresh complete run of retained scope'},
 'foundry':{'files':56,'net_bytes_delta':sum(r['after_bytes']-r['before_bytes'] for r in resources),'manifest':'build/legacy_eight_retirement/foundry_resource_manifest.json','commands':foundry,'original_counts':[36,18],'comparison':'build/legacy_eight_retirement/foundry_comparison.json','replays':54,'original_frames_compared':56113,'result':'all original frame actions/axis/positions/shots and all non-whitelist Manifest/proof fields exactly equal; only enumerated provenance basis/derived hashes differ'},
 'native_final_commands':final,
 'native_completions':{'core':'ALL TESTS: 5681 assertions, 0 failures','generated':'GENERATED CONSUMER SUITES: 26 suites passed','underworld_ui':'UNDERWORLD UI: 243 checks, 0 failures','styles':[line for p in sorted((BASE/'styles').glob('*.log')) for line in p.read_text().splitlines() if re.match(r'^STYLE_(EXPLORATION|BIOMES|BIOME_CLI)',line)],'worlds':[line for d in ['world0','world1'] for line in (BASE/d/'native.log').read_text().splitlines() if line.startswith('PLAINS WORLD REBUILD:')]},
 'retained_suite_results':markers,
 'before_after':{'baseline_phase':'W5 + one typed-empty-array repair, before retirement','phase_manifest':'build/legacy_eight_retirement/baseline_phase.json','data':{'before':'build/legacy_eight_retirement/before_worlds.json','after':'build/legacy_eight_retirement/after_worlds.json','comparison':'build/legacy_eight_retirement/worlds_comparison.json','maps':60,'independent_streams':10,'foundry_manifests':54,'schema1_and_schema2_version_construction':12},'apps':{'before':'build/legacy_eight_retirement/before_apps.json','after':'build/legacy_eight_retirement/after_apps.json','comparison':'build/legacy_eight_retirement/apps_comparison.json','cases':46,'matrix':{'plains_schema1_three_pins_two_seeds':6,'forest_schema2_all_recorded_pins_two_maps_two_seeds':36,'world_candidates':2,'quick3':1,'style_menu':1},'old_manifest_decoder':'build/legacy_eight_retirement/prior_decoder.json','old_decoder_cases':45,'restorable_current_preserved':43,'development_world_refusals_preserved':2,'exceptions':'44 generated-App config_hashes.branch_profile dead stamps; world0/1 versions.generated_layout/run_policy/pickups/encounters only, actual fixture version now accurate. Exact indexed paths in apps_comparison.json; no other field removed.'},'foundry_exceptions':'Only each Foundry manifest basis/hash, itinerary phrases[i].basis/hash, replay basis/manifest_hash and batch basis; exact indexed paths in comparison reports. No recursive hash/ID erasure. All semantic fields and56113 original input/position/resource frames compared.'},
 'original_failures_and_rework':[{'name':'original W5 world candidate typed[] crash','log':'build/legacy_eight_retirement/world_before_failure.log','data':'build/legacy_eight_retirement/world_before_failure.json','exit_code':1,'reason':'DemoApp:546 conditional generic empty Array assigned to Array[Dictionary], both world variants could not complete setup','repair':'Initialize typed empty Array, assign actual records only when connected. Actual original44 current snapshots identical after repair; repaired fullworld0/1 baseline completes but restore remains unsupported as before.'},{'name':'additional diagnostic12 whole Motor routes timed out','log':'build/legacy_eight_retirement/generated26_added_motor_timeout.log','record':'build/legacy_eight_retirement/validation_initial_with_rework.json','exit_code':1,'timeout_seconds':90,'disposition':'REWORK preserved. Retracted only newly added12 whole-map diagnostic route loops. All original12 ground-support shape/plan/PhysicsPoint/tamper assertions remain, generic samples now produce43 real solid columns/188 assertions. Original90s budget and FIXED_STEP set unchanged. Current real Motor coverage remains core/spatial/shared routes.'}],
 'runner_negatives':{'actual_nonzero':'build/legacy_eight_retirement/camera_failure_probe.json','actual_timeout_rejected':'build/legacy_eight_retirement/generated26_added_motor_timeout.log','missing_marker_mock':'build/legacy_eight_retirement/missing_marker_negative.log','scope':'camera intentional failure exit1; real timeout wrapper exit1; separate mocked exit0 missing marker rejected. These are guard negatives, not gameplay acceptance.'},
 'browser_helpers':{'actual_import_smoke':'build/legacy_eight_retirement/browser_import_smoke.json','storage_key_envelope_equal':True,'original_rendered_art_palette_functions_equal':True,'real_browser_runtime':'not run by this agent; Python import smoke is not GUI/browser/device evidence'},
 'preserved':{'frozen_audit_sha256':hashlib.sha256((ROOT/'docs/quality/level_design_v2_audit.md').read_bytes()).hexdigest(),'audit_unchanged':True,'historical_raw_evidence':'preserved','user_save_files':'not touched','forest_original80':'not modified or removed; root runs new freeze','camera_comfort':'831 original assertions retained/passed','world_and_five_style_candidates':'preserved and actual app starts/native suites passed'},
 'remaining':['Root commits55 retirement paths +56 Foundry files; root-owned docs/evidence kept separate as planned.','Independent review final source binding and root exact-source policy600/forest80/integration CI still pending.','Public Web browser/package/real-device/user aesthetic and jump-camera feel acceptance are outside this child’s evidence.']}
(BASE/'handoff-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'summary':'build/legacy_eight_retirement/handoff-summary.json','bytes':(BASE/'handoff-summary.json').stat().st_size,'source_inventory_exact_equal':True,'strict_logs':len(logs),'retirement_paths':55,'foundry_files':56,'suites':26,'net_bytes_removed':summary['retirement']['net_bytes_removed']},indent=2))
