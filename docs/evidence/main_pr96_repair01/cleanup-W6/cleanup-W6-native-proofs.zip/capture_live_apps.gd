extends SceneTree
## Actual app starts, snapshots, and compatibility; no user save writes.
var failures: Array[String] = []
var apps: Array = []
var output := ""
var app: DemoApp
var skip_world:=false
func _initialize() -> void:
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--output="):output=arg.trim_prefix("--output=")
		if arg=="--skip-world":skip_world=true
	if output.is_empty():quit(2);return
	run.call_deferred()
func frames(n:int) -> void:
	for i:int in n:await physics_frame
func close_app() -> void:
	paused=false
	if not is_instance_valid(app):return
	if not await load("res://tests/audio_teardown.gd").drain_world(app):
		failures.append("actual audio did not drain")
	app.free()
	await process_frame
func new_app() -> void:
	await close_app()
	app=DemoApp.new()
	app.meta_persistence_enabled=false
	root.add_child(app)
func settle(id:String) -> bool:
	for i:int in 180:
		await physics_frame
		if not app._stage_pending and is_instance_valid(app.stage):return true
	failures.append(id+": app start/assembly failed")
	return false
func capture(id:String,expected_compatible:bool) -> void:
	var snapshot:=app.director.manifest.snapshot()
	var compatible:=RunManifest.compatible(JSON.parse_string(JSON.stringify(snapshot)))
	if compatible!=expected_compatible:failures.append(id+": unexpected actual compatibility "+str(compatible))
	apps.append({"id":id,"compatible":compatible,"manifest":snapshot,"geometry":(app.stage as GeneratedDemoStage).generated.manifest if app.generated_plains else {}})
func run() -> void:
	for seed_value:String in ["legacy-retire-00","legacy-retire-01"]:
		for mode:String in ["legacy_v10","v2","v3"]:
			await new_app()
			if not app.start_plains(seed_value):failures.append("plains start refused");continue
			# Explicitly pin the existing internal run version before deferred load.
			app._root_bell_run_mode=mode
			var id:="plains/"+seed_value+"/"+mode
			if await settle(id):capture(id,true)
		for map_index:int in [1,2]:
			for variant:Dictionary in ThornForestRegionGenerator.recorded_variants():
				await new_app()
				if not app.start_debug_region(&"thorn_forest",map_index,seed_value,variant.version,variant.layout):failures.append("forest start refused");continue
				if variant.has("north_return"):app._forest_v9_north_return=variant.north_return
				var id:="forest/"+seed_value+"/"+str(map_index)+"/"+str(variant)
				if await settle(id):capture(id,true)
	for variant:int in [0,1]:
		if skip_world:break
		await new_app()
		app.set_meta("plains_world_rebuild_candidate",true)
		app.set_meta("plains_world_rebuild_variant",variant)
		if not app.start_plains("world-rebuild-01"):failures.append("world start refused");continue
		var id:="world/"+str(variant)
		if await settle(id):capture(id,false)
	await new_app()
	if not app.start_demo("legacy-retire-00",false):failures.append("quick start refused")
	if await settle("quick3"):capture("quick3",true)
	await new_app()
	app.menu.requested_style_lab.emit()
	await frames(4)
	var style_ready:=is_instance_valid(app._style_lab)
	if not style_ready:failures.append("actual menu style start refused")
	apps.append({"id":"style-menu","ready":style_ready})
	await close_app()
	var file:=FileAccess.open(output,FileAccess.WRITE)
	if file==null:quit(2);return
	file.store_string(JSON.stringify({"scope":"actual app start, schema compatibility, full initial snapshot and world/style menu availability only; no traversal/user approval","apps":apps,"failures":failures},"\t",true)+"\n")
	file.close()
	print("LEGACY RETIRE LIVE APPS: %d cases / %d failures"%[apps.size(),failures.size()])
	quit(1 if not failures.is_empty() else 0)
