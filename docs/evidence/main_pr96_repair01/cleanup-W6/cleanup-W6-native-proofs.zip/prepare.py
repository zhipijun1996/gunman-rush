from pathlib import Path
import difflib, hashlib, json
ROOT=Path.cwd(); OUT=ROOT/'build/legacy_eight_retirement'
changes={}
def edit(path,transform):
    original=(ROOT/path).read_text(); revised=transform(original)
    assert revised!=original,path
    changes[path]=(original,revised)
def replace(path,a,b):
    def f(s):
        assert s.count(a)==1,(path,a,s.count(a))
        return s.replace(a,b)
    edit(path,f)
def cut(s,a,b):
    assert s.count(a)==1,(a,s.count(a)); assert s.count(b)==1,(b,s.count(b))
    i=s.index(a); return s[:i]+s[s.index(b,i):]
producers=['plains_stage_generator','plains_branch_layout','plains_room_grammar','plains_blueprint_schedule']
pure=['plains_room_grammar_runner','plains_blueprint_runner','plains_blueprint_schedule_runner','plains_weak_capabilities_runner','plains_branch_runner','plains_polish_routes_runner','plains_ten_generation_runner']
removed=['scripts/generation/'+n+'.gd' for n in producers]+['tests/'+n+'.gd' for n in pure+['plains_polish_density_report','plains_camera_trace_driver']]
removed += [p+'.uid' for p in removed if (ROOT/(p+'.uid')).exists()]
removed += ['config/plains_branch_profile.json','config/plains_room_templates.json','tools/verify_plains_browser.py']
for path in removed: changes[path]=((ROOT/path).read_text(),None)
def manifest(s):
    s=cut(s,'func enable_plains_generation() -> void:\n','func enable_plains_region(')
    marker='func enable_plains_region('
    development='''func enable_development_generation(content_version: String) -> void:
	# Independent world candidates are live development fixtures, never old rooms.
	# Preserve their actual content identity without claiming restorable run data.
	_data.versions.erase("fixed_layout")
	_data.versions.generated_layout = content_version
	_data.versions.run_policy = "DEVELOPMENT_GENERATED_FIXTURE_v1"

'''
    s=s.replace(marker,development+marker,1)
    s=cut(s,'\tvar generated_versions := fixed_versions.duplicate(true)\n','\tvar declared_versions: Variant')
    s=s.replace('\tvar declared_versions: Variant','\tvar region_versions := fixed_versions.duplicate(true)\n\tregion_versions.erase("fixed_layout")\n\tvar declared_versions: Variant',1)
    s=cut(s,'\tvar versions_supported: bool =','\treturn versions_supported and')
    return s.replace('return versions_supported and','return _versions_equal(data.get("versions", {}), fixed_versions) and',1)
edit('scripts/run/run_manifest.gd',manifest)
def app(s):
    s=s.replace('director.manifest.enable_plains_generation()','director.manifest.enable_development_generation((stage as GeneratedDemoStage).generated.stage_generator_version)')
    s=s.replace('\t\t\tconfig_hashes.branch_profile = FileAccess.get_sha256(PlainsBranchLayout.PROFILE_PATH)\n','')
    s=s.replace('var static_records: Array[Dictionary] = random_stage.assembler.world_static_hazard_records() if connected_region else []','var static_records: Array[Dictionary] = []\n\t\tif connected_region: static_records.assign(random_stage.assembler.world_static_hazard_records())')
    return s.replace('menu.requested_start.connect(start_demo)','menu.requested_start.connect(func(seed: String) -> void: start_demo(seed, false))')
edit('scripts/demo/demo_app.gd',app)
def generic(s):
    s=s.replace(' or manifest.has("stage_type")','') if False else s
    s=s.replace('if manifest.has("stage_type") or manifest.has("ground_support_version")','if manifest.has("ground_support_version")')
    s=s.replace('manifest.get("layout_id") not in ["seamless_port_chain", "branched_terminal_paths"]','manifest.get("layout_id") != "seamless_port_chain"')
    s=cut(s,'\tif manifest.has("stage_type"):\n','\tvar attempt: Variant')
    s=s.replace('\tvar attempt: Variant','\tif manifest.has("stage_type"):\n\t\treturn _failure("Retired eight-room manifest format")\n\tvar attempt: Variant',1)
    return s.replace('\tif manifest.layout_id == "branched_terminal_paths":\n\t\treturn PlainsBranchLayout.new().validate(manifest, tuning, self)\n','')
edit('scripts/generation/random_stage_generator.gd',generic)
edit('scripts/generation/random_stage_assembler.gd',lambda s:cut(s,'\tif manifest.layout_id == "branched_terminal_paths":\n','\tvar last: PlatformingModule'))
edit('scripts/generation/plains_region_assembler.gd',lambda s:s.replace('## Explicit region assembler, leaves the eight-room regression assembler intact.','## Explicit current-region assembler using the shared module consumer.'))
def menu(s):
    s=s.replace('signal requested_start(seed: String, formal_ten: bool)','signal requested_start(seed: String)')
    s=s.replace('_button(body, "3 rooms   /   A quick taste", func() -> void: _start(false))','_button(body, "3 rooms   /   A quick taste", _start_quick_demo)')
    s=s.replace('\t_label(body, "DEVELOPMENT / OLD EIGHT-ROOM TRIAL", 12, GOLD)\n\t_button(body, "8 rooms   /   Regression fixture", func() -> void: _start(true))\n','')
    s=s.replace('func _start(formal_ten: bool) -> void:','func _start_quick_demo() -> void:')
    return s.replace('requested_start.emit(seed, formal_ten)','requested_start.emit(seed)')
edit('scripts/ui/demo_menu.gd',menu)
def menutest(s):
    s=s.replace('var starts: Array[Dictionary] = []','var starts: Array[String] = []\n\tvar plains: Array[String] = []')
    s=s.replace('menu.requested_start.connect(func(seed: String, formal_ten: bool) -> void: starts.append({"seed": seed, "formal": formal_ten}))','menu.requested_start.connect(func(seed: String) -> void: starts.append(seed))\n\tmenu.requested_plains.connect(func(seed: String) -> void: plains.append(seed))')
    a=s.index('\tvar formal_button :=');b=s.index('\tmenu.show_home()\n\tmenu._seed = " "',a)
    s=s[:a]+'''	check.call(button(menu, "8 rooms   /   Regression fixture") == null, "retired eight-room option is absent")
	var explore_button := button(menu, "Explore   /   Windchime Plains")
	check.call(explore_button != null, "current two-map Explore option remains available")
	if explore_button == null:
		menu.queue_free()
		await tree.process_frame
		return
	explore_button.pressed.emit()
	check.call(plains == ["seeded trial"] and starts.is_empty() and menu.visible_panel == &"", "Explore sends trimmed seed to current region flow then hides")
'''+s[b:]
    return s.replace('starts[1] == {"seed": "rush-demo", "formal": false}','starts == ["rush-demo"]')
edit('tests/menu_tests.gd',menutest)
for path in ['tests/home_ui_tests.gd','tests/underworld_plains/test_underworld_ui.gd']:
    edit(path,lambda s:s.replace('and text.contains("8 rooms")','and not text.contains("8 rooms")').replace('all original development routes preserved','current development routes preserved; retired eight-room option absent').replace('Development routes preserved','Current development routes preserved; retired eight-room option absent'))
edit('tests/plains_feedback_runner.gd',lambda s:cut(s,'\tvar occurrences :=','\tvar ui_font :='))
edit('tests/plains_spatial_runner.gd',lambda s:cut(s,'\tvar families: Dictionary = {}','\t# Recalibrated authored spatial fixtures').split('\nfunc _reject_signed(')[0]+'\n')
edit('tests/windkeeper_runner.gd',lambda s:cut(s,'\t# Formal generator binds the sheep contract','\tworld.free()\n\tawait process_frame\n\tif "--failure-probe"'))
edit('tests/plains_camera_trace_runner.gd',lambda s:cut(s,'\tDirAccess.make_dir_recursive_absolute','\tvar boss_camera :='))
def ground(s):
    s=s.replace('var data := PlainsStageGenerator.new().generate("ground-support-%d" % index, 1 + index % 7, &"combat", tuning)','var data := generator.generate(("ground-support-%d" % index).hash(), tuning, 14, "plains_standard")')
    marker='\t\tvar recorded: Dictionary = JSON.parse_string(JSON.stringify(data.manifest))\n'
    s=s.replace(marker,marker+'''		recorded.ground_support_version = PlainsGroundSupports.VERSION
		recorded.ground_supports = PlainsGroundSupports.recorded_plan(recorded, generator)
		recorded.manifest_hash = generator._manifest_hash(recorded)
''')
    s=s.replace('\tvar total := 0\n','\tvar total := 0\n\tvar driver = load("res://tests/plains_run_trace.gd").new()\n\tdriver.tree = self\n\tdriver.check = check\n',1)
    s=s.replace('\t\tassembler.free()\n','\t\tassembler.free()\n\t\tawait driver.route(recorded, tuning, "ground supports generic %d" % index)\n',1)
    s=s.replace('\tcheck(total >= 12,','\tif is_instance_valid(driver.world):\n\t\tif not await load("res://tests/audio_teardown.gd").drain_world(driver.world):\n\t\t\tcheck(false, "actual route audio releases within budget")\n\t\tdriver.world.free()\n\tcheck(total >= 12,',1)
    return s.replace('formal generated map succeeds','shared generic generated map succeeds').replace('formal sample receives actual grounded earth','generic sample receives actual grounded earth').replace('12 formal rooms','12 shared generic samples')
edit('tests/plains_ground_support_runner.gd',ground)
edit('tests/plains_run_trace.gd',lambda s:cut(s,'func route(manifest: Dictionary, tuning: PlayerTuning, label: String) -> void:\n','func traverse(module: PlatformingModule) -> void:'))
def wrapper(s):
    return '\n'.join(line for line in s.split('\n') if not any('("tests/'+n+'.gd"' in line for n in pure)).replace('"tests/plains_room_grammar_runner.gd",','').replace('"tests/plains_polish_routes_runner.gd", ','').replace('"tests/plains_blueprint_runner.gd", ','').replace('"tests/plains_branch_runner.gd", ','').replace(', "tests/plains_ten_generation_runner.gd"','')
edit('tools/run_generated_consumer_tests.py',wrapper)
old=(ROOT/'tools/verify_plains_browser.py').read_text()
shared=old[old.index('PALETTES = {'):old.index('\ndef palette_mask(')]
def browser(s):
    s=s.replace('import verify_plains_browser as art\n','').replace('art.FOLDER = FOLDER\n','')
    s=s.replace('\n\ndef map_hash(', '\n\n'+shared+'\ndef map_hash(',1)
    return s.replace('art.rendered_art(', 'rendered_art(')
edit('tools/verify_plains_capability_browser.py',browser)
replace('tools/verify_random_stage_browser.py','verify_plains_browser.py','verify_plains_capability_browser.py')
# Active entry points state the retirement; historical raw evidence stays untouched.
def module_docs(s):
    s=s.replace('本轮新增PlainsStageGenerator（类型与关数生成配方）、GeneratedDemoStage（共享Assembler/内容布置消费者）','历史八房曾使用的 PlainsStageGenerator 已按用户授权退休；当前保留 GeneratedDemoStage（共享Assembler/内容布置消费者）')
    s=s.replace('## D074 房间连接模板','## D074 房间连接模板（历史退休）')
    start=s.index('`PlainsStageGenerator → PlainsRoomGrammar.plan')
    end=s.index('\n', start)
    return s[:start]+'旧八房生成链、专有配置和测试已退休；历史设计与当时技术结果见[十轮记录](plains_room_grammar.md)。当前正式入口为 DemoApp → PlainsRegionGenerator / ThornForestRegionGenerator → 对应 RegionStage / Assembler。RandomStageGenerator、模块库、Foundry 与三房快速演示继续保留。'+s[end:]
edit('docs/module_map.md',module_docs)
edit('docs/procedural_generation.md',lambda s:s.replace('## D074 平原房间内生成消费者','## D074 平原房间内生成消费者（历史退休）\n\n以下记录旧八房功能；本轮按用户授权删除其 producer、专有配置和测试，不是当前两张大地图的生成规则。当前消费者见[generation_current](generation_current.md)。'))
for path in ['docs/plains_room_grammar.md','docs/plains_hazard_density.md']:
    def banner(s):
        i=s.index('\n')
        return s[:i]+'\n\n> 历史记录：旧八房功能已按用户授权退休，文中旧生成器和专有测试已删除。以下参数、命令和数字仅解释当时版本，不作为当前执行入口；现行验证使用 `python3 tools/run_generated_consumer_tests.py`，当前两图见[generation_current](generation_current.md)。'+s[i:]
    edit(path,banner)

# Source candidates and full exact-byte patch, never apply to guarded source here.
patch=[]; manifest=[]
for path,(old,new) in changes.items():
    if new is not None:
        candidate=OUT/'candidates'/path;candidate.parent.mkdir(parents=True,exist_ok=True);candidate.write_text(new)
    patch.extend(difflib.unified_diff(old.splitlines(True),([] if new is None else new.splitlines(True)),fromfile='a/'+path,tofile=('/dev/null' if new is None else 'b/'+path)))
    manifest.append({'path':path,'operation':'delete' if new is None else 'modify','before_sha256':hashlib.sha256(old.encode()).hexdigest(),'before_bytes':len(old.encode()),'after_bytes':0 if new is None else len(new.encode())})
(OUT/'retirement.patch').write_text(''.join(patch))
(OUT/'change_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'files':len(changes),'delete':sum(new is None for old,new in changes.values()),'net_bytes_removed':sum(len(old.encode())-len((new or '').encode()) for old,new in changes.values()),'paths':list(changes)},indent=2))
