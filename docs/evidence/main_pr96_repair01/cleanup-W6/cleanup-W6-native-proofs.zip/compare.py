"""Exact baseline comparison with a narrowly enumerated stamp exception list."""
import argparse, copy, hashlib, json
from pathlib import Path
BASE=Path('build/legacy_eight_retirement')
def read(p):return json.loads(Path(p).read_text())
def differences(a,b,path=''):
    if type(a)!=type(b) and not (isinstance(a,(int,float)) and isinstance(b,(int,float))):return [path+': type']
    if isinstance(a,dict):
        result=[path+'/'+key+': missing' for key in sorted(a.keys()-b.keys())]+[path+'/'+key+': extra' for key in sorted(b.keys()-a.keys())]
        for key in sorted(a.keys()&b.keys()):result+=differences(a[key],b[key],path+'/'+key)
        return result
    if isinstance(a,list):
        if len(a)!=len(b):return [path+': length']
        result=[]
        for i,(x,y) in enumerate(zip(a,b)):result+=differences(x,y,path+'/'+str(i))
        return result
    return [] if a==b else [path+': value']
def manifest(value,exceptions,path):
    result=copy.deepcopy(value)
    for key in ('basis','hash'):
        if key in result:exceptions.append(path+'/'+key);del result[key]
    if result.get('kind')=='itinerary':
        for index,phrase in enumerate(result['phrases']):
            # Each listed phrase is a Foundry phrase, never arbitrary recursion.
            for key in ('basis','hash'):
                if key in phrase:exceptions.append(f'{path}/phrases/{index}/{key}');del phrase[key]
    return result

def worlds():
    a=read(BASE/'before_worlds.json');b=read(BASE/'after_worlds.json');allowed=[]
    assert not a['failures'] and not b['failures']
    for label,data in [('before',a),('after',b)]:
        assert len(data['foundry'])==54
        data['foundry']=[manifest(v,allowed,f'/foundry/{i}') for i,v in enumerate(data['foundry'])]
    diffs=differences(a,b)
    return {'scope':'all current generator geometry/versions/independent RNG exact; Foundry semantic fields exact with explicit provenance paths','allowed_stamp_paths':sorted(set(allowed)),'differences':diffs,'passed':not diffs,'cases':len(a['cases']),'foundry':len(a['foundry']),'streams':len(a['streams'])}
def apps():
    a=read(BASE/'before_apps.json');b=read(BASE/'after_apps.json');allowed=[]
    assert not a['failures'] and not b['failures']
    assert len(a['apps'])==len(b['apps'])
    for i,(x,y) in enumerate(zip(a['apps'],b['apps'])):
        assert x['id']==y['id']
        if 'manifest' not in x:continue
        # One dead stamp on all generated runs; no other configuration ignored.
        hashes=x['manifest']['config_hashes']
        if 'branch_profile' in hashes:
            allowed.append(f'/apps/{i}/manifest/config_hashes/branch_profile')
            assert 'branch_profile' not in y['manifest']['config_hashes']
            del hashes['branch_profile']
        if x['id'].startswith('world/'):
            assert x['compatible'] is False and y['compatible'] is False
            old=x['manifest']['versions'];new=y['manifest']['versions']
            assert old['generated_layout']=='plains-run-v12-room-grammar'
            assert old['run_policy']=='PLAINS_BANK_NOTES_v1'
            assert new['run_policy']=='DEVELOPMENT_GENERATED_FIXTURE_v1'
            assert new['generated_layout']==y['geometry']['world_rebuild_plan']['version']
            for key in ('generated_layout','run_policy','pickups','encounters'):
                if key in old:del old[key]
                if key in new:del new[key]
                allowed.append(f'/apps/{i}/manifest/versions/{key}')
    diffs=differences(a,b)
    return {'scope':'actual full current initial RunManifest/app geometry exact; old world fixtures remain unsupported restores; style/quick starts remain','allowed_stamp_paths':allowed,'differences':diffs,'passed':not diffs,'cases':len(a['apps'])}
def foundry_resources():
    olddir=BASE/'before_foundry';newdir=Path('resources/foundry');a=read(olddir/'batch.json');b=read(newdir/'batch.json');allowed=['/batch/basis']
    assert len(a['accepted'])==len(b['accepted'])==36
    assert len(a['itineraries'])==len(b['itineraries'])==18
    del a['basis'];del b['basis']
    for data in [a,b]:
        for i,v in enumerate(data['accepted']):v['manifest']=manifest(v['manifest'],allowed,f'/batch/accepted/{i}/manifest')
        data['itineraries']=[manifest(v,allowed,f'/batch/itineraries/{i}') for i,v in enumerate(data['itineraries'])]
    diffs=differences(a,b)
    oldfiles={p.name:p for p in (olddir/'replays').glob('*.json')};newfiles={p.name:p for p in (newdir/'replays').glob('*.json')}
    assert oldfiles.keys()==newfiles.keys() and len(oldfiles)==54
    frame_count=0
    for name in sorted(oldfiles):
        old=read(oldfiles[name]);new=read(newfiles[name])
        for key in ['basis','manifest_hash']:
            assert key in old and key in new
            del old[key];del new[key];allowed.append('/replays/'+name+'/'+key)
        frame_count+=len(old['frames']);diffs+=differences(old,new,'/replays/'+name)
    return {'scope':'fresh validated Foundry36 phrases/18 itineraries vs original recorded manifests and all original input/position/resource frames; provenance changes listed explicitly','allowed_stamp_paths':sorted(set(allowed)),'differences':diffs,'passed':not diffs,'replays':len(oldfiles),'frames':frame_count}
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('kind',choices=['worlds','apps','foundry']);args=parser.parse_args()
    report={'worlds':worlds,'apps':apps,'foundry':foundry_resources}[args.kind]()
    (BASE/(args.kind+'_comparison.json')).write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k!='allowed_stamp_paths'},indent=2))
    raise SystemExit(0 if report['passed'] else 1)
