extends SceneTree
var output:=""
var app:DemoApp
var cases:Array=[]
func _initialize()->void:
	for arg:String in OS.get_cmdline_user_args():
		if arg.begins_with("--output="):output=arg.trim_prefix("--output=")
	if output.is_empty():quit(2);return
	run.call_deferred()
func run()->void:
	for variant:int in [0,1]:
		app=DemoApp.new()
		app.meta_persistence_enabled=false
		app.set_meta("plains_world_rebuild_candidate",true)
		app.set_meta("plains_world_rebuild_variant",variant)
		root.add_child(app)
		var accepted:=app.start_plains("world-rebuild-01")
		for i:int in 8:await physics_frame
		var snapshot:=app.director.manifest.snapshot()
		cases.append({"variant":variant,"accepted":accepted,"stage_pending":app._stage_pending,"has_stage":is_instance_valid(app.stage),"compatible":RunManifest.compatible(snapshot),"manifest":snapshot,"geometry":(app.stage as GeneratedDemoStage).generated.manifest if is_instance_valid(app.stage) else {}})
		await load("res://tests/audio_teardown.gd").drain_world(app)
		app.free()
		await process_frame
	FileAccess.open(output,FileAccess.WRITE).store_string(JSON.stringify({"scope":"baseline failure capture; not a successful world start","cases":cases},"\t",true)+"\n")
	print("WORLD BEFORE FAILURE PROBE: captured2; original runtime errors must remain failures")
	quit(1)
