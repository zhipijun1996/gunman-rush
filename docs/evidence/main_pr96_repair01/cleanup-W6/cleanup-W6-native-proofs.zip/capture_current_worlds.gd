extends SceneTree
## Data-only actual generator capture. No fixtures are installed in a live run.
var failures: Array[String] = []

func _initialize() -> void:
	run.call_deferred()

func add_case(cases: Array, id: String, result: Dictionary) -> void:
	if not result.get("ok", false):
		failures.append(id + ": " + str(result.get("error", "generation failed")))
		return
	cases.append({"id":id,"manifest":result.manifest.duplicate(true)})

func run() -> void:
	var output := ""
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--output="):output=arg.trim_prefix("--output=")
	if output.is_empty():
		printerr("Fresh explicit --output is required")
		quit(1)
		return
	var tuning := PlayerTuning.load_default()
	var cases: Array = []
	var streams: Array = []
	var run_versions: Array = []
	for seed_value: String in ["legacy-retire-00", "legacy-retire-01"]:
		for map_index: int in [1,2]:
			var difficulty := "intro" if map_index==1 else "advanced"
			for mode: String in ["legacy_v10","v2","v3"]:
				var plains := PlainsRegionGenerator.new()
				plains.root_bell_mode = mode
				add_case(cases,"plains-"+mode+"/"+seed_value+"/"+str(map_index),plains.generate(PlainsRegionCampaign.seed_for(seed_value,map_index),tuning,false,"",difficulty))
			var forest_seed := seed_value+"/thorn_forest/map_"+str(map_index)
			var capability := {"grapple":true,"weapon_id":"pulse_gun","abilities":["grapple"],"items":[]}
			for variant: Dictionary in ThornForestRegionGenerator.recorded_variants():
				var pinned := capability.duplicate(true)
				pinned.forest_layout_version = variant.layout
				if variant.has("north_return"):pinned.forest_v9_north_return=variant.north_return
				add_case(cases,"forest/"+seed_value+"/"+str(map_index)+"/"+str(variant),ThornForestRegionGenerator.new().generate_version(variant.version,forest_seed,tuning,map_index,pinned))
		for domain: String in ["map","route","reward","shop","boss_pattern"]:
			var stream := RunRandomStream.new(seed_value,domain,"stage_1","demo_v1")
			var values: Array[int] = []
			for index: int in 16:values.append(stream.next_int(2147483647))
			streams.append({"seed":seed_value,"domain":domain,"values":values,"position":stream.position()})
		for content_version: String in [PlainsRegionGenerator.VERSION,PlainsRootBellEncounterV2.CONTENT_VERSION,PlainsRootBellEncounterV3.CONTENT_VERSION]:
			var run_manifest := RunManifest.new(seed_value,RunProfile.formal())
			if not run_manifest.enable_plains_region(content_version):failures.append("region version rejected")
			run_versions.append(run_manifest.snapshot())
			run_manifest.enable_campaign()
			run_versions.append(run_manifest.snapshot())
	for index: int in 12:
		add_case(cases,"generic/"+str(index),RandomStageGenerator.new().generate(("ground-support-%d" % index).hash(),tuning,14,"plains_standard"))
	var foundry: Array = []
	var source_batch: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://resources/foundry/batch.json"))
	var current_phrases: Dictionary = {}
	for item: Dictionary in source_batch.accepted:
		var old: Dictionary = item.manifest
		var value := FoundryCatalog.generate(old.template_id,int(old.variant),int(old.phase_index),old.seed,old.capability_profile)
		if value.is_empty():failures.append("foundry phrase refused "+str(old.id));continue
		current_phrases[value.id]=value
		foundry.append(value)
	for old: Dictionary in source_batch.itineraries:
		var phrases: Array = []
		for phrase: Dictionary in old.phrases:phrases.append(current_phrases[phrase.id])
		var value := FoundryCatalog.itinerary(phrases,old.seed)
		if value.is_empty():failures.append("foundry itinerary refused "+str(old.id));continue
		foundry.append(value)
	var report := {"scope":"actual data-only Plains v10/v2/v3, all recorded forest pins, generic manifests, schema1/2 version construction, Foundry36/18 geometry and independent stream draws; no traversal or user acceptance","engine":Engine.get_version_info().string,"cases":cases,"streams":streams,"run_versions":run_versions,"foundry":foundry,"failures":failures}
	var file := FileAccess.open(output,FileAccess.WRITE)
	if file==null:
		printerr("Cannot write explicit output")
		quit(1)
		return
	file.store_string(JSON.stringify(report,"\t",true)+"\n")
	file.close()
	print("LEGACY RETIRE BASELINE: %d worlds / %d streams / %d failures" % [cases.size(),streams.size(),failures.size()])
	quit(1 if not failures.is_empty() else 0)
