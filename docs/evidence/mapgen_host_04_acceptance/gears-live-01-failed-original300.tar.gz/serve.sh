#!/bin/sh
set -eu
exec python3 -B /tmp/gunman-rush-mapgen-04/tools/mobile_web_perf/serve_coi.py --directory /tmp/mapgen04a-recovery/browser/live/gears-01/site --port 8831
