"""Offline lossless raw-record archive and explicitly transcoded review media."""
import datetime,gzip,hashlib,html,json,shutil,subprocess
from pathlib import Path
SRC=Path('/tmp/plains_world_rebuild');OUT=Path('/workspace/art-direction-exploration/docs/evidence/plains_world_rebuild')
def sha(data):return hashlib.sha256(data).hexdigest()
def read(p):return json.loads(p.read_text())
def media(p):return json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(p)],text=True))
def video_info(m):
 v=next(s for s in m['streams']if s['codec_type']=='video');a=next(s for s in m['streams']if s['codec_type']=='audio');return {'width':v['width'],'height':v['height'],'fps':v['avg_frame_rate'],'frames':int(v['nb_frames']),'duration_seconds':float(m['format']['duration']),'audio_sample_rate':int(a['sample_rate']),'audio_channels':a['channels']}
for f in ['records/raw','frames','movies']:(OUT/f).mkdir(parents=True,exist_ok=True)
# Exclude delivery-owned work, mutable package internals and raw encodings. All
# verification/route on-disk JSON/log originals remain byte-identical in gzip.
files=sorted(f for f in SRC.rglob('*')if f.is_file() and f.suffix in {'.json','.log','.gd','.py'} and 'delivery'not in f.relative_to(SRC).parts)
raw=[]
for f in files:
 rel=f.relative_to(SRC);dst=OUT/'records/raw'/Path(str(rel)+'.gz');dst.parent.mkdir(parents=True,exist_ok=True);data=f.read_bytes();packed=gzip.compress(data,compresslevel=9,mtime=0);dst.write_bytes(packed);restored=gzip.decompress(dst.read_bytes());assert restored==data
 raw.append({'source_path':str(f),'archive':str(dst.relative_to(OUT)),'original_bytes':len(data),'gzip_bytes':len(packed),'original_sha256':sha(data),'gzip_sha256':sha(packed),'decompressed_sha256':sha(restored),'byte_equal_verified':True})
reports=[];known=[]
for f in files:
 if f.name=='report.json':
  r=read(f)
  if r.get('source_commit') and r.get('source_before'):known.append((r['source_before'],r['source_commit']))
for f in files:
 if f.name!='report.json':continue
 r=read(f);folder=f.parent;receipt=read(folder/'frames/receipt.json')if(folder/'frames/receipt.json').exists()else(read(folder/'trace/receipt.json')if(folder/'trace/receipt.json').exists()else{})
 actual_error=None
 try: actual=read(folder/'actual.json')if(folder/'actual.json').exists()else{}
 except (json.JSONDecodeError,UnicodeDecodeError) as exc: actual={};actual_error=str(exc)
 plan=actual.get('source_plan',receipt.get('actual',{}).get('world_plan',{}))
 equivalent=sorted({c for snap,c in known if snap==r.get('source_before')})
 inf=video_info(r['media'])if r.get('media')else None
 reports.append({'run':str(folder.relative_to(SRC)),'status':r.get('status'),'source_commit_recorded':r.get('source_commit')or receipt.get('source_commit')or None,'equivalent_capture_source_commits':equivalent,'equivalence_basis':'Exact complete source_before dictionary equality only; does not rewrite the original producer header','source_snapshot_sha256':sha(json.dumps(r.get('source_before',{}),sort_keys=True,separators=(',',':')).encode()),'source_stable':r.get('source_before')==r.get('source_after'),'elapsed_seconds':r.get('elapsed_seconds'),'variant':r.get('variant',receipt.get('variant',plan.get('variant'))),'root_seed':receipt.get('seed',plan.get('root_seed')),'world_version':plan.get('version'),'assertions':actual.get('assertions'),'actual_parse_error':actual_error,'native_failures':actual.get('failures'),'route':r.get('route',receipt.get('route')),'video':inf,'error':r.get('error'),'raw_report':'records/raw/'+str(f.relative_to(SRC))+'.gz'})
selected=[
('first_start','route_v3_main_02/frames/normal_start.png','第一构造：正常进入、真实角色与风树','97703a8f','normal_game_view'),
('first_landing','route_v3_main_02/frames/normal_waypoint_03.png','第一构造：实际落岸，角色完整可见','97703a8f','normal_game_view'),
('first_shelter','route_v3_main_02/frames/normal_waypoint_04.png','第一构造：棚屋与末端正常镜头，不把未连接外延暴露为场景','97703a8f','normal_game_view'),
('first_combat','route_v3_main_02/combat_frame_02.png','第一构造：实际战斗，视频第350帧 / 5.833秒','97703a8f','actual_movie_frame'),
('second_valley','route_layout1_main_01/frames/normal_waypoint_03.png','第二构造：同四图源，西高东低120，溪床成为主路','ba787df7','normal_game_view'),
('second_climb','route_layout1_main_01/frames/normal_waypoint_04.png','第二构造：由溪床实际攀上东岸','ba787df7','normal_game_view'),
('second_end','route_layout1_main_01/frames/normal_waypoint_05.png','第二构造：末端棚屋与地貌连续性','ba787df7','normal_game_view'),
('second_combat','route_layout1_main_01/combat_frame_02.png','第二构造：实际战斗，视频第480帧 / 8.0秒','ba787df7','actual_movie_frame'),
('negative_v1','route_01/frames/normal_waypoint_03.png','v1负例：将源画归一到独立岸体造成拉伸、草带截断','e76e5c24','normal_game_view'),
('negative_v2','route_lower_02/frames/normal_waypoint_02.png','v2负例：UV合法仍出现竖向接缝、平切上缘与角色遮挡','5871a02b','normal_game_view'),
('negative_actor_occlusion','route_v3_lower_01/frames/normal_waypoint_06.png','v3早期负例：原图画法改善，但角色被同深度后绘草缘遮挡','9052f62e','normal_game_view'),
('negative_exposed_edge','route_v3_main_01/frames/normal_waypoint_04.png','v3负例：未连接外延接口进入正常相机，右侧出现全深竖切','cf9f152e','normal_game_view')]
frames=[]
for name,relative,caption,commit,kind in selected:
 src=SRC/relative;dst=OUT/'frames'/(name+'.png');shutil.copyfile(src,dst);assert dst.read_bytes()==src.read_bytes();frames.append({'id':name,'path':str(dst.relative_to(OUT)),'caption':caption,'source_commit':commit,'kind':kind,'original_path':str(src),'sha256':sha(dst.read_bytes()),'bytes':dst.stat().st_size})
movies=[]
for name,original,review,commit,variant in [('layout0','route_v3_main_02/gameplay.mp4','layout0_review.mp4','97703a8ff4ca9a86c7fb92ff2d182d0595ffce96',0),('layout1','route_layout1_main_01/gameplay.mp4','layout1_review.mp4','ba787df7261dba40f75409a3b99457dd9bbef985',1)]:
 original=SRC/original;review=SRC/review;orig_info=video_info(media(original));info=video_info(media(review));assert info==orig_info,(info,orig_info);assert info['fps']=='60/1'and info['width']==1280 and info['height']==720 and info['audio_sample_rate']==48000 and info['audio_channels']==2;assert review.stat().st_size<15_000_000
 dst=OUT/'movies'/(name+'_review.mp4');shutil.copyfile(review,dst);assert dst.read_bytes()==review.read_bytes();movies.append({'id':name,'variant':variant,'source_commit':commit,'path':str(dst.relative_to(OUT)),'kind':'complete_normal_speed_review_transcode_not_original_encoding','media':info,'original_path':str(original),'original_bytes':original.stat().st_size,'original_sha256':sha(original.read_bytes()),'review_bytes':dst.stat().st_size,'review_sha256':sha(dst.read_bytes()),'transcode':'ffmpeg libx264 medium crf25 yuv420p; audio bitstream copied; original untouched','frame_count_and_clock_verified_equal':True,'full_playback':'unverified','actual_listening':'unverified'})
idx={'schema_version':1,'generated_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Real Godot evidence of two explicit source-painted construction layouts, not a complete random region, all-Seed admission, user style acceptance, market or device validation','raw_byte_preservation':'Every listed on-disk original is gzip archived; decompressed bytes and SHA were checked. Missing producer fields are null, never reconstructed. Delivery work is separately owned under ../delivery/.','comparison_limits':'v1/v2/v3 changed physical geometry, painting and camera. Images are method/experience comparisons, not same-pixel registered before/after. Layout0 movie remains 97703a8f; layout1 remains ba787df7.','source_commit_policy':'source_commit_recorded is copied from a producer header or is null. Equivalent capture commits require exact complete source fingerprint equality and do not alter old headers.','media_limits':'Review MP4s are explicitly transcoded copies. Full source movies remain /tmp. All original logs/receipts retain source hashes. Screenshot viewing and selected video-frame inspection occurred; complete playback and actual listening did not.','runs':reports,'raw_records':raw,'frames':frames,'movies':movies,'totals':{'raw_original_bytes':sum(x['original_bytes']for x in raw),'raw_gzip_bytes':sum(x['gzip_bytes']for x in raw),'raw_record_count':len(raw),'selected_frame_count':len(frames),'selected_frame_bytes':sum(x['bytes']for x in frames),'review_movie_bytes':sum(x['review_bytes']for x in movies)}}
(OUT/'records/index.json').write_text(json.dumps(idx,ensure_ascii=False,indent=2)+'\n')
# Small source-first gallery; plain files, no generated artwork or scoring UI.
def cards(items):
 return ''.join('<figure><a href="'+f['path']+'"><img loading="lazy" src="'+f['path']+'" alt="'+html.escape(f['caption'])+'"></a><figcaption>'+html.escape(f['caption'])+' · '+f['source_commit']+' · '+('正常录像抽帧'if f['kind']=='actual_movie_frame'else'真实Godot正常镜头')+'</figcaption></figure>'for f in items)
text='''<!doctype html><html lang="zh"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>风铃平原：源绘画构造的两次实机验证</title><style>body{font:16px/1.6 system-ui,sans-serif;background:#f2efe6;color:#282c2a;max-width:1320px;margin:32px auto;padding:0 20px}h1,h2{line-height:1.25}figure{margin:24px 0}img,video{display:block;width:100%;height:auto;background:#182024}figcaption{padding:8px 0;font-size:14px;color:#444}a{color:#265c65}table{border-collapse:collapse;width:100%}td,th{border:1px solid #bdbbae;padding:8px;text-align:left}.note{padding:12px 16px;background:#e4e9df}.grid{display:grid;grid-template-columns:1fr 1fr;gap:20px}@media(max-width:800px){.grid{grid-template-columns:1fr}}</style><h1>风铃平原：先看真实作品</h1><p>同一组四张源画，用完整岸体的源像素、等比变换与接触轮廓共同产生碰撞和画面；没有把整屏概念图烘焙为背景，也没有为第二布局重画图片。独审给予有限内部准入，不代表用户最终画风、商业品质或完整随机区域已获认可。</p><p class="note">本页只有真实Godot正常镜头和明确标注的正常录像抽帧。旧新方案重设了几何与镜头，不能作像素同位前后比较。完整播放、实际听音、真人和设备验证均未完成。</p><h2>第一构造：双岸裂谷与棚屋</h2>'''+cards(frames[:4])+'''<h2>第二构造：同四源画，宽溪床成为主路</h2><p>两岸相对高差从0变为120；主路线先下溪床再攀岸，区别于第一构造的上缘跨越。它是第二个显式注册布局，不是多个随机Seed的品质证明。</p>'''+cards(frames[4:8])+'''<h2>完整正常速度录像</h2><p>下列是体积较小的评审转码副本；1280×720、60fps、原帧数/时长与48kHz双声道已逐一核对。原片未改，原片与副本SHA均在记录索引。</p><div class="grid">'''
for movie,poster in zip(movies,['first_start','second_valley']):
 text+='<figure><video controls preload="metadata" poster="frames/'+poster+'.png" src="'+movie['path']+'"></video><figcaption>构造'+str(movie['variant'])+' · '+movie['source_commit'][:8]+' · '+str(movie['media']['frames'])+'帧 / '+str(movie['media']['duration_seconds'])+'秒 · 完整路线评审副本</figcaption></figure>'
text+='''</div><table><tr><th>实机路线</th><th>实际观测</th><th>范围</th></tr><tr><td>第一构造 main</td><td>1003 tick、9点、3次正常战斗射击接受、HP5/5</td><td>97703a8f，17.2秒正常片</td></tr><tr><td>第二构造 main</td><td>1347 tick、11点、9次射击接受、HP5/5</td><td>ba787df7，22.966667秒正常片</td></tr><tr><td>工程</td><td>第一124、第二138、原模块1310项通过</td><td>不替代艺术、用户、设备或正式CI验收</td></tr></table><h2>保留的失败：方法确实换过</h2><p>这些负例保持原始像素与原版本，不因为后续修复改标。v3源画法仍经过角色层级、相机对未连接接口的约束修正；未连接接口没有冒充已连接世界。</p>'''+cards(frames[8:])+'''<h2>证据与限制</h2><p><a href="records/index.json">完整索引：每轮状态、实际耗时、记录到的版本、源指纹、原件gzip与SHA</a> · <a href="independent-art-03.md">第一构造独审</a> · <a href="independent-art-04.md">第二构造独审</a></p><p>原始失败、JSON数值复现、入口安全查询、源图/碰撞绑定和1310回归原日志均可从索引恢复。尚未验证完整区域拓扑、跨模块外延连接、随机Seed总体品质、真人手感、实体设备性能或市场认可。</p></html>'''
(OUT/'gallery.html').write_text(text)
print(json.dumps(idx['totals'],ensure_ascii=False));print(OUT/'records/index.json');print(OUT/'gallery.html')
