"""Preserve original branch Motor assertions using the existing strict native host."""
import sys,json,time,re,fcntl,subprocess,hashlib
from pathlib import Path
ROOT=Path('/workspace/art-direction-exploration');sys.path.insert(0,str(ROOT/'tools'))
from level_formal import source_files
from run_plains_joint_recoil_tests import logged_engine
from run_root_bell_ecology import godot_lock_path
from run_plains_world_rebuild_tests import EXTRA
p=Path(sys.argv[1]);p.mkdir(exist_ok=False);start=time.monotonic();r={'status':'failed','source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'scope':'Original unmodified branch-library real Motor normal/reflected routes and no-shot negatives; not art or complete CI','host_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()};args=['--headless','--fixed-fps','60','--path','.','--script','tests/branch_library_runner.gd'];r['command']=['bash','tools/godot.sh',*args]
with godot_lock_path(ROOT).open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX);before=source_files(EXTRA);r['source_before']=before
 try:
  out=logged_engine(args,540,p/'native.log')
  if not re.search(r'^BRANCH LIBRARY: 1310 assertions, 0 failures$',out,re.M):raise RuntimeError('Original 1310 completion missing')
  if re.search(r'(?m)^\s*(ERROR:|SCRIPT ERROR:|Parse Error:|SHADER ERROR:)',out):raise RuntimeError('Native error')
  if source_files(EXTRA)!=before:raise RuntimeError('Source changed')
  r['status']='passed'
 except Exception as exc:
  r['error']=str(exc);raise
 finally:
  r['source_after']=source_files(EXTRA);r['elapsed_seconds']=time.monotonic()-start;(p/'report.json').write_text(json.dumps(r,indent=2)+'\n');print(p/'report.json')
